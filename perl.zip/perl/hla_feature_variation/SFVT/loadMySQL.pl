#!/usr/bin/perl -w
################################################################################
###
### loadMySQL.pl
###
################################################################################

################################################################################
###
### Libraries
###
################################################################################

use strict;

use Carp 'cluck', 'confess';
use Cwd 'chdir';
use File::Basename;
use FileHandle;
use Getopt::Long;
use POSIX;

################################################################################
###
### Constants
###
################################################################################

sub SINGLE_QUOTE    { return "'"; }
sub APPEND_MODE     { return '>>'; }
sub ASSIGN          { return '=>'; }
sub CLOSE_PAREN     { return '}'; }
sub COMMA_SEPARATOR { return ', '; }
sub CTRL_M          { return ""; }
sub DOT             { return '.'; }
sub EMPTY_STR       { return ''; }
sub EQUALS          { return '='; }
sub EXCEL_SUFFIX    { return 'xls'; }
sub FALSE           { return 0; }
sub LOG             { return 'log'; }
sub NEW_LINE        { return "\n"; }
sub OPEN_PAREN      { return '{'; }
sub READ_MODE       { return '<'; }
sub SEMI_COLON      { return ' ; '; }
sub SEPARATOR       { return '::'; }
sub SLASH           { return '/'; }
sub SPACE           { return ' '; }
sub TAB             { return "\t"; }
sub TRUE            { return 1; }
sub TXT_SUFFIX      { return "txt"; }
sub WHITE_SPACE     { return '\s+'; }
sub WRITE_MODE      { return '>'; }

sub DEFINED {
  my ($str) = @_;
  return ( defined($str) && $str ne EMPTY_STR ) ? TRUE : FALSE;
}

################################################################################
###
### Constants
###
################################################################################
###
### Standard Properties
###
sub stdPropertiesFile { return 'loadMySQL.std.properties'; }

sub bcpDirectory            { return 'bcpDirectory'; }
sub databaseName            { return 'databaseName'; }
sub dbConfigFile            { return 'dbConfigFile'; }
sub exportCommand           { return 'exportCommand'; }
sub headerMessage           { return 'headerMessage'; }
sub logInfix                { return 'logInfix'; }
sub mySQLCreateScript       { return 'mySQLCreateScript'; }
sub mySQLTool               { return 'mySQLTool'; }
sub propertiesFile          { return 'propertiesFile'; }
sub schemaOwner             { return 'schemaOwner'; }
sub serverName              { return 'serverName'; }
sub softwareDirectories     { return 'softwareDirectories'; }
sub templateProperties      { return 'templateProperties'; }
sub uploadTool              { return 'uploadTool'; }
sub useControlledVocabulary { return 'useControlledVocabulary'; }
sub workspaceRoot           { return 'workspaceRoot'; }

sub skipStandardProperties {
  return {
    &databaseName        => EMPTY_STR,
    &exportCommand       => EMPTY_STR,
    &mySQLCreateScript   => EMPTY_STR,
    &mySQLTool           => EMPTY_STR,
    &propertiesFile      => EMPTY_STR,
    &schemaOwner         => EMPTY_STR,
    &serverName          => EMPTY_STR,
    &softwareDirectories => EMPTY_STR,
    &templateProperties  => EMPTY_STR,
    &uploadTool          => EMPTY_STR,
  };
}
###
### Run Properties
###
### Always Required
###
sub executionDirectory { return 'executionDirectory'; }
sub optDirectory       { return 'optDirectory'; }
sub userName           { return 'userName'; }
sub password           { return 'password'; }
###
### Optional
###
sub debugSwitch { return 'debugSwitch'; }

sub skipRunProperties {
  return {
    &optDirectory => EMPTY_STR,
    &password     => EMPTY_STR,
    &userName     => EMPTY_STR,
  };
}
###
### Default Values
###
sub debugSwitchDefault { return '0'; }

###
### Other Properties
###
sub runScript { return 'run.sh'; }

################################################################################
###
### Program Constants
###
################################################################################

chdir(DOT);
my $EXEC_DIR     = $ENV{PWD};
my $PROGRAM_NAME = basename($0);
my $PROGRAM_DIR  = dirname($0);
my $HOSTNAME     = `hostname`;
chomp($HOSTNAME);

STDERR->autoflush(TRUE);    ### Make unbuffered
STDOUT->autoflush(TRUE);    ### Make unbuffered
select STDOUT;

my $CMD_MSG = "";

################################################################################
###
### Local Functions
###
################################################################################

sub _cmdMsg {
  my $msgs = [ split( /\n/, $CMD_MSG ) ];
  return $msgs;
}

sub _dieOnError {
  my ( $err, $msgs ) = @_;
  return if ( !$err );
  print $PROGRAM_NAME . NEW_LINE;
  my $emsgs = [];
  foreach my $msg ( @{$msgs} ) {
    push( @{$emsgs}, 'ERROR:  ' . $msg );
  }
  _printMsg($emsgs);
  cluck;
  POSIX::_exit(2);
}

sub _printMsg {
  my ($msgs) = @_;
  print join( NEW_LINE, @{$msgs}, EMPTY_STR );
}

sub _makeAbsolute {
  my ($file) = @_;
  if ( $file !~ /^\// ) {
    $file = join( SLASH, $EXEC_DIR, $file );
  }
  return $file;
}

sub _getProperties {
  my ($file) = @_;
  _dieOnError( !-e $file || !-r $file || $file !~ /\.properties$/,
    ['Properties File in NOT accessible'] );
  my $properties     = {};
  my $row_num        = 0;
  my $start_property = TRUE;
  my $whitespace     = WHITE_SPACE;
  my $fh             = new FileHandle;
  $fh->open( $file, READ_MODE );
  my $property;
  my $value;

  while ( !$fh->eof ) {
    my $input_line = $fh->getline;
    chomp($input_line);
    $row_num++;
    if ($start_property) {
      next
        if ( $input_line eq EMPTY_STR
        || $input_line =~ /^$whitespace$/
        || $input_line =~ /^#/ );
      $start_property = ( $input_line !~ /\\$/ );
      $input_line =~ s/\\$//;
      if ( $input_line =~ /^(.+?)=(.*)$/ ) {
        $property = $1;
        $value    = $2;
      }
      else {
        _dieOnError( TRUE,
          ["input_line ($row_num) = '$input_line' has incorrect format"] );
      }
    }
    else {
      $start_property = ( $input_line !~ /\\$/ );
      $input_line =~ s/\\$//;
      $value .= NEW_LINE . $input_line;
    }
    if ($start_property) {
      $properties->{$property} = $value;
    }
  }
  $fh->close;
  return $properties;
}

################################################################################
###
### Parameters
###
################################################################################

$CMD_MSG = "
$PROGRAM_NAME --propertiesFile PROPERTIES_FILE (--help)
This tool uploads bcp file data for the mysql database mhc_seq_var
help           -- This help message
propertiesFile -- File containing the properties for a given pipeline run:
  Required Properties:
    executionDirectory  -- The path of the directory in which the tool is
                           executed.  The path is either absolute or relative to
                           directory in which the this tool is running.  The
                           directory path cannot have any space characters in it.
    optDirectory        -- Absolute path for the 'opt' directory.  This is the
                           directory into which the installation for SFVT has
                           been installed, normally located in the your home
                           root directory e.g., /home/tsmith/opt
    userName            -- User name for MySQL server
    password            -- Password for MySQL server
  Optional Properties:
    debugSwitch         -- The debug switch, either 0 (FALSE) or 1 (TRUE)
                           (default = 0)
";

my $propertiesFile = EMPTY_STR;
my $help           = undef;

GetOptions(
  'propertiesFile=s' => \$propertiesFile,
  'help!'            => \$help,
) or _dieOnError( TRUE, _cmdMsg );

if ($help) {
  _printMsg(_cmdMsg);
  POSIX::_exit(0);
}
_dieOnError( !DEFINED($propertiesFile), _cmdMsg );
###
### Standard Properties
###
my $stdPropertiesFile = join( SLASH, $PROGRAM_DIR, stdPropertiesFile );
my $stdProperties = _getProperties($stdPropertiesFile);
###
### Run Properties
###
my $runProperties = _getProperties($propertiesFile);
###
### Check Run Properties
###
my $executionDirectory = $runProperties->{&executionDirectory};
_dieOnError( !DEFINED($executionDirectory),
  ["executionDirectory property is NOT defined"] );
$runProperties->{&executionDirectory} = _makeAbsolute($executionDirectory);
_dieOnError( ( $executionDirectory =~ / / ) ? TRUE : FALSE,
  ["Execution directory contains spaces in its path ($executionDirectory)"] );
###
### Creating execution directory, if necessary
###
system("mkdir -m 777 -p '$executionDirectory'");
my $status = $?;
_dieOnError( DEFINED($status) && $status,
  ["Failed to create executionDirectory = $executionDirectory"] );

_dieOnError(
  !DEFINED( $runProperties->{&optDirectory} ),
  ["optDirectory property is NOT defined"]
);
_dieOnError( !-d $runProperties->{&optDirectory},
  ["optDirectory does not exist"] );

_dieOnError( !DEFINED( $runProperties->{&userName} ),
  ["MySQL Database server userName property is NOT defined"] );

_dieOnError( !DEFINED( $runProperties->{&password} ),
  ["MySQL Database server password property is NOT defined"] );

if ( !DEFINED( $runProperties->{&debugSwitch} ) ) {
  $runProperties->{&debugSwitch} = debugSwitchDefault;
}
_dieOnError(
  $runProperties->{&debugSwitch} ne FALSE
    && $runProperties->{&debugSwitch} ne TRUE,
  ["debugSwitch property neither 0 nor 1"]
);

_printMsg( [ "Run Properties Validated!", ] );
###
### Process Templates for Standard Properties
###
_printMsg( ["Substituting Template Values..."] );
my $templateProperties = eval $stdProperties->{&templateProperties};
$status = $@;
_dieOnError( DEFINED($status) && $status,
  ["Failed to eval templateProperties"] );

foreach my $property ( keys %{$templateProperties} ) {
  my $data        = $templateProperties->{$property};
  my $value       = $runProperties->{$property};
  my $substitutor = $data->{substitutor};
  _printMsg( ["  ($property, $value, $substitutor)"] );
  foreach my $prop ( @{ $data->{properties} } ) {
    _printMsg( [ "    $prop (before) = " . $stdProperties->{$prop} ] );
    $stdProperties->{$prop} =~ s/$substitutor/$value/g;
    _printMsg( [ "    $prop (after)  = " . $stdProperties->{$prop} ] );
  }
}
###
### Create dbConfigFile
###
my $dfh = new FileHandle;
$dfh->open( $stdProperties->{&dbConfigFile}, WRITE_MODE );
$dfh->print( join( TAB, 'Server', $stdProperties->{&serverName} ) . NEW_LINE );
$dfh->print(
  join( TAB, 'Database', $stdProperties->{&databaseName} ) . NEW_LINE );
$dfh->print( join( TAB, 'Username', $runProperties->{&userName} ) . NEW_LINE );
$dfh->print( join( TAB, 'Password', $runProperties->{&password} ) . NEW_LINE );
$dfh->print(
  join( TAB, 'SchemaOwner', $stdProperties->{&schemaOwner} ) . NEW_LINE );
$dfh->close;
###
### Create Properties File
###
my $thePropertiesFile = $stdProperties->{&propertiesFile};
my $pfh               = new FileHandle;
$pfh->open( $thePropertiesFile, WRITE_MODE );
###
### Add Run Properties
###
my $skipRunProperties = skipRunProperties;

foreach my $property ( sort keys %{$runProperties} ) {
  next if ( defined( $skipRunProperties->{$property} ) );
  my $value = $runProperties->{$property};
  if ( !DEFINED($value) ) {
    $value = EMPTY_STR;
  }
  $pfh->print( join( EQUALS, $property, $value ) . NEW_LINE );
}
###
### Add Standard Properties
###
my $skipStandardProperties = skipStandardProperties;
foreach my $property ( sort keys %{$stdProperties} ) {
  next if ( defined( $skipStandardProperties->{$property} ) );
  $pfh->print(
    join( EQUALS, $property, $stdProperties->{$property} ) . NEW_LINE );
}

$pfh->close;
###
### Create MySQL Database
###
my $createCmd = join( SPACE,
  $stdProperties->{&mySQLTool},
  '--user=' . $runProperties->{&userName},
  '--password=' . $runProperties->{&password},
  '<',
  $stdProperties->{&mySQLCreateScript} );
_printMsg( ["create cmd = $createCmd"] );
system($createCmd);
$status = $?;
_dieOnError( DEFINED($status) && $status, ["Create MySQL database failed."] );
###
### Run the tool
###
my $runScript = join( SLASH, $executionDirectory, runScript );
my $rfh = new FileHandle;
$rfh->open( $runScript, WRITE_MODE );
my $cmd = join(
  NEW_LINE,
  '#!/bin/bash',
  join( SPACE,
    'source',
    $stdProperties->{&exportCommand},
    split( /;/, $stdProperties->{&softwareDirectories} ) ),
  join( SPACE, $stdProperties->{&uploadTool}, '-P', $thePropertiesFile ),
  EMPTY_STR
);
$rfh->print($cmd);
$rfh->close;
system("chmod 777 $runScript");
_printMsg( ["runScript cmd = $cmd"] );
system("$runScript");

POSIX::_exit(0);
