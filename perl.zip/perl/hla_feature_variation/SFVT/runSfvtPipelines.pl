#!/usr/bin/perl -w
################################################################################
###
### runSfvtPipelines.pl
###
###
################################################################################

################################################################################
###
### Libraries
###
################################################################################

use strict;

use Carp 'cluck', 'confess';
use Cwd 'chdir';
use File::Basename;
use File::Find ();
use FileHandle;
use Getopt::Long;
use POSIX;
###
### for the convenience of &wanted calls,
### including -eval statements:
###
use vars qw(*FIND_NAME
  *FIND_DIR
  *FIND_PRUNE);
*FIND_NAME  = *File::Find::name;
*FIND_DIR   = *File::Find::dir;
*FIND_PRUNE = *File::Find::prune;

################################################################################
###
### Constants
###
################################################################################

sub SINGLE_QUOTE    { return "'"; }
sub APPEND_MODE     { return '>>'; }
sub ASSIGN          { return '=>'; }
sub CLOSE_PAREN     { return '}'; }
sub COMMA_SEPARATOR { return ', '; }
sub CTRL_M          { return ""; }
sub DOT             { return '.'; }
sub EMPTY_STR       { return ''; }
sub EQUALS          { return '='; }
sub EXCEL_SUFFIX    { return 'xls'; }
sub FALSE           { return 0; }
sub LOG             { return 'log'; }
sub NEW_LINE        { return "\n"; }
sub OPEN_PAREN      { return '{'; }
sub READ_MODE       { return '<'; }
sub SEMI_COLON      { return ' ; '; }
sub SEPARATOR       { return '::'; }
sub SLASH           { return '/'; }
sub SPACE           { return ' '; }
sub TAB             { return "\t"; }
sub TRUE            { return 1; }
sub TXT_SUFFIX      { return "txt"; }
sub WHITE_SPACE     { return '\s+'; }
sub WRITE_MODE      { return '>'; }

sub DEFINED {
  my ($str) = @_;
  return ( defined($str) && $str ne EMPTY_STR ) ? TRUE : FALSE;
}

################################################################################
###
### Constants
###
################################################################################
###
### Standard Properties
###
sub stdPropertiesFile { return 'runSfvtPipelines.std.properties'; }

sub analysisFile        { return 'analysisFile'; }
sub databaseName        { return 'databaseName'; }
sub dbConfigFile        { return 'dbConfigFile'; }
sub exportCommand       { return 'exportCommand'; }
sub fileTypeFile        { return 'fileTypeFile'; }
sub imgtReleaseDate     { return 'imgtReleaseDate'; }
sub imgtReleaseVersion  { return 'imgtReleaseVersion'; }
sub pipelineTool        { return 'pipelineTool'; }
sub propertiesFile      { return 'propertiesFile'; }
sub schemaOwner         { return 'schemaOwner'; }
sub serverName          { return 'serverName'; }
sub softwareDirectories { return 'softwareDirectories'; }
sub templateProperties  { return 'templateProperties'; }
sub toolNameVersion     { return 'toolNameVersion'; }

sub skipStandardProperties {
  return {
    &analysisFile        => EMPTY_STR,
    &databaseName        => EMPTY_STR,
    &exportCommand       => EMPTY_STR,
    &pipelineTool        => EMPTY_STR,
    &propertiesFile      => EMPTY_STR,
    &schemaOwner         => EMPTY_STR,
    &serverName          => EMPTY_STR,
    &softwareDirectories => EMPTY_STR,
    &templateProperties  => EMPTY_STR,
    &toolNameVersion     => EMPTY_STR,
  };
}
###
### Run Properties
###
### Always Required
###
sub executionDirectory { return 'executionDirectory'; }
sub hlaAlleleFile      { return 'hlaAlleleFile'; }
sub optDirectory       { return 'optDirectory'; }
sub pipelineType       { return 'pipelineType'; }
sub taskId             { return 'taskId'; }
sub userName           { return 'userName'; }
sub password           { return 'password'; }
###
### Required for hlaqc
###
sub pypop { return 'pypop'; }
###
### Required for hlava
###
sub hlaLoci             { return 'hlaLoci'; }
sub phenotypeColumn     { return 'phenotypeColumn'; }
sub vectorFileDirectory { return 'vectorFileDirectory'; }
###
### Optional
###
sub debugSwitch       { return 'debugSwitch'; }
sub outputImgtVersion { return 'outputImgtVersion'; }

sub skipRunProperties {
  return {
    &hlaLoci             => EMPTY_STR,
    &optDirectory        => EMPTY_STR,
    &pypop               => EMPTY_STR,
    &password            => EMPTY_STR,
    &userName            => EMPTY_STR,
    &vectorFileDirectory => EMPTY_STR,
  };
}

sub HLAVF_TYPE { return 'hlavf'; }
sub HLAQC_TYPE { return 'hlaqc'; }
sub HLAVD_TYPE { return 'hlavd'; }
sub HLAVT_TYPE { return 'hlavt'; }
sub HLAVA_TYPE { return 'hlava'; }

sub pipelineTypes {
  return {
    &HLAVF_TYPE => EMPTY_STR,
    &HLAQC_TYPE => EMPTY_STR,
    &HLAVD_TYPE => EMPTY_STR,
    &HLAVT_TYPE => EMPTY_STR,
    &HLAVA_TYPE => EMPTY_STR,
  };
}
###
### Default Values
###
sub debugSwitchDefault { return '0'; }

sub outputImgtVersion2       { return '2'; }
sub outputImgtVersionDefault { return '3'; }
###
### Other Properties
###
sub headerMessage     { return 'headerMessage'; }
sub hlaAlleleFileType { return 'hlaAlleleFileType'; }
sub toolName          { return 'toolName'; }
sub toolVersion       { return 'toolVersion'; }

sub runScript { return 'run.sh'; }

################################################################################
###
### Program Constants
###
################################################################################

chdir(DOT);
my $EXEC_DIR     = $ENV{PWD};
my $PROGRAM_NAME = basename($0);
my $PROGRAM_DIR  = dirname($0);
my $HOSTNAME     = `hostname`;
chomp($HOSTNAME);

STDERR->autoflush(TRUE);    ### Make unbuffered
STDOUT->autoflush(TRUE);    ### Make unbuffered
select STDOUT;

my $CMD_MSG = "";

################################################################################
###
### Global Variables
###
################################################################################

my @_FILES_   = ();
my $_PATTERN_ = undef;

################################################################################
###
### Local Functions
###
################################################################################

sub _filesWanted {
  my ( $dev, $ino, $mode, $nlink, $uid, $gid );

  ( ( $dev, $ino, $mode, $nlink, $uid, $gid ) = lstat($_) )
    && -f _
    && /^$_PATTERN_$/s
    && push( @_FILES_, $FIND_NAME );
}

sub _pipelineTypeDefined {
  my ($type) = @_;
  my $pipelineTypes = pipelineTypes;
  return ( !defined( $pipelineTypes->{$type} ) ) ? FALSE : TRUE;
}

sub _validPipelineTypes {
  my ($type) = @_;
  my $pipelineTypes = pipelineTypes;
  return sort keys %{$pipelineTypes};
}

sub _cmdMsg {
  my $msgs = [ split( /\n/, $CMD_MSG ) ];
  return $msgs;
}

sub _dieOnError {
  my ( $err, $msgs ) = @_;
  return if ( !$err );
  print $PROGRAM_NAME . NEW_LINE;
  my $emsgs = [];
  foreach my $msg ( @{$msgs} ) {
    push( @{$emsgs}, 'ERROR:  ' . $msg );
  }
  _printMsg($emsgs);
  cluck;
  POSIX::_exit(2);
}

sub _printMsg {
  my ($msgs) = @_;
  print join( NEW_LINE, @{$msgs}, EMPTY_STR );
}

sub _makeAbsolute {
  my ($file) = @_;
  if ( $file !~ /^\// ) {
    $file = join( SLASH, $EXEC_DIR, $file );
  }
  return $file;
}

sub _getProperties {
  my ($file) = @_;
  _dieOnError( !-e $file || !-r $file || $file !~ /\.properties$/,
    ['Properties File in NOT accessible'] );
  my $properties     = {};
  my $row_num        = 0;
  my $start_property = TRUE;
  my $whitespace     = WHITE_SPACE;
  my $fh             = new FileHandle;
  $fh->open( $file, READ_MODE );
  my $property;
  my $value;

  while ( !$fh->eof ) {
    my $input_line = $fh->getline;
    chomp($input_line);
    $row_num++;
    if ($start_property) {
      next
        if ( $input_line eq EMPTY_STR
        || $input_line =~ /^$whitespace$/
        || $input_line =~ /^#/ );
      $start_property = ( $input_line !~ /\\$/ );
      $input_line =~ s/\\$//;
      if ( $input_line =~ /^(.+?)=(.*)$/ ) {
        $property = $1;
        $value    = $2;
      }
      else {
        _dieOnError( TRUE,
          ["input_line ($row_num) = '$input_line' has incorrect format"] );
      }
    }
    else {
      $start_property = ( $input_line !~ /\\$/ );
      $input_line =~ s/\\$//;
      $value .= NEW_LINE . $input_line;
    }
    if ($start_property) {
      $properties->{$property} = $value;
    }
  }
  $fh->close;
  return $properties;
}

################################################################################
###
### Parameters
###
################################################################################

$CMD_MSG = "
$PROGRAM_NAME --propertiesFile PROPERTIES_FILE (--help)
help           -- This help message
propertiesFile -- File containing the properties for a given pipeline run:
  Required Properties:
    executionDirectory  -- The path of the directory in which the tool is
                           executed and all the logs and results are writtern.
                           The path is either absolute or relative to directory
                           in which the this tool is running.  The directory path
                           cannot have any space characters in it.
    taskId              -- Numeric identifier (e.g., 123) for pipeline run files
                           in the executionDirectory
    pipelineType        -- The type of the pipeline.  One of the following:
                             hlavf - validate the input file only
                             hlaqc - validate and run pypop tool pipeline
                             hlavd - validate and run the ambiguity reduction
                                     pipeline
                             hlavt - validate and generate sfvt vector files
                             hlava - analyze sfvt vector file(s) generated by 
                                     hlavt
    optDirectory        -- Absolute path for the 'opt' directory.  This is the
                           directory into which the installation for SFVT has
                           been installed, normally located in the your home
                           root directory e.g., /home/tsmith/opt
    hlaAlleleFile       -- For all pipeline types, you must provide the allele
                           file path to process.  In the case of hlava, it was
                           the file from which the vector files were generated.
                           The file path can be absolute or relative to the
                           directory in which this tool is currently executing.
                           This file is either a tab-separated text file (.txt)
                           or an Excel spreadsheet (.xls).  If the basename of
                           the file path has space characters, then spaces will
                           be replaced with underscores.  This file is copied
                           into executionDirectory for processing.  The HLA file
                           content type can be 'HLA Typing' (ImmPort template
                           file HLA_Typing.txt), Pypop (pypop-guide.pdf), or
                           Custom.
    userName            -- User name for MySQL server
    password            -- Password for MySQL server
  Required Based on pipelineType:
    pypop               -- For pipeline type hlaqc, the location of the pypop
                           tool.  Using the standard installation, this tool
                           file will be located at:
                             /usr/bin/pypop

    hlaLoci             -- For pipeline type hlava, you must provide a
                           semi-colon separated list of HLA loci to analyze
                           (e.g., HLA-A;HLA-DBA)
    vectorFileDirectory -- For pipeline type hlava, you must provide the absolute
                           path to the directory containing the vector files for
                           the HLA loci in the hlaLoci property that were
                           previously generated using the hlavt pipeline.
    phenotypeColumn     -- For pipeline type hlava, you must provide the column
                           name in the vector files that specifies the phenotype
                           to analyze.  This column must appear in the original
                           input file for the hlavt generation
  Optional Properties:
    outputImgtVersion   -- The out version of the alleles in the generated files,
                           either IMGT/HLA version 2 or IMGT/HLA 3 (default = 3)
    debugSwitch         -- The debug switch, either 0 (FALSE) or 1 (TRUE)
                           (default = 0)
";

my $propertiesFile = EMPTY_STR;
my $help           = undef;

GetOptions(
  'propertiesFile=s' => \$propertiesFile,
  'help!'            => \$help,
) or _dieOnError( TRUE, _cmdMsg );

if ($help) {
  _printMsg(_cmdMsg);
  POSIX::_exit(0);
}
_dieOnError( !DEFINED($propertiesFile), _cmdMsg );
###
### Standard Properties
###
my $stdPropertiesFile = join( SLASH, $PROGRAM_DIR, stdPropertiesFile );
my $stdProperties = _getProperties($stdPropertiesFile);
###
### Run Properties
###
my $runProperties = _getProperties($propertiesFile);
###
### Check Run Properties
###
my $executionDirectory = $runProperties->{&executionDirectory};
_dieOnError( !DEFINED($executionDirectory),
  ["executionDirectory property is NOT defined"] );
$runProperties->{&executionDirectory} = _makeAbsolute($executionDirectory);
_dieOnError( ( $executionDirectory =~ / / ) ? TRUE : FALSE,
  ["Execution directory contains spaces in its path ($executionDirectory)"] );
###
### Creating execution directory, if necessary
###
system("mkdir -m 777 -p '$executionDirectory'");
my $status = $?;
_dieOnError( DEFINED($status) && $status,
  ["Failed to create executionDirectory = $executionDirectory"] );

_dieOnError(
  !DEFINED( $runProperties->{&optDirectory} ),
  ["optDirectory property is NOT defined"]
);
_dieOnError( !-d $runProperties->{&optDirectory},
  ["optDirectory does not exist"] );

my $pipelineType = $runProperties->{&pipelineType};
_dieOnError( !DEFINED($pipelineType),
  ["pipelineType property is NOT defined"] );
_dieOnError( !_pipelineTypeDefined($pipelineType),
  ["pipelineType property ($pipelineType) not a valid value:  "]
  . join( COMMA_SEPARATOR, _validPipelineTypes ) );

_dieOnError( !DEFINED( $runProperties->{&taskId} ),
  ["taskId property is NOT defined"] );
_dieOnError(
  $runProperties->{&taskId} !~ /^\d+$/,
  ["taskId property is not a positive integer"]
);

_dieOnError( !DEFINED( $runProperties->{&userName} ),
  ["MySQL Database server userName property is NOT defined"] );

_dieOnError( !DEFINED( $runProperties->{&password} ),
  ["MySQL Database server password property is NOT defined"] );

my $hlaAlleleFile = $runProperties->{&hlaAlleleFile};
_dieOnError( !DEFINED($hlaAlleleFile),
  ["hlaAlleleFile property is NOT defined"] );
$hlaAlleleFile = _makeAbsolute($hlaAlleleFile);
_dieOnError(
  !-f $hlaAlleleFile || !-r $hlaAlleleFile,
  ["hlaAlleleFile file is not readable"]
);
_dieOnError(
  $hlaAlleleFile !~ /^.+\.(txt|xls)$/,
  [
"hlaAlleleFile file is neither a text file (.txt) or an Excel spreadsheet (.xls)"
  ]
);
###
### Replace spaces with under-scores and copy to executionDirectory
### Copy the file to the execution directory
###
my $sourceDirectory   = dirname($hlaAlleleFile);
my $hlaAlleleFileBase = basename($hlaAlleleFile);
my $hasSpaces         = FALSE;

if ( $hlaAlleleFileBase =~ / / ) {
  $hlaAlleleFileBase =~ s/ /_/g;
  $hasSpaces = TRUE;
}
$hlaAlleleFile = join( SLASH, $executionDirectory, $hlaAlleleFileBase );
if ( $hasSpaces || $executionDirectory ne $sourceDirectory ) {
  _printMsg( ["copying hlaAlleleFile to $hlaAlleleFile"] );
  system( "cp '" . $runProperties->{&hlaAlleleFile} . "' $hlaAlleleFile" );
}
$runProperties->{&hlaAlleleFile} = $hlaAlleleFile;

my $pypop = $runProperties->{&pypop};
_dieOnError( !DEFINED($pypop) && $pipelineType eq HLAQC_TYPE,
  ["pypop property is NOT defined"] );
_dieOnError( ( !-e $pypop || !-x $pypop ) && $pipelineType eq HLAQC_TYPE,
  ["pypop property ($pypop) is NOT accessible"] );

_dieOnError( !DEFINED( $runProperties->{&hlaLoci} )
    && $pipelineType eq HLAVA_TYPE,
  ["hlaLoci property is NOT defined"] );

my $vectorFileDirectory = $runProperties->{&vectorFileDirectory};
_dieOnError( !DEFINED($vectorFileDirectory) && $pipelineType eq HLAVA_TYPE,
  ["vectorFileDirectory is NOT defined"] );
_dieOnError( !-d $vectorFileDirectory && $pipelineType eq HLAVA_TYPE,
  ["vectorFileDirectory ($vectorFileDirectory) directory does NOT exist"] );

_dieOnError(
  !DEFINED( $runProperties->{&phenotypeColumn} ) && $pipelineType eq HLAVA_TYPE,
  ["phenotypeColumn property is NOT defined"]
);

if ( !DEFINED( $runProperties->{&outputImgtVersion} ) ) {
  $runProperties->{&outputImgtVersion} = outputImgtVersionDefault;
}
_dieOnError(
  $runProperties->{&outputImgtVersion} ne outputImgtVersion2
    && $runProperties->{&outputImgtVersion} ne outputImgtVersionDefault,
  ["outputImgtVersion property neither 2 nor 3"]
);

if ( !DEFINED( $runProperties->{&debugSwitch} ) ) {
  $runProperties->{&debugSwitch} = debugSwitchDefault;
}
_dieOnError(
  $runProperties->{&debugSwitch} ne FALSE
    && $runProperties->{&debugSwitch} ne TRUE,
  ["debugSwitch property neither 0 nor 1"]
);

_printMsg( [ "Run Properties Validated!", ] );
###
### Process Templates for Standard Properties
###
_printMsg( ["Substituting Template Values..."] );
my $templateProperties = eval $stdProperties->{&templateProperties};
$status = $@;
_dieOnError( DEFINED($status) && $status,
  ["Failed to eval templateProperties"] );

foreach my $property ( keys %{$templateProperties} ) {
  my $data        = $templateProperties->{$property};
  my $value       = $runProperties->{$property};
  my $substitutor = $data->{substitutor};
  _printMsg( ["  ($property, $value, $substitutor)"] );
  foreach my $prop ( @{ $data->{properties} } ) {
    _printMsg( [ "    $prop (before) = " . $stdProperties->{$prop} ] );
    $stdProperties->{$prop} =~ s/$substitutor/$value/g;
    _printMsg( [ "    $prop (after)  = " . $stdProperties->{$prop} ] );
  }
}
###
### Create dbConfigFile
###
my $dfh = new FileHandle;
$dfh->open( $stdProperties->{&dbConfigFile}, WRITE_MODE );
$dfh->print( join( TAB, 'Server', $stdProperties->{&serverName} ) . NEW_LINE );
$dfh->print(
  join( TAB, 'Database', $stdProperties->{&databaseName} ) . NEW_LINE );
$dfh->print( join( TAB, 'Username', $runProperties->{&userName} ) . NEW_LINE );
$dfh->print( join( TAB, 'Password', $runProperties->{&password} ) . NEW_LINE );
$dfh->print(
  join( TAB, 'SchemaOwner', $stdProperties->{&schemaOwner} ) . NEW_LINE );
$dfh->close;
###
### Create Properties File
###
my $thePropertiesFile = $stdProperties->{&propertiesFile};
my $pfh               = new FileHandle;
$pfh->open( $thePropertiesFile, WRITE_MODE );
###
### Add Header Message
###
my $toolNameVersion = eval $stdProperties->{&toolNameVersion};
$status = $@;
_dieOnError( DEFINED($status) && $status, ["Failed to eval toolNameVersion"] );
my $toolNameVersionData = $toolNameVersion->{$pipelineType};
my $headerMessage =
    "Version Information\\\n"
  . "Immport generated data using:\\\n"
  . "  tool name    = "
  . $toolNameVersionData->{&toolName} . "\\\n"
  . "  tool version = "
  . $toolNameVersionData->{&toolVersion} . "\\\n" . "\\\n";

if ( $pipelineType eq HLAVT_TYPE || $pipelineType eq HLAVA_TYPE ) {
  $headerMessage .= "Please go to the database for the sequence feature and\\\n"
    . "the sequence feature variant type definitions used here.\\\n";
}
else {
  $headerMessage .= "Please go to database for the HLA allele information.\\\n";
}
$headerMessage .= "\\\n"
  . "HLA alleles and allele alignments are from IMGT/HLA database:\\\n"
  . "  IMGT version = "
  . $stdProperties->{&imgtReleaseVersion} . "\\\n"
  . "  IMGT date    = "
  . $stdProperties->{&imgtReleaseDate};
$pfh->print( join( EQUALS, headerMessage, $headerMessage ) . NEW_LINE );
###
### Add Run Properties
###
my $skipRunProperties = skipRunProperties;

foreach my $property ( sort keys %{$runProperties} ) {
  next if ( defined( $skipRunProperties->{$property} ) );
  my $value = $runProperties->{$property};
  if ( !DEFINED($value) ) {
    $value = EMPTY_STR;
  }
  $pfh->print( join( EQUALS, $property, $value ) . NEW_LINE );
}
###
### Add Tool Name and Version
###
foreach my $property ( sort keys %{$toolNameVersionData} ) {
  $pfh->print(
    join( EQUALS, $property, $toolNameVersionData->{$property} ) . NEW_LINE );
}
###
### Add hlaLoci Files
###
my $hlaLoci = EMPTY_STR;
if ( $pipelineType eq HLAVA_TYPE ) {
  _printMsg( [ "Finding vector files", ] );
  chdir($vectorFileDirectory);
  $_PATTERN_ = $stdProperties->{&analysisFile};
  @_FILES_   = ();
  File::Find::find( { wanted => \&_filesWanted }, DOT );
  chdir($EXEC_DIR);
  _printMsg( [ "Finding vector files...", ] );
  my $vectorFiles = {};

  foreach my $file (@_FILES_) {
    $file =~ s/\.\///;
    _printMsg( [ "  $file", ] );
    $vectorFiles->{"$file"} = join( SLASH, $vectorFileDirectory, $file );
  }
  ###
  ### Match loci to files
  ###
  _printMsg( [ "Selecting vector file for locus...", ] );
  my @loci = split( /;/, $runProperties->{&hlaLoci} );
  $hlaLoci = OPEN_PAREN;
  foreach my $locus (@loci) {
    _printMsg( [ "  $locus", ] );
    my $foundVectorFile = FALSE;
    foreach my $file ( keys %{$vectorFiles} ) {
      next if ( $file !~ /$locus/ );
      $hlaLoci .=
          SINGLE_QUOTE 
        . $locus
        . SINGLE_QUOTE
        . ASSIGN
        . SINGLE_QUOTE
        . $vectorFiles->{$file}
        . SINGLE_QUOTE
        . COMMA_SEPARATOR;
      $foundVectorFile = TRUE;
    }
    _dieOnError( !$foundVectorFile,
      ["Cannot find vector file for locus = $locus"] );
  }
  $hlaLoci .= CLOSE_PAREN;
  my $foo = eval $hlaLoci;
  $status = $@;
  _dieOnError( DEFINED($status) && $status, ["Failed to eval hlaLoci"] );
}
$pfh->print( join( EQUALS, hlaLoci, $hlaLoci ) . NEW_LINE );
$pfh->print( join( EQUALS, hlaAlleleFileType, EMPTY_STR ) . NEW_LINE );
###
### Add Standard Properties
###
my $skipStandardProperties = skipStandardProperties;
foreach my $property ( sort keys %{$stdProperties} ) {
  next if ( defined( $skipStandardProperties->{$property} ) );
  $pfh->print(
    join( EQUALS, $property, $stdProperties->{$property} ) . NEW_LINE );
}

$pfh->close;
###
### Run the tool
###
###
my $runScript = join( SLASH, $executionDirectory, runScript );
my $rfh = new FileHandle;
$rfh->open( $runScript, WRITE_MODE );
my $cmd = join(
  NEW_LINE,
  '#!/bin/bash',
  join( SPACE,
    'source',
    $stdProperties->{&exportCommand},
    split( /;/, $stdProperties->{&softwareDirectories} ) ),
  join( SPACE, $stdProperties->{&pipelineTool}, '-P', $thePropertiesFile ),
  EMPTY_STR
);
$rfh->print($cmd);
$rfh->close;
system("chmod 777 $runScript");
_printMsg( ["runScript cmd = $cmd"] );
system("$runScript");
POSIX::_exit(0);
