#!/bin/bash
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
cd $LOADING_ROOT
###
### Environment
###
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export PERL_SW="$OPT_DIR/hlavt/perl"
export SFVT_DIR="$LOADING_ROOT/sfvt"
###
### File in LOADING_ROOT
###
export SFVT_PROPERTIES="$LOADING_ROOT/.sfvt.properties"
###
### Sub-Directories of MHC_DATA_ROOT
###
export FeatureVariants="$MHC_DATA_ROOT/FeatureVariants"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### SFVT Generator
###
$DEVEL_BIN/generateHlaSfvt.pl -P $SFVT_PROPERTIES > generateSfvt.std 2> generateSfvt.err
cp $SFVT_DIR/FeatureVariants.*.xls $FeatureVariants
