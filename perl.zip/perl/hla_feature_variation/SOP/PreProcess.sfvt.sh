#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### This script is only used to convert IMGT/HLA Version 2.28 format
### into IMGT/HLA Version 3.0.0 format
###
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"

cd $LOADING_ROOT
###
### Environment
###
export PERL_SW="$OPT_DIR/hlavt/perl"
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export SFVT_DIR="$LOADING_ROOT/sfvt"
export BIN_NOMEN="$PERL_SW/hla_feature_variation/bin-nomenclature"
###
### Sub-Directories of MHC_DATA_ROOT
###
export FeatureVariants="$MHC_DATA_ROOT/FeatureVariants"
###
### File in LOADING_ROOT
###
export SFVT_PREPROCESS_PROPERTIES="$LOADING_ROOT/.sfvt.preprocess.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### Update sequence feature files that are
### provided in IMGT/HLA version 2 format
###
$BIN_NOMEN/fixSequenceFeature.pl -P $SFVT_PREPROCESS_PROPERTIES > fixSequenceFeature.std 2> fixSequenceFeature.err
$BIN_NOMEN/fixSequenceVariant.pl -P $SFVT_PREPROCESS_PROPERTIES > fixSequenceVariant.std 2> fixSequenceVariant.err
cp $SFVT_DIR/Classical_HLA_Sequence_Feature*.xls $FeatureVariants
