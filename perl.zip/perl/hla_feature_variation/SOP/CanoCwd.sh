#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"

cd $LOADING_ROOT
###
### Environment
###
export PERL_SW="$OPT_DIR/hlavt/perl"
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export MHC_DIR="$LOADING_ROOT/mhc"
export BIN_NOMEN="$PERL_SW/hla_feature_variation/bin-nomenclature"
###
### Sub-Directories of MHC_DATA_ROOT
###
export lookup_v3="$MHC_DATA_ROOT/lookup.v3"
###
### File in LOADING_ROOT
###
export MHC_PROPERTIES="$LOADING_ROOT/.mhc.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### Cano CWD Dataset Pre-Process for Database Loading
###
$BIN_NOMEN/fixCwdAlleles.pl -P $MHC_PROPERTIES > fixCwdAlleles.std 2> fixCwdAlleles.err
cp $MHC_DIR/cwd200_alleles.fixed.txt $lookup_v3
