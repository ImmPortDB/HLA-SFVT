#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
cd $LOADING_ROOT
###
### Environment
###
export PERL_SW="$OPT_DIR/hlavt/perl"
###
### File in LOADING_ROOT
###
export MHC_DB_PROPERTIES="$LOADING_ROOT/.mhc.db.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
###  Database Loaders
###
$DEVEL_BIN/generateLookupTables.pl -P $MHC_DB_PROPERTIES > generateLookupTables.std 2> generateLookupTables.err

$DEVEL_BIN/generateNmdpLookupTables.pl -P $MHC_DB_PROPERTIES > generateNmdpLookupTables.std 2> generateNmdpLookupTables.err

$DEVEL_BIN/generateAnt.pl -P $MHC_DB_PROPERTIES > generateAnt.std 2> generateAnt.err

$DEVEL_BIN/generateAlleleFreq.pl -P $MHC_DB_PROPERTIES > generateAlleleFreq.std 2> generateAlleleFreq.err

$DEVEL_BIN/generateRegionCwd.pl -P $MHC_DB_PROPERTIES > generateRegionCwd.std 2> generateRegionCwd.err

$DEVEL_BIN/generateHla.pl -P $MHC_DB_PROPERTIES > generateHla.std 2> generateHla.err
