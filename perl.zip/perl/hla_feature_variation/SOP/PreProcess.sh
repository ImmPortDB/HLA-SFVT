#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"

cd $LOADING_ROOT
###
### Environment
###
export PERL_SW="$OPT_DIR/hlavt/perl"
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export MHC_DIR="$LOADING_ROOT/mhc"
export BIN_NOMEN="$PERL_SW/hla_feature_variation/bin-nomenclature"
###
### Sub-Directories of MHC_DATA_ROOT
###
export FeatureVariants="$MHC_DATA_ROOT/FeatureVariants"
export dbMHC="$MHC_DATA_ROOT/dbMHC"
export lookup_v3="$MHC_DATA_ROOT/lookup.v3"
###
### File in LOADING_ROOT
###
export MHC_PROPERTIES="$LOADING_ROOT/.mhc.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### Step 1:  Fix the Following Files
###
### a.  Nomenclature_changes.txt
###
$BIN_NOMEN/fixChangedNames.pl -P $MHC_PROPERTIES > fixChangedNames.std 2> fixChangedNames.err
cp $MHC_DIR/Nomenclature_changes.txt $lookup_v3
###
### b.  Deleted_alleles.v3.txt
###
$BIN_NOMEN/fixDeletedNames.pl -P $MHC_PROPERTIES > fixDeletedNames.std 2> fixDeletedNames.err
cp $MHC_DIR/Deleted_alleles.v3.txt $lookup_v3
###
### c.  mhc.v3.tab.fixed
###
$BIN_NOMEN/fixDbMhc.pl -P $MHC_PROPERTIES > fixDbMhc.std 2> fixDbMhc.err
cp $MHC_DIR/mhc.v3.tab.fixed $dbMHC
