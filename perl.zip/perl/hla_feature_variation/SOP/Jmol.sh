#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
cd $LOADING_ROOT
###
### Environment
###
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export MHC_DIR="$LOADING_ROOT/mhc"
export PERL_SW="$OPT_DIR/hlavt/perl"
###
### Sub-Directories of MHC_DATA_ROOT
###
export Jmol="$MHC_DATA_ROOT/Jmol"
###
### File in LOADING_ROOT
###
export MHC_PROPERTIES="$LOADING_ROOT/.mhc.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### JMol Files Generation
###
### NOTE:  Once the file, pdb_structure.bcp, is generated and copied, it needs
###        to be updated into the perl directory,
###        BISC/dev/trunk/perl/hla_feature_variation/lib/db/controlled_vocabulary
###
$DEVEL_BIN/generateJmolFiles.pl -P $MHC_PROPERTIES > generateJmolFiles.std 2> generateJmolFiles.err
cp $MHC_DIR/deploy_env.properties $Jmol
cp $MHC_DIR/feature_allele.bcp    $Jmol
cp $MHC_DIR/pdb_structure.bcp     $PERL_SW/hla_feature_variation/lib/db/controlled_vocabulary
