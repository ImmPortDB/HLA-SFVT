#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### This script provides the setup for uploading MHC data,
### pre-processing, and database loading
###
### LOADING_ROOT Defined
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
export CREATE_ROOT="$3"
###
### Create LOADING_ROOT, if requested
###
if [ "$CREATE_ROOT" = "" ]; then
  echo "NOT Creating Root"
else
  echo "Creating Root $LOADING_ROOT"
  /bin/rm -rf $LOADING_ROOT
  mkdir -m777 -p $LOADING_ROOT
fi
cd $LOADING_ROOT
###
### Sub-Directories of LOADING_ROOT
###
export PERL_SW="$OPT_DIR/hlavt/perl"
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export MHC_DIR="$LOADING_ROOT/mhc"
export MHC_DB_DIR="$LOADING_ROOT/mhc.db"
###
### File in LOADING_ROOT
###
export DB_CONFIG_FILE="$LOADING_ROOT/.dbconfig"
export MHC_PROPERTIES="$LOADING_ROOT/.mhc.properties"
export MHC_DB_PROPERTIES="$LOADING_ROOT/.mhc.db.properties"
###
### Sub-Directories of MHC_DATA_ROOT
###
export CWD="$MHC_DATA_ROOT/CWD"
export IMGT_HLA="$MHC_DATA_ROOT/IMGT-HLA"
export FeatureVariants="$MHC_DATA_ROOT/FeatureVariants"
export RegionData="$MHC_DATA_ROOT/RegionData"
export dbMHC="$MHC_DATA_ROOT/dbMHC"
export NMDP="$MHC_DATA_ROOT/NMDP"
export IPD_KIR="$MHC_DATA_ROOT/IPD-KIR"
export Jmol="$MHC_DATA_ROOT/Jmol"
export lookup_v3="$MHC_DATA_ROOT/lookup.v3"
###
### Create MHC_DATA_ROOT and Sub-Directories
###
/bin/rm -rf $MHC_DATA_ROOT
mkdir -p $MHC_DATA_ROOT
mkdir -p $CWD
mkdir -p $IMGT_HLA
mkdir -p $FeatureVariants
mkdir -p $RegionData
mkdir -p $dbMHC
mkdir -p $NMDP
mkdir -p $IPD_KIR
mkdir -p $Jmol
mkdir -p $lookup_v3
###
### Initialize the dbconfig File
###
/bin/rm -f $DB_CONFIG_FILE
touch $DB_CONFIG_FILE
###
### Initialize the Pre-Processing Sub-Directory
###
/bin/rm -rf $MHC_DIR
mkdir -p $MHC_DIR
touch $MHC_PROPERTIES
###
### Initialize the Database Loading Sub-Directory
###
/bin/rm -rf $MHC_DB_DIR
mkdir -p $MHC_DB_DIR
touch $MHC_DB_PROPERTIES
