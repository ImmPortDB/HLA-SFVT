#!/bin/bash
###
### This script provides the setup for uploading MHC data,
### pre-processing, and Oracle database loading
###
### LOADING_ROOT Defined
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
export CREATE_ROOT="$3"
###
### Create LOADING_ROOT, if requested
###
if [ "$CREATE_ROOT" = "" ]; then
  echo "NOT Creating Root"
else
  echo "Creating Root $LOADING_ROOT"
  /bin/rm -rf $LOADING_ROOT
  mkdir -p $LOADING_ROOT
fi
cd $LOADING_ROOT
###
### Sub-Directories of LOADING_ROOT
###
export PERL_SW="$OPT_DIR/hlavt/perl"
export MHC_DATA_ROOT="$LOADING_ROOT/data"
export SFVT_DIR="$LOADING_ROOT/sfvt"
###
### File in LOADING_ROOT
###
export SFVT_PROPERTIES="$LOADING_ROOT/.sfvt.properties"
export SFVT_PREPROCESS_PROPERTIES="$LOADING_ROOT/.sfvt.preprocess.properties"
###
### Sub-Directories of MHC_DATA_ROOT
###
export IMGT_HLA="$MHC_DATA_ROOT/IMGT-HLA"
export FeatureVariants="$MHC_DATA_ROOT/FeatureVariants"
###
### Perl Software Checkout Setup
###
/bin/rm -rf $PERL_SW
mkdir -p $PERL_SW
###
### Perl Software Checkout
###
cd $PERL_SW
mkdir -p $PERL_SW/hla_feature_variation
cd $PERL_SW/hla_feature_variation
cd $PERL_SW/..
###
### Create MHC_DATA_ROOT and Sub-Directories
###
/bin/rm -rf $MHC_DATA_ROOT
mkdir -p $MHC_DATA_ROOT
mkdir -p $IMGT_HLA
mkdir -p $FeatureVariants
###
### Initialize the sfvt Sub-Directory
###
/bin/rm -rf $SFVT_DIR
mkdir -p $SFVT_DIR
touch $SFVT_PROPERTIES
touch $SFVT_PREPROCESS_PROPERTIES
