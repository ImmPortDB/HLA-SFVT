#!/bin/bash

export OPT_DIR="$1"
export HOME_DIR="$2"

export SCRIPT_HOME="$OPT_DIR/hlavt/perl/hla_feature_variation/SOP"
export LOADING_ROOT="$HOME_DIR/HLA-SOP"
export IMGT_HLA_DIR="$LOADING_ROOT/data/IMGT-HLA"

cd $LOADING_ROOT

/bin/rm -rf $LOADING_ROOT/sfvt

for release in '3.00' '3.10' '3.20' '3.30' '3.40' '3.50' '3.60' '3.70' '3.80' '3.90' '3.100'
do
  echo "Release $release Started"
  cd $IMGT_HLA_DIR
  /bin/rm -f Deleted_alleles.txt
  ln -s Deleted_alleles.Release.${release}.txt Deleted_alleles.txt

  cd $LOADING_ROOT
  cp $SCRIPT_HOME/.sfvt.${release}.properties $LOADING_ROOT/.sfvt.properties
  /bin/rm -rf sfvt
  mkdir sfvt
  /bin/rm -rf sfvt.${release}
  mkdir sfvt

  $SCRIPT_HOME/GenerateSfvt.sh $LOADING_ROOT $OPT_DIR
  mv $LOADING_ROOT/sfvt $LOADING_ROOT/sfvt.${release}
  echo "Release $release Completed"
done
