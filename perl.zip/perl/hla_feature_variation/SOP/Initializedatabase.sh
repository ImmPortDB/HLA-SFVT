#!/bin/bash

export OPT_DIR="$1"
export HOME_DIR="$2"

export SCRIPT_HOME="$OPT_DIR/hlavt/perl/hla_feature_variation/SOP"
export LOADING_ROOT="$HOME_DIR/HLA-SOP"
export PERL_SW="$OPT_DIR/hlavt/perl"

mkdir -m 777 -p $LOADING_ROOT
cd $LOADING_ROOT

source $PERL_SW/common/bin/Env/config $PERL_SW/hla_feature_variation $PERL_SW/common

/bin/rm -f initializeDatabase.log
$PERL_SW/hla_feature_variation/bin/initializeDatabase.pl -P $LOADING_ROOT/.mhc.db.properties > initializeDatabase.log 2>&1
