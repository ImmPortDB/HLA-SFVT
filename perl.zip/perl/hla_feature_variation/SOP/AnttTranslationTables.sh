#!/bin/bash
######################################################################
#                  Copyright (c) 2011 Northrop Grumman.
#                          All rights reserved.
######################################################################
###
### LOADING_ROOT Definition
###
export LOADING_ROOT="$1"
export OPT_DIR="$2"
cd $LOADING_ROOT
###
### Environment
###
export PERL_SW="$OPT_DIR/hlavt/perl"
###
### File in LOADING_ROOT
###
export MHC_PROPERTIES="$LOADING_ROOT/.mhc.properties"
###
### Perl Setup
###
source $PERL_SW/common/bin/Env/config.bash $PERL_SW/hla_feature_variation $PERL_SW/common
###
### ANTT Translation Table Generation
###
$DEVEL_BIN/createANTTTranslationTables.pl -P $MHC_PROPERTIES > createANTTTranslationTables.std 2> > createANTTTranslationTables.err
