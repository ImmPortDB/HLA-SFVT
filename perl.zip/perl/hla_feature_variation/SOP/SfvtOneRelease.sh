#!/bin/bash


export VERSION="$1"
export OPT_DIR="$2"
export HOME_DIR="$3"

echo "SFVT VERSION = $VERSION"

export SCRIPT_HOME="$OPT_DIR/hlavt/perl/hla_feature_variation/SOP"
export LOADING_ROOT="$HOME_DIR/HLA-SOP"
export IMGT_HLA_DIR="$LOADING_ROOT/data/IMGT-HLA"

cd $IMGT_HLA_DIR
/bin/rm Deleted_alleles.txt
ln -s Deleted_alleles.Release.$VERSION.txt Deleted_alleles.txt

cd $LOADING_ROOT
/bin/rm .sfvt.properties
ln -s .sfvt.$VERSION.properties .sfvt.properties
/bin/rm -rf sfvt
/bin/rm -rf sfvt.$VERSION
mkdir sfvt

cd $LOAD_ROOT
$SCRIPT_HOME/GenerateSfvt.sh $LOADING_ROOT $OPT_DIR

cd $LOADING_ROOT
mv sfvt sfvt.$VERSION
