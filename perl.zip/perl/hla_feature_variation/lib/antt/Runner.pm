package antt::Runner;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::PathSpecifics;

use antt::ErrMsgs;

use db::MhcTypes;

use fields qw (
  ambiguous_allele_separator
  antt
  antt_file
  antt_ini_file
  antt_translation_directory
  col_to_locus_map
  config
  config_categories
  error_mgr
  antt_log
  log_info
  map_suffix
  mono_tool
  not_found_counts
  process_log
  property_ord
  reader
  tools
  variant_type
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Input Specs
###
sub ANTT_INPUT_FILE { return 'ANTT_input'; }
###
### Log Specs
###
sub BEGIN_COL_PATTERN { return '^Translating column \d+ \((.+)\)\.$'; }
sub NOT_COL_PATTERN   { return '^Not translating column \d+ \((.+)\)\.$'; }

sub NOT_FOUND_PATTERN {
  return '^(.+) could not be found in the .+ translation file\.$';
}

sub NOT_CONFORM_PATTERN {
  return
'^(.+) does not seem to conform to nomenclature standards\. The closest match, \(.+\) cannot be truncated to .+\.$';
}

sub NOT_CONFORM_2002_PATTERN {
  return
'^(.+) does not seem to conform to 2002 - March 2010 nomenclature standards \(2-characters per polymorphic domain\)\.$';
}

sub APPEARS_IN_WRONG_COLUMN {
  return '^(.+) appears to be in the wrong column\.$';
}

sub V3_TO_V2_MATCH_ERROR {
  return
'^(.+) appears to be a truncated version of .+, but the former is colon-delimited and the latter is not\. It is not clear how to truncate this allele\.$';
}

sub CANNOT_BE_TRUNCATED_ERROR {
  return
'^(.+) is a truncated allele name that matches .+ but was translated to .+, which cannot be truncated\.$';
}

sub SHORTER_THAN_ERROR {
  return
'^(.+) is a truncated allele name that matches .+, but was translated to .+, which is shorter than .+\.$';
}
###
### properties for ANTT
###
sub ANTT_ANTTTRANSLATIONDIRECTORY { return 'anttTranslationDirectory'; }
sub ANTT_ANTTTRANSLATIONMAP       { return 'anttTranslationMap'; }
sub ANTT_FILE                     { return 'anttFile'; }
sub ANTT_INI_FILE                 { return 'anttIniFile'; }
sub ANTT_TOOL                     { return 'anttTool'; }
sub MONO_TOOL                     { return 'monoTool'; }
###
### INI Sections
###
sub ANTT_PARSEDATAFILE   { return 'ParseDataFile'; }
sub ANTT_CONVERSIONFILES { return 'ConversionFiles'; }
###
### INI Properties
###
sub ANTT_ALLELEDESIGNATOR_PROP         { return 'alleleDesignator'; }
sub ANTT_AMBIGUOUSALLELESEPARATOR_PROP { return 'ambiguousAlleleSeparator'; }
sub ANTT_CONVERSIONFILEPATH_PROP       { return 'conversionFilePath'; }
sub ANTT_DATAFILEMAPPINGS_PROP         { return 'dataFileMappings'; }
sub ANTT_UNTYPEDALLELE_PROP            { return 'untypedAllele'; }
sub ANTT_VALIDSAMPLEFIELDS_PROP        { return 'validSampleFields'; }
###
### Translation Actions
###
sub FORWARD_ACTION { return 'forward'; }
sub GCODE_ACTION   { return 'gcode'; }
sub PCODE_ACTION   { return 'pcode'; }
sub REVERSE_ACTION { return 'reverse'; }

sub FORWARD_SUFFIX { return '.upd'; }
sub GCODE_SUFFIX   { return '-G.upd'; }
sub PCODE_SUFFIX   { return '-P.upd'; }

sub ACTION_TO_MAP_SUFFIX {
  return {
    &FORWARD_ACTION => FORWARD_SUFFIX,
    &GCODE_ACTION   => GCODE_SUFFIX,
    &PCODE_ACTION   => PCODE_SUFFIX,
    &REVERSE_ACTION => FORWARD_SUFFIX,
  };
}
###
### Error Category
###
sub ERR_CAT { return antt::ErrMsgs::RUNNER_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _logHeader {
  my antt::Runner $this = shift;
  my ($msg) = @_;
  return if ( !$this->{log_info} );
  $this->{error_mgr}->printHeader($msg);
}

sub _logMsg {
  my antt::Runner $this = shift;
  my ($msg) = @_;
  return if ( !$this->{log_info} );
  $this->{error_mgr}->printMsg($msg);
}

sub _setStdConfigProps {
  my antt::Runner $this = shift;

  $this->{config} = {

    &ANTT_PARSEDATAFILE => {
      &ANTT_ALLELEDESIGNATOR_PROP => '*',
      &ANTT_AMBIGUOUSALLELESEPARATOR_PROP =>
        $this->{ambiguous_allele_separator},
      &ANTT_UNTYPEDALLELE_PROP     => $this->{reader}->getEmptyVal,
      &ANTT_VALIDSAMPLEFIELDS_PROP => undef,
    },

    &ANTT_CONVERSIONFILES => {
      &ANTT_CONVERSIONFILEPATH_PROP => undef,
      &ANTT_DATAFILEMAPPINGS_PROP   => undef,
    },

  };
  $this->{config_categories} = [ ANTT_PARSEDATAFILE, ANTT_CONVERSIONFILES, ];
  $this->{property_ord} = {
    &ANTT_PARSEDATAFILE => [
      ANTT_ALLELEDESIGNATOR_PROP, ANTT_AMBIGUOUSALLELESEPARATOR_PROP,
      ANTT_UNTYPEDALLELE_PROP,    ANTT_VALIDSAMPLEFIELDS_PROP,
    ],
    &ANTT_CONVERSIONFILES =>
      [ ANTT_CONVERSIONFILEPATH_PROP, ANTT_DATAFILEMAPPINGS_PROP, ]
  };
}

sub _createAnttLog {
  my antt::Runner $this = shift;

  $this->{antt_log}         = {};
  $this->{col_to_locus_map} = {};

  my $reader = $this->{reader};
  my $log    = $this->{antt_log};

  foreach my $entity_col ( $reader->getEntityFileCols ) {
    my $entityData = $reader->getEntityDataByFileCol($entity_col);
    my $locusName  = $entityData->{entity_names};
    ###
    ### For sequence features we only use allele features
    ###
    if ( $reader->getTypeValue eq $this->{variant_type} ) {
      next if ( $locusName !~ /_allele$/ );
      $locusName =
        db::MhcTypes::getName( db::MhcTypes::MHC_LOCUS_TABLE,
        $entityData->{locus_id} );
    }
    if ( !defined( $log->{$locusName} ) ) {
      $log->{$locusName} = {
        cols     => [],
        err_msgs => {},
      };
    }
    $this->{col_to_locus_map}->{$entity_col} = $locusName;
    push( @{ $log->{$locusName}->{cols} }, $entity_col );
  }
}

sub _getInitialCols {
  my antt::Runner $this = shift;

  my $reader      = $this->{reader};
  my @initialCols = $reader->getInitialCols;
  foreach my $index ( 0 .. $#initialCols ) {
    $initialCols[$index] =~ s/\*//g;
  }
  return @initialCols;
}

sub _createAnttInput {
  my antt::Runner $this = shift;

  my $reader = $this->{reader};
  my $tools  = $this->{tools};

  $this->_logHeader("ANTT input File");
  my $fh       = new FileHandle;
  my $fileName = join( util::Constants::SLASH,
    $tools->executionDir, $tools->cmds->TMP_FILE( ANTT_INPUT_FILE, 'txt' ) );
  my $open_failed = !$fh->open( $fileName, '>' );
  $this->{error_mgr}->registerError( ERR_CAT, 4, [$fileName], $open_failed );
  return if ($open_failed);

  my @header = $this->_getInitialCols;
  foreach my $entity_col ( $reader->getEntityColsByOrder ) {
    my $entityData = $reader->getEntityData($entity_col);
    my $locusName  = $entityData->{entity_names};
    ###
    ### For sequence features we only convert the allele features
    ###
    next
      if ( $reader->getTypeValue eq $this->{variant_type}
      && $locusName !~ /_allele$/ );
    push( @header, $entityData->{col_name} );
  }
  $fh->print(
    join( util::Constants::TAB, @header ) . util::Constants::NEWLINE );

  my @initialCols = $reader->getInitialCols;
  foreach my $entity ( $reader->getData ) {
    my @row = ();
    ###
    ### First the initial columns (init cols and optional columns)
    ###
    foreach my $col (@initialCols) {
      push( @row, $entity->{$col} );
    }
    ###
    ### Next the locus columns
    ###
    foreach my $index ( ( scalar @initialCols ) .. $#header ) {
      my $locus_col  = $header[$index];
      my $entityData = $reader->getEntityDataByFileCol($locus_col);
      push( @row, $entity->{ $entityData->{reader_col_name} } );
    }
    $fh->print( join( util::Constants::TAB, @row ) . util::Constants::NEWLINE );
  }
  $fh->close;
  return $fileName;
}

sub _getConfigVal {
  my antt::Runner $this = shift;
  my (@row) = @_;

  my $val       = util::Constants::EMPTY_STR;
  my $first_col = util::Constants::TRUE;
  foreach my $col (@row) {
    if ( !$first_col ) { $val .= "\n "; }
    $first_col = util::Constants::FALSE;
    $val .= $col;
  }
  $val .= "\n";
  return $val;
}

sub _setAnttProps {
  my antt::Runner $this = shift;
  my ($action) = @_;
  ###
  ### Get the antt type and header data
  ###
  my $reader       = $this->{reader};
  my @initial_cols = $this->_getInitialCols;
  my @locus_cols   = $reader->getEntityFileCols;
  my $map_suffix   = $this->{map_suffix}->{$action};
  ###
  ### Check to see that the header is defined, otherwise return!
  ###
  my $head_error = ( @initial_cols == 0 && @locus_cols == 0 );
  $this->{error_mgr}->registerError( ERR_CAT, 3, [], $head_error );
  return if ($head_error);
  ###
  ### create validSampleFields value
  ###
  my $file_config_props = $this->{config}->{&ANTT_PARSEDATAFILE};
  my @header_row        = @initial_cols;
  foreach my $locus_col (@locus_cols) {
    my $entityData = $reader->getEntityDataByFileCol($locus_col);
    my $locusName  = $entityData->{entity_names};
    ###
    ### For sequence features we only use allele features
    ###
    next
      if ( $reader->getTypeValue eq $this->{variant_type}
      && $locusName !~ /_allele$/ );
    push( @header_row,
      $file_config_props->{&ANTT_ALLELEDESIGNATOR_PROP} . $locus_col );
  }
  $file_config_props->{&ANTT_VALIDSAMPLEFIELDS_PROP} =
    $this->_getConfigVal(@header_row);
  ###
  ### create conversionFilePath and dataFileMappings values
  ###
  my $map_config_props = $this->{config}->{&ANTT_CONVERSIONFILES};
  $map_config_props->{&ANTT_CONVERSIONFILEPATH_PROP} =
    $this->{antt_translation_directory};
  my @map_row = ();
  foreach my $locus_col (@locus_cols) {
    my $entityData = $reader->getEntityDataByFileCol($locus_col);
    my $locusName  = $entityData->{entity_names};
    ###
    ### For sequence features we only use allele features
    ###
    if ( $reader->getTypeValue eq $this->{variant_type} ) {
      next if ( $locusName !~ /_allele$/ );
      $locusName =
        db::MhcTypes::getName( db::MhcTypes::MHC_LOCUS_TABLE,
        $entityData->{locus_id} );
    }
    push( @map_row,
      $locus_col . util::Constants::COLON . $locusName . $map_suffix );
  }
  $map_config_props->{&ANTT_DATAFILEMAPPINGS_PROP} =
    $this->_getConfigVal(@map_row);
}

sub _generateAnttConfig {
  my antt::Runner $this = shift;
  my ($action) = @_;
  ###
  ### evaluate the ANTT properties
  ###
  $this->_setAnttProps($action);
  ###
  ### Create and open the config file
  ###
  $this->_logMsg("ANTT Configuration (ini) File:\n");
  my $fh = new FileHandle;
  my $open_failed = !$fh->open( $this->{antt_ini_file}, '>' );
  $this->{error_mgr}->registerError(
    ERR_CAT, 1,
    [
      join( util::Constants::DOT, $this->{antt_file}, 'txt' ),
      $this->{antt_ini_file}
    ],
    $open_failed
  );
  return if ($open_failed);

  foreach my $category ( @{ $this->{config_categories} } ) {
    my $properties   = $this->{config}->{$category};
    my $category_str = "[" . $category . "]";
    $this->_logMsg($category_str);
    $fh->print("\n$category_str\n");
    my $property_ord = $this->{property_ord}->{$category};
    foreach my $property ( @{$property_ord} ) {
      my $val          = $properties->{$property};
      my $property_str = "$property=$val";
      $this->_logMsg($property_str);
      $fh->print("$property_str\n");
    }
  }
  $fh->close;
}

sub _processAnttLog {
  my antt::Runner $this = shift;
  my ($action) = @_;
  ###
  ### Terminators
  ###
  my $begin_col_pattern = BEGIN_COL_PATTERN;
  my $not_col_pattern   = NOT_COL_PATTERN;
  ###
  ### Error Messages
  ###
  my $appears_in_wrong_column   = APPEARS_IN_WRONG_COLUMN;
  my $cannot_be_truncated_error = CANNOT_BE_TRUNCATED_ERROR;
  my $not_conform_2002_pattern  = NOT_CONFORM_2002_PATTERN;
  my $not_conform_pattern       = NOT_CONFORM_PATTERN;
  my $not_found_pattern         = NOT_FOUND_PATTERN;
  my $shorter_than_error        = SHORTER_THAN_ERROR;
  my $v3_to_v2_match_error      = V3_TO_V2_MATCH_ERROR;

  my $anttLogFile =
    join( util::Constants::DOT, $this->{antt_file} . '_log', 'txt' );
  $this->_logHeader( "Parsing ANTT Log File\n" . " log file = $anttLogFile" );
  my $fh = new FileHandle;
  my $open_failed = !$fh->open( $anttLogFile, '<' );
  $this->{error_mgr}->registerError( ERR_CAT, 5, [$anttLogFile], $open_failed );
  return if ($open_failed);

  my $current_col = undef;
  my $locus_name  = undef;
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    $line =~ s///g;
    chomp($line);
    if ( $line =~ /$begin_col_pattern/ ) {
      $current_col = $1;
      $locus_name  = $this->{col_to_locus_map}->{$current_col};
      next;
    }
    elsif ( $line =~ /$not_col_pattern/ ) {
      $current_col = undef;
      $locus_name  = undef;
      next;
    }
    next if ( !defined($current_col) );

    $this->{not_found_counts}->{"$action"}++
      if ( $line =~ /$not_found_pattern/ );

    my $col    = undef;
    my $allele = undef;
    if ( $line =~ /$not_found_pattern/
      || $line =~ /$not_conform_pattern/
      || $line =~ /$not_conform_2002_pattern/
      || $line =~ /$appears_in_wrong_column/
      || $line =~ /$v3_to_v2_match_error/
      || $line =~ /$cannot_be_truncated_error/
      || $line =~ /$shorter_than_error/ )
    {
      $allele = $1;
      if (
           ( $action eq GCODE_ACTION && $allele =~ /:/ && $allele =~ /G$/ )
        || ( $action eq PCODE_ACTION && $allele =~ /:/ && $allele =~ /P$/ )
        || ( $action eq REVERSE_ACTION
          && $allele =~ /:/
          && $allele !~ /(P|G)$/
          && $allele !~ /\*\d+:[A-Z][A-Z]+$/ )
        || ( $action eq FORWARD_ACTION
          && $allele !~ /:/
          && $allele !~ /\*\d+[A-Z][A-Z]+$/ )
        )
      {
        $col = $current_col;
      }
    }
    ###
    ### If a valid error message capture it for the locus
    ###
    next if ( !defined($col) );
    ###
    ### Remove locus header so that we do not have a problem
    ### from loci names (old/new--i.e. C, Cw)
    ### unless it appears in wrong column
    ###
    if ( $line !~ /$appears_in_wrong_column/ ) {
      $allele =~ s/^.+\*//;
    }
    $this->{antt_log}->{$locus_name}->{err_msgs}->{$allele} = $line;
  }
  $fh->close;
}

sub _checkActions {
  my antt::Runner $this = shift;
  my (@actions) = @_;

  foreach my $action (@actions) {
    if ( $action ne FORWARD_ACTION
      && $action ne GCODE_ACTION
      && $action ne PCODE_ACTION
      && $action ne REVERSE_ACTION )
    {
      $this->{error_mgr}
        ->registerError( ERR_CAT, 7, [$action], util::Constants::TRUE );
    }
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my antt::Runner $this = shift;
  my ( $hla_file_reader, $ambiguous_allele_separator, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{ambiguous_allele_separator} = $ambiguous_allele_separator;
  $this->{antt_file}                  = undef;
  $this->{antt_ini_file}              = undef;
  $this->{antt_log}                   = {};
  $this->{antt_translation_directory} = undef;
  $this->{antt}                       = undef;
  $this->{col_to_locus_map}           = {};
  $this->{config_categories}          = undef;
  $this->{config}                     = {};
  $this->{error_mgr}                  = $error_mgr;
  $this->{map_suffix}                 = ACTION_TO_MAP_SUFFIX;
  $this->{mono_tool}                  = undef;
  $this->{property_ord}               = undef;
  $this->{process_log}                = util::Constants::FALSE;
  $this->{reader}                     = $hla_file_reader;
  $this->{tools}                      = $tools;

  $this->{log_info}     = $tools->getProperty( $tools->WRITE_MSGS_PROP );
  $this->{variant_type} = $tools->getFileTypeHeader( $tools->VariantType );
  ###
  ### Initialize the not found counts
  ###
  $this->{not_found_counts} = {};
  foreach my $action ( keys %{ $this->{map_suffix} } ) {
    $this->{not_found_counts}->{"$action"} = 0;
  }

  $this->_setStdConfigProps;

  return $this;
}

sub run {
  my antt::Runner $this = shift;
  my (@actions) = @_;

  my $tools = $this->{tools};
  ###
  ### Check that the actions are acceptable
  ###
  my $numErrors = $this->{error_mgr}->getErrors;
  $this->_checkActions(@actions);
  return if ( $numErrors < $this->{error_mgr}->getErrors );
  ###
  ### Run ANTT
  ###
  $this->_logHeader("Running ANTT");
  my $inputFilename = $this->_createAnttInput;
  ###
  ### Run the actions
  ###
  foreach my $action (@actions) {
    ###
    ### Set the not found count for action
    ###
    $this->{not_found_counts}->{"$action"} = 0;
    ###
    ### Create config file
    ###
    $this->_generateAnttConfig($action);
    return if ( $numErrors < $this->{error_mgr}->getErrors );
    ###
    ### Run ANTT
    ###
    my $antt_cmd = join(
      util::Constants::SPACE,
      $this->{mono_tool},
      $this->{antt},
      ( $action eq REVERSE_ACTION ) ? '-b' : util::Constants::EMPTY_STR,
      $this->{antt_ini_file},
      $inputFilename,
      $this->{antt_file}
    );
    my $cmd_status = $tools->executeTool( $antt_cmd, "Executing ANTT" );
    return if ($cmd_status);
    ###
    ### At this point, the ANTT output and log files
    ### have been generated.  Now read and process
    ### the log for error messages related to the action.
    ###
    $this->_processAnttLog($action) if ( $this->{process_log} );
  }
  $tools->printStruct( 'antt_log', $this->{antt_log} )
    if ( $this->{process_log} && $this->{log_info} );
}

sub updateReader {
  my antt::Runner $this = shift;

  my $reader   = $this->{reader};
  my $anttFile = join( util::Constants::DOT, $this->{antt_file}, 'txt' );
  my @data     = $reader->getData;

  $this->_logHeader("Update Reader Content with ANTT Result");
  my $fh = new FileHandle;
  my $open_failed = !$fh->open( $anttFile, '<' );
  $this->{error_mgr}->registerError( ERR_CAT, 6, [$anttFile], $open_failed );
  return if ($open_failed);

  my @header_cols = ();
  my $index       = undef;
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    $line =~ s///g;
    chomp($line);
    ###
    ### First row
    ###
    if ( @header_cols == 0 ) {
      @header_cols = split( /\t/, $line );
      $index = 0;
      next;
    }
    my $entity = $data[$index];
    my @row = split( /\t/, $line );
    foreach my $index ( 0 .. $#header_cols ) {
      my $locus_col  = $header_cols[$index];
      my $entityData = $reader->getEntityDataByFileCol($locus_col);
      my $col_name   = $entityData->{reader_col_name};
      $entity->{$col_name} = $row[$index];
      next if ( $reader->emptyCell( $entity->{$col_name} ) );
      $entity->{$col_name} =~ s/^\*//;
      $entity->{$col_name} =~ s/\/\*/\//g;
    }
    $index++;
  }
  $fh->close;
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setAnttFile {
  my antt::Runner $this = shift;
  my ($anttFile) = @_;
  $this->{antt_file} = $anttFile;
  my $error = util::Constants::EMPTY_LINE( $this->{antt_file} )
    || $this->{antt_file} !~ /\.txt$/;
  $this->{error_mgr}->registerError( ERR_CAT, 2, [ANTT_FILE], $error );
  return if ($error);
  ###
  ### Now set it as the prefix
  ###
  $this->{antt_file} =~ s/\.txt$//;
  ###
  ### Set the taskId in the ouput prefix
  ###
  my $tools      = $this->{tools};
  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  $this->{antt_file} =~ s/$task_infix/$task_id/;
}

sub setAnttIniFile {
  my antt::Runner $this = shift;
  my ($anttIniFile) = @_;
  $this->{antt_ini_file} = $anttIniFile;
  $this->{error_mgr}->registerError( ERR_CAT, 2, [ANTT_INI_FILE],
    util::Constants::EMPTY_LINE( $this->{antt_ini_file} ) );
}

sub setAnttTool {
  my antt::Runner $this = shift;
  my ($anttTool) = @_;
  $this->{antt} = $anttTool;
  $this->{error_mgr}->registerError( ERR_CAT, 2, [ANTT_TOOL],
    util::Constants::EMPTY_LINE( $this->{antt} ) );
}

sub setMonoTool {
  my antt::Runner $this = shift;
  my ($monoTool) = @_;
  $this->{mono_tool} = $monoTool;
  $this->{error_mgr}->registerError( ERR_CAT, 2, [MONO_TOOL],
    util::Constants::EMPTY_LINE( $this->{mono_tool} ) );
}

sub setAnttTranslationDirectory {
  my antt::Runner $this = shift;
  my ($anttTranslationDirectory) = @_;
  $this->{antt_translation_directory} = getPath($anttTranslationDirectory);
  $this->{error_mgr}->registerError(
    ERR_CAT, 2,
    [ANTT_ANTTTRANSLATIONDIRECTORY],
    util::Constants::EMPTY_LINE( $this->{antt_translation_directory} )
  );
  $this->{error_mgr}->registerError(
    ERR_CAT,
    5,
    [ ANTT_ANTTTRANSLATIONDIRECTORY, $this->{antt_translation_directory}, ],
    !-e $this->{antt_translation_directory}
      || !-d $this->{antt_translation_directory}
  );
}

sub setProcessAnttLog {
  my antt::Runner $this = shift;
  my ($process_log) = @_;
  $this->{process_log} =
    ( !util::Constants::EMPTY_LINE($process_log) && $process_log )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### Create the ANTT log for processing error messages
  ###
  $this->_createAnttLog if ( $this->{process_log} );
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub getLogLoci {
  my antt::Runner $this = shift;
  return sort keys %{ $this->{antt_log} };
}

sub getLogForLocus {
  my antt::Runner $this = shift;
  my ($locus_name) = @_;
  return $this->{antt_log}->{$locus_name};
}

sub getLogForAllele {
  my antt::Runner $this = shift;
  my ( $locus_name, $allele_name ) = @_;
  my $locus_msgs = $this->{antt_log}->{$locus_name};
  return undef if ( !defined($locus_msgs) );
  return $locus_msgs->{err_msgs}->{$allele_name};
}

sub getNotFoundCount {
  my antt::Runner $this = shift;
  my ($action) = @_;

  return $this->{not_found_counts}->{"$action"};
}

################################################################################

1;

__END__

=head1 NAME

Runner.pm

=head1 DESCRIPTION

This concrete class defines the mechanism for running the ANTT tool on
an HLA allele file and capturing ANTT output including error messages.

=head1 CONSTANTS

The following actions can be processed by ANTT:

   antt::Runner::FORWARD_ACTION -- IMGT/HLA version 2 to version 3
   antt::Runner::GCODE_ACTION   -- IMGT/HLA G-Code
   antt::Runner::PCODE_ACTION   -- IMGT/HLA P-Code
   antt::Runner::REVERSE_ACTION -- IMGT/HLA version 3 to version 2

For each action type, this class will capture ANTT errors for alleles
of the given type above that conform to the descriptions provided
below:

   antt::Runner::FORWARD_ACTION -- allele does contains a colon (':') and does not
                                   terminate in more than one alphabetic characters
   antt::Runner::GCODE_ACTION   -- allele contains a colon (':') and terminates in a 'G'
   antt::Runner::PCODE_ACTION   -- allele contains a colon (':') and terminates in a 'P'
   antt::Runner::REVERSE_ACTION -- allele contains a colon (':') and does not terminate
                                   in a 'G' or 'P' or more than one alphabetic characters

It is noted that NMDP codes (both version 2 and version 3) are not
validated by this class.

=head1 ERRORS DETECTED

The following ANTT error messages in regular expression format are
detected by this class so that they may be stored and communicated to
a validation class for a given locus and allele:

   ^(.+) could not be found in the .+ translation file\.$
   ^(.+) does not seem to conform to nomenclature standards\. The closest match, \(.+\) cannot be truncated to .+\.$
   ^(.+) does not seem to conform to 2002 - March 2010 nomenclature standards \(2-characters per polymorphic domain\)\.$
   ^(.+) appears to be in the wrong column\.$
   ^(.+) appears to be a truncated version of .+, but the former is colon-delimited and the latter is not\. It is not clear how to truncate this allele\.$
   ^(.+) is a truncated allele name that matches .+ but was translated to .+, which cannot be truncated\.$
   ^(.+) is a truncated allele name that matches .+, but was translated to .+, which is shorter than .+\.$

=head1 METHODS

The following methods are exported by this class.

=head2 B<new antt::Runner(hla_file_reader, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

The B<hla_file_reader> is the file reader for the HLA allele file to
process.

=head2 B<run(@actions)>

This method executes the ANTT tool by running the ANTT tool in each
action as specified by the list B<@action>.  The allowable actions are
defined in L<"CONSTANTS">.  This method assumes that the following
attributes have been set by the L<"SETTER METHODS">:

  antt_file
  antt_ini_file
  antt_tool
  mono_tool
  antt_translation_directory

For each action, this method runs the ANTT tool using the appropriate
translation files for the given action.

Once the ANTT run for the action is completed and the attribute
B<process_log> is TRUE (1), the method acquires all error messages
from the ANTT log that are appropriate for the action and adds them to
the B<antt_log> attribute.  This attribute stores the full locus name
of the error message and the file reader columns in which the error
occurred and the specific allele and associated error message.

=head2 B<updateReader>

The method updates the file reader with the content of the last ANTT
result file that was generated.

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setAnttFile(antt_file)>

This method sets the antt_file name to use as the output file and as
the log prefix.  The B<task_id> is substituted for the task infix
string.  The antt_file must end in a B<.txt> suffix.

=head2 B<setAnttIniFile(antt_ini_file)>

This method sets the antt ini file name.

=head2 B<setAnttTool(antt_tool)>

This method sets the ANTT (binary) tool to use for the ANTT
translation.

=head2 B<setMonoTool(mono_tool)>

This method sets the mono tool to use to execute the ANTT tool on
Linux systems.

=head2 B<setAnttTranslationDirectory(antt_translation_directory)>

This method sets ANTT translation directory path.  The directory must
exist.

=head2 B<setProcessAnttLog(process_log)>

This method sets process_log attribute to the boolean value
B<process_log> parameter.  If the parameter is TRUE (1), then it sets
the attribute to TRUE (1) and the log (B<antt_log>) for process annt
log error messages, otherwise it sets the attribute to FALSE (0).

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<@loci = getLogLoci>

This method returns the list of loci that have been processed from the
log file produced by the ANTT tool.  The B<locus_name> in the list are
the full locus names (i.e., HLA-A).

=head2 B<$log_data = getLogForLocus(locus_name)>

This method returns the referenced Perl hash containing the log data
for the given locus_name.  The data-structure contains two components:

  cols     -- referenced Perl array of the column names for the locus
  err_msgs -- referenced Perl hash containing the alleles as the key
              and the error message associate the allele as the value

The B<locus_name> is the full locus name (i.e., HLA-A).

=head2 B<$log_msg = getLogForAllele(locus_name, allele_name)>

This method returns the error log message associated with the allele
for the locus_name and allele_name.  If there is not error message,
then B<undef> is returned.  The B<locus_name> is the full locus name
(i.e., HLA-A).  The B<allele_name> is the allele as it appeared in the
input file.

=head2 B<$not_found_count = getNotFoundCount(action)>

This method returns not found count for the action.  The not found
count is the number of times the following error message occurred for
the run:

  (.+) could not be found in the .+ translation file\.

This method assumes that the run for the action occurred with
B<process_log> TRUE (1), otherwise zero (0) will be returned.

=cut
