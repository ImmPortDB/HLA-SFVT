package antt::TranslationTables;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::PathSpecifics;
use util::Table;

use fields qw (
  code_data
  code_header
  counts
  deleted_names
  error_mgr
  forward_header
  hla_prefix
  hla_prefix_map
  minimum_rows
  min_rows
  new_names
  nomenclature
  none_counters
  synthetic_2_category
  synthetic_3_start
  tools
  translation_dir
  translation_file_suffix
);

################################################################################
#
#			     Static Class Constants
#
################################################################################

sub G_CODE      { return 'G'; }
sub NONE_ALLELE { return 'None'; }
sub ZERO_PREFIX { return '0'; }
###
### Special Loci
###
sub MICA { return 'MICA'; }
sub MICB { return 'MICB'; }
###
### Statistics Table Specifics
###
### The Columns
###
sub ALLELE_GROUP_COL { return 'allele_group'; }
sub DELETE_COL       { return 'delete'; }
sub LOCUS_COL        { return 'locus'; }
sub MIN_COL          { return 'min'; }
sub NEW_COL          { return 'new'; }
sub NONE_COL         { return 'none'; }

sub COLS {
  return ( &ALLELE_GROUP_COL, &DELETE_COL, &LOCUS_COL, &MIN_COL, &NEW_COL,
    &NONE_COL );
}

sub COL_HEADERS {
  return (
    &ALLELE_GROUP_COL => 'Allele Group',
    &DELETE_COL       => 'Delete',
    &LOCUS_COL        => 'Locus',
    &MIN_COL          => 'Num Rows',
    &NEW_COL          => 'New',
    &NONE_COL         => 'None'
  );
}

sub TABLE_ROW_ORDER { return 'sub {$a->{locus} cmp $b->{locus};}'; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getCountStruct {
  my antt::TranslationTables $this = shift;
  my ( $counter, $key ) = @_;

  if ( !defined( $counter->{$key} ) ) {
    $counter->{$key} = {};
    foreach my $col (COLS) { $counter->{$key}->{$col} = 0; }
    $counter->{$key}->{&LOCUS_COL} = $key;
  }
  return $counter->{$key};
}

sub _setNoneAlleleCounter {
  my antt::TranslationTables $this = shift;
  my ($key) = @_;

  my $none_counters = $this->{none_counters};
  return if ( defined( $none_counters->{$key} ) );
  $none_counters->{$key} = 0;
}

sub _incNoneAlleleCounter {
  my antt::TranslationTables $this = shift;
  my ($key) = @_;

  my $none_counters = $this->{none_counters};
  $none_counters->{$key}++;
  my $counter = $none_counters->{$key};

  if    ( $counter < 10 )   { $counter = '000' . $counter; }
  elsif ( $counter < 100 )  { $counter = '00' . $counter; }
  elsif ( $counter < 1000 ) { $counter = '0' . $counter; }

  return $counter;
}

sub _setData {
  my antt::TranslationTables $this = shift;
  my ( $data, $key, $old_allele, $new_allele ) = @_;

  if ( !defined( $data->{$key} ) ) { $data->{$key} = []; }
  push( @{ $data->{$key} }, [ $old_allele, $new_allele ] );
}
###
### Add synthetic rows so minimum number
### of rows for a file is satisfied
###
sub _addSyntheticRows {
  my antt::TranslationTables $this = shift;
  my ( $locus, $code, $data, $fh ) = @_;

  return if ( defined($data) && scalar @{$data} >= $this->{minimum_rows} );
  my $rowCount = defined($data) ? scalar @{$data} : 0;
  ###
  ### Fill in the required number of rows
  ### (minimumRows) with syntethic data
  ###
  my $count =
    $this->_getCountStruct( $this->{min_rows},
    !defined($code) ? $locus : $locus . util::Constants::HYPHEN . $code );
  $count->{min} = $rowCount;

  my $synthetic_3_start = $this->{synthetic_3_start};
  my $last_field        = 1;
  while ( $rowCount < $this->{minimum_rows} ) {
    $rowCount++;
    my $old_allele = $locus . util::Constants::ASTERISK;
    my $new_allele = $locus . util::Constants::ASTERISK;
    if ( defined($code) ) {
      my @comps = ( $synthetic_3_start, $synthetic_3_start );
      push( @comps, $synthetic_3_start ) if ( $code eq G_CODE );
      $old_allele .= join( util::Constants::COLON, @comps ) . $code;
      $new_allele = $old_allele;
    }
    else {
      ###
      ### For locus files
      ###
      my $lastField =
        ( $last_field < 10 ) ? ZERO_PREFIX . $last_field : $last_field;
      $old_allele .= join( util::Constants::EMPTY_STR,
        $this->{synthetic_2_category}, $this->{synthetic_2_category},
        $this->{synthetic_2_category}, $lastField
      );
      $new_allele .= join( util::Constants::COLON,
        $this->{synthetic_3_start}, $this->{synthetic_3_start},
        $this->{synthetic_3_start}, $lastField
      );
    }
    $synthetic_3_start++;
    $last_field++;
    $fh->print(
      join( util::Constants::TAB, $old_allele, $new_allele )
        . util::Constants::NEWLINE );
  }
}

sub _writeData {
  my antt::TranslationTables $this = shift;
  my ( $data, $fh ) = @_;

  return if ( !defined($data) );
  foreach my $row ( @{$data} ) {
    $fh->print(
      join( util::Constants::TAB, $row->[0], $row->[1] )
        . util::Constants::NEWLINE );
  }
}

sub _readDeletedNames {
  my antt::TranslationTables $this = shift;

  my $tools = $this->{tools};
  $tools->generateDeletedNamesMap;
  my $deleted_names = $this->{deleted_names};
  foreach my $line ($tools->deletedNames) {
    my $allele_name = $line->{deleted_name};
    if ( $allele_name =~ /:/ ) { $allele_name =~ s/://g; }
    $deleted_names->{$allele_name} = util::Constants::EMPTY_STR;
  }
}

sub _readNewNames {
  my antt::TranslationTables $this = shift;
  my ($file) = @_;

  $file = getPath($file);
  my $fh = new FileHandle;
  $fh->open( $file, "<" );
  my $new_names = $this->{new_names};
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    my ( $hla_id, $allele_name ) = split( / /, $line );
    $new_names->{$allele_name} = util::Constants::EMPTY_STR;
  }
  $fh->close;
}

sub _readNomenclature {
  my antt::TranslationTables $this = shift;
  my ($file) = @_;

  $file = getPath($file);
  my $fh = new FileHandle;
  $fh->open( $file, "<" );
  my $nomenclature = $this->{nomenclature};
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    ###
    ### Note that the deleted alleles in IMGT/HLA version 2.*
    ### map to None
    ###
    next
      if ( util::Constants::EMPTY_LINE($line)
      || $line =~ /None$/
      || $line =~ /Current|=/ );
    my ( $old_allele, $new_allele ) = split( /\t| +/, $line );
    push( @{$nomenclature}, [ $old_allele, $new_allele ] );
  }
}

sub _getCodeData {
  my antt::TranslationTables $this = shift;
  my ( $file, $code ) = @_;

  $file = getPath($file);
  my $fh = new FileHandle;
  $fh->open( $file, "<" );
  $this->{code_data}->{$code} = {};
  my $data = $this->{code_data}->{$code};
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    next if ( util::Constants::EMPTY_LINE($line) || $line !~ /$code$/ );
    my ( $locus, $group, $the_code ) = split( /;/, $line );
    $the_code = $locus . $the_code;
    $locus =~ s/\*//;
    $this->_setData( $data, $locus, $the_code, $the_code );
  }
  $fh->close;
}

sub _generateCountsTable {
  my antt::TranslationTables $this = shift;

  my @ord = ( LOCUS_COL, NONE_COL, NEW_COL, DELETE_COL, ALLELE_GROUP_COL );
  my $table = new util::Table( $this->{error_mgr}, COL_HEADERS );
  $table->setColumnOrder(@ord);
  $table->setRowOrder(TABLE_ROW_ORDER);
  $table->setInHeader(util::Constants::TRUE);

  my @count_data = ();
  foreach my $count ( values %{ $this->{counts} } ) {
    my $keep_count = util::Constants::FALSE;
    foreach my $comp (@ord) {
      next if ( $comp eq LOCUS_COL || $count->{$comp} == 0 );
      $keep_count = util::Constants::TRUE;
      last;
    }
    next if ( !$keep_count );
    push( @count_data, $count );
  }
  $table->setData(@count_data);

  $table->generateTable(
    "Update Data Counts",
    "Legend:\n"
      . "  Locus        - The locus name\n"
      . "  Delete       - These are IMGT/HLA version 3* alleles\n"
      . "                 that are deleted, but in the update file\n"
      . "  New          - These are new IMGT/HLA version 3* alleles\n"
      . "                 with IMGT/HLA version 2* equivalents\n"
      . "  None         - These are new IMGT/HLA version 3* alleles\n"
      . "                 without IMGT/HLA version 2* equivalents\n"
      . "  Allele Group - These are allele groups with at least\n"
      . "                 3-digits"
  );
}

sub _generateMinRowsTable {
  my antt::TranslationTables $this = shift;

  my $table = new util::Table( $this->{error_mgr}, COL_HEADERS );
  $table->setColumnOrder( LOCUS_COL, MIN_COL );
  $table->setRowOrder(TABLE_ROW_ORDER);
  $table->setInHeader(util::Constants::TRUE);
  $table->setData( values %{ $this->{min_rows} } );

  $table->generateTable(
    "Minimum Rows Violated",
    "Legend:\n"
      . "  Locus        - The locus name or G-/P-Code\n"
      . "  Num Rows     - There number of rows for a\n"
      . "                 locus which is less than\n"
      . "                 minimum number of rows ("
      . $this->{minimum_rows} . ")"
  );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$) {
  my antt::TranslationTables $this = shift;
  my ( $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr}     = $error_mgr;
  $this->{tools}         = $tools;
  $this->{none_counters} = {};
  ###
  ### set the properties used by this class
  ###
  $this->{hla_prefix}   = $tools->getProperty('hlaPrefix');
  $this->{minimum_rows} = int( $tools->getProperty('minimumRows') );
  $this->{synthetic_2_category} =
    int( $tools->getProperty('synthetic2Category') );
  $this->{synthetic_3_start} = int( $tools->getProperty('synthetic3Start') );
  $this->{translation_file_suffix} =
    $tools->getProperty('translationFileSuffix');
  $this->{translation_dir} =
    $tools->cmds->createDirectory( $tools->getProperty('translationDir'),
    "Creating translation directory" );

  my $hlaPrefixLoci = eval $tools->getProperty('hlaPrefixLoci');
  $this->{hla_prefix_map} = {};
  foreach my $hlaPrefix ( @{$hlaPrefixLoci} ) {
    $this->{hla_prefix_map}->{$hlaPrefix} = util::Constants::EMPTY_STR;
  }

  my $currentHeader = $tools->getProperty('currentHeader');
  my $newHeader     = $tools->getProperty('newHeader');
  $this->{code_header} =
    join( util::Constants::TAB, $currentHeader, $currentHeader );
  $this->{forward_header} =
    join( util::Constants::TAB, $currentHeader, $newHeader );
  ###
  ### The Counting Data-Structures
  ###
  $this->{counts}   = {};
  $this->{min_rows} = {};
  ###
  ### Get the data files
  ###
  $this->{deleted_names} = {};
  $this->_readDeletedNames;

  $this->{new_names} = {};
  $this->_readNewNames( $tools->getProperty('alleleListFile') );

  $this->{nomenclature} = [];
  $this->_readNomenclature( $tools->getProperty('nomenclatureFile') );

  my $codeFiles = eval $tools->getProperty('codeFiles');
  $this->{code_data} = {};
  foreach my $code ( keys %{$codeFiles} ) {
    $this->_getCodeData( $tools->setWorkspaceForProperty( $codeFiles->{$code} ),
      $code );
  }

  return $this;
}

sub generateTables {
  my antt::TranslationTables $this = shift;
  ###
  ### The data that will be used to
  ### generate locus translation tables
  ###
  my $delete_data = {};
  my $new_data    = {};
  my $none_data   = {};
  my $nomen_data  = {};
  my $group_data  = {};
  ###
  ### Processing Nomenclature File
  ###
  $this->{error_mgr}->printHeader("Processing Nomenclature File");
  my $new_update_alleles = {};

  foreach my $row ( @{ $this->{nomenclature} } ) {
    my $old_allele = $row->[0];
    my $new_allele = $row->[1];
    $new_allele =~ /^(.+)\*/;
    my $key = $1;
    $new_update_alleles->{$new_allele} = util::Constants::EMPTY_STR;
    ###
    ### IMGT/HLA version 2.* alleles that are now
    ### deleted names in IMGT/HLA version 3.*
    ### must be put to the end of the translation
    ### file so that back translations occur correctly
    ###
    if ( defined( $this->{deleted_names}->{$old_allele} ) ) {
      $this->{error_mgr}->printMsg(
        "keeping deleted allele to the last ($old_allele, $new_allele)");
      my $count = $this->_getCountStruct( $this->{counts}, $key );
      $count->{delete}++;
      $this->_setData( $delete_data, $key, $old_allele, $new_allele );
      next;
    }
    $this->_setData( $nomen_data, $key, $old_allele, $new_allele );
    $this->_setNoneAlleleCounter($key);
  }
  ###
  ### Now add new alleles that do appear in the nomenclature file
  ###
  foreach my $new_allele ( sort keys %{ $this->{new_names} } ) {
    next if ( defined( $new_update_alleles->{$new_allele} ) );
    $new_allele =~ /^(.+)\*([0-9:]+)[A-Z]?$/;
    my $key    = $1;
    my $digits = $2;
    ###
    ### Must fix for C/Cw (new/old names)
    ###
    my $old_key = $key;
    if ($key eq 'C') {$old_key = 'Cw';}
    ###
    ### We determine if new allele can be represented in
    ### IMGT/HLA version 2.* (that is, no component more
    ### than 2 digits)
    ###
    my $use_none = util::Constants::FALSE;
    my @comps = split( /:/, $digits );
    if ( @comps >= 1 ) {
      foreach my $index (0..$#comps) {
        my $comp = $comps[$index];
	if ($index == 0 && ($key eq MICA || $key eq MICB)) {
          if ( $comp =~ /^\d\d\d\d\d*$/ ) {
            $use_none = util::Constants::TRUE;
	    last;
	  }
	} elsif ( $comp =~ /^\d\d\d\d*$/ ) {
          $use_none = util::Constants::TRUE;
          last;
        }
      }
    }
    my $old_allele = undef;
    my $data       = undef;
    my $count      = $this->_getCountStruct( $this->{counts}, $key );
    if ($use_none) {
      $data = $none_data;
      $count->{none}++;
      $old_allele =
          $old_key
        . util::Constants::ASTERISK
        . NONE_ALLELE
        . $this->_incNoneAlleleCounter($key);
    }
    else {
      $data = $new_data;
      $count->{new}++;
      $old_allele = $new_allele;
      if ($key ne $old_key) {$old_allele =~ s/^$key\*/$old_key\*/;}
      $old_allele =~ s/://g;
    }
    $this->_setData( $data, $key, $old_allele, $new_allele );
    $this->{error_mgr}->printMsg("adding allele ($old_allele, $new_allele)");
  }
  ###
  ### Write Locus Files
  ###
  foreach my $locus ( keys %{$nomen_data} ) {
    my @locus_data = @{ $nomen_data->{$locus} };
    push( @locus_data, @{ $none_data->{$locus} } )
      if ( defined( $none_data->{$locus} ) );
    push( @locus_data, @{ $new_data->{$locus} } )
      if ( defined( $new_data->{$locus} ) );
    push( @locus_data, @{ $delete_data->{$locus} } )
      if ( defined( $delete_data->{$locus} ) );

    my $prefix = util::Constants::EMPTY_STR;
    if ( defined( $this->{hla_prefix_map}->{$locus} ) ) {
      $prefix = $this->{hla_prefix};
    }
    my $filename = join( util::Constants::SLASH,
      $this->{translation_dir},
      join( util::Constants::DOT,
        $prefix . $locus,
        $this->{translation_file_suffix}
      )
    );
    my $outFh = new FileHandle;
    $outFh->open( $filename, '>' );
    $outFh->autoflush(util::Constants::TRUE);
    $outFh->print( $this->{forward_header} . "\n" );

    $this->_writeData( \@locus_data, $outFh );
    ###
    ### Add allele groups that exceed 2-digits, as necessary
    ###
    my %allele_groups = ();
    foreach my $row (@locus_data) {
      next if ( $row->[1] !~ /^(.+\*\d\d\d\d*):/ );
      my $comp = $1;
      next if ( defined( $allele_groups{$comp} ) );
      $allele_groups{$comp} = $comp;
      $this->{error_mgr}->printMsg("adding allele group $comp");
      $this->_setData( $group_data, $locus, $comp, $comp );
      my $count = $this->_getCountStruct( $this->{counts}, $locus );
      $count->{allele_group}++;
    }
    $this->_writeData( $group_data->{$locus}, $outFh );
    ###
    ### Add synthetic rows, as necessary
    ###
    $this->_addSyntheticRows( $locus, undef, \@locus_data, $outFh );
    $outFh->close;
  }
  ###
  ### Write Code Files
  ###
  foreach my $code ( keys %{ $this->{code_data} } ) {
    my $code_data = $this->{code_data}->{$code};
    ###
    ### We use all loci defined that the alleles files
    ###
    foreach my $locus ( keys %{$nomen_data} ) {
      my $locus_data = $code_data->{$locus};
      my $prefix     = util::Constants::EMPTY_STR;
      if ( defined( $this->{hla_prefix_map}->{$locus} ) ) {
        $prefix = $this->{hla_prefix};
      }
      my $infix    = util::Constants::HYPHEN . $code;
      my $filename = join( util::Constants::SLASH,
        $this->{translation_dir},
        join( util::Constants::DOT,
          $prefix . $locus . $infix,
          $this->{translation_file_suffix}
        )
      );
      my $outFh = new FileHandle;
      $outFh->open( $filename, '>' );
      $outFh->autoflush(util::Constants::TRUE);
      $outFh->print( $this->{code_header} . "\n" );
      ###
      ### Write the code data, if any
      ###
      $this->_writeData( $locus_data, $outFh );
      ###
      ### Add synthetic rows, as necessary
      ###
      $this->_addSyntheticRows( $locus, $code, $locus_data, $outFh );
      $outFh->close;
    }
  }
  ###
  ### Generate tables statistics
  ###
  $this->_generateCountsTable;
  $this->_generateMinRowsTable;
}

################################################################################

1;

__END__

=head1 NAME

TranslationTables.pm

=head1 DESCRIPTION

This concrete class defines the mechanism for generating the ANTT tool
translation tables.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new antt::TranslationTables(tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

=head2 B<generateTables>

This method uses the files that have been read to generate the ANTT
translation table files into the translation directory.

=cut
