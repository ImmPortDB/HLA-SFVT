package antt::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'ANTT-ERROR: '; }

sub RUNNER_CAT { return 1000000000; }    ### Runner Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &RUNNER_CAT => {

      1 => "Error opening ANTT config file\n"
        . "  ANTT  file  = __1__\n"
        . "  config file = __2__",

      2 => "ANTT property is not defined correctly the properties\n"
        . "  property = __1__",

      3 => "Header row has not been set",

      4 => "Error opening ANTT input file\n" . "  input file = __1__",

      5 => "Error opening ANTT log file\n" . "  log file = __1__",

      6 => "Error opening ANTT generated file\n" . "  generated file = __1__",

      7 => "Unknown action, terminating run\n"
        . "  action = __1__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = { &RUNNER_CAT => 'antt::Runner', };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use antt::ErrMsgs;

   my $error_msgs  = antt::ErrMsgs::ERROR_MSGS;
   my $error_names = antt::ErrMsgs::ERROR_CATS;
   my $err_cat     = antt::ErrMsgs::RUNNER_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the hla library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   antt::ErrMsgs::RUNNER_CAT -- (1000000000) Runnner Class

=head1 STATIC CLASS METHODS

=head2 B<antt::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<antt::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
