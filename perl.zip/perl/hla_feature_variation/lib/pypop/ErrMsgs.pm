package pypop::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'PYPOP-ERROR: '; }

sub RUNNER_CAT { return 1000000; }    ### Runner Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &RUNNER_CAT => {

      1 => "Error opening pypop config file\n"
        . "  pypop  file = __1__\n"
        . "  config file = __2__",

      2 => "Pypop config category missing\n" . "  category = __1__",

      3 => "Pypop property is not defined correctly the properties\n"
        . "  property = __1__",

      4 => "pypopCategories is not a Perl referenced hash\n"
        . "  property = __1__\n"
        . "  value    = __2__",

      5 => "Header row has not been set",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = { &RUNNER_CAT => 'pypop::Runner', };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use pypop::ErrMsgs;

   my $error_msgs  = pypop::ErrMsgs::ERROR_MSGS;
   my $error_names = pypop::ErrMsgs::ERROR_CATS;
   my $err_cat     = pypop::ErrMsgs::RUNNER_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the hla library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   pypop::ErrMsgs::RUNNER_CAT -- ( 1000000 ) Runnner Class

=head1 STATIC CLASS METHODS

=head2 B<pypop::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<pypop::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
