package pypop::XmlConverter;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use Pod::Usage;

use util::Constants;
use util::Table;

use xml::Parser;

use db::MhcTypes;

use fields qw (
  alleles
  category_separator
  error_mgr
  geno_separator
  name_map
  output_imgt_version
  parser
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################

sub MAIN_TAG { return 'dataanalysis'; }

sub FORCE_TAGS {
  return [
    'allelepair',   'allele',  'genotype', 'group',
    'individcount', 'locus',   'loci',     'permutation',
    'haplotype',    'summary', 'pvalue',
  ];
}

sub _sortByFreq { return 'sub {$b->{frequency} <=> $a->{frequency};}'; }
sub _sortByName { return 'sub {$a->{name} cmp $b->{name};}'; }

sub _sortByColRow {
  return 'sub {$a->{col} cmp $b->{col} or $a->{row} cmp $b->{row};}';
}

sub _sortByRowCol {
  return 'sub {$a->{row} cmp $b->{row} or $a->{col} cmp $b->{col};}';
}

sub _sortByLoci { return 'sub {$a->{loci} cmp $b->{loci};}'; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _significance {
  my pypop::XmlConverter $this = shift;
  my ($pvalue) = @_;

  my $significance = undef;
  if    ( $pvalue == 0.0 )    { $significance = '*'; }
  elsif ( $pvalue < 0.00001 ) { $significance = '*****'; }
  elsif ( $pvalue < 0.0001 )  { $significance = '****'; }
  elsif ( $pvalue < 0.001 )   { $significance = '***'; }
  elsif ( $pvalue < 0.01 )    { $significance = '**'; }
  elsif ( $pvalue < 0.05 )    { $significance = '*'; }

  return $significance;
}

sub _lociInFile {
  my pypop::XmlConverter $this = shift;

  my $parser = $this->{parser};
  my $obj    = $parser->getObject;
  my @strs   = ();
  foreach my $locus ( @{ $obj->{locus} } ) {
    push( @strs, $parser->getAttribute( $locus, 'locus', 'name' ) );
  }
  return '[' . join( util::Constants::COMMA_SEPARATOR, @strs ) . ']';
}

sub _lociWithData {
  my pypop::XmlConverter $this = shift;

  my $parser = $this->{parser};
  my $obj    = $parser->getObject;
  my @strs   = ();
  foreach my $locus ( @{ $obj->{locus} } ) {
    my $role =
      $parser->getAttribute( $locus->{allelecounts}, 'allelecounts', 'role' );
    next if ( defined($role) && $role eq 'no-data' );
    push( @strs, $parser->getAttribute( $locus, 'locus', 'name' ) );
  }
  return '[' . join( util::Constants::COMMA_SEPARATOR, @strs ) . ']';
}

sub _convertFormat {
  my pypop::XmlConverter $this = shift;
  my ( $locus_name, $data ) = @_;

  my $lookup              = $this->{tools}->getAllelesLookup;
  my $category_separator  = $this->{category_separator};
  my $alleles             = $this->{alleles};
  my $output_imgt_version = $this->{output_imgt_version};
  my $ambiguous_allele_separator =
    db::MhcTypes::STANDARD_AMBIGUOUS_ALLELE_SEPARATOR;
  my @comps = split( /$ambiguous_allele_separator/, $data );
  foreach my $index ( 0 .. $#comps ) {
    $comps[$index] =~ s/$category_separator/:/g;
    next
      if (
      (
           $output_imgt_version == db::MhcTypes::IMGT_HLA_V2
        && $comps[$index] =~ /(P|G)$/
      )
      || $output_imgt_version == db::MhcTypes::IMGT_HLA_V3
      );
    my $allele = join( util::Constants::ASTERISK, $locus_name, $comps[$index] );
    if ( defined( $alleles->{$allele} ) ) {
      $comps[$index] = $alleles->{$allele};
      next;
    }
    $comps[$index] =
      $lookup->convertAllele( $locus_name, $comps[$index],
      db::MhcTypes::IMGT_HLA_V3 );
    $comps[$index] =~ s/^\w+\*//;
    $alleles->{$alleles} = $comps[$index];
  }
  return join( $ambiguous_allele_separator, @comps );
}

sub _locusCounts {
  my pypop::XmlConverter $this = shift;
  my ( $locus, $locus_num, $section ) = @_;

  my $parser = $this->{parser};

  my $locus_name = $parser->getAttribute( $locus, 'locus', 'name' );
  $this->{error_mgr}
    ->printMsg("\n${locus_num}.${section}. Allele Counts [${locus_name}]\n");

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Item',
    value => 'Value'
  );

  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }
  my @data         = ();
  my $allelecounts = $locus->{allelecounts};
  push(
    @data,
    {
      name  => 'Untyped individuals',
      value => $allelecounts->{untypedindividuals}
    }
  );
  push( @data,
    { name => 'Sample Size (n)', value => $allelecounts->{indivcount} } );
  push( @data,
    { name => 'Allele Count (2n)', value => $allelecounts->{allelecount} } );
  push(
    @data,
    {
      name  => 'Distinct alleles (k)',
      value => $allelecounts->{distinctalleles}
    }
  );
  $table->setData(@data);
  $table->generateTable();

  @columns = ( 'name', 'frequency', 'count' );
  %header = (
    name      => 'Name',
    count     => 'Count',
    frequency => 'Frequency'
  );
  $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  $table->setColumnJustification( 'name', util::Table::LEFT_JUSTIFY );
  my $totals = {
    name      => 'Total',
    count     => $allelecounts->{totalcount},
    frequency => $allelecounts->{totalfrequency},
  };
  my $freq_data = [];

  foreach my $allele ( @{ $allelecounts->{allele} } ) {
    my $struct = {};
    push( @{$freq_data}, $struct );
    $struct->{name} =
      $this->_convertFormat( $locus_name,
      $parser->getAttribute( $allele, 'allele', 'name' ) );
    $struct->{count}     = $allele->{count};
    $struct->{frequency} = $allele->{frequency};
  }
  $table->setData( @{$freq_data} );
  $table->setRowOrder(_sortByFreq);
  $table->generateTable( "Counts ordered by frequency", undef, $totals );

  $table->setRowOrder(_sortByName);
  $table->generateTable( "Counts ordered by name", undef, $totals );
  ###
  ### Get the col/row order numbers for the alleles of the locus
  ###
  $this->{name_map} = {};
  foreach my $allele ( @{ $allelecounts->{allele} } ) {
    my $name = $parser->getAttribute( $allele, 'allele', 'name' );
    $this->{name_map}->{$name} = util::Constants::EMPTY_STR;
  }
  my @names = sort keys %{ $this->{name_map} };
  foreach my $index ( 0 .. $#names ) {
    $this->{name_map}->{ $names[$index] } = $index;
  }
}

sub _gtHW {
  my pypop::XmlConverter $this = shift;
  my ( $locus, $locus_num, $section ) = @_;

  my $parser = $this->{parser};
  my $hw     = $locus->{hardyweinbergGuoThompson};

  my $locus_name = $parser->getAttribute( $locus, 'locus', 'name' );
  my $allelelump =
    $parser->getAttribute( $hw, 'hardyweinbergGuoThompson', 'allelelump' );
  return if ( util::Constants::EMPTY_LINE($allelelump) );

  $this->{error_mgr}->printMsg(
    "\n${locus_num}.${section}. Guo and Thompson HardyWeinberg output (mcmc) ["
      . $parser->getAttribute( $locus, 'locus', 'name' )
      . "]\n" );

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Name',
    value => 'Value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }

  my @data         = ();
  my $samplingNum  = $hw->{samplingNum};
  my $samplingSize = $hw->{samplingSize};

  my $pvalues = $hw->{pvalue};
  my $pvalue  = undef;
  my $type    = $parser->getAttribute( $pvalues->[0], 'pvalue', 'type' );
  if ( !util::Constants::EMPTY_LINE($type) && $type eq 'overall' ) {
    $pvalue = $parser->getTextNode( $pvalues->[0], 'pvalue' );
  }
  push(
    @data,
    {
      name  => 'Total steps in MCMC',
      value => $samplingNum * $samplingSize
    }
  );
  push(
    @data,
    {
      name  => 'Dememorization steps',
      value => $hw->{dememorizationSteps}
    }
  );
  push(
    @data,
    {
      name  => 'Number of Markov chain samples',
      value => $samplingNum
    }
  );
  push(
    @data,
    {
      name  => 'Markov chain sample size',
      value => $samplingSize
    }
  );
  push(
    @data,
    {
      name  => 'Std. error',
      value => $hw->{stderr}
    }
  );
  push(
    @data,
    {
      name  => 'p-value (overall)',
      value => $pvalue
    }
  );
  $table->setData(@data);
  $table->generateTable();

  @columns =
    ( 'name', 'genotype', 'obs_expected', 'chen_pvalue', 'diff_pvalue' );
  %header = (
    name         => util::Constants::EMPTY_STR,
    genotype     => 'Genotype',
    obs_expected => '(observed/expected)',
    chen_pvalue  => "[Chen's pval]",
    diff_pvalue  => '[diff pval]'
  );
  $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);

  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }

  my $geno_data = [];
  foreach my $geno ( @{ $hw->{genotypetable}->{genotype} } ) {

    my $col = $parser->getAttribute( $geno, 'genotype', 'col' );
    my $row = $parser->getAttribute( $geno, 'genotype', 'row' );
    my $row_num = $this->{name_map}->{$row};
    my $col_num = $this->{name_map}->{$col};

    my $chen_pvalue = undef;
    my $diff_pvalue = undef;
    foreach my $pvalue ( @{$pvalues} ) {
      my $type = $parser->getAttribute( $pvalue, 'pvalue', 'type' );
      my $prow = $parser->getAttribute( $pvalue, 'pvalue', 'row' );
      my $pcol = $parser->getAttribute( $pvalue, 'pvalue', 'col' );
      next
        if ( $type ne 'genotype' || $prow != $row_num || $pcol != $col_num );

      my $statistic = $parser->getAttribute( $pvalue, 'pvalue', 'statistic' );
      my $pValue = $parser->getTextNode( $pvalue, 'pvalue' );
      if ( $statistic eq 'chen_statistic' ) {
        $chen_pvalue = $pValue;
      }
      elsif ( $statistic eq 'diff_statistic' ) {
        $diff_pvalue = $pValue;
      }
      last if ( defined($chen_pvalue) && defined($diff_pvalue) );
    }
    my $chen_significance = $this->_significance($chen_pvalue);
    my $diff_significance = $this->_significance($diff_pvalue);
    next
      if ( util::Constants::EMPTY_LINE($chen_significance)
      && util::Constants::EMPTY_LINE($diff_significance) );

    my $struct = {};
    push( @{$geno_data}, $struct );
    $struct->{col} = $col;
    $struct->{row} = $row;

    $struct->{genotype} = join(
      $this->{geno_separator},
      $this->_convertFormat( $locus_name, $row ),
      $this->_convertFormat( $locus_name, $col )
    );

    $struct->{obs_expected} = join( util::Constants::SLASH,
      '(' . $geno->{observed},
      $geno->{expected} . ')'
    );
    $struct->{chen_pvalue} = $chen_pvalue;

    if ( !util::Constants::EMPTY_LINE($chen_significance) ) {
      $struct->{chen_pvalue} .= $chen_significance;
    }
    $struct->{diff_pvalue} = $diff_pvalue;
    if ( !util::Constants::EMPTY_LINE($diff_significance) ) {
      $struct->{diff_pvalue} .= $diff_significance;
    }
  }
  $table->setData( @{$geno_data} );
  $table->setRowOrder(_sortByRowCol);
  $table->generateTable("Individual genotype p-values found to be significant");
}

sub _plainHW {
  my pypop::XmlConverter $this = shift;
  my ( $locus, $locus_num, $section ) = @_;

  my $parser = $this->{parser};
  my $hw     = $locus->{hardyweinberg};

  my $locus_name = $parser->getAttribute( $locus, 'locus', 'name' );
  $this->{error_mgr}
    ->printMsg("\n${locus_num}.${section}. HardyWeinberg [${locus_name}]\n");

  my @columns = ( 'name', 'observed', 'expected', 'chisq', 'dof', 'pvalue' );
  my %header = (
    name     => util::Constants::EMPTY_STR,
    observed => 'Observed',
    expected => 'Expected',
    chisq    => 'Chi-square',
    dof      => 'Dof',
    pvalue   => 'p-value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);

  my $hetero_data = [];
  foreach my $allele ( @{ $hw->{heterozygotesByAllele}->{allele} } ) {
    my $struct = {};
    push( @{$hetero_data}, $struct );

    $struct->{name} =
      $this->_convertFormat( $locus_name,
      $parser->getAttribute( $allele, 'allele', 'name' ) );
    $struct->{observed} = $allele->{observed};
    $struct->{expected} = $allele->{expected};
    $struct->{chisq}    = $allele->{chisq};
    $struct->{pvalue}   = $allele->{pvalue}->[0];
  }

  my $geno_data      = [];
  my $observed_total = 0;
  my $expected_total = 0.0;
  foreach my $geno ( @{ $hw->{genotypetable}->{genotype} } ) {
    my $chisq_role = $parser->getAttribute( $geno->{chisq}, 'chisq', 'role' );
    next
      if ( !util::Constants::EMPTY_LINE($chisq_role)
      && $chisq_role eq 'not-calculated' );
    my $pvalue_role =
      $parser->getAttribute( $geno->{pvalue}->[0], 'pvalue', 'role' );
    next
      if ( !util::Constants::EMPTY_LINE($pvalue_role)
      && $pvalue_role eq 'not-calculated' );
    my $struct = {};
    push( @{$geno_data}, $struct );
    $struct->{col} = $parser->getAttribute( $geno, 'genotype', 'col' );
    $struct->{row} = $parser->getAttribute( $geno, 'genotype', 'row' );
    $struct->{name} = join(
      $this->{geno_separator},
      $this->_convertFormat(
        $locus_name, $parser->getAttribute( $geno, 'genotype', 'col' )
      ),
      $this->_convertFormat(
        $locus_name, $parser->getAttribute( $geno, 'genotype', 'row' )
      )
    );
    $struct->{observed} = $geno->{observed};
    $struct->{expected} = $geno->{expected};
    $struct->{chisq}    = $geno->{chisq};
    $struct->{pvalue}   = $geno->{pvalue}->[0];
    $observed_total += $struct->{observed};
    $expected_total += $struct->{expected};
  }
  my $geno_total = {
    name     => 'Total',
    observed => $observed_total,
    expected => $expected_total,
  };

  my $first_names = {
    common           => 'Common',
    lumped           => 'Lumped genotype',
    commonpluslumped => 'Common + lumped',
    homozygotes      => 'All homozygotes',
    heterozygotes    => 'All heterozygotes',
  };
  my $first_data = [];
  foreach
    my $first_datum ( 'common', 'lumped', 'commonpluslumped', 'homozygotes',
    'heterozygotes' )
  {
    my $struct = {};
    my $data   = $hw->{$first_datum};
    push( @{$first_data}, $struct );
    $struct->{name}     = $first_names->{$first_datum};
    $struct->{observed} = $data->{observed};
    $struct->{expected} = $data->{expected};
    $struct->{chisq}    = $data->{chisq};
    $struct->{pvalue}   = $data->{pvalue}->[0];
    $struct->{dof}      = $data->{chisqdf};

    if ( $first_datum eq 'common'
      || $first_datum eq 'lumped'
      || $first_datum eq 'commonpluslumped' )
    {
      $struct->{observed} = 'N/A';
      $struct->{expected} = 'N/A';
    }
  }

  $table->setData( @{$first_data} );
  $table->generateTable();

  $table->setData( @{$hetero_data} );
  $table->setRowOrder(_sortByName);
  $table->generateTable("Common heterozygotes by allele");

  $table->setData( @{$geno_data} );
  $table->setRowOrder(_sortByColRow);
  $table->generateTable( "Common genotypes", undef, $geno_total );
}

sub _locusHW {
  my pypop::XmlConverter $this = shift;
  my ( $locus, $locus_num, $section ) = @_;

  $this->_plainHW( $locus, $locus_num, $section )
    if ( defined( $locus->{hardyweinberg} ) );
  $this->_gtHW( $locus, $locus_num, $section )
    if ( defined( $locus->{hardyweinbergGuoThompson} ) );
}

sub _locusSlatkin {
  my pypop::XmlConverter $this = shift;
  my ( $locus, $locus_num, $section ) = @_;

  my $parser = $this->{parser};
  my $hewse  = $locus->{homozygosityEWSlatkinExact};
  return if ( !defined($hewse) );

  $this->{error_mgr}->printMsg(
"\n${locus_num}.${section}. Slatkin's implementation of EW homozygosity test of neutrality ["
      . $parser->getAttribute( $locus, 'locus', 'name' )
      . "]\n" );

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Name',
    value => 'Value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }
  my %nameValues = (
    observedHomozygosity => 'Observed F',
    meanHomozygosity     => 'Expected F',
    varHomozygosity      => 'Variance in F',
    normDevHomozygosity  => 'Normalized deviate of F (Fnd)',
    probHomozygosity     => 'p-value of F'
  );
  my @rowOrder = (
    'observedHomozygosity', 'meanHomozygosity',
    'varHomozygosity',      'normDevHomozygosity',
    'probHomozygosity'
  );
  my @data = ();
  foreach my $rowName (@rowOrder) {
    my $struct = {};
    push( @data, $struct );
    $struct->{name}  = $nameValues{$rowName};
    $struct->{value} = $hewse->{$rowName};
    if ( $rowName eq 'probHomozygosity' ) {
      my $significance = $this->_significance( $struct->{value} );
      if ( !util::Constants::EMPTY_LINE($significance) ) {
        $struct->{value} .= $significance;
      }
    }
  }
  $table->setData(@data);
  $table->generateTable();
}

sub _pairwiseLdEst {
  my pypop::XmlConverter $this = shift;
  my ($emhaplofreq) = @_;

  my $parser = $this->{parser};
  ###
  ### Get pairwise groups that have data and sort by loci
  ###
  my @columns =
    ( 'loci', 'd', 'dprime', 'wn', 'lnl_1', 'lnl_0', 's', 'npermu', 'pvalue' );
  my %header = (
    loci   => 'Locus pair',
    d      => 'D',
    dprime => "D'",
    wn     => 'Wn',
    lnl_1  => 'ln(L_1)',
    lnl_0  => 'ln(L_0)',
    s      => 'S',
    npermu => '# permu',
    pvalue => 'p-value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);

  my @groups = ();
  foreach my $group ( @{ $emhaplofreq->{group} } ) {
    my $mode = $parser->getAttribute( $group, 'group', 'mode' );
    my $role = $parser->getAttribute( $group, 'group', 'role' );
    next if ( $mode ne 'all-pairwise-ld-with-permu'
      || $role eq 'no-data' );
    my $struct = {};
    push( @groups, $struct );
    my $summary = $group->{linkagediseq}->{summary}->[0];
    my $permSum = $group->{permutationSummary};
    $struct->{loci}   = $parser->getAttribute( $group, 'group', 'loci' );
    $struct->{d}      = $summary->{dsummary};
    $struct->{dprime} = $summary->{dprime};
    $struct->{wn}     = $summary->{wn};
    $struct->{lnl_1}  = $group->{haplotypefreq}->{loglikelihood};
    $struct->{lnl_0} =
      $parser->getTextNode( $group->{loglikelihood}, 'loglikelihood' );
    $struct->{s} =
      $parser->getTextNode( $permSum->{permutation}->[0], 'permutation' );
    $struct->{npermu} =
      $parser->getAttribute( $permSum->{pvalue}->[0], 'pvalue', 'totalperm' );
    $struct->{pvalue} =
      $parser->getTextNode( $permSum->{pvalue}->[0], 'pvalue' );
    my $significance = $this->_significance( $struct->{pvalue} );
    if ( defined($significance) ) { $struct->{pvalue} .= $significance; }
  }
  ###
  ### If there are no groups then do not generate table...
  ###
  return if ( @groups == 0 );

  $this->{error_mgr}->printMsg("\nII. Multi-locus Analyses");
  $this->{error_mgr}
    ->printMsg("\nHaplotype / linkage disequilibrium (LD) statistics");
  $table->setData(@groups);
  $table->setRowOrder(_sortByLoci);
  $table->generateTable("Pairwise LD estimates");
}

sub _ldEst {
  my pypop::XmlConverter $this = shift;
  my ($emhaplofreq) = @_;

  my $parser = $this->{parser};

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Name',
    value => 'Value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }

  foreach my $group ( @{ $emhaplofreq->{group} } ) {
    my $mode      = $parser->getAttribute( $group, 'group', 'mode' );
    my $showHaplo = $parser->getAttribute( $group, 'group', 'showHaplo' );
    next if ( $mode ne 'LD' || $showHaplo ne 'no' );
    ###
    ### Now do LD estimates for the group
    ###
    my $after_filtering  = undef;
    my $before_filtering = undef;
    foreach my $individcount ( @{ $group->{individcount} } ) {
      my $role = $parser->getAttribute( $individcount, 'individcount', 'role' );
      if ( $role eq 'after-filtering' ) {
        $after_filtering = $individcount;
      }
      elsif ( $role eq 'before-filtering' ) {
        $before_filtering = $individcount;
      }
    }
    my @data = ();
    push(
      @data,
      {
        name  => 'individcount',
        value => $parser->getTextNode( $before_filtering, 'individcount' )
          . " (before-filtering)"
      }
    );
    push(
      @data,
      {
        name  => 'individcount',
        value => $parser->getTextNode( $after_filtering, 'individcount' )
          . " (after-filtering)"
      }
    );
    push( @data, { name => 'uniquepheno', value => $group->{uniquepheno} } );
    push( @data, { name => 'uniquegeno',  value => $group->{uniquegeno} } );
    push( @data, { name => 'haplocount',  value => $group->{haplocount} } );

    my $loglikelihood = $group->{loglikelihood};
    my $role = $parser->getAttribute( $loglikelihood, 'loglikelihood', 'role' );
    if ( $role eq 'no-ld' ) {
      push(
        @data,
        {
          name  => 'loglikelihood',
          value => $parser->getTextNode( $loglikelihood, 'loglikelihood' )
            . " (no-ld)"
        }
      );
    }
    $table->setData(@data);
    $table->generateTable(
      "LD est. for loci: " . $parser->getAttribute( $group, 'group', 'loci' ) );
  }
}

sub _haploTypeFreq {
  my pypop::XmlConverter $this = shift;
  my ($emhaplofreq) = @_;

  my $parser = $this->{parser};

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Name',
    value => 'Value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);

  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }

  foreach my $group ( @{ $emhaplofreq->{group} } ) {
    my $mode      = $parser->getAttribute( $group, 'group', 'mode' );
    my $showHaplo = $parser->getAttribute( $group, 'group', 'showHaplo' );
    next if ( $mode ne 'haplo' || $showHaplo ne 'yes' );

    my $haplotypefreq = $group->{haplotypefreq};

    my $after_filtering  = undef;
    my $before_filtering = undef;
    foreach my $individcount ( @{ $group->{individcount} } ) {
      my $role = $parser->getAttribute( $individcount, 'individcount', 'role' );
      if ( $role eq 'after-filtering' ) { $after_filtering = $individcount; }
      elsif ( $role eq 'before-filtering' ) {
        $before_filtering = $individcount;
      }
    }

    my @data = ();
    push(
      @data,
      {
        name  => 'individcount',
        value => $parser->getTextNode( $before_filtering, 'individcount' )
          . " (before-filtering)"
      }
    );
    push(
      @data,
      {
        name  => 'individcount',
        value => $parser->getTextNode( $after_filtering, 'individcount' )
          . " (after-filtering)"
      }
    );
    push( @data, { name => 'uniquepheno', value => $group->{uniquepheno} } );
    push( @data, { name => 'uniquegeno',  value => $group->{uniquegeno} } );
    push( @data, { name => 'haplocount',  value => $group->{haplocount} } );
    $table->setData(@data);
    $table->generateTable( "Haplotype frequency est. for loci: "
        . $parser->getAttribute( $group, 'group', 'loci' ) );

    @data = ();
    push(
      @data,
      {
        name => 'Loglikelihood under linkage equilibrium [ln(L_0)]',
        value =>
          $parser->getTextNode( $group->{loglikelihood}, 'loglikelihood' )
      }
    );
    push(
      @data,
      {
        name  => 'Loglikelihood obtained via the EM algorithm [ln(L_1)]',
        value => $haplotypefreq->{loglikelihood}
      }
    );
    push(
      @data,
      {
        name  => 'Number of iterations before convergence',
        value => $haplotypefreq->{iterConverged}
      }
    );
    $table->setData(@data);
    $table->generateTable();
    ###
    ### Get the haplo types
    ###
    @columns = ( 'name', 'frequency', 'copies' );
    %header = (
      name      => 'haplotype',
      frequency => 'frequency',
      copies    => '# copies'
    );
    $table = new util::Table( $this->{error_mgr}, %header );
    $table->setColumnOrder(@columns);

    my @haplotypes = ();
    foreach my $haplotype ( @{ $haplotypefreq->{haplotype} } ) {
      my $struct = {};
      push( @haplotypes, $struct );
      $struct->{name} =
        $parser->getAttribute( $haplotype, 'haplotype', 'name' );
      $struct->{frequency} = $haplotype->{frequency};
      $struct->{copies}    = $haplotype->{numCopies};
    }
    $table->setData(@haplotypes);

    $table->setRowOrder(_sortByFreq);
    $table->generateTable("Haplotypes sorted by frequency");

    $table->setRowOrder(_sortByName);
    $table->generateTable("Haplotypes sorted by name");
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my pypop::XmlConverter $this = shift;
  my ( $pypop_xml_file, $category_separator, $tools, $error_mgr ) = @_;

  $this = fields::new($this) unless ref($this);

  $this->{alleles}            = {};
  $this->{category_separator} = $category_separator;
  $this->{error_mgr}          = $error_mgr;
  $this->{tools}              = $tools;

  $this->{output_imgt_version} =
    $tools->getProperty( $tools->OUTPUT_IMGT_VERSION_PROP );

  $this->{geno_separator} =
      util::Constants::SPACE
    . util::Constants::AMPERSAND
    . util::Constants::SPACE;

  $this->{parser} = new xml::Parser( MAIN_TAG, FORCE_TAGS, $error_mgr );
  $this->{parser}->parse($pypop_xml_file);

  return $this;
}

sub generate {
  my pypop::XmlConverter $this = shift;
  ###
  ### Get the object
  ###
  my $parser = $this->{parser};
  my $obj    = $parser->getObject;
  ###
  ### Write content to log
  ###
  $this->{error_mgr}->printHeader( "Results of PyPop Data Analysis\n"
      . "  Generated from xml document "
      . basename( $this->{parser}->sourceFile ) );

  my @columns = ( 'name', 'value' );
  my %header = (
    name  => 'Item',
    value => 'Value'
  );
  my $table = new util::Table( $this->{error_mgr}, %header );
  $table->setColumnOrder(@columns);
  foreach my $col (@columns) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }
  my @data     = ();
  my $sum_info = $obj->{summaryinfo};
  push( @data,
    { name => 'Sample Size (n)', value => $sum_info->{indivcount} } );
  push( @data,
    { name => 'Allele Count (2n)', value => $sum_info->{allelecount} } );
  push(
    @data,
    {
      name  => 'Total loci in file',
      value => "(" . $sum_info->{locuscount} . ") " . $this->_lociInFile
    }
  );
  push(
    @data,
    {
      name  => 'Total loci with data',
      value => "("
        . $sum_info->{lociWithDataCount} . ") "
        . $this->_lociWithData
    }
  );
  $table->setData(@data);
  $table->generateTable("Population Totals");

  $this->{error_mgr}->printHeader( "Legend for all analyses\n\n"
      . "    * = significant at the 5% level\n"
      . "   ** = significant at the 1% level\n"
      . "  *** = significant at the 0.1% level\n"
      . " **** = significant at the 0.01% level\n"
      . "***** = significant at the 0.001% level" );
  ###
  ### Locus specific data
  ###
  $this->{error_mgr}->printMsg("\nI. Single Locus Analyses\n");
  my $locus_num = 0;
  foreach my $locus ( @{ $obj->{locus} } ) {
    $locus_num++;
    $this->{error_mgr}->printMsg( "\n$locus_num. Locus: "
        . $parser->getAttribute( $locus, 'locus', 'name' )
        . "\n" );
    my $role =
      $parser->getAttribute( $locus->{allelecounts}, 'allelecounts', 'role' );
    if ( defined($role) && $role eq 'no-data' ) {
      $this->{error_mgr}->printMsg("No data for this locus!");
      next;
    }
    $this->_locusCounts( $locus, $locus_num, 1 );
    $this->_locusHW( $locus, $locus_num, 2 );
    $this->_locusSlatkin( $locus, $locus_num, 3 );
  }
  ###
  ### LD data for locus pairs
  ###
  $this->_pairwiseLdEst( $obj->{emhaplofreq} );
  ###
  ### Get the LD and haplotype data for the full set of loci
  ###
  $this->_ldEst( $obj->{emhaplofreq} );
  $this->_haploTypeFreq( $obj->{emhaplofreq} );
}

################################################################################

1;

__END__

=head1 NAME

XmlConverter.pm

=head1 DESCRIPTION

This class generates reads pypop analysis XML output and generates
results into the log file for the following analysis categories:

   Emhaplofreq
   HardyWeinberg
   HardyWeinbergGuoThompson
   HomozygosityEWSlatkinExact

=head1 XML-STRUCTURE OF PYPOP ANALYIS OUTPUT

The following XML-structure is generated by pypop analysis into an xml-document:

   <dataanalysis>
     <filename>
     <pypop-version>
     <summaryinfo>
       <indivcount>
       <allelecount>
       <locuscount>
       <lociWithDataCount>
     <locus name="">*
       <allelecounts>
         <allelecount>
         <distinctalleles>
         <indivcount>
         <totalcount>
         <totalfrequency>
         <unsequencedsites>
         <untypedindividuals>
         <allele name="">*
           <frequency>
           <count>
       <hardyweinberg allelelump="0">
         <samplesize>
         <lumpBelow>
         <lumped>
           <observed>
           <expected>
           <chisq>
           <pvalue>
           <chisqdf>
         <common>
           <observed>
           <expected>
           <chisq>
           <pvalue>
           <chisqdf>
         <commonpluslumped>
           <observed>
           <expected>
           <chisq>
           <pvalue>
           <chisqdf>
         <homozygotes>
           <observed>
           <expected>
           <chisq>
           <pvalue>
           <chisqdf>
         <heterozygotes>
           <observed>
           <expected>
           <chisq>
           <pvalue>
           <chisqdf>
         <genotypetable>
             <genotype col="010101g" row="010101g" id="0">*
               <observed>
               <expected>
               <chisq role="">
               <pvalue role="">
         <heterozygotesByAllele>
           <allele name="">*
             <observed>
             <expected>
             <chisq>
             <pvalue>
       <hardyweinbergGuoThompson allelelump="0">
         <dememorizationSteps>
         <samplingNum>
         <samplingSize>
         <stderr>
         <elapsed-time>
         <timestamp>
         <switches>
           <percent-partial>
           <percent-full>
           <percent-all>
         <pvalue>* (type="overall" or "genotype" col="" row="" statistic="chen_statisitic" or "diff_statistic")
         <genotypetable>
           <genotype col="" row="" id="">*  --by allele name
             <observed>
             <expected>
             <chisq>
             <pvalue>
       <homozygosityEWSlatkinExact>
         <theta>
         <probEwens>
         <probHomozygosity>
         <meanHomozygosity>
         <observedHomozygosity>
         <varHomozygosity>
         <normDevHomozygosity>

     <emhaplofreq>
       <group loci="A:DRB3" showHaplo="no" mode="all-pairwise-ld-with-permu" role="no-data">
       <group loci="A:B" showHaplo="no" mode="all-pairwise-ld-with-permu">
       <group loci="A:B:CW:DPB1:DQB1:DRB1" showHaplo="yes" mode="haplo">*
       <group loci="A:B:CW:DPB1:DQB1:DRB1" showHaplo="no" mode="LD">
         <individcount role="after-filtering">*
         <individcount role="before-filtering">
         <uniquegeno>  <<Unique genotypes: 22061>>
         <uniquepheno> <<Unique phenotypes: 991>>
         <haplocount>
         <loglikelihood role="no-ld">
         <permutationSummary>
           <permutation>*
           <pvalue totalperm="999">
           <lr>
           <lr-mean>
           <lr-sd>
         <haplotypefreq>
           <condition role="converged">
           <iterConverged>
           <loglikelihood>
           <haplotype name="010101g:070201g:">*
             <frequency>
             <numCopies>
         <linkagediseq>
           <loci first="0" second="1">*
             <allelepair first="010101g:" second="080101g:">*
               <observed>
               <expected>
               <diseq>
               <norm_dij>
               <chisq>
           <summary first="0" second="1">*
             <wn>
             <q>
               <chisq>
               <dof>
             </q>
             <dsummary>
             <dprime>

=head1 METHODS

The following methods are exported by this class.

=head2 B<new pypop::XmlConverter(pypop_xml_file, category_separator, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

The B<pypop_xml_file> is the file name of the file contain the pypop
analysis XML output.  The B<category_separator> identifies the symbol
used as the category separator for IMGT/HLA version 3 formats.
Currently the colon (':') category separator is significant to pypop
so another separator is used as identified by this parameter.

The constructor sets the genotype separator to be B<' & '>, and also
determines the IMGT/HLA version for the results to be generated into
the log file (uses tools property B<outputImgtVersion>).  Finally, the
contructor parses the XML file for processing using the class
L<xml::Parser>.  The XML-structure is defined in 
L<"XML-STRUCTURE OF PYPOP ANALYIS OUTPUT">.

=head2 B<generate>

This method generates the pypop analysis output into the log file.  It
converts the allele data into the correct IMGT/HLA version as
determined by the contructor.  The log file content mirrors the
content of the pypop analysis text file output with better table
formating.

=cut
