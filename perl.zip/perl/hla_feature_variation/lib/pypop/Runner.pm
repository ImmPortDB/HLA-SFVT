package pypop::Runner;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;

use pypop::ErrMsgs;
use pypop::XmlConverter;

use file::HlaConverter;

use fields qw (
  error_mgr
  category_separator
  config
  config_categories
  hla_converter
  pypop
  pypop_file
  pypop_ini_file
  reader
  taxon_id
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### pypop prefix
###
sub PYPOP_CATEGORIES { return 'pypopCategories'; }
sub PYPOP_FILE       { return 'pypopFile'; }
sub PYPOP_INI_FILE   { return 'pypopIniFile'; }
sub PYPOP_TOOL       { return 'pypopTool'; }

sub PYPOP_PARSEGENOTYPEFILE { return 'ParseGenotypeFile'; }
sub PYPOP_GENERAL           { return 'General'; }
sub PYPOP_EMHAPLOFREQ       { return 'Emhaplofreq'; }

sub PYPOP_ALLELEDESIGNATOR_PROP  { return 'alleleDesignator'; }
sub PYPOP_DEBUG_PROP             { return 'debug'; }
sub PYPOP_OUTFILEPREFIXTYPE_PROP { return 'outFilePrefixType'; }
sub PYPOP_POPNAMEDESIGNATOR_PROP { return 'popNameDesignator'; }
sub PYPOP_UNTYPEDALLELE_PROP     { return 'untypedAllele'; }
sub PYPOP_VALIDPOPFIELDS_PROP    { return 'validPopFields'; }
sub PYPOP_VALIDSAMPLEFIELDS_PROP { return 'validSampleFields'; }

sub PYPOP_LOCITOESTLD_PROP    { return 'lociToEstLD'; }
sub PYPOP_LOCITOESTHAPLO_PROP { return 'lociToEstHaplo'; }
###
### Error Category
###
sub ERR_CAT { return pypop::ErrMsgs::RUNNER_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _setStdConfigProps {
  my pypop::Runner $this = shift;

  my $pypop_reader = $this->{hla_converter}->getDestReader;
  $this->{config} = {

    &PYPOP_GENERAL => {
      &PYPOP_DEBUG_PROP             => $this->{error_mgr}->isDebugging,
      &PYPOP_OUTFILEPREFIXTYPE_PROP => 'filename',
    },

    &PYPOP_PARSEGENOTYPEFILE => {
      &PYPOP_ALLELEDESIGNATOR_PROP  => '*',
      &PYPOP_POPNAMEDESIGNATOR_PROP => '+',
      &PYPOP_UNTYPEDALLELE_PROP     => $pypop_reader->getEmptyVal,
      &PYPOP_VALIDPOPFIELDS_PROP    => undef,
      &PYPOP_VALIDSAMPLEFIELDS_PROP => undef,
    },

  };

  $this->{config_categories} = [ PYPOP_GENERAL, PYPOP_PARSEGENOTYPEFILE ];
}

sub _getConfigVal {
  my pypop::Runner $this = shift;
  my (@row) = @_;

  my $val       = util::Constants::EMPTY_STR;
  my $first_col = util::Constants::TRUE;
  foreach my $col (@row) {
    if ( !$first_col ) { $val .= "\n "; }
    $first_col = util::Constants::FALSE;
    $val .= $col;
  }
  $val .= "\n";
  return $val;
}
###
### _correctEmhaplofreqProps:
###   Correct lociToEstLD and lociToEstHaplo if in Emhaplofreq
###   and present the wildcard '*'
###
sub _correctEmhaplofreqProps {
  my pypop::Runner $this = shift;

  my $config_props = $this->{config}->{&PYPOP_EMHAPLOFREQ};
  ###
  ### Determine is there is anything to do
  ###
  return if ( !defined($config_props) );
  my $lociToEstLD    = $config_props->{&PYPOP_LOCITOESTLD_PROP};
  my $lociToEstHaplo = $config_props->{&PYPOP_LOCITOESTHAPLO_PROP};
  return
    if (
    (
         util::Constants::EMPTY_LINE($lociToEstLD)
      && util::Constants::EMPTY_LINE($lociToEstHaplo)
    )
    || ( $lociToEstLD ne '*'
      && $lociToEstHaplo ne '*' )
    );
  ###
  ### Must determine which loci are defined
  ### use the file generated for pypop run
  ###
  ###
  my $tools  = $this->{tools};
  my $reader = $tools->getMhcFileReader(
    $tools->HlaReader,   $tools->PypopType,
    $this->{pypop_file}, $this->{taxon_id}
  );
  $reader->openReader;
  my $defined_loci = {};
  my $defined_ord  = [];
  foreach my $entity ( $reader->getData ) {
    foreach my $col ( $reader->getEntityCols ) {
      my $entity_data = $reader->getEntityData($col);
      my $cell        = $entity->{$col};
      my $locus       = uc( $entity_data->{col_name} );
      $locus =~ s/_\d+$//;
      next
        if ( defined( $defined_loci->{$locus} ) || $reader->emptyCell($cell) );
      $defined_loci->{$locus} = util::Constants::EMPTY_STR;
      push( @{$defined_ord}, $locus );
    }
  }
  return if ( @{$defined_ord} == 0 );
  ###
  ### Set the value
  ###
  my $val = join( util::Constants::COLON, @{$defined_ord} );
  if ( !util::Constants::EMPTY_LINE($lociToEstLD)
    && $lociToEstLD eq '*' )
  {
    $config_props->{&PYPOP_LOCITOESTLD_PROP} = $val;
  }
  if ( !util::Constants::EMPTY_LINE($lociToEstHaplo)
    && $lociToEstHaplo eq '*' )
  {
    $config_props->{&PYPOP_LOCITOESTHAPLO_PROP} = $val;
  }
}

###
### _generateParseFileProps:
###   Create the validPopFields validSampleFields
###
sub _generateParseFileProps {
  my pypop::Runner $this = shift;
  ###
  ### Get the pypop type and header data
  ###
  my $converter  = $this->{hla_converter};
  my @header_row = $converter->getHeaderRow;
  my @type_row   = $converter->getTypeRow;
  ###
  ### Check to see that the header is defined, otherwise return!
  ###
  my $head_error = ( @header_row == 0 );
  $this->{error_mgr}->registerError( ERR_CAT, 5, [], $head_error );
  return if ($head_error);
  ###
  ### Now generate the configuration file
  ###
  my $config_props = $this->{config}->{&PYPOP_PARSEGENOTYPEFILE};
  ###
  ### create validPopFields value
  ###
  if ( @type_row == 0 ) {
    delete( $config_props->{&PYPOP_VALIDPOPFIELDS_PROP} );
  }
  else {
    $config_props->{&PYPOP_VALIDPOPFIELDS_PROP} =
      $this->_getConfigVal(@type_row);
  }
  ###
  ### create validSampleFields value
  ###
  $header_row[0] =
    $config_props->{&PYPOP_POPNAMEDESIGNATOR_PROP} . $header_row[0];
  foreach my $index ( 2 .. $#header_row ) {
    $header_row[$index] =
      $config_props->{&PYPOP_ALLELEDESIGNATOR_PROP} . $header_row[$index];
  }
  $config_props->{&PYPOP_VALIDSAMPLEFIELDS_PROP} =
    $this->_getConfigVal(@header_row);
}

sub _generatePypopConfig {
  my pypop::Runner $this = shift;
  ###
  ### Create the validPopFields validSampleFields
  ###
  $this->_generateParseFileProps;
  ###
  ### Correct lociToEstLD and lociToEstHaplo if in Emhaplofreq
  ### and present the wildcard '*'
  ###
  $this->_correctEmhaplofreqProps;
  ###
  ### Create and open the config file
  ###
  $this->{error_mgr}->printHeader("PyPop Configuration (ini) File");
  my $fh = new FileHandle;
  my $open_failed = !$fh->open( $this->{pypop_ini_file}, '>' );
  $this->{error_mgr}->registerError( ERR_CAT, 1,
    [ $this->{pypop_file}, $this->{pypop_ini_file} ], $open_failed );
  return if ($open_failed);

  foreach my $category ( @{ $this->{config_categories} } ) {
    my $properties   = $this->{config}->{$category};
    my $category_str = "[" . $category . "]";
    $this->{error_mgr}->printMsg($category_str);
    $fh->print("\n$category_str\n");
    foreach my $property ( keys %{$properties} ) {
      my $val          = $properties->{$property};
      my $property_str = "$property=$val";
      $this->{error_mgr}->printMsg($property_str);
      $fh->print("$property_str\n");
    }
  }
  $fh->close;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my pypop::Runner $this = shift;
  my ( $hla_file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{category_separator} = util::Constants::UNDERSCORE;
  $this->{config}             = {};
  $this->{config_categories}  = undef;
  $this->{error_mgr}          = $error_mgr;
  $this->{pypop}              = undef;
  $this->{pypop_file}         = undef;
  $this->{pypop_ini_file}     = undef;
  $this->{reader}             = $hla_file_reader;
  $this->{taxon_id}           = $taxon_id;
  $this->{tools}              = $tools;
  ###
  ### Create the pypop file converter and set the colon replacement strategy
  ###
  $this->{hla_converter} =
    new file::HlaConverter( $hla_file_reader, $tools->PypopType, $tools,
    $taxon_id, $error_mgr );
  $this->{hla_converter}->setEntityConversion( util::Constants::COLON,
    $this->{category_separator} );

  $this->_setStdConfigProps;

  return $this;
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setPypopConfigProps {
  my pypop::Runner $this = shift;
  my ($pypopCategories) = @_;

  my $serializer = $this->{tools}->serializer;
  ###
  ### Get the pypop categories and make sure they exist
  ###
  my $cat_error = util::Constants::EMPTY_LINE($pypopCategories);
  $this->{error_mgr}
    ->registerError( ERR_CAT, 3, [PYPOP_CATEGORIES], $cat_error );
  return if ($cat_error);

  my $categoryHash = eval $pypopCategories;
  my $status       = $@;
  $cat_error =
    ( ( defined($status) && $status )
      || ref($categoryHash) ne $serializer->HASH_TYPE );
  $this->{error_mgr}
    ->registerError( ERR_CAT, 4, [ PYPOP_CATEGORIES, $pypopCategories ],
    $cat_error );
  return if ($cat_error);
  ###
  ### Remove the General and ParseGenotypeFile from the
  ### category list and add allowed categories to
  ### config_categories
  ###
  my $config = $this->{config};
  foreach my $category ( keys %{$categoryHash} ) {
    next
      if ( $category eq PYPOP_GENERAL
      || $category eq PYPOP_PARSEGENOTYPEFILE );
    push( @{ $this->{config_categories} }, $category );
    ###
    ### Check that pypop config properties
    ### for category are present
    ###
    my $properties = $categoryHash->{$category};
    my $cat_error  = util::Constants::FALSE;
    if ( ref($properties) ne $serializer->HASH_TYPE ) {
      $cat_error = util::Constants::TRUE;
    }
    else {
      my @keys = keys %{$properties};
      $cat_error = ( @keys == 0 ) ? util::Constants::TRUE : $cat_error;
    }
    $this->{error_mgr}->registerError( ERR_CAT, 2, [$category], $cat_error );
    return if ($cat_error);

    $config->{$category} = { %{$properties} };
  }
}

sub setPypopFile {
  my pypop::Runner $this = shift;
  my ($pypopFile) = @_;
  $this->{pypop_file} = $pypopFile;
  $this->{error_mgr}->registerError( ERR_CAT, 3, [PYPOP_FILE],
    util::Constants::EMPTY_LINE( $this->{pypop_file} )
      || $this->{pypop_file} !~ /\.txt$/ );
}

sub setPypopIniFile {
  my pypop::Runner $this = shift;
  my ($pypopIniFile) = @_;
  $this->{pypop_ini_file} = $pypopIniFile;
  $this->{error_mgr}->registerError( ERR_CAT, 3, [PYPOP_INI_FILE],
    util::Constants::EMPTY_LINE( $this->{pypop_ini_file} ) );
}

sub setPypopTool {
  my pypop::Runner $this = shift;
  my ($pypopTool) = @_;
  $this->{pypop} = $pypopTool;
  $this->{error_mgr}->registerError( ERR_CAT, 3, [PYPOP_TOOL],
    util::Constants::EMPTY_LINE( $this->{pypop} ) );
}

################################################################################
#
#				Runner Method
#
################################################################################

sub run {
  my pypop::Runner $this = shift;

  my $hla_converter = $this->{hla_converter};
  my $reader        = $this->{reader};
  my $tools         = $this->{tools};
  ###
  ### Get the pypop file and the associated configuration data.
  ###
  $reader->openReader;
  $hla_converter->setFileConversion;
  $hla_converter->writeFile( $this->{pypop_file} );
  return if ( $this->{error_mgr}->getErrors );
  ###
  ### Create config file
  ###
  $this->_generatePypopConfig;
  return if ( $this->{error_mgr}->getErrors );
  ###
  ### Run Pypop
  ###
  $this->{error_mgr}->printHeader("Running PyPop");
  my $pypop_cmd = join(
    util::Constants::SPACE,
    $this->{pypop}, '-c', $this->{pypop_ini_file},
    $this->{pypop_file}
  );
  my $cmd_status = $tools->executeTool( $pypop_cmd, "Executing Pypop" );
  return if ($cmd_status);
  ###
  ### Generate the XML output into the log
  ###
  my $pypopXmlFile = $this->{pypop_file};
  $pypopXmlFile =~ s/\.txt$//;
  $pypopXmlFile = join( util::Constants::DOT, $pypopXmlFile . '-out', 'xml' );
  my $generator = new pypop::XmlConverter(
    $pypopXmlFile,  $this->{category_separator},
    $this->{tools}, $this->{error_mgr}
  );
  $generator->generate;
  ###
  ### Convert pypop file to IMGT/HLA Version 3 format
  ###
  my $pypop_reader = $tools->getMhcFileReader(
    $tools->HlaReader,   $tools->PypopType,
    $this->{pypop_file}, $this->{taxon_id}
  );
  $reader->openReader;
  my $final_converter =
    new file::HlaConverter( $pypop_reader, $tools->PypopType, $tools,
    $this->{taxon_id}, $this->{error_mgr} );
  $this->{hla_converter}->setEntityConversion( $this->{category_separator},
    util::Constants::COLON );
  $hla_converter->setFileConversion;
  $hla_converter->writeFile( $this->{pypop_file} );
}

################################################################################

1;

__END__

=head1 NAME

Runner.pm

=head1 DESCRIPTION

This class runs the PyPop tool on an HLA file, generates log output
from the pypop run and converts the pypop input file into IMGT/HLA
version 3 format.  Also, if the final output is to be IMGT/HLA version
2, it generates the log and pypop input file into IMGT/HLA version 2
format.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new pypop::Runner(hla_file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The file to process is
represented by the B<file_reader> object, an instance of a subclass of
L<file::Mhc::Hla>, the tools object
(L<util::Tools::mhcSeqVar::qualityControl>), and the error logger
(L<util::ErrMgr>).  The taxon_id specifies the species that is being
processed.  Currently, it must be B<9606> (Homo sapiens).

=head2 B<run>

This method runs a pypop analysis on the file content in file reader
using the following attribute information set by L<"SETTER METHODS">:

  config         -- the pypop ini configuration
  pypop          -- pypop (binary) tool
  pypop_file     -- file name of file containing the input in pypop input format
  pypop_ini_file -- file name of pypop ini-file

First, this method converts the HLA data content of the file reader
into pypop format and writes it to the pypop_file.  For IMGT/HLA
version 3 format data, it converts the colon (':') category separator
into an underscore ('_').  Currently, the colon is significant to
pypop so an alternative symbol needs to be used for category
separator.  Then it generates the pypop ini-configuration and write it
to the pypop_ini_file.  Next, the method executes pypop using the
pypop_ini_file and pypop_file.  On the pypop analysis is complete,
this method reads the pypop XML output and generates the results into
the pypop log for the following analysis categores using the class
L<pypop::XmlConverter>:

   Emhaplofreq
   HardyWeinberg
   HardyWeinbergGuoThompson
   HomozygosityEWSlatkinExact

Finally, the method converts the pypop_file into IMGT/HLA version 3
format.  That is, it converts the underscore ('_') category separator
to colon (':') in the pypop_file.

=head1 SETTER METHODS

The following settter methods are exported by this class.

=head2 B<setPypopConfigProps(pypop_properties)>

This method reads the pypop configuration properties from
B<pypop_properties>.  This parameter must a string that evals into a
referenced Perl hash.  The keys of the hash are property categories
are used in the pypop ini-file.  The following categories, B<General>
and B<ParseGenotypeFile>, are ignored in pypop_properties since these
are configured by this class. The value of the hash is a referenced
Perl hash of properties for the category which the key is property
name and the value is the property value.  Currently, the following
category options are post processed into the log file from the XML:

   Emhaplofreq
   HardyWeinberg
   HardyWeinbergGuoThompson
   HomozygosityEWSlatkinExact

=head2 B<setPypopFile(pypop_file)>

This method sets the pypop input file name for the pypop analysis.  It
must in the B<.txt> suffix.

=head2 B<setPypopIniFile(pypop_ini_file)>

This method set the pypop configuration file name for the pypop
analysis.

=head2 B<setPypopTool(pypop_tool)>

This method sets the location of the PyPop (binary) tool to execute
for a pypop analysis.

=cut
