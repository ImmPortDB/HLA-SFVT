package qualityControl::Allele;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PathSpecifics;
use util::Messaging;

use db::MhcTypes;

use featureAnalysis::AnalysisTypes;

use qualityControl::ErrMsgs;
use qualityControl::Lookup;

use fields qw (
  ambiguous_allele_separator
  error_mgr
  lookup
  msgs
  nomen_ord
  out_file
  population_area
  population_areas
  population_col
  queries
  reader
  tools
  write_msgs
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Allele Types
###
sub DIGIT_AGROUP { return 'digit_agroup'; }
sub DIGIT_GCODE  { return 'digit_gcode'; }
sub DIGIT_NAME   { return 'digit'; }
sub DIGIT_NMDP   { return 'digit_nmdp'; }
sub DIGIT_PCODE  { return 'digit_pcode'; }
sub DIGIT_SUFFIX { return 'digit_suffix'; }
sub FULL_AGROUP  { return 'agroup'; }
sub FULL_NAME    { return 'full'; }
sub FULL_SUFFIX  { return 'suffix'; }
sub GCODE_NAME   { return 'gcode'; }
sub NMDP_NAME    { return 'nmdp'; }
sub PCODE_NAME   { return 'pcode'; }
###
### Coarse Type
###
sub ALLELE_TYPE { return 'allele'; }
sub GCODE_TYPE  { return 'gcode'; }
sub PCODE_TYPE  { return 'pcode'; }
###
### Population Data Query
###
sub DB_QUERIES {
  return {
    &db::MhcTypes::LK_POP_AREA_TYPE_TABLE => {
      msg => db::MhcTypes::LK_POP_AREA_TYPE_TABLE . ' Query',
      col_ord =>
        [ db::MhcTypes::POP_AREA_NAME_COL, db::MhcTypes::POP_AREA_ABBRV_COL, ],
    },
  };
}
###
### Optional Columns
###
sub OPTIONAL_COLS {
  return (featureAnalysis::AnalysisTypes::SUBJECT_PHENOTYPE_COL);
}
###
### Error Category
###
sub ERR_CAT { return qualityControl::ErrMsgs::ALLELE_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getStruct {
  my qualityControl::Allele $this = shift;
  my ( $query, $row ) = @_;

  my $ord    = $this->{queries}->{$query}->{col_ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _getPopAreaData {
  my qualityControl::Allele $this = shift;

  my $pop_area_data = db::MhcTypes::LK_POP_AREA_TYPE_TABLE;
  my $query         = $this->{queries}->{$pop_area_data};
  my $cmd           = join(
    util::Constants::SPACE,
    'select',
    join(
      util::Constants::COMMA . util::Constants::NEWLINE,
      @{ $query->{col_ord} }
    ),
    "from $pop_area_data"
  );
  my $pop_areas  = $this->{population_areas};
  my $db_queries = new util::DbQuery( $this->{tools}->getSession );
  $db_queries->doQuery( $pop_area_data, $cmd, $query->{msg} );
  while ( my $row_ref = $db_queries->fetchRowRef($pop_area_data) ) {
    my $struct = $this->_getStruct( $pop_area_data, $row_ref );
    $pop_areas->{ lc( $struct->{pop_area_abbrv} ) } = $struct->{pop_area_name};
    $pop_areas->{ lc( $struct->{pop_area_name} ) }  = $struct->{pop_area_name};
  }
}

sub nmdpLookup {
  my qualityControl::Allele $this = shift;

  my $lookup     = $this->{lookup};
  my $nmdpLookup = $lookup->getLookupTable( $lookup->NmdpCodesLookup );
  return $nmdpLookup;
}
###
### This assumes that preprocessFile has been performed
### and all preprocessChecks have been performed.
###
sub _determineCellCompData {
  my qualityControl::Allele $this = shift;
  my ( $locus_data, $cell_comp ) = @_;

  my $msgs  = $this->{msgs};
  my $tools = $this->{tools};
  $tools->debugStruct( "locus_data", $locus_data );

  my $allelesLookup = $tools->getAllelesLookup;
  ###
  ### Create cell data
  ###
  my $cell_data = $this->createCellData( $locus_data, $cell_comp );
  ###
  ### Make searches case insensitive
  ###
  $cell_comp = uc($cell_comp);
  my $full_locus_name  = uc( $locus_data->{full_entity_name} );
  my $short_locus_name = uc( $locus_data->{short_locus_name} );
  my $alt_locus_name   = uc( $locus_data->{alt_locus_name} );
  ###
  ### There are two cases that are parsed separately and will
  ### be marked appropriately:
  ###
  ### 1.  Current nomenclature (3.*--name includes a colon (':')):
  ###     a.  allele name
  ###     b.  G-code
  ###     c.  P-code
  ###
  ### 2.  Other formats:
  ###     a.  NMDP-code (both version 2.* and version 3.*)
  ###     b.  allele group (with/without 'XX')
  ###
  $cell_data->{current} =
    ( $cell_comp =~ /:/ ) ? util::Constants::TRUE : util::Constants::FALSE;
  ###
  ### Categories of cell types:
  ###  - FULL_NAME     full allele name without suffix
  ###  - FULL_AGROUP   full allele group (with/without 'XX')
  ###  - FULL_SUFFIX   full allele name with suffix
  ###  - GCODE_NAME    imgt/hla g-code name
  ###  - PCODE_NAME    imgt/hla p-code name
  ###  - NMDP_NAME     nmdp name
  ###  - DIGIT_NAME    digit allele
  ###  - DIGIT_GCODE   digit imgt/hla gcode name
  ###  - DIGIT_PCODE   digit imgt/hla pcode name
  ###  - DIGIT_NMDP    digit nmdp name
  ###  - DIGIT_AGROUP  digit allele group (with/without 'XX')
  ###  - DIGIT_SUFFIX  digit allele with suffix
  ###
  my $errNum = undef;
  if ( $cell_data->{current} ) {
    ###
    ### Current Format (with colon--':')
    ###
    my $locus = undef;
    my $comps = $cell_comp;
    if ( $cell_comp =~
      /^($full_locus_name|$short_locus_name|$alt_locus_name)\*(.+)$/ )
    {
      $locus = $1;
      $comps = $2;
    }
    ###
    ### Must take care of version 3.* NMDP codes first
    ### since they have a special format
    ###
    if ( $comps =~ /^(\d+):([A-Z][A-Z]+)$/ ) {
      my $digits = $1;
      my $suffix = $2;
      my $nomen  = $cell_data->{nomen};
      $cell_data->{suffix} = $suffix;
      $nomen->{max_index}  = 0;
      $nomen->{max_comp}   = db::MhcTypes::ALLELE_GROUP_COL;
      $nomen->{&db::MhcTypes::ALLELE_GROUP_COL} = $digits;
      if (
        $this->nmdpLookup->nmdpKeyDefined( db::MhcTypes::IMGT_HLA_V3,
          $cell_data->{suffix}
        )
        )
      {

        if ( defined($locus) ) {
          $cell_data->{type} = NMDP_NAME;
        }
        else {
          $cell_data->{type} = DIGIT_NMDP;
        }
      }
      else {
        $errNum = 5;
      }
    }
    elsif ( !$this->generateNomenclature( $cell_data, $comps ) ) {
      $errNum = 3;
    }
    elsif ( defined($locus)
      && defined( $cell_data->{suffix} )
      && $cell_data->{suffix} eq 'G' )
    {
      $cell_data->{type} = GCODE_NAME;
    }
    elsif ( defined($locus)
      && defined( $cell_data->{suffix} )
      && $cell_data->{suffix} eq 'P' )
    {
      $cell_data->{type} = PCODE_NAME;
    }
    elsif ( !defined($locus)
      && defined( $cell_data->{suffix} )
      && $cell_data->{suffix} eq 'G' )
    {
      $cell_data->{type} = DIGIT_GCODE;
    }
    elsif ( !defined($locus)
      && defined( $cell_data->{suffix} )
      && $cell_data->{suffix} eq 'P' )
    {
      $cell_data->{type} = DIGIT_PCODE;
    }
    elsif ( defined($locus)
      && defined( $cell_data->{suffix} )
      && $allelesLookup->alleleSuffix( $cell_data->{suffix} ) )
    {
      $cell_data->{type} = FULL_SUFFIX;
    }
    elsif ( defined($locus) && !defined( $cell_data->{suffix} ) ) {
      $cell_data->{type} = FULL_NAME;
    }
    elsif ( !defined($locus)
      && defined( $cell_data->{suffix} )
      && $allelesLookup->alleleSuffix( $cell_data->{suffix} ) )
    {
      $cell_data->{type} = DIGIT_SUFFIX;
    }
    elsif ( !defined($locus) && !defined( $cell_data->{suffix} ) ) {
      $cell_data->{type} = DIGIT_NAME;
    }
    else {
      $errNum = 3;
    }
  }
  else {
    ###
    ### Allele Group (with/without 'XX') and
    ###
    ### erroneous version 2.* NMDP-code
    ###
    if ( $cell_comp =~
      /^($full_locus_name|$short_locus_name|$alt_locus_name)\*(\d+)XX$/ )
    {
      $cell_data->{digits} = $2;
      my $len = length( $cell_data->{digits} );
      if (
        ( $allelesLookup->isMIC( $cell_data->{name} ) && $len == 3 )
        || (!$allelesLookup->isMIC( $cell_data->{name} )
          && $len >= 2
          && $len <= 3 )
        )
      {
        $cell_data->{type}   = FULL_AGROUP;
        $cell_data->{agroup} = util::Constants::TRUE;
      }
      else {
        $errNum = 2;
      }
    }
    elsif ( $cell_comp =~
      /^($full_locus_name|$short_locus_name|$alt_locus_name)\*(\d+)([A-Z]+)$/ )
    {
      $cell_data->{digits} = $2;
      $cell_data->{suffix} = $3;
      if (
        $this->nmdpLookup->nmdpKeyDefined( db::MhcTypes::IMGT_HLA_V2,
          $cell_data->{suffix}
        )
        )
      {
        $cell_data->{type} = NMDP_NAME;
      }
      else {
        $errNum = 8;
      }
    }
    elsif ( $cell_comp =~
      /^($full_locus_name|$short_locus_name|$alt_locus_name)\*(\d+)$/ )
    {
      $cell_data->{digits} = $2;
      my $len = length( $cell_data->{digits} );
      if (
        ( $allelesLookup->isMIC( $cell_data->{name} ) && $len == 3 )
        || (!$allelesLookup->isMIC( $cell_data->{name} )
          && $len >= 2
          && $len <= 3 )
        )
      {
        $cell_data->{type}   = FULL_AGROUP;
        $cell_data->{agroup} = util::Constants::TRUE;
      }
      else {
        $errNum = 2;
      }
    }
    elsif ( $cell_comp =~ /^(\d+)XX$/ ) {
      $cell_data->{digits} = $1;
      my $len = length( $cell_data->{digits} );
      if ( ( $allelesLookup->isMIC( $cell_data->{name} ) && $len == 3 )
        || ( !$allelesLookup->isMIC( $cell_data->{name} ) && $len >= 2 ) )
      {
        $cell_data->{type}   = DIGIT_AGROUP;
        $cell_data->{agroup} = util::Constants::TRUE;
      }
      else {
        $errNum = 2;
      }
    }
    elsif ( $cell_comp =~ /^(\d+)([A-Z]+)$/ ) {
      $cell_data->{digits} = $1;
      $cell_data->{suffix} = $2;
      if (
        $this->nmdpLookup->nmdpKeyDefined( db::MhcTypes::IMGT_HLA_V2,
          $cell_data->{suffix}
        )
        )
      {
        $cell_data->{type} = DIGIT_NMDP;
      }
      else {
        $errNum = 8;
      }
    }
    elsif ( $cell_comp =~ /^(\d+)$/ ) {
      $cell_data->{digits} = $1;
      my $len = length( $cell_data->{digits} );
      if ( ( $allelesLookup->isMIC( $cell_data->{name} ) && $len == 3 )
        || ( !$allelesLookup->isMIC( $cell_data->{name} ) && $len >= 2 ) )
      {
        $cell_data->{type}   = DIGIT_AGROUP;
        $cell_data->{agroup} = util::Constants::TRUE;
      }
      else {
        $errNum = 2;
      }
    }
    else {
      $errNum = 9;
    }
  }
  ###
  ### Final Check -- Is the cell typed?
  ###
  $cell_data->{checks} =
    !defined( $cell_data->{type} )
    ? util::Constants::FALSE
    : $cell_data->{checks};
  $msgs->registerError(
    ERR_CAT, $errNum,
    [ $full_locus_name, $cell_data->{cell}, ],
    !$cell_data->{checks}
  );
  return $cell_data;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my qualityControl::Allele $this = shift;
  my ( $file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{ambiguous_allele_separator} =
    db::MhcTypes::STANDARD_AMBIGUOUS_ALLELE_SEPARATOR;

  $this->{error_mgr}        = $error_mgr;
  $this->{nomen_ord}        = db::MhcTypes::NOMENCLATURE_ORDER;
  $this->{out_file}         = undef;
  $this->{population_area}  = undef;
  $this->{population_areas} = {};
  $this->{population_col}   = undef;
  $this->{queries}          = DB_QUERIES;
  $this->{reader}           = $file_reader;
  $this->{tools}            = $tools;
  $this->{write_msgs}       = $tools->getProperty( $tools->WRITE_MSGS_PROP );

  $this->{lookup} = new qualityControl::Lookup( $taxon_id, $tools, $error_mgr );

  $this->_getPopAreaData;

  $this->{msgs} =
    new util::Messaging( $file_reader, $taxon_id, $this->{write_msgs}, $tools,
    $error_mgr );

  return $this;
}

sub processFile {
  my qualityControl::Allele $this = shift;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}
    ->printDebug("Abstract Method:  qualityControl::Allele::processFile");
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setOutFile {
  my qualityControl::Allele $this = shift;
  my ($outFile) = @_;
  ###
  ### Check for '.txt' since the file will contain tab-separated data
  ###
  my $file_error = $outFile !~ /\.txt$/;
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$outFile], $file_error );
  return if ($file_error);

  $this->{out_file} = getPath($outFile);
}

sub setPopulationArea {
  my qualityControl::Allele $this = shift;
  my ($populationArea) = @_;

  $this->{population_area} = $this->{population_areas}->{ lc($populationArea) };
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub outFile {
  my qualityControl::Allele $this = shift;
  return $this->{out_file};
}

sub getAmbiguousAlleleSeparator {
  my qualityControl::Allele $this = shift;
  return $this->{ambiguous_allele_separator};
}

################################################################################
#
#				Other Public Methods
#
################################################################################

sub preprocessFile {
  my qualityControl::Allele $this = shift;

  my $reader = $this->{reader};
  ###
  ### read the file and preprocess it
  ###
  my $emptyVal = $reader->getEmptyVal;
  foreach my $entity ( $reader->getData ) {
    foreach my $locus_col ( $reader->getEntityCols ) {
      my $locus_data       = $reader->getEntityData($locus_col);
      my $full_locus_name  = uc( $locus_data->{full_entity_name} );
      my $short_locus_name = uc( $locus_data->{short_locus_name} );
      my $alt_locus_name   = uc( $locus_data->{alt_locus_name} );
      ###
      ### 1.  Upper-case and remove whitespace
      ###
      my $cell = uc( strip_whitespace( $entity->{$locus_col} ) );
      ###
      ### If there is nothing, there replace it with the
      ### standard empty value
      ###
      if ( $reader->emptyCell($cell) ) {
        $entity->{$locus_col} = $emptyVal;
        next;
      }
      ###
      ### Separate cell based on separator ('/', '\', ',', or ' +')
      ###
      ### NOTE:  colon (':') is no longer permitted as an allele separator
      ###
      my @comps = ($cell);
      if    ( $cell =~ /\// ) { @comps = split( /\//, $cell ); }
      elsif ( $cell =~ /\\/ ) { @comps = split( /\\/, $cell ); }
      elsif ( $cell =~ /,/ )  { @comps = split( /,/,  $cell ); }
      elsif ( $cell =~ / / )  { @comps = split( / +/, $cell ); }
      ###
      ### For each component:
      ### 1.  strip white-space
      ### 2.  remove locus name, if present
      ### 3.  remove initial asterisk ('*'), if present
      ###
      my $cell_checks = util::Constants::TRUE;
      foreach my $index ( 0 .. $#comps ) {
        my $comp = strip_whitespace( $comps[$index] );
        if ( $comp =~
          /^($full_locus_name|$short_locus_name|$alt_locus_name)\*(.+)$/ )
        {
          $comp = $2;
        }
        elsif ( $comp =~ /^\*(.+)$/ ) {
          $comp = $1;
        }
        $comps[$index] = $comp;
      }
      ###
      ### reconstitute the cell using the standard separator, as necessary
      ###
      $entity->{$locus_col} =
        join( $this->{ambiguous_allele_separator}, @comps );
    }
  }
}

sub createCellData {
  my qualityControl::Allele $this = shift;
  my ( $locus_data, $cell ) = @_;
  return {
    current  => util::Constants::FALSE,
    alt      => $locus_data->{alt_locus_name},
    cell     => $cell,
    checks   => util::Constants::TRUE,
    digits   => undef,
    full     => $locus_data->{full_entity_name},
    locus_id => $locus_data->{locus_id},
    name     => $locus_data->{short_locus_name},
    agroup   => util::Constants::FALSE,
    suffix   => undef,
    type     => undef,
    nomen    => {
      max_index                            => -1,
      max_comp                             => undef,
      &db::MhcTypes::ALLELE_GROUP_COL      => undef,
      &db::MhcTypes::HLA_PROTEIN_COL       => undef,
      &db::MhcTypes::CODING_REGION_COL     => undef,
      &db::MhcTypes::NON_CODING_REGION_COL => undef,
    },
  };
}

sub copyCellData {
  my qualityControl::Allele $this = shift;
  my ($cell_data) = @_;

  return $cell_data if ( !$cell_data->{current} );
  my $locus_data = {
    alt_locus_name   => $cell_data->{alt},
    full_entity_name => $cell_data->{full},
    locus_id         => $cell_data->{locus_id},
    short_locus_name => $cell_data->{name},
  };
  my $copy_cell_data = $this->createCellData( $locus_data, undef );
  $copy_cell_data->{current} = util::Constants::TRUE;
  return $copy_cell_data;
}

sub generateNomenclature {
  my qualityControl::Allele $this = shift;
  my ( $cell_data, $comps ) = @_;

  my $msgs = $this->{msgs};
  my @comps = split( /:/, $comps );
  my $comp_error =
    ( scalar @comps > scalar @{ $this->{nomen_ord} } )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  return !$comp_error if ($comp_error);

  $cell_data->{nomen}->{max_index} = $#comps;
  $cell_data->{nomen}->{max_comp}  = $this->{nomen_ord}->[$#comps];
  foreach my $index ( 0 .. $#comps ) {
    my $name  = $this->{nomen_ord}->[$index];
    my $comp  = $comps[$index];
    my $error = ( $index < $#comps && $comp !~ /^\d+$/ )
      || ( $index == $#comps && $comp !~ /^\d+[A-Z]?$/ );
    return !$error if ($error);

    $comp =~ /^(\d+)([A-Z]?)$/;
    my $digits = $1;
    my $suffix = $2;
    $cell_data->{nomen}->{$name} = $digits;
    if ( $index == $#comps
      && !util::Constants::EMPTY_LINE($suffix) )
    {
      $cell_data->{suffix} = $suffix;
    }
  }
  return util::Constants::TRUE;
}

sub generateCompName {
  my qualityControl::Allele $this = shift;
  my ($cell_data) = @_;

  my $compName = undef;
  if ( $cell_data->{current} ) {
    my $colon_name = util::Constants::EMPTY_STR;
    foreach my $index ( 0 .. $cell_data->{nomen}->{max_index} ) {
      if ( $index > 0 ) { $colon_name .= util::Constants::COLON; }
      $colon_name .= $cell_data->{nomen}->{ $this->{nomen_ord}->[$index] };
      if ( $cell_data->{type} eq NMDP_NAME
        || $cell_data->{type} eq DIGIT_NMDP )
      {
        $colon_name .= util::Constants::COLON;
      }
    }
    $compName = join( util::Constants::ASTERISK,
      $cell_data->{name}, $colon_name . $cell_data->{suffix} );
  }
  else {
    $compName = join( util::Constants::ASTERISK,
      $cell_data->{name}, $cell_data->{digits} . $cell_data->{suffix} );
  }
  return $compName;
}

sub preprocessChecks {
  my qualityControl::Allele $this = shift;
  my ( $locus_data, $allele_name ) = @_;
  ###############################
  ### RE-IMPLEMENTABLE Method ###
  ###############################
  ###
  ### Default action:  return TRUE (NO-OP)
  ###
  return util::Constants::TRUE;
}

sub determineComps {
  my qualityControl::Allele $this = shift;
  my ( $locus_col, $entity ) = @_;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};

  my $cell       = $entity->{$locus_col};
  my $locus_data = $reader->getEntityData($locus_col);
  my @comps      = ();
  return @comps if ( $reader->emptyCell($cell) );
  ###
  ### Separate cell based on the standard separator
  ###
  @comps = ($cell);
  my $ambiguous_allele_separator = $this->{ambiguous_allele_separator};
  if ( $cell =~ /$ambiguous_allele_separator/ ) {
    @comps = split( /$ambiguous_allele_separator/, $cell );
  }
  ###
  ### compute components
  ###
  my @new_comps = ();
  foreach my $comp (@comps) {
    ###
    ### Based on the pre-process check, determine
    ### if need to proceed with allele
    ###
    my $preprocessChecks = $this->preprocessChecks( $locus_data, $comp );
    push( @new_comps, undef ) if ( !$preprocessChecks );
    next if ( !$preprocessChecks );
    ###
    ### Now parse the allele and check to see
    ### if there is a syntax error
    ###
    my $comp = $this->_determineCellCompData( $locus_data, $comp );
    push( @new_comps, undef ) if ( !$comp->{checks} );
    push( @new_comps, $comp ) if ( $comp->{checks} );
  }
  return @new_comps;
}

sub alleleData {
  my qualityControl::Allele $this = shift;
  my ($cell_data) = @_;

  my $struct = {
    locus    => undef,
    allele   => undef,
    data     => undef,
    type     => undef,
    gcode    => undef,
    pcode    => undef,
    cwd      => undef,
    rare     => undef,
    reg      => undef,
    reg_cwd  => undef,
    reg_rare => undef,
    reg_freq => 0,
  };
  ###
  ### create allele data for an undefined cell
  ###
  if ( !defined($cell_data) ) {
    $struct->{allele} = $this->{reader}->getEmptyVal;
    return $struct;
  }
  ###
  ### Compute the allele data for a defined value
  ###
  my $allele = $this->generateCompName($cell_data);
  my $lookup = $this->{lookup};
  my $msgs   = $this->{msgs};
  ###
  ### Must check that the data in current format,
  ### this is an error since validation will
  ### have removed any non-current formats.
  ###
  if ( !$cell_data->{current} ) {
    $msgs->registerError( ERR_CAT, 4, [$allele], util::Constants::TRUE );
    return undef;
  }
  ###
  ### Check the data type
  ### 1.  GCODE_NAME or DIGIT_GCODE
  ### 2.  PCODE_NAME or DIGIT_PGROUP
  ### 3.  Allele
  my $cell_type = $cell_data->{type};
  my $locus     = $cell_data->{name};
  $struct->{locus}  = $locus;
  $struct->{allele} = $allele;
  $struct->{data}   = $cell_data;

  if ( $cell_type eq GCODE_NAME || $cell_type eq DIGIT_GCODE ) {
    $struct->{gcode} = $allele;
    $struct->{type}  = GCODE_TYPE;
  }
  elsif ( $cell_type eq PCODE_NAME || $cell_type eq DIGIT_PCODE ) {
    $struct->{pcode} = $allele;
    $struct->{type}  = PCODE_TYPE;
  }
  else {
    $struct->{type} = ALLELE_TYPE;

    my %allele_data =
      $lookup->getCwd( $allele, $lookup->CwdAllelesHlaProteinLookup );
    $struct->{cwd}  = $allele_data{cwd};
    $struct->{rare} = $allele_data{rare};

    %allele_data     = $lookup->getPAndGCode($allele);
    $struct->{gcode} = $allele_data{gcode};
    $struct->{pcode} = $allele_data{pcode};

    if ( defined( $this->{population_area} ) ) {
      %allele_data = $lookup->getRegionCwdRare( $this->{population_area},
        $cell_data->{full}, $allele );
      $struct->{reg} = $allele_data{reg};
      if ( $allele_data{reg} ) {
        $struct->{reg_cwd}  = $allele_data{reg_cwd};
        $struct->{reg_rare} = $allele_data{reg_rare};
      }
      $struct->{reg_freq} =
        $lookup->getRegionFrequency( $this->{population_area},
        $cell_data->{full}, $allele );
    }
  }

  return $struct;
}

sub determineOptionalCols {
  my qualityControl::Allele $this = shift;
  my (@entities) = @_;

  my $optCols = {};
  foreach my $opt_col (OPTIONAL_COLS) {
    my $opt_vals = {};
    foreach my $entity (@entities) {
      my $val = $entity->{"$opt_col"};
      next if ( util::Constants::EMPTY_LINE($val) );
      $opt_vals->{"$val"} = util::Constants::EMPTY_STR;
    }
    my @vals = keys %{$opt_vals};
    next if ( @vals != 1 );
    $optCols->{"$opt_col"} = $vals[0];
  }
  return $optCols;
}

sub removeErrors {
  my qualityControl::Allele $this = shift;
  my (@comps) = @_;

  my @new_comps = ();
  foreach my $comp (@comps) {
    next if ( !defined($comp) );
    push( @new_comps, $comp );
  }
  return @new_comps;
}

################################################################################
#
#			       Population Area Methods
#
################################################################################

sub populationAreaDefined {
  my qualityControl::Allele $this = shift;
  my ($populationArea) = @_;

  my $pop_areas = $this->{population_areas};
  return ( defined( $pop_areas->{ lc($populationArea) } ) )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

sub populationAreaName {
  my qualityControl::Allele $this = shift;
  my ($populationArea) = @_;

  my $pop_areas = $this->{population_areas};
  return $pop_areas->{ lc($populationArea) }
    if ( $this->populationAreaDefined($populationArea) );
  return $populationArea;
}

sub populationAreColumnMissing {
  my qualityControl::Allele $this = shift;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};
  ###
  ### First check to see that column exists
  ###
  my $foundCol = util::Constants::FALSE;
  foreach my $opt_col ( $reader->getOptCols ) {
    next if ( !db::MhcTypes::IS_POPULATION_AREA_COL($opt_col) );
    $foundCol = util::Constants::TRUE;
    $this->{population_col} = $opt_col;
    last;
  }
  $msgs->directRegisterError( ERR_CAT, 10, [], !$foundCol );
  return util::Constants::TRUE if ( !$foundCol );
  ###
  ### Now check to see that column contains data
  ###
  my $foundData = util::Constants::FALSE;
  foreach my $entity ( $reader->getData ) {
    next
      if (
      util::Constants::EMPTY_LINE( $entity->{ $this->{population_col} } ) );
    $foundData = util::Constants::TRUE;
    last;
  }
  $msgs->directRegisterError( ERR_CAT, 16, [], !$foundData );
  return !$foundData;
}

sub unknownPopulationArea {
  my qualityControl::Allele $this = shift;
  my ($entity) = @_;

  my $msgs           = $this->{msgs};
  my $reader         = $this->{reader};
  my $populationArea = $entity->{ $this->{population_col} };
  if ( util::Constants::EMPTY_LINE($populationArea) ) {
    $msgs->directRegisterError( ERR_CAT, 11,
      [ $entity->{ $reader->getIdCol }, $entity->{ $reader->ROW_ID_COL } ],
      util::Constants::TRUE );
    return util::Constants::TRUE;
  }
  return util::Constants::FALSE
    if ( $this->populationAreaDefined($populationArea) );

  $msgs->directRegisterError(
    ERR_CAT, 12,
    [
      $entity->{ $reader->getIdCol },
      $entity->{ $reader->ROW_ID_COL },
      $populationArea
    ],
    util::Constants::TRUE
  );
  return util::Constants::TRUE;
}

sub _sortRowNums { $a <=> $b; }

sub unknownPopulationAreaForGroup {
  my qualityControl::Allele $this = shift;
  my ( $id, @entities ) = @_;

  my $msgs              = $this->{msgs};
  my $reader            = $this->{reader};
  my %populationAreas   = ();
  my $unknownPopulation = util::Constants::FALSE;
  my @entityRowNums     = ();
  foreach my $entity (@entities) {
    push( @entityRowNums, $entity->{ $reader->ROW_ID_COL } );
    $unknownPopulation =
      $this->unknownPopulationArea($entity)
      ? util::Constants::TRUE
      : $unknownPopulation;
    my $populationArea =
      $this->populationAreaName( $entity->{ $this->{population_col} } );
    next if ( util::Constants::EMPTY_LINE($populationArea) );
    $populationAreas{$populationArea} = util::Constants::EMPTY_STR;
  }

  @entityRowNums = sort qualityControl::Allele::_sortRowNums @entityRowNums;
  my @populations = sort keys %populationAreas;
  $msgs->directRegisterError(
    ERR_CAT, 14,
    [ $id, join( util::Constants::COMMA_SEPARATOR, @entityRowNums ) ],
    scalar @populations == 0
  );
  $msgs->directRegisterError(
    ERR_CAT, 15,
    [
      $id,
      join( util::Constants::COMMA_SEPARATOR, @entityRowNums ),
      join( util::Constants::COMMA_SEPARATOR, @populations )
    ],
    scalar @populations > 1
  );

  return ( $unknownPopulation || @populations != 1 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

################################################################################

1;

__END__

=head1 NAME

AlleleValidator.pm

=head1 DESCRIPTION

This class defines an abstract class that is the base class for quality control tools.
The abstract method is L<"processFile">.  Also, this class contains a re-implementable 
method L<"preprocessChecks(locus_data, allele_name)">.

=head1 CONSTANTS

The following constants represent the component type where the
component does not contain a locus name:

   qualityControl::Allele::DIGIT_AGROUP -- digit_agroup (allele group)
   qualityControl::Allele::DIGIT_GCODE  -- digit_gcode  (IMGT/HLA G-Code)
   qualityControl::Allele::DIGIT_NAME   -- digit        (without suffix)
   qualityControl::Allele::DIGIT_NMDP   -- digit_nmdp   (NMDP-Code)
   qualityControl::Allele::DIGIT_PCODE  -- digit_pcode  (IMGT/HLA P-Code)
   qualityControl::Allele::DIGIT_SUFFIX -- digit_suffix (with suffix)

The following constants represent the component type where the
component contains a locus name:

   qualityControl::Allele::FULL_AGROUP  -- agroup       (allele group)
   qualityControl::Allele::FULL_NAME    -- full         (without suffix)
   qualityControl::Allele::FULL_SUFFIX  -- suffix       (with suffix)
   qualityControl::Allele::GCODE_NAME   -- gcode        (IMGT/HLA G-Code)
   qualityControl::Allele::NMDP_NAME    -- nmdp         (NMDP-Code)
   qualityControl::Allele::PCODE_NAME   -- pcode        (IMGT/HLA P-Code)

The following constants define the type of allele for ambiguity reduction:

   qualityControl::Allele::ALLELE_TYPE -- allele
   qualityControl::Allele::GCODE_TYPE  -- gcode (IMGT/HLA G-Code)
   qualityControl::Allele::PCODE_TYPE  -- pcode (IMGT/HLA P-Code)

=head1 METHODS

The following methods are exported by this class.

=head2 B<new qualityControl::Allele(file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.  The B<file_reader> is the file reading
object that is a subclass of L<file::Mhc>.

This method also determines the set of population areas defined in the
controlled vocabulary for population areas including including both
full names and abbreviations.

=head2 B<processFile>

This abstract method processes the file according to the subclass.

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setPopulationArea(population_area)>

This method sets the population_area attribute.

=head2 B<setOutFile(outFile)>

This method sets the output file for generating the results of
processing the file.  The file suffix for this file is B<'.txt'>.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$out_file = outFile>

This method returns the output file that has been set.

=head2 B<$ambiguous_separator = getAmbiguousAlleleSeparator>

This method returns the standard ambiguous allele separator
symbol ('/').

=head1 OTHER PUBLIC METHODS

The following methods are exported by this class.

=head2 B<preprocessFile>

This method pre-processes each locus column for each data entity.  It
performs the following actions on the locus cell:

   1.  Upper-case contents
   2.  Strip white-space left and right
   3.  Separate the contents of the cell into ambiguous alleles
       based on a separator ('/', '\', ' ', or ' +') identified in
       the cell
   4.  Removes whitespace left and right from each component
   5.  Removes the appropriate locus designator (e.g., HLA-A*, or A*,
       HLA-C*, or Cw*, or C*) for each component, as needed
   6.  Remove initial asterisk ('*'), if present
   7.  Reconstitutes the cell using the standard ambiguous allele
       separator ('/')

=head2 B<$cell_data = createCellData(locus_data, cell)>

This method generates cell data-structure which is a referenced Perl
hash containing the following components:

    current  - Boolean indicating IMGT/HLA version 3 TRUE (1)
               or version 2 FALSE (0)--intially FALSE
    alt      - alternate locus name (locus_data->{alt_locus_name})
    cell     - cell component (cell)
    checks   - Boolean indicating the the cells check sytactically
               --initially TRUE (1)
    digits   - digit portion of the cell if IMGT/HLA version 2
    full     - full locus name (locus_data->{full_entity_name})
    locus_id - locus ID (locus_data->{locus_id})
    name     - short locus name (locus_data->{short_locus_name})
    agroup   - Boolean indicating whether cell is allele group
               --intially FALSE (0)
    suffix   - suffix of cell if there is one
    type     - cell enumeration type--initiall undef
                  without locus:
                    digit_agroup (allele group)
                    digit_gcode  (IMGT/HLA G-Code)
                    digit        (without suffix)
                    digit_nmdp   (NMDP-Code)
                    digit_pcode  (IMGT/HLA P-Code)
                    digit_suffix (with suffix)
                  with locus:
                    agroup       (allele group)
                    full         (without suffix)
                    suffix       (with suffix)
                    gcode        (IMGT/HLA G-Code)
                    nmdp         (NMDP-Code)
                    pcode        (IMGT/HLA P-Code)
    nomen    - referenced Perl hash with the following components
               to contain the allele field categories for IMGT/HLA
               version 3 data
                 max_index         - the maximum category index (0..3)
                                     --initial -1
                 max_comp          - the maximum category name
                                       allele_group
                                       hla_protein
                                       coding_region
                                       non_coding_region
                 allele_group      - allele group category field
                 hla_protein       - HLA protein category field
                 coding_region     - coding region category field
                 non_coding_region - non-coding region category field

=head2 B<$copied_cell_data = copyCellData(cell_data)>

This method copies the B<cell_data> data-structure if B<current> is
TRUE (1), otherwise it returns the cell_data 'as-is'.  This method
assumes that the cell_data data-structure is created using
L<"$cell_data = createCellData(locus_data, cell)">.
The method recreates a cell data data-structure and copies the
following components from B<cell_data> into the copy: current, alt, full,
locus_id, and name.  It also sets B<checks> to TRUE (1).

=head2 B<generateNomenclature(cell_data, comps)>

This method determines B<nomen> component data-structure and the
B<suffix> component for the B<cell_data>.  This method assumes that
the cell_data data-structure is created using 
L<"$cell_data = createCellData(locus_data, cell)">.
The B<comps> is an IMGT/HLA
version 3 allele name without the locus prefix.  This method then
decomposes the B<comp> into its category fields and sets both
B<max_index> and B<max_comp> in B<nomen>.  Finally, it sets the
B<suffix> component of the cell_data if comps has a suffix.  If the
method successfully parses the comps, it return TRUE (1), otherwise it
returns FALSE (0).

=head2 B<$comp_name = generateCompName(cell_data)>

This method returns the full name of the cell_data either as IMGT/HLA
version 3 allele or an IMGT/HLA version 2 allele as determined by the
B<current> key.  If the cell_data is current (TRUE (1)), then the cell_data
is returned in IMGT/HLA version 3 allele notation:

   <name>*<allele_group>[:<hla_protein>[:<coding_region>[:<non_coding_region]][suffix]]

or as version 3 NMDP-Code:

   <name>*<allele_group>[:<suffix>

If the cell_data is not current (FALSE (0)), then the entity is returned as follows:

   <name>*<digits><suffix>

=head2 B<preprocessChecks(locus_data, allele_name)>

This re-implementable method return a Boolean indicating whether the
pre-process checks are successfully (TRUE (1)) or not (FALSE (0)) for
the given B<locus_data> and B<allele_name>.  The default for the
method is TRUE (1).

=head2 B<@comps = determineComps(locus_col, entity)>

This method returns the list of cell component data-structures for a
cell defined by the B<locus_col> in the B<entity>.  The B<entity> is a
referenced Perl hash representing a row data from the reader.  The
cell is split into its components using slash ('/') as the separator.
Each component is checked by L<"preprocessChecks(locus_data, allele_name)">.
If this fails, an B<undef> is added to the B<@comps> list of it.  The
component is then parsed and checked syntactically.  If there are any
errors associated with the parse, then B<undef> is added to B<@comps>
list for it.  Otherwise, if the component successfully passes the
preprocess checks and parsing, it will have a B<cell_data>
data-structure generated and filled in for it (see 
L<"$cell_data = createCellData(locus_data, cell)">.
This method assumes that L<"preprocessFile"> has been performed on the
file.

=head2 B<$allele_data = alleleData(cell_data)>

This method generates a data-structure for the given B<cell_data>
data-structure (see
L<"$cell_data = createCellData(locus_data, cell)">).
The data-structure generated by this method is a referenced Perl hash
with the following components:

   locus    - the short locus name of the cell_data
   allele   - the full name of the cell_data using generateCompName
   data     - reference to the cell_data
   type     - enumerated type of the allele
                allele - IMGT/HLA version 3 allele
                gcode  - IMGT/HLA G-Code
                pcode  - IMGT/HLA P-Code
   gcode    - the IMGT/HLA G-Code for the cell_data, if any
   pcode    - the IMGT/HLA P-Code for the cell_data, if any
   The following components only are evaluated for type == 'allele'
   cwd      - Boolean indicating whether the allele is CWD or not,
   rare     - Boolean indicating whether the allele is Rare or not,
   reg      - Boolean indicating whether the allele is region-specific
              or not
   reg_cwd  - Boolean indicating reg-CWD if the allele is region-specific,
              undef otherwise
   reg_rare - Boolean indicating reg-Rare if the allele is region-specific,
              undef otherwise
   reg_freq - The region frequency for the allele (if it unknown, then
              it is zero (0))

If the B<cell_data> is B<undef>, then this method returns the above
data_structure with only the B<allele> component evaluated as an empty
cell value.  If the B<cell_data> is not current (FALSE (0)), then an
error is registered and B<undef> is returned.

Note: The Global and Region cwd and rare statuses assume that the
cell_data allele is peptide-level allele.

=head2 B<@reduced_comps = removeErrors(@comps)>

This method removes the components that are B<undef> from the
B<@comps> list and returns the list with only defined components.  An
undef indicates an error component.

=head1 POPULATION AREA METHODS

The following population area specific methods are exported.

=head2 B<populationAreaDefined(population_area)>

This method determines if the population_area is a defined population
area either by full name or abbreviation in a case-insensitive manner.
If the population area is defined, it returns TRUE (1), othewise it
returns FALSE (0).

=head2 B<$population_area = populationAreaName(population_area)>

This method returns the population area name in the controlled
vocabulary for the B<population_area> if it is defined in the
vocabulary.  Otherwise, it returns the B<population_area>
'as-is'.

=head2 B<populationAreColumnMissing>

This method determines if the 'Population Area' column is missing or
or not in a case-insensitive manner in the file that is being read.
If the column is missing, the TRUE (1) is returned.  Further, this
method determines if the column contains data or not. If there is no
data in the column, then TRUE (1) is returned, otherwise FALSE (0) is
returned.  Also, any error encountered are registered.

=head2 B<unknownPopulationArea(entity)>

This method returns a Boolean indicating whether or not the
B<population_area> component of the entity is defined and in the
controlled vocabulary of population areas.  If it is not defined or
not in the controlled vocabulary, then TRUE (0) is returned, otherwise
FALSE (0) is returned.  Also, any error encountered are registered.

=head2 B<unknownPopulationAreaForGroup(id, @identities)>

This method determined whether the group of entities @entities has a
common defined population area that is also in the controlled
vocabulary for population areas.  If there is no such population area
for the group, then TRUE (0) is returned, otherwise FALSE (0) is
returned.   Also, any error encountered are registered.

=cut

