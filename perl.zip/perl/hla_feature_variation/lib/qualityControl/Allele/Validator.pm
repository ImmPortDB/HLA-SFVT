package qualityControl::Allele::Validator;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use Pod::Usage;

use antt::Runner;

use db::MhcTypes;

use util::Constants;

use qualityControl::ErrMsgs;

use base 'qualityControl::Allele';

use fields qw (
  antt
  current_alleles
  failed_alleles
  valid_alleles
  valid_current_alleles
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Err Msg Segmentation
###
sub NUM_CHAR_PER_SEGMENT { return 50; }
sub PREFIX_PER_SEGMENT   { return "\n               "; }
###
### Error Category
###
sub ERR_CAT { return qualityControl::ErrMsgs::ALLELEVALIDATOR_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _checkDeletedAllele {
  my qualityControl::Allele::Validator $this = shift;
  my ( $allele, $cell_data ) = @_;

  my $lookup = $this->{lookup};
  my $msgs   = $this->{msgs};

  $cell_data->{replaced} = undef;
  my $dallele = join( util::Constants::ASTERISK, $cell_data->{name}, $allele );
  my $deletedLookup  = $lookup->getLookupTable( $lookup->DeletedNamesLookup );
  my $allele_deleted = $deletedLookup->keyDefined($dallele);
  ###
  ### Check to see if allele is deleted
  ###
  return util::Constants::FALSE if ( !$allele_deleted );
  $msgs->incStatistic(
    $msgs->dataTypeCounter, $msgs->locusNameTag,
    $msgs->getLocusName,    $msgs->dataTypeTag,
    $msgs->deletedNameTagValue
  );
  ###
  ### Now determine replacements for deleted allele
  ###
  my $replaceLookup = $lookup->getLookupTable( $lookup->ReplacementAlleles );
  my @alleles       = $replaceLookup->getValue($dallele);
  ###
  ### Check to see if there are replacements
  ###
  $msgs->registerError( ERR_CAT, 6, [$allele], scalar @alleles == 0 );
  if ( scalar @alleles == 0 ) {
    $cell_data->{checks} = util::Constants::FALSE;
    return util::Constants::TRUE;
  }
  ###
  ### At this point, we can use the replacements
  ###
  $msgs->addNote( "Allele has been deleted\n"
      . "  locus           = "
      . $cell_data->{full} . "\n"
      . "  deleted allele     = $allele\n"
      . "  replaced allele(s) = ("
      . join( util::Constants::COMMA_SEPARATOR, @alleles )
      . ")" );
  $cell_data->{replaced} = [@alleles];
  return util::Constants::TRUE;
}

sub _processVersion2Allele {
  my qualityControl::Allele::Validator $this = shift;
  my ( $allele, $cell_data ) = @_;
  ###
  ### Now convert only version 2 format data to version 3 format
  ###
  my $imgt_hla_version = (
    !$cell_data->{current} && ( $cell_data->{type} eq $this->NMDP_NAME
      || $cell_data->{type} eq $this->DIGIT_NMDP )
  ) ? db::MhcTypes::IMGT_HLA_V2 : db::MhcTypes::IMGT_HLA_V3;
  return if ( $imgt_hla_version == db::MhcTypes::IMGT_HLA_V3 );

  my $lookup = $this->{tools}->getAllelesLookup;
  $cell_data->{replaced} = [
    $lookup->convertAllele( $cell_data->{name}, $allele, $imgt_hla_version ) ];
}

sub _validateAllele {
  my qualityControl::Allele::Validator $this = shift;
  my ( $allele, $cell_data ) = @_;

  my $tools = $this->{tools};
  ###
  ### Initialize checks
  ###
  $cell_data->{checks} = util::Constants::TRUE;
  ###
  ### Determine if allele has been deleted
  ###
  return if ( $this->_checkDeletedAllele( $allele, $cell_data ) );

  my $imgt_hla_version = (
    !$cell_data->{current} && ( $cell_data->{type} eq $this->NMDP_NAME
      || $cell_data->{type} eq $this->DIGIT_NMDP )
  ) ? db::MhcTypes::IMGT_HLA_V2 : db::MhcTypes::IMGT_HLA_V3;

  my $allelesLookup = $tools->getAllelesLookup;
  my @alleles_found = $allelesLookup->getAlleles( $cell_data->{locus_id},
    $allele, $imgt_hla_version );
  ###
  ### If there are no alleles, then the allele
  ### does not exist in the given version.
  ###
  if ( @alleles_found == 0 ) {
    $cell_data->{checks} = util::Constants::FALSE;
    return;
  }
  ###
  ### Now that there is at least one allele in the list
  ### implies that the allele does exist in the version
  ### and we can return successfully
  ###
  $this->_processVersion2Allele( $allele, $cell_data );
}

sub _validateAlleleGroup {
  my qualityControl::Allele::Validator $this = shift;
  my ($cell_data) = @_;
  ###
  ### Record the allele group
  ###
  my $msgs = $this->{msgs};
  $msgs->incStatistic(
    $msgs->dataTypeCounter, $msgs->locusNameTag,
    $msgs->getLocusName,    $msgs->dataTypeTag,
    $msgs->alleleGroupTagValue
  );
  ###
  ### Check to see if allele group has already appreard
  ###
  my $locus_name     = $cell_data->{name};
  my $currentAlleles = $this->{current_alleles};
  my $failedAlleles  = $this->{failed_alleles}->{$locus_name};
  my $validAlleles   = $this->{valid_alleles}->{$locus_name};

  my $allele_group =
    join( util::Constants::ASTERISK, $locus_name, $cell_data->{digits} );
  return if ( defined( $failedAlleles->{$allele_group} ) );

  if ( defined( $validAlleles->{$allele_group} ) ) {
    $currentAlleles->{$allele_group} = util::Constants::EMPTY_STR;
  }
  else {
    $this->_validateAllele( $cell_data->{digits}, $cell_data );
    if ( !$cell_data->{checks} ) {
      $msgs->registerError(
        ERR_CAT, 4,
        [ $cell_data->{name}, $cell_data->{digits} . $cell_data->{suffix} ],
        !$cell_data->{checks}
      );
      $failedAlleles->{$allele_group} = util::Constants::EMPTY_STR;
    }
    else {
      $validAlleles->{$allele_group}   = util::Constants::EMPTY_STR;
      $currentAlleles->{$allele_group} = util::Constants::EMPTY_STR;
    }
  }
}

sub _validateCurrentAllele {
  my qualityControl::Allele::Validator $this = shift;
  my ($cell_data) = @_;

  my $lookup = $this->{lookup};
  ###
  ### Add current allele and check to see if it has already appeared
  ###
  my $allele     = $this->generateCompName($cell_data);
  my $locus_name = $cell_data->{name};

  my $currentAlleles      = $this->{current_alleles};
  my $validAlleles        = $this->{valid_alleles}->{$locus_name};
  my $validCurrentAlleles = $this->{valid_current_alleles}->{$locus_name};
  ###
  ### Set the allele sets
  ###
  return if ( defined( $validCurrentAlleles->{$allele} ) );
  $currentAlleles->{$allele}      = util::Constants::EMPTY_STR;
  $validCurrentAlleles->{$allele} = util::Constants::EMPTY_STR;
  $validAlleles->{$allele}        = util::Constants::EMPTY_STR;
  ###
  ### Now check the CWD status for current allele
  ###
  my $nomen   = $cell_data->{nomen};
  my %cwdData = undef;
  if ( $nomen->{max_comp} eq db::MhcTypes::HLA_PROTEIN_COL ) {
    %cwdData = $lookup->getCwd( $allele, $lookup->CwdAllelesHlaProteinLookup );
  }
  elsif ( $nomen->{max_comp} eq db::MhcTypes::CODING_REGION_COL ) {
    %cwdData =
      $lookup->getCwd( $allele, $lookup->CwdAllelesCodingRegionLookup );
  }
  else {
    %cwdData = $lookup->getCwd( $allele, $lookup->CwdAllelesLookup );
  }
  my $full_length = undef;
  if ($cwdData{cwd} && $allele ne $cwdData{full_length}) {
    $full_length = $cwdData{full_length};
  }
  my $msgs = $this->{msgs};
  $msgs->addDataCapture( $cwdData{cwd} ? $msgs->CWD_TABLE : $msgs->RARE_TABLE,
    $allele, $full_length );
  $msgs->incStatistic( $msgs->cwdCounter, $msgs->locusNameTag,
      $msgs->getLocusName, $msgs->cwdTag, $cwdData{cwd}
    ? $msgs->cwdAlleleTagValue
    : $msgs->rareAlleleTagValue );
}

sub _validateImgtHlaCode {
  my qualityControl::Allele::Validator $this = shift;
  my ($cell_data) = @_;

  my $msgs = $this->{msgs};
  my $type = $cell_data->{type};
  $msgs->incStatistic(
    $msgs->dataTypeCounter, $msgs->locusNameTag, $msgs->getLocusName,
    $msgs->dataTypeTag,     $msgs->gCodeTagValue
  ) if ( $type eq $this->DIGIT_GCODE || $type eq $this->GCODE_NAME );
  $msgs->incStatistic(
    $msgs->dataTypeCounter, $msgs->locusNameTag, $msgs->getLocusName,
    $msgs->dataTypeTag,     $msgs->pCodeTagValue
  ) if ( $type eq $this->DIGIT_PCODE || $type eq $this->PCODE_NAME );
  ###
  ### code is valid
  ###
  my $locus_name     = $cell_data->{name};
  my $code           = $this->generateCompName($cell_data);
  my $currentAlleles = $this->{current_alleles};
  my $validAlleles   = $this->{valid_alleles}->{$locus_name};
  $validAlleles->{$code}   = util::Constants::EMPTY_STR;
  $currentAlleles->{$code} = util::Constants::EMPTY_STR;
}

sub _validateNmdpCode {
  my qualityControl::Allele::Validator $this = shift;
  my ($cell_data) = @_;

  my $lookup = $this->{lookup};
  my $msgs   = $this->{msgs};
  my $tools  = $this->{tools};

  my $nmdp_code  = $this->generateCompName($cell_data);
  my $locus_name = $cell_data->{name};

  my $currentAlleles = $this->{current_alleles};
  my $failedAlleles  = $this->{failed_alleles}->{$locus_name};
  my $validAlleles   = $this->{valid_alleles}->{$locus_name};

  $msgs->incStatistic(
    $msgs->dataTypeCounter, $msgs->locusNameTag, $msgs->getLocusName,
    $msgs->dataTypeTag,     $msgs->nmdpCodeTagValue
  );
  ###
  ### return if this is a failed NMDP code
  ###
  return if ( defined( $failedAlleles->{$nmdp_code} ) );
  ###
  ### if this is a valid NMDP code set current alleles
  ### and return immediately
  ###
  if ( defined( $validAlleles->{$nmdp_code} ) ) {
    foreach my $lallele ( @{ $validAlleles->{$nmdp_code} } ) {
      $currentAlleles->{$lallele} = util::Constants::EMPTY_STR;
    }
    return;
  }
  ###
  ### Now determine if NMDP code is valid
  ###
  ### Return immediately if it is not
  ###
  my $nmdpLookup = $lookup->getLookupTable( $lookup->NmdpCodesLookup );
  my @alleles    = $nmdpLookup->getNmdpAlleles($nmdp_code);
  $cell_data->{checks} =
    ( @alleles == 0 ) ? util::Constants::FALSE : $cell_data->{checks};
  if ( !$cell_data->{checks} ) {
    $msgs->registerError(
      ERR_CAT, 3,
      [
        $cell_data->{name},
        $nmdp_code,
        $cell_data->{suffix},
        join( util::Constants::COMMA_SEPARATOR,
          $nmdpLookup->getValue( $cell_data->{suffix} ) )
      ],
      !$cell_data->{checks}
    );
    $failedAlleles->{$nmdp_code} = util::Constants::EMPTY_STR;
    return;
  }
  ###
  ### Now validate each of the alleles
  ### from the expanded NMDP code
  ###
  my @failedNmdpAlleles = ();
  my $validNmdpAlleles  = [];
  foreach my $allele (@alleles) {
    my $lallele = join( util::Constants::ASTERISK, $locus_name, $allele );
    if ( defined( $failedAlleles->{$lallele} ) ) {
      push( @failedNmdpAlleles, $allele );
      next;
    }
    if ( defined( $validAlleles->{$lallele} ) ) {
      if ( ref( $validAlleles->{$lallele} ) eq $tools->serializer->ARRAY_TYPE )
      {
        foreach my $rallele ( @{ $validAlleles->{$lallele} } ) {
          $currentAlleles->{$rallele} = util::Constants::EMPTY_STR;
          push( @{$validNmdpAlleles}, $rallele );
        }
      }
      else {
        $currentAlleles->{$lallele} = util::Constants::EMPTY_STR;
        push( @{$validNmdpAlleles}, $lallele );
      }
      next;
    }
    ###
    ### must validate allele component
    ### If not valid then go set failed alleles
    ### and go to next allele
    ###
    $this->_validateAllele( $allele, $cell_data );
    if ( !$cell_data->{checks} ) {
      $failedAlleles->{$lallele} = util::Constants::EMPTY_STR;
      push( @failedNmdpAlleles, $allele );
      next;
    }
    if ( defined( $cell_data->{replaced} ) ) {
      $validAlleles->{$lallele} = $cell_data->{replaced};
      foreach my $rallele ( @{ $cell_data->{replaced} } ) {
        $currentAlleles->{$rallele} = util::Constants::EMPTY_STR;
        push( @{$validNmdpAlleles}, $rallele );
      }
    }
    else {
      $validAlleles->{$lallele}   = util::Constants::EMPTY_STR;
      $currentAlleles->{$lallele} = util::Constants::EMPTY_STR;
      push( @{$validNmdpAlleles}, $lallele );
    }
  }
  $msgs->registerError(
    ERR_CAT, 5,
    [
      $locus_name, $nmdp_code,
      join( util::Constants::COMMA_SEPARATOR, @alleles ),
      join( util::Constants::COMMA_SEPARATOR, @failedNmdpAlleles ),
    ],
    @failedNmdpAlleles > 0
  );
  $validAlleles->{$nmdp_code} = $validNmdpAlleles;
}

sub _setAlleleSets {
  my qualityControl::Allele::Validator $this = shift;
  my ($locus_name) = @_;
  ###
  ### Set the allele sets
  ###
  $this->{current_alleles} = {};

  $this->{valid_current_alleles} = {};
  my $validCurrentAlleles = $this->{valid_current_alleles};
  if ( !defined( $validCurrentAlleles->{$locus_name} ) ) {
    $validCurrentAlleles->{$locus_name} = {};
  }

  if ( !defined( $this->{valid_alleles} ) ) {
    $this->{valid_alleles} = {};
  }
  my $validAlleles = $this->{valid_alleles};
  if ( !defined( $validAlleles->{$locus_name} ) ) {
    $validAlleles->{$locus_name} = {};
  }

  if ( !defined( $this->{failed_alleles} ) ) {
    $this->{failed_alleles} = {};
  }
  my $failedAlleles = $this->{failed_alleles};
  if ( !defined( $failedAlleles->{$locus_name} ) ) {
    $failedAlleles->{$locus_name} = {};
  }
}

sub _validateCell {
  my qualityControl::Allele::Validator $this = shift;
  my (@comps) = @_;
  ###
  ### return immediately if there is nothing to do...
  ###
  return undef if ( @comps == 0 );
  ###
  ### Set the allele sets
  ###
  $this->_setAlleleSets( $comps[0]->{name} );
  ###
  ### process the components
  ###
  foreach my $comp (@comps) {
    my $type = $comp->{type};
    $comp->{checks} = util::Constants::TRUE;
    ###
    ### Now validate the alleles for the cell
    ###
    $this->_validateCurrentAllele($comp)
      if ( $type eq $this->FULL_NAME
      || $type eq $this->FULL_SUFFIX
      || $type eq $this->DIGIT_NAME
      || $type eq $this->DIGIT_SUFFIX );

    $this->_validateImgtHlaCode($comp)
      if ( $type eq $this->GCODE_NAME
      || $type eq $this->DIGIT_GCODE
      || $type eq $this->DIGIT_PCODE
      || $type eq $this->PCODE_NAME );

    $this->_validateNmdpCode($comp)
      if ( $type eq $this->NMDP_NAME
      || $type eq $this->DIGIT_NMDP );

    $this->_validateAlleleGroup($comp)
      if ( $type eq $this->FULL_AGROUP || $type eq $this->DIGIT_AGROUP );
  }
  ###
  ### Determine the cell and return it
  ###
  my $allele_list = util::Constants::EMPTY_STR;
  foreach my $allele ( sort keys %{ $this->{current_alleles} } ) {
    if ( $allele_list ne util::Constants::EMPTY_STR ) {
      $allele_list .= $this->getAmbiguousAlleleSeparator;
    }
    $allele =~ s/^\w+\*//;
    $allele_list .= $allele;
  }
  return $allele_list;
}

sub _generateErrMsgSegments {
  my qualityControl::Allele::Validator $this = shift;
  my ($err_msg) = @_;

  my @segments = ();
  my $max_len  = NUM_CHAR_PER_SEGMENT;
  if ( $max_len >= length($err_msg) ) {
    push( @segments, $err_msg );
    return @segments;
  }
  ###
  ### Now construct the segments
  ###
  my $current_seg = util::Constants::EMPTY_STR;
  my @comps = split( / +/, $err_msg );
  while ( scalar @comps > 0 ) {
    my $current_comp     = $comps[0];
    my $current_comp_len = length($current_comp);
    my $current_seg_len  = length($current_seg);
    my $new_seg_len      = $current_seg_len + $current_comp_len + 1;
    if ( length($current_seg) == 0 ) {
      if ( $current_comp_len < $max_len ) {
        $current_seg = $current_comp;
        shift(@comps);
      }
      elsif ( $current_comp_len == $max_len ) {
        push( @segments, $current_comp );
        shift(@comps);
      }
      else {
        my $substr = substr( $current_comp, 0, $max_len - 1 );
        push( @segments, $substr . '-' );
        $comps[0] = substr(
          $current_comp,
          $max_len - 1,
          $current_comp_len - $max_len + 1
        );
      }
    }
    elsif ( $new_seg_len < $max_len ) {
      $current_seg .= " $current_comp";
      shift(@comps);
    }
    elsif ( $new_seg_len == $max_len ) {
      push( @segments, "$current_seg $current_comp" );
      shift(@comps);
      $current_seg = util::Constants::EMPTY_STR;
    }
    else {
      push( @segments, $current_seg );
      $current_seg = util::Constants::EMPTY_STR;
    }
  }
  if ( length($current_seg) > 0 ) {
    push( @segments, $current_seg );
  }

  return @segments;
}

sub _processAnttErrors {
  my qualityControl::Allele::Validator $this = shift;
  my ( $locus_col, $entity ) = @_;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};

  my $cell             = $entity->{$locus_col};
  my $locus_data       = $reader->getEntityData($locus_col);
  my $full_locus_name  = uc( $locus_data->{full_entity_name} );
  my $short_locus_name = uc( $locus_data->{short_locus_name} );
  my $alt_locus_name   = uc( $locus_data->{alt_locus_name} );

  my @comps = ();
  return if ( $reader->emptyCell($cell) );
  ###
  ### Separate cell based on the standard separator
  ###
  @comps = ($cell);
  my $ambiguous_allele_separator = $this->{ambiguous_allele_separator};
  if ( $cell =~ /$ambiguous_allele_separator/ ) {
    @comps = split( /$ambiguous_allele_separator/, $cell );
  }
  ###
  ### Check for ANTT Errors
  ###
  foreach my $comp (@comps) {
    $comp =~ s/^($full_locus_name|$short_locus_name|$alt_locus_name)\*//;
    my $errMsg = $this->{antt}->getLogForAllele( $full_locus_name, $comp );
    next if ( util::Constants::EMPTY_LINE($errMsg) );
    my $format_type = undef;
    if ( $comp =~ /:/ ) {
      $format_type = "IMGT/HLA 3.* format";
    }
    else {
      $format_type = "IMGT/HLA 2.* format";
    }
    $msgs->registerError(
      ERR_CAT, 1,
      [
        $full_locus_name, $cell, $comp, $format_type,
        join( PREFIX_PER_SEGMENT, $this->_generateErrMsgSegments($errMsg) )
      ],
      util::Constants::TRUE
    );
  }
}

sub _createAntt {
  my qualityControl::Allele::Validator $this = shift;

  my $tools = $this->{tools};

  $this->{antt} =
    new antt::Runner( $this->{reader}, $this->{ambiguous_allele_separator},
    $tools, $this->{error_mgr} );

  my $antt = $this->{antt};
  $antt->setAnttIniFile( $tools->getProperty( $tools->ANTT_INI_FILE_PROP ) );
  $antt->setAnttTool( $tools->getProperty( $tools->ANTT_TOOL_PROP ) );
  $antt->setMonoTool( $tools->getProperty( $tools->MONO_TOOL_PROP ) );
  $antt->setAnttTranslationDirectory(
    $tools->getProperty( $tools->ANTT_TRANSLATION_DIR_PROP ) );
}

sub _runAntt {
  my qualityControl::Allele::Validator $this = shift;
  my ( $process_log, $antt_file, @actions ) = @_;

  my $antt = $this->{antt};
  $antt->setProcessAnttLog($process_log);
  $antt->setAnttFile($antt_file);
  $antt->run(@actions);
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  my qualityControl::Allele::Validator $this =
    $that->SUPER::new( $file_reader, $taxon_id, $tools, $error_mgr );

  $this->{current_alleles}       = undef;
  $this->{failed_alleles}        = undef;
  $this->{valid_alleles}         = undef;
  $this->{valid_current_alleles} = undef;

  return $this;
}

sub preprocessChecks {
  my qualityControl::Allele::Validator $this = shift;
  my ( $locus_data, $allele_name ) = @_;

  my $full_locus_name  = uc( $locus_data->{full_entity_name} );
  my $short_locus_name = uc( $locus_data->{short_locus_name} );
  my $alt_locus_name   = uc( $locus_data->{alt_locus_name} );

  $allele_name =~ s/^($full_locus_name|$short_locus_name|$alt_locus_name)\*//;
  my $errMsg = $this->{antt}->getLogForAllele( $full_locus_name, $allele_name );

  return util::Constants::EMPTY_LINE($errMsg)
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

sub processFile {
  my qualityControl::Allele::Validator $this = shift;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};
  my $tools  = $this->{tools};
  ###
  ### Read and Pre-Process the file
  ###
  my $emptyVal = $reader->getEmptyVal;
  $reader->openReader;
  $this->preprocessFile;
  ###
  ### Create ANTT Runner
  ###
  $this->_createAntt;
  my $antt = $this->{antt};
  ###
  ### Run ANTT to determine logging errors
  ###
  my $anttFile = $tools->cmds->TMP_FILE( 'ValidatorRuns', 'txt' );
  $this->_runAntt(
    util::Constants::TRUE, $anttFile,             $antt->GCODE_ACTION,
    $antt->PCODE_ACTION,   $antt->REVERSE_ACTION, $antt->FORWARD_ACTION
  );
  ###
  ### Run ANTT to get the ANTT results
  ### and log to save for user
  ###
  my $log_action = undef;
  if ( $antt->getNotFoundCount( $antt->FORWARD_ACTION ) >
    $antt->getNotFoundCount( $antt->REVERSE_ACTION ) )
  {
    $log_action = $antt->REVERSE_ACTION;
  }
  else {
    $log_action = $antt->FORWARD_ACTION;
  }
  $this->_runAntt( util::Constants::FALSE,
    $tools->getProperty( $tools->ANTT_FILE_PROP ), $log_action );
  ###
  ### Run ANTT to translate the contents of the file
  ### into IMGT/HLA version 3 format
  ###
  $this->_runAntt( util::Constants::FALSE, $anttFile, $antt->FORWARD_ACTION );
  $antt->updateReader;
  ###
  ### Set the info data to the file to be written
  ###
  my $process_info = "HLA alleles validated typing results";
  $reader->addHeaderInfo( $process_info, $tools->versionInfo );
  ###
  ### process the file
  ###
  $msgs->resetRowNum;
  my @newEntities = ();
  foreach my $entity ( $reader->getData ) {
    ###
    ### Determine if the row is empty (no id and no data)
    ###
    next if ( $reader->noIdData($entity) );
    ###
    ### Capture subject information
    ###
    $msgs->addDataCapture( $msgs->SUBJECT_TABLE,
      $entity->{ $reader->getIdCol } );
    ###
    ### Now process row
    ###
    $msgs->incRowNum;
    foreach my $col_name ( $reader->getEntityCols ) {
      $msgs->initializeMsgs( $col_name, $entity );
      $this->_processAnttErrors( $col_name, $entity );
      my @comps = $this->determineComps( $col_name, $entity );
      $msgs->setAmbiguousCell if ( scalar @comps > 1 );
      my $cell = $this->_validateCell( $this->removeErrors(@comps) );
      $entity->{$col_name} = $reader->emptyCell($cell) ? $emptyVal : $cell;
      $msgs->finalizeMsgs;
    }
    push( @newEntities, $entity );
  }
  ###
  ### At this point, the data must be replaced with newEntities!!
  ###
  $reader->replaceData(@newEntities);

  return if ( !defined( $this->outFile ) );
  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  my $out_file   = $this->outFile;
  $out_file =~ s/$task_infix/$task_id/;
  $reader->writeFile($out_file);
  my @property_data = ();
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Validated File",
      $tools->VALUE_COL    => basename($out_file),
    }
  );
  $msgs->printStatistics(@property_data);
}

################################################################################

1;

__END__

=head1 NAME

Validator.pm

=head1 DESCRIPTION

This is the concrete class that performs allele validation on a file.
The parent class is L<qualityControl::Allele>.  This class utilizes
the ANTT tool via the class L<antt::Runner> to validate version 2 & 3
IMGT/HLA alleles and IMGT/HLA G-Codes and P-Codes.  This class also
validates NMDP Codes (both version 2 and version 3) and replaces them
with their allele code groups.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new qualityControl::Allele::Validator(file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The file to process is
represented by the B<file_reader> object, an instance of a subclass of
L<file::Mhc::Hla>, the tools object
(L<util::Tools::mhcSeqVar::qualityControl>), and the error logger
(L<util::ErrMgr>).  The taxon_id specifies the species that is being
processed.  Currently, it must be B<9606> (Homo sapiens).

=head2 B<preprocessChecks(locus_data, allele_name)>

This method re-implements the parent method and determines for a given
locus (locus_data) and allele_name whether there were any ANTT errors
raised in validating the allele.  If there are ANTT errors, then this
method returns FALSE (0), othewise it returns TRUE (1).

Consult the class L<antt::Runner> for specific ANTT error messages
retained for the validator to use in determining valiation errors.

=head2 B<processFile>

This method processes the file to it contents.  The process of
validation is desccribed below.

First, the ANTT tool (L<antt::Runner>) is execcuted on the file using
the following order of ANTT actions:

   antt::Runner::GCODE_ACTION
   antt::Runner::PCODE_ACTION
   antt::Runner::REVERSE_ACTION
   antt::Runner::FORWARD_ACTION

This execution provides the ANTT error messages that occurred for the
file.  Next ANTT is run in either FORWARD_ACTION or REVERSE_ACTION
depending on which action had fewer not found errors.  Finally, ANTT
is run in FORWARD_ACTION to update the file contents with IMGT/HLA
version 3 format content (execpt for those IMGT/HLA version 2 alleles
that have validation errors).

Next, the method processes each locus column and cell in each row as
follows.  First, it determines if the cell contains any component that
has an ANTT error and adds this error to the errors tracked by this
class for this locus, cell and component.  Second, it determines the
components of the cell and remove any that have ANTT errors.  For each
valid allele component, this method determines whether the allele is
CWD or Rare.  For each valid allele that is only an allele group, it
records the occurrence of an allele group.  For each valid G-Code and
P-Code, it records the occurrence of such codes.  For each NMDP code
(either version 2 or version 3), this method determines whether the
NMDP code is valid and replaces the code with its allele code group in
IMGT/HLA version 3 format.  All alleles in the code group are
determined to be valid IMGT/HLA version 3 alleles.

Next to last, this method generates a result file containing only
validated results.  All invalid data is removed and empty cells are
annotated by a hyphen ('-').

Finally, this method generates the output for the log.  This includes
the tables and details as specified in the class L<util::Messaging>
for the B<printStatistics> method.

=cut
