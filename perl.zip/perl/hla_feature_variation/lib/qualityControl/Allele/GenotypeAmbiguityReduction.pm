package qualityControl::Allele::GenotypeAmbiguityReduction;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use Pod::Usage;

use util::Constants;
use util::Table;

use db::MhcTypes;

use qualityControl::ErrMsgs;

use base 'qualityControl::Allele';

use fields qw (
  col_name_0
  col_name_1
  col_names
  current_steps
  id_col
  row_nums
  formated_data
  subgenotypes_table
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### writing a set of SubGenoTypes for an ID
###
my %SUBGENOTYPE_COLS = (
  allele_1  => 'AlleleSet 1',
  type_1    => 'Type 1',
  cwd_1     => 'CWD 1',
  reg_cwd_1 => 'Reg-CWD 1',

  allele_2  => 'AlleleSet 2',
  type_2    => 'Type 2',
  cwd_2     => 'CWD 2',
  reg_cwd_2 => 'Reg-CWD 2'
);

my @SUBGENOTYPE_ORD = (
  'allele_1', 'type_1', 'cwd_1', 'reg_cwd_1',
  'allele_2', 'type_2', 'cwd_2', 'reg_cwd_2'
);

my $TABLE_ORDER =
'sub {$a->{allele_1} cmp $b->{allele_1} or $a->{allele_2} cmp $b->{allele_2};}';

my $EPILOGUE =
  "Global and Region CWD statuses are computed at the 4-digit level.
That is, only the peptide-level (allele group and HLA protein fields)
of an allele is used in determining these statuses.";
###
### Row Header Information
###
sub ROWS_SPACER      { return "                     "; }
sub NUM_ROWS_PER_ROW { return 10; }
###
### Subgenotypes
###
sub GENOTYPES_SPACER         { return "                      "; }
sub NUM_SUBGENOTYPES_PER_ROW { return 3; }
###
### Error Category
###
sub ERR_CAT { return qualityControl::ErrMsgs::GENOTYPEAMBIGUITYREDUCTION_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _createEmptyCells {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $emptyVal = $this->{reader}->getEmptyVal;
  my $cells    = {};
  foreach my $colName ( @{ $this->{col_names} } ) {
    $cells->{$colName} = $emptyVal;
  }
  return $cells;
}

sub _emptyGenotype {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $emptyVal = $this->{reader}->getEmptyVal;
  return "($emptyVal, $emptyVal)";
}

sub _regCwdRegCwd {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $colNames = $this->{col_names};
  my $step     = 'Reg-CWD/Reg-CWD';
  my $types    = [];
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_cwd',
      $colNames->[1] => 'reg_cwd',
    }
  );
  return ( $step, $types );
}

sub _regCwdCwd {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $colNames = $this->{col_names};
  my $step     = 'Reg-CWD/CWD';
  my $types    = [];
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_cwd',
      $colNames->[1] => 'cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'cwd',
      $colNames->[1] => 'reg_cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'cwd',
      $colNames->[1] => 'cwd',
    }
  );
  return ( $step, $types );
}

sub _codeRegCwd {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $colNames = $this->{col_names};
  my $step     = 'G-Code and/or P-Code, or (G-Code, P-Code)/(Reg-CWD, CWD)';
  my $types    = [];
  push(
    @{$types},
    {
      $colNames->[0] => 'gcode',
      $colNames->[1] => 'gcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'pcode',
      $colNames->[1] => 'pcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'pcode',
      $colNames->[1] => 'gcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'gcode',
      $colNames->[1] => 'pcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'gcode',
      $colNames->[1] => 'reg_cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_cwd',
      $colNames->[1] => 'gcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'pcode',
      $colNames->[1] => 'reg_cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_cwd',
      $colNames->[1] => 'pcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'gcode',
      $colNames->[1] => 'cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'cwd',
      $colNames->[1] => 'gcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'pcode',
      $colNames->[1] => 'cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'cwd',
      $colNames->[1] => 'pcode',
    }
  );
  return ( $step, $types );
}

sub _regRare {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $colNames = $this->{col_names};
  my $step     = 'Reg-Rare and Reg-CWD, or CWD or G-Code or P-Code';
  my $types    = [];
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_cwd',
      $colNames->[1] => 'reg_rare',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_rare',
      $colNames->[1] => 'reg_cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'cwd',
      $colNames->[1] => 'reg_rare',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_rare',
      $colNames->[1] => 'cwd',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'gcode',
      $colNames->[1] => 'reg_rare',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_rare',
      $colNames->[1] => 'gcode',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'pcode',
      $colNames->[1] => 'reg_rare',
    }
  );
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_rare',
      $colNames->[1] => 'pcode',
    }
  );
  return ( $step, $types );
}

sub _regRareRegRare {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $colNames = $this->{col_names};
  my $step     = 'Reg-Rare/Reg-Rare';
  my $types    = [];
  push(
    @{$types},
    {
      $colNames->[0] => 'reg_rare',
      $colNames->[1] => 'reg_rare',
    }
  );
  return ( $step, $types );
}

sub _createEntity {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ( $entity, $optCols ) = @_;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};

  my $newEntity = {};
  foreach my $col_name ( keys %{$entity} ) {
    $newEntity->{$col_name} = undef;
  }
  $newEntity->{ $reader->getIdCol }       = $this->{id_col};
  $newEntity->{ $reader->ROW_ID_COL }     = $msgs->getRowNum;
  $newEntity->{ $this->{population_col} } = $this->{population_area};

  foreach my $col_name ( keys %{$optCols} ) {
    $newEntity->{"$col_name"} = $optCols->{"$col_name"};
  }

  return $newEntity;
}

sub _printStepsProcessed {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($genotype) = @_;

  $this->{error_mgr}->printHeader(
        "Steps Processed\n"
      . "  Population Area = "
      . $this->{population_area} . "\n"
      . "  Genotype ID     = "
      . $this->{id_col} . "\n"
      . "  Locus Col Names = "
      . join( util::Constants::COMMA_SEPARATOR,
      $this->{col_name_0}, $this->{col_name_1} )
      . "\n"
      . "  Row Nums        = "
      . $this->{msgs}->generateRowsHeader( ROWS_SPACER, NUM_ROWS_PER_ROW )
      . "\n"
      . "  genotype        = $genotype\n"
      . "  Steps           = ("
      . join( ",\n                     ", @{ $this->{current_steps} } ) . ")"
  );
}

sub _processSingleton {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($subGenotype) = @_;

  my $multiple_subgenotypes =
    util::Constants::EMPTY_LINE( $this->{formated_data} )
    ? util::Constants::FALSE
    : util::Constants::TRUE;

  push( @{ $this->{current_steps} }, 'Generated genotype' );
  my $names    = [ 'genotype returned', 'sub-genotypes', 'steps processed' ];
  my $genotype = '(';
  my $cells    = {};
  foreach my $colName ( @{ $this->{col_names} } ) {
    if ( $genotype ne '(' ) { $genotype .= ', '; }
    $genotype .= $subGenotype->{$colName}->{allele};
    $cells->{$colName} = $subGenotype->{$colName}->{allele};
    $cells->{$colName} =~ s/^\w+\*//;
  }
  $genotype .= ')';
  ###
  ### Generate message based on multiple_subgenotypes
  ###
  my $msg = undef;
  if ( defined($multiple_subgenotypes) ) {
    $msg = 'Genotype reduced from multiple subGenotypes';
  }
  else {
    $msg = 'Single subGenotype';
  }
  ###
  ### write result message
  ###
  $this->{msgs}->addResult(
    $msg, $names,
    {
      'sub-genotypes' => $multiple_subgenotypes
      ? $this->{formated_data}
      : $genotype,
      'genotype returned' => $genotype,
      'steps processed'   => '('
        . join( ",\n                       ", @{ $this->{current_steps} } )
        . ')',
    },
    $this->{msgs}->MSG_MSG
  );
  $this->_printStepsProcessed($genotype) if ($multiple_subgenotypes);

  return $cells;
}

sub _reduceAllelesByType {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ( $types, $subGenotypes, $step ) = @_;

  my $reducedSubGenotypes = [];
  foreach my $subGenotype ( @{$subGenotypes} ) {
    ###
    ### This requires the the pair in the subGenotype to conform
    ### to one of the types in order to be added to the reduced set
    ###
    my $isOfType = util::Constants::FALSE;
  TYPES_LOOP:
    foreach my $type ( @{$types} ) {
      my $foundType = util::Constants::TRUE;
      foreach my $colName ( @{ $this->{col_names} } ) {
        my $testType   = $type->{$colName};
        my $alleleData = $subGenotype->{$colName};
        if ( $testType eq 'reg_cwd' || $testType eq 'reg_rare' ) {
          $foundType =
            (
            !(
                 defined( $alleleData->{reg} )
              && $alleleData->{reg}
              && $alleleData->{$testType}
            )
            )
            ? util::Constants::FALSE
            : $foundType;
        }
        elsif ( $testType eq 'cwd' ) {
          $foundType =
            ( !( defined( $alleleData->{cwd} ) && $alleleData->{cwd} ) )
            ? util::Constants::FALSE
            : $foundType;
        }
        elsif ( $testType eq 'pcode' || $testType eq 'gcode' ) {
          $foundType =
            ( $alleleData->{type} ne $testType )
            ? util::Constants::FALSE
            : $foundType;
        }
        last if ( !$foundType );
      }
      if ($foundType) {
        $isOfType = util::Constants::TRUE;
        last TYPES_LOOP;
      }
    }
    push( @{$reducedSubGenotypes}, $subGenotype ) if ($isOfType);
  }
  push( @{ $this->{current_steps} }, "Processed $step" )
    if ( scalar @{$reducedSubGenotypes} != 0 );

  return $reducedSubGenotypes;
}

sub _determineHomozygousSet {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ( $hstep, $subGenotypes ) = @_;

  my $colNames            = $this->{col_names};
  my $reducedSubGenotypes = [];
  my $homozygousAlleles   = {};
  foreach my $subGenotype ( @{$subGenotypes} ) {
    my $subG1   = $subGenotype->{ $colNames->[0] };
    my $subG2   = $subGenotype->{ $colNames->[1] };
    my $allele1 = $subG1->{allele};
    my $allele2 = $subG2->{allele};
    next
      if ( $allele1 ne $allele2
      || $subG1->{type} ne $this->ALLELE_TYPE
      || $subG2->{type} ne $this->ALLELE_TYPE );
    $homozygousAlleles->{$allele1} = util::Constants::EMPTY_STR;
    push( @{$reducedSubGenotypes}, $subGenotype );
  }
  ###
  ### If there are no homozygous subGenotypes, return immediately
  ### otherwise add step
  ###
  return $reducedSubGenotypes if ( scalar @{$reducedSubGenotypes} == 0 );
  push( @{ $this->{current_steps} }, $hstep );
  ###
  ### Now find any subGenotypes that contain an homozygous allele
  ###
  foreach my $subGenotype ( @{$subGenotypes} ) {
    my $subG1   = $subGenotype->{ $colNames->[0] };
    my $subG2   = $subGenotype->{ $colNames->[1] };
    my $allele1 = $subG1->{allele};
    my $allele2 = $subG2->{allele};
    next
      if (
      ( $allele1 eq $allele2 )
      || ( !defined( $homozygousAlleles->{$allele1} )
        && !defined( $homozygousAlleles->{$allele2} ) )
      );
    push( @{$reducedSubGenotypes}, $subGenotype );
  }

  return $reducedSubGenotypes;
}

sub _sortSums { $a <=> $b; }

sub _lowestSum {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($subGenotypes) = @_;

  my $colNames = $this->{col_names};
  my $lstep    = "Computed lowest sum of HLA protein fields";
  my $sums     = {};
  foreach my $subGenotype ( @{$subGenotypes} ) {
    my $subG1       = $subGenotype->{ $colNames->[0] };
    my $subG2       = $subGenotype->{ $colNames->[1] };
    my $hlaProtein1 = $subG1->{data}->{nomen}->{hla_protein};
    my $hlaProtein2 = $subG2->{data}->{nomen}->{hla_protein};
    my $sum         = int($hlaProtein1) + int($hlaProtein2);
    if ( !defined( $sums->{$sum} ) ) {
      $sums->{$sum} = [];
    }
    push( @{ $sums->{$sum} }, $subGenotype );
  }
  my @sums =
    sort qualityControl::Allele::GenotypeAmbiguityReduction::_sortSums
    keys %{$sums};
  push( @{ $this->{current_steps} }, $lstep );
  ###
  ### Check the least sum
  ###
  my $reducedSubGenotypes = $sums->{ $sums[0] };
  if ( scalar @{$reducedSubGenotypes} == 1 ) {
    push( @{ $this->{current_steps} }, "Determined single subGenotype" );
    return $this->_processSingleton( $reducedSubGenotypes->[0] );
  }
  ###
  ### Error Condition
  ###
  my $errstep = "ERROR:  Determined more than one subGenotype";
  push( @{ $this->{current_steps} }, $errstep );
  $this->{msgs}->registerError(
    ERR_CAT, 3,
    [
      $this->{msgs}->getLocusName, $this->{id_col},
      $lstep . ' and ' . $errstep, $this->{formated_data},
    ],
    util::Constants::TRUE
  );
  $this->_printStepsProcessed;

  return $this->_createEmptyCells;
}

sub _homozygousTest {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($subGenotypes) = @_;

  my $hstep = 'Reduced by homozygous alleles';
  my $reducedSubGenotypes =
    $this->_determineHomozygousSet( $hstep, $subGenotypes );

  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_lowestSum($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### No homozygous pairs
  ###
  return $this->_lowestSum($subGenotypes);
}

sub _reduceSubGenotypes {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($subGenotypes) = @_;

  my $reducedSubGenotypes = undef;
  my $step                = undef;
  my $types               = undef;
  ###
  ### 1.  Test (Reg-CWD, Reg-CWD)
  ###
  ( $step, $types ) = $this->_regCwdRegCwd;
  $reducedSubGenotypes =
    $this->_reduceAllelesByType( $types, $subGenotypes, $step );
  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_homozygousTest($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### 2.  Test (Reg-CWD, CWD) or (CWD, CWD)
  ###
  ( $step, $types ) = $this->_regCwdCwd;
  $reducedSubGenotypes =
    $this->_reduceAllelesByType( $types, $subGenotypes, $step );
  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_homozygousTest($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### 3.  Test (G-code, G-code),  (P-code, P-code),
  ###          (G-code, P-code),
  ###          (G-code, Reg-CWD), (P-code, Reg-CWD),
  ###          (G-code, CWD),     (P-code, CWD)
  ###
  ( $step, $types ) = $this->_codeRegCwd;
  $reducedSubGenotypes =
    $this->_reduceAllelesByType( $types, $subGenotypes, $step );
  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_homozygousTest($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### 4.  test for (Reg-CWD, reg-Rare), (CWD, reg-Rare),
  ###              (G-code, reg-Rare),  (P-code, reg-Rare)
  ###
  ( $step, $types ) = $this->_regRare;
  $reducedSubGenotypes =
    $this->_reduceAllelesByType( $types, $subGenotypes, $step );
  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_homozygousTest($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### 5.  test for (reg-Rare, reg-Rare)
  ###
  ( $step, $types ) = $this->_regRareRegRare;
  $reducedSubGenotypes =
    $this->_reduceAllelesByType( $types, $subGenotypes, $step );
  return $this->_processSingleton( $reducedSubGenotypes->[0] )
    if ( scalar @{$reducedSubGenotypes} == 1 );
  return $this->_homozygousTest($reducedSubGenotypes)
    if ( scalar @{$reducedSubGenotypes} > 1 );
  ###
  ### No reductions worked, just use the given set of subGenotypes
  ###
  return $this->_homozygousTest($subGenotypes);
}

sub _removeSubGenotypesMissingAllelSet {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my (@entities) = @_;
  ###
  ### Now generate the set of defined subGenotypes
  ### both cells are defined and have content
  ###
  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};

  my @finalEntities = ();
  foreach my $entity (@entities) {
    my $badCol   = util::Constants::FALSE;
    my $numEmpty = 0;
    foreach my $colName ( @{ $this->{col_names} } ) {
      my $cell      = $entity->{$colName};
      my $locusData = $reader->getEntityData($colName);
      if ( $reader->emptyCell($cell) ) {
        $numEmpty++;
        next;
      }
      my @comps = $this->determineComps( $colName, $entity );
      if ( @comps > 1 ) {
        $badCol = util::Constants::TRUE;
        $msgs->registerError(
          ERR_CAT, 2,
          [
            $cell,                  $msgs->getLocusName,
            $locusData->{col_name}, $this->{id_col},
            $entity->{ $reader->ROW_ID_COL },
          ],
          $badCol
        );
      }
      elsif ( @comps == 1 && !defined( $comps[0] ) ) {
        ###
        ### Case where there is a single component,
        ### but it has incorrect syntax
        ###
        $badCol = util::Constants::TRUE;
      }
    }
    if ( $numEmpty == 1 ) {
      $badCol = util::Constants::TRUE;
      $msgs->registerError(
        ERR_CAT, 1,
        [
          $msgs->getLocusName, $this->{id_col},
          $entity->{ $reader->ROW_ID_COL },
        ],
        $badCol
      );
    }
    push( @finalEntities, $entity ) if ( !$badCol );
  }
  push(
    @{ $this->{current_steps} },
    'Removed subGenotypes missing one alleleSet'
  ) if ( scalar @entities != scalar @finalEntities );

  return @finalEntities;
}

sub _printSubGenoTypes {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my (@subGenotypes) = @_;
  ###
  ### Setup for printing table
  ###
  my @tableSubGenotypes = ();
  foreach my $subGenotype (@subGenotypes) {
    my $subgenotype = {};
    foreach my $index ( 0 .. $#{ $this->{col_names} } ) {
      my $colName    = $this->{col_names}->[$index];
      my $colIndex   = $index + 1;
      my $alleleData = $subGenotype->{$colName};
      foreach my $col ( keys %{$alleleData} ) {
        my $subgenotype_col = $col . "_$colIndex";
        $subgenotype->{$subgenotype_col} = $alleleData->{$col};
      }
    }
    push( @tableSubGenotypes, $subgenotype );
  }
  $this->{subgenotypes_table}->setData(@tableSubGenotypes);

  my $header =
      "SubGenotypes Data\n"
    . "  Population Area = "
    . $this->{population_area} . "\n"
    . "  Genotype ID     = "
    . $this->{id_col} . "\n"
    . "  Locus Col Names = "
    . join( util::Constants::COMMA_SEPARATOR,
    $this->{col_name_0}, $this->{col_name_1} )
    . "\n"
    . "  Row Nums        = "
    . $this->{msgs}->generateRowsHeader( ROWS_SPACER, NUM_ROWS_PER_ROW );
  $this->{subgenotypes_table}->generateTable( $header, $EPILOGUE );
}

sub _determineGenotype {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my (@entities) = @_;
  ###
  ### 1.  Print subGenotypes
  ###
  my @allSubGenotypes = ();
  foreach my $entity (@entities) {
    my $subGenotype = {};
    foreach my $colName ( @{ $this->{col_names} } ) {
      my @comps = $this->determineComps( $colName, $entity );
      if ( scalar @comps == 0 ) {
        $subGenotype->{$colName} = $this->alleleData();
      }
      else {
        $subGenotype->{$colName} = $this->alleleData( $comps[0] );
      }
    }
    push( @allSubGenotypes, $subGenotype );
  }
  $this->_printSubGenoTypes(@allSubGenotypes)
    if ( scalar @allSubGenotypes > 1 );
  ###
  ### 2.  Remove subGenotypes missing one alleleSet
  ###     (return empty genotype if there are no entities left)
  ###
  @entities = $this->_removeSubGenotypesMissingAllelSet(@entities);
  return $this->_createEmptyCells if ( @entities == 0 );
  ###
  ### 3.  Remove duplicate subGenotypes
  ###
  ###     Must remove duplicate subGenotypes
  ###     (a1,b1) and (a2, b2) are equal if
  ###       (a1 == a2 && b1 == b2)
  ###       or
  ###       (a1 == b2 && b1 == a2)
  ###
  my $genotypeGroups = {};
  my $subGenotypes   = [];
  foreach my $entity (@entities) {
    my $subGenotype = {};
    my $fkey        = util::Constants::EMPTY_STR;
    my $rkey        = util::Constants::EMPTY_STR;
    foreach my $colName ( @{ $this->{col_names} } ) {
      if ($fkey) {
        $fkey .= util::Constants::SLASH . util::Constants::SLASH;
        $rkey = util::Constants::SLASH . util::Constants::SLASH . $rkey;
      }
      my @comps = $this->determineComps( $colName, $entity );
      $subGenotype->{$colName} = $this->alleleData( $comps[0] );
      $fkey .= $subGenotype->{$colName}->{allele};
      $rkey = $subGenotype->{$colName}->{allele} . $rkey;
    }
    ###
    ### Add only if the subGenotype has not occurred yet
    ###
    next
      if ( defined( $genotypeGroups->{$fkey} )
      || defined( $genotypeGroups->{$rkey} ) );
    push( @{$subGenotypes}, $subGenotype );
    $genotypeGroups->{$fkey} = util::Constants::EMPTY_STR;
  }
  $this->{tools}->debugStruct( "subGenotypes", $subGenotypes );
  push( @{ $this->{current_steps} }, 'Removed duplicate subGenotypes' )
    if ( scalar @entities != scalar @{$subGenotypes} );
  ###
  ### 4.  Singleton subGenotype
  ###
  $this->{formated_data} = undef;
  return $this->_processSingleton( $subGenotypes->[0] )
    if ( scalar @{$subGenotypes} == 1 );
  ###
  ### 5.  Multiple subGenotypes
  ###
  $this->{formated_data} =
    $this->{msgs}
    ->formatData( $this, util::Constants::EMPTY_STR, util::Constants::EMPTY_STR,
    GENOTYPES_SPACER, NUM_SUBGENOTYPES_PER_ROW, @{$subGenotypes} );
  return $this->_reduceSubGenotypes($subGenotypes);
}

sub _determineNonemptyEntities {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my (@entities) = @_;

  return @entities if ( scalar @entities == 0 );

  my @finalEntities = ();
  foreach my $entity (@entities) {
    my $haveData = util::Constants::FALSE;
    foreach my $colName ( @{ $this->{col_names} } ) {
      my $cell = $entity->{$colName};
      if ( !$this->{reader}->emptyCell($cell) ) {
        $haveData = util::Constants::TRUE;
      }
    }
    push( @finalEntities, $entity ) if ($haveData);
  }
  push( @{ $this->{current_steps} }, 'Removed empty subGenotypes' )
    if ( scalar @entities != scalar @finalEntities );

  return @finalEntities;
}

sub _createSubGenotypesTable {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  my $table = new util::Table( $this->{error_mgr}, %SUBGENOTYPE_COLS );
  $table->setEmptyField(util::Constants::HYPHEN);
  $table->setColumnOrder(@SUBGENOTYPE_ORD);
  $table->setInHeader(util::Constants::TRUE);
  $table->setRowOrder($TABLE_ORDER);
  $table->setColumnJustification( 'allele_1', $table->LEFT_JUSTIFY );
  $table->setColumnJustification( 'allele_2', $table->LEFT_JUSTIFY );
  $this->{subgenotypes_table} = $table;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  my qualityControl::Allele::GenotypeAmbiguityReduction $this =
    $that->SUPER::new( $file_reader, $taxon_id, $tools, $error_mgr );

  $this->_createSubGenotypesTable;

  $this->{col_names} = undef;
  $this->{id_col}    = undef;

  return $this;
}

sub formatDatum {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;
  my ($subGenotype) = @_;

  my $colNames    = $this->{col_names};
  my $subgenotype = '('
    . $subGenotype->{ $colNames->[0] }->{allele}
    . util::Constants::COMMA_SEPARATOR
    . $subGenotype->{ $colNames->[1] }->{allele} . ')';

  return $subgenotype;
}

sub processFile {
  my qualityControl::Allele::GenotypeAmbiguityReduction $this = shift;

  $this->{col_names} = undef;
  $this->{id_col}    = undef;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};
  my $tools  = $this->{tools};
  ###
  ### read the file
  ###
  $reader->openReader;
  $msgs->resetRowNum;
  ###
  ### Check that Population Area column is defined
  ###
  return if ( $this->populationAreColumnMissing );
  ###
  ### Set the info data to the file to be written
  ###
  my $process_info = "HLA allele ambiguity reduction results";
  $reader->addHeaderInfo( $process_info, $tools->versionInfo );
  ###
  ### process the file
  ###
  my @newEntities = ();
  foreach my $id_col ( $reader->getIdCols ) {
    $this->{id_col} = $id_col;
    $msgs->incRowNum;
    ###
    ### The entity group for id_col
    ###
    my @entities = $reader->getEntitiesById($id_col);
    $msgs->initializeRowNums(@entities);
    ###
    ### Check that Population Area has a common population
    ###
    my $unknownPopulationArea =
      $this->unknownPopulationAreaForGroup( $this->{id_col}, @entities );
    my $populationArea = undef;
    if ( !$unknownPopulationArea ) {
      $populationArea = $entities[0]->{ $this->{population_col} };
    }
    $this->setPopulationArea($populationArea);
    my $optCols = $this->determineOptionalCols(@entities);
    my $newEntity = $this->_createEntity( $entities[0], $optCols );
    ###
    ### For each specific HLA locus and entity, the entity
    ### must have a pair of singleton values, otherwise it
    ### is ignored
    ###
    foreach my $locus_id ( $reader->getLoci ) {
      ###
      ### Setup for processing genotype for sample for locus
      ###
      $this->{current_steps} = [];
      $this->{col_names}     = [ $reader->getLocusColNames($locus_id) ];
      my $locus_data_0 = $reader->getEntityData( $this->{col_names}->[0] );
      my $locus_data_1 = $reader->getEntityData( $this->{col_names}->[1] );
      $this->{col_name_0} = $locus_data_0->{col_name};
      $this->{col_name_1} = $locus_data_1->{col_name};
      ###
      ### Remove all subGenotypes whose alleleSets are both empty
      ###
      my @locus_entities = $this->_determineNonemptyEntities(@entities);
      $msgs->initializeGenotypeMsgs( $locus_id, @locus_entities );
      ###
      ### If there were no entities or there is no population,
      ### then finalize and skip
      ###
      if ( @locus_entities == 0 ) {
        my $cells = $this->_createEmptyCells;
        foreach my $colName ( @{ $this->{col_names} } ) {
          $newEntity->{$colName} = $cells->{$colName};
        }
        $msgs->finalizeMsgs;
        next;
      }
      elsif ($unknownPopulationArea) {
        my $cells = $this->_createEmptyCells;
        foreach my $colName ( @{ $this->{col_names} } ) {
          $newEntity->{$colName} = $cells->{$colName};
        }
        $msgs->finalizeMsgs;
        next;
      }
      my $cells = $this->_determineGenotype(@locus_entities);
      foreach my $colName ( @{ $this->{col_names} } ) {
        $newEntity->{$colName} = $cells->{$colName};
      }
      $msgs->finalizeMsgs;
    }
    push( @newEntities, $newEntity );
  }
  ###
  ### At this point, the data must be replaced with newEntities!!
  ###
  $reader->replaceData(@newEntities);

  return if ( !defined( $this->outFile ) );
  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  my $out_file   = $this->outFile;
  $out_file =~ s/$task_infix/$task_id/;
  $reader->writeFile($out_file);
  my @property_data = ();
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Ambiguity Reduced File",
      $tools->VALUE_COL    => basename($out_file),
    }
  );
  $msgs->printStatistics(@property_data);
}

################################################################################

1;

__END__

=head1 NAME

GenotypeAmbiguityReduction.pm

=head1 DESCRIPTION

This concrete class defines the genotypic ambiguity reduction for an
HLA file.  The parent class is L<qualityControl::Allele>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new qualityControl::Allele::GenotypeAmbiguityReduction(file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The file to process is
represented by the B<file_reader> object, an instance of a subclass of
L<file::Mhc::Hla>, the tools object
(L<util::Tools::mhcSeqVar::qualityControl>), and the error logger
(L<util::ErrMgr>).  The taxon_id specifies the species that is being
processed.  Currently, it must be B<9606> (Homo sapiens).

=head2 B<processFile>

This method processes the file to perform genotypic ambiguity
reduction for each locus and sample ID.  Each sample row will contain
two locus columns.  For each locus, sample ID and sample row having
the ID, there will be two locus columns each containing an
allele/code.  The pair will be a subGenotype for the locus and sample
ID.  The set of subGenotypes for a locus and sample ID will be the set
of subGenotypes having the locus and sample ID.  This method assumes
that all data in the file are valid IMGT/HLA version 3 alleles,
G-Codes, and P-Codes.  This method assumes that the 'Population Area'
column exists in the file and contains a valid population area region
name or abbreviation (case-insensitive), otherwise errors are
generated into log, either the file or row is skipped, respectively.
Further, for each locus and sample ID, set of subGenotypes have the
same population area name, otherwise an error is generated and the set
of subGenotypes is not processed.

For each locus and sample ID, the set of subGenotypes are processed as
follow to reduce the set to a single subGenotype.  First, the set of
subGenotypes is preprocessed to remove all subGenotypes that have
empty pairs.  Next, the table B<SubGenotypes Data> is generated into the log for
the set of subGenotypes as a table B<Allele Data> into the log
containing the following columns:

  AlleleSet 1 -- allele/code in first locus column
  Type 1      -- type of alleleSet 1:  allele, gcode, or pcode
  CWD 1       -- for alleles in alleleSet 1, if CWD (1), otherwise Rare (0)
  Reg-CWD 1   -- for alleles in alleleSet 1, if reg-CWD (1) for population area,
                 else reg-Rare (0) for population area, else unknown (-)
  AlleleSet 2 -- allele/code in second locus column
  Type 2      -- type of alleleSet 2:  allele, gcode, or pcode
  CWD 2       -- for alleles in alleleSet 2, if CWD (1), otherwise Rare (0)
  Reg-CWD 2   -- for alleles in alleleSet 2, if reg-CWD (1) for population area,
                 else reg-Rare (0) for population area, else unknown (-)

Next, all duplicate subGenotypes are removed from the set of
subGenotypes.  subGenotypes are equal if for (a1, b1) and (a2, b2)
either a1 == a2 and b1 == b2 or a1 = b2 and b1 == a2.  If there is
only one subGenotype, then this is the genotype for the set and
processing terminates.  Otherwise, the genotype ambiguity reduction
algorithm is applied to the set of unique subGenotypes.

=over 4

=item B<Reg-CWD/Reg-CWD>

This step reduces the set of subGenotypes to the set of subGenotypes
for which both entities are both Reg-CWD.  If subGenotypes of this
sort are found, then continue with Determine Singleton Step.

=item B<Reg-CWD/CWD>

This step reduces the set of subGenotypes to the set of subGenotypes
for which both entities are one of the following (Reg-CWD, CWD),
(CWD, Reg-CWD), or (CWD, CWD).  If subGenotypes of this sort are
found, then continue with Determine Singleton Step.

=item B<G-Code and/or P-Code, or (G-Code, P-Code)/(Reg-CWD, CWD)>

This step reduces the set of subGenotypes to the set of subGenotypes
for which both entities are one of the following (G-Code, G-Code),
(P-Code, P-Code), (P-Code, G-Code), (G-Code, P-Code), (G-Code,
Reg-CWD), (Reg-CWD, G-Code), (P-Code, Reg-CWD), (Reg-CWD, P-Code),
(G-Code, CWD), (CWD, G-Code), (P-Code, CWD), or (CWD, P-Code).  If
subGenotypes of this sort are found, then continue with Determine
Singleton Step.

=item B<Reg-Rare and Reg-CWD, or CWD or G-Code or P-Code>

This step reduces the set of subGenotypes to the set of subGenotypes
for which both entities are one of the following (Reg-CWD, Reg-Rare),
(Reg-Rare, Reg-CWD), (CWD, Reg-Rare), (Reg-Rare, CWD),
(G-Code, Reg-Rare), (Reg-Rare, G-Code), (P-Code, Reg-Rare), or
(Reg-Rare, P-Code).  If subGenotypes of this sort are found, then
continue with Determine Singleton Step.

=item B<Reg-Rare/Reg-Rare>

This step reduces the set of subGenotypes to the set of subGenotypes
for which both entities are both Reg-Rare.  If subGenotypes of this
sort are found, then continue with Determine Singleton Step.

=item B<Determine Singleton>

If the set of subGenotypes a single subGenotype, then the genotype is
determined and processing terminates for the set, otherwise continue
to the next Step.

=item B<Homozygous Allele Processing>

The homozygous allele processing step consists of two actions on the
set of subGenotypes to generate a reduced set of subGenotypes:

Determine homozygous subGenotypes: For a give subGenotype (AS1, AS2),
if both AS1 and AS2 are both alleles and AS1 = AS2 (identically), then
this subGenotype is homozygous and the subGenotype is added to the
reduced set of subGenotypes.  Also, the homozygous allele AS1 is added
to a list of homozygous alleles for the next action.

Add non-homozygous subGenotypes: For a subGenotype (AS3, AS4) of the
set of subGenotypes that is not homozygous from action a., add this
subGenotype to the reduced set of subGenotypes, if either AS3 or AS4
occurs in the list of homozygous alleles generated in action a.

=item B<Lowest Sum HLA Protein Field Processing>

This step consists of ordering the set of subGenotypes by an assigned
number as follows.  This assigned number is the sum of the HLA protein
field of the two alleleSets (note the HLA protein field is an
integer).  That is, assume that a subGenotype, (AS1, AS2) has the
format: (a11:a12, a21:a22) without code suffixes or the coding region
field in the case of G-Code.  The assigned number is a12 + a22.  The
set of subGenotypes is now ordered into a list using the assigned
number from lowest to highest.  If there is only one subGenotype with
the lowest assigned number in the ordered list, then this subGenotype
is the genotype.  Otherwise, an error occurs and is reported.

=back

=head2 B<formatDatum(sub_genotype)>

This method formats a sub_genotype and is used by the method
B<formatData> in the class L<util::Messaging>.  The format for a
sub_genotype is defined as follows B<(allele_1, allele_2)>.

=cut
