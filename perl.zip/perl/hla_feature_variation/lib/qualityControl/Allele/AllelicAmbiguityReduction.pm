package qualityControl::Allele::AllelicAmbiguityReduction;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use Pod::Usage;

use util::Constants;
use util::Set;
use util::Table;

use db::MhcTypes;

use qualityControl::ErrMsgs;

use base 'qualityControl::Allele';

use fields qw (
  allele_set_table
  col_name
  current_steps
  formated_data
  mrwaf_threshold
  sample_id
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Writing allele data for an allele set
###
my %ALLELE_DATA_COLS = (
  orig_allele => 'Original Name',
  allele      => 'Peptide-level',
  type        => 'Type',
  gcode       => 'G-Code',
  pcode       => 'P-Code',
  cwd         => 'CWD',
  rare        => 'Rare',
  reg_cwd     => 'reg-CWD',
  reg_rare    => 'reg-Rare',
  reg_freq    => 'Region Freq'
);

my @ALLELE_DATA_ORD = (
  'allele',   'orig_allele', 'type', 'gcode',
  'pcode',    'cwd',         'rare', 'reg_cwd',
  'reg_rare', 'reg_freq',
);

my $HLA_PROTEIN_INDEX = 1;

my $ALLELE_ORD = 'sub {'
  . '$a->{orig_nomen}->{allele_group} <=> $b->{orig_nomen}->{allele_group}'
  . ' or $a->{orig_nomen}->{hla_protein} <=> $b->{orig_nomen}->{hla_protein}'
  . ' or $a->{orig_nomen}->{coding_region} <=> $b->{orig_nomen}->{coding_region}'
  . ' or $a->{orig_nomen}->{non_coding_region} <=> $b->{orig_nomen}->{non_coding_region}'
  . ';}';

my $EPILOGUE =
  "Global and Region CWD statuses are computed at the 4-digit level.
That is, only the peptide-level (allele group and HLA protein fields)
of an allele is used in determining these statuses.";
###
### Error Category
###
sub ERR_CAT { return qualityControl::ErrMsgs::ALLELICAMBIGUITYREDUCTION_CAT; }
###
### Entities Header
###
sub ENTITY_SPACER        { return "                    "; }
sub NUM_ENTITIES_PER_ROW { return 8; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _reduceAllelesByType {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ( $type, @alleles ) = @_;
  my @reduced_set = ();
  my $foundType   = util::Constants::FALSE;
  foreach my $allele (@alleles) {
    ###
    ### For all types except 'rare', keep alleles of the type as defined
    ### by the condition.  For 'rare' type, keep all alleles that are not
    ###
    ### Note:  G- and P-codes are left 'as-is' and are not processed
    ###
    if ( ( $type eq 'reg_cwd' && $allele->{reg} && $allele->{reg_cwd} )
      || ( $type eq 'reg_rare' && $allele->{reg} && $allele->{reg_rare} )
      || ( $type eq 'cwd' && $allele->{cwd} )
      || $allele->{type} eq $this->GCODE_TYPE
      || $allele->{type} eq $this->PCODE_TYPE )
    {
      push( @reduced_set, $allele );
      if ( $allele->{type} ne $this->GCODE_TYPE
        && $allele->{type} ne $this->PCODE_TYPE )
      {
        $foundType = util::Constants::TRUE;
      }
    }
  }
  return ( $foundType, @reduced_set );
}

sub _removeRareAlleles {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;
  ###
  ### Determine if the alleleSet contains
  ### any G-Codes or P-Codes
  ###
  my $found_code = util::Constants::FALSE;
  foreach my $allele (@alleles) {
    next
      if ( $allele->{type} ne $this->GCODE_TYPE
      && $allele->{type} ne $this->PCODE_TYPE );
    $found_code = util::Constants::TRUE;
    last;
  }
  ###
  ### If no Codes, then return immediately
  ###
  return @alleles if ( !$found_code );
  ###
  ### Now remove Rare alleles that are neither
  ### Reg-CWD nor Reg-Rare, if any
  ###
  my @reduced_set = ();
  foreach my $allele (@alleles) {
    next if ( !$allele->{reg} && $allele->{rare} );
    push( @reduced_set, $allele );
  }
  push( @{ $this->{current_steps} }, 'Removed rare alleles' )
    if ( scalar @alleles != scalar @reduced_set );

  return @reduced_set;
}

sub _generateAlleleFromCode {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ( $locus, $code, $code_type ) = @_;

  my $locus_data = {};
  my $data       = $this->createCellData( $locus_data, $code );
  my $comps      = $code;
  $comps =~ s/^.+\*//;
  $this->generateNomenclature( $data, $comps );

  my $struct = {
    locus    => $locus,
    allele   => $code,
    data     => $data,
    type     => $code_type,
    gcode    => ( $code_type eq $this->GCODE_TYPE ) ? $code : undef,
    pcode    => ( $code_type eq $this->PCODE_TYPE ) ? $code : undef,
    cwd      => undef,
    rare     => undef,
    reg      => undef,
    reg_cwd  => undef,
    reg_rare => undef,
  };

  return $struct;
}

sub _reduceAllelesByCode {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ( $code_type, @alleles ) = @_;

  my $lookup = $this->{lookup};

  my @reduced_set = ();
  my %codes       = ();
  foreach my $allele (@alleles) {
    ###
    ### For alleles, if it has a code,
    ### add it to codes if not defined,
    ### and/or increment.
    ###
    if ( $allele->{type} eq $this->ALLELE_TYPE
      && defined( $allele->{$code_type} ) )
    {
      if ( !defined( $codes{ $allele->{$code_type} } ) ) {
        $codes{ $allele->{$code_type} } = {
          allele => $allele,
          count  => 0,
        };
      }
      $codes{ $allele->{$code_type} }->{count}++;
    }
    elsif (
      (
        $code_type eq $this->PCODE_TYPE && $allele->{type} eq $this->PCODE_TYPE
      )
      || ( $code_type eq $this->GCODE_TYPE
        && $allele->{type} eq $this->GCODE_TYPE )
      )
    {
      ###
      ### If the code has already seen, the increment
      ### and there will a reduction by this code.
      ###
      ### Otherwise, add the code and increment,  if
      ### it the code does not appear again, it will
      ### left as the code, else we will reduce by
      ### this code
      ###
      if ( !defined( $codes{ $allele->{$code_type} } ) ) {
        $codes{ $allele->{$code_type} } = {
          allele => $allele,
          count  => 0,
        };
      }
      $codes{ $allele->{$code_type} }->{count}++;
    }
    elsif ( $code_type eq $this->GCODE_TYPE
      && $allele->{type} eq $this->PCODE_TYPE )
    {
      ###
      ### Add the P-Code to reduced set
      ### 'as-is' (a pass through)
      ###
      push( @reduced_set, $allele );
    }
    elsif ( $code_type eq $this->PCODE_TYPE
      && $allele->{type} eq $this->GCODE_TYPE )
    {
      my $nomen = $allele->{data}->{nomen};
      ###
      ### If a G-code has been found, then must
      ### determine if G-code can be replaced by
      ### P-code.
      ###
      ### If it can be replaced by a P-Code, then
      ### there must be other entities for which
      ### the P-Code is a replacement to use this
      ### P-Code.
      ###
      my $potential_p_code = join( util::Constants::ASTERISK,
        $allele->{locus},
        join( util::Constants::COLON,
          $nomen->{db::MhcTypes::ALLELE_GROUP_COL},
          $nomen->{db::MhcTypes::HLA_PROTEIN_COL}
        )
      ) . 'P';
      my $pcodelookup = $lookup->getLookupTable( $lookup->ImgtHlaPCodesLookup );
      if ( $pcodelookup->keyDefined($potential_p_code) ) {
        if ( !defined( $codes{$potential_p_code} ) ) {
          $codes{$potential_p_code} = {
            allele => $allele,
            count  => 0,
          };
        }
        $codes{$potential_p_code}->{count}++;
      }
      else {
        push( @reduced_set, $allele );
      }
    }
    else {
      push( @reduced_set, $allele );
    }
  }
  my $found_code = util::Constants::FALSE;
  foreach my $code ( sort keys %codes ) {
    if ( $codes{$code}->{count} == 1 ) {
      push( @reduced_set, $codes{$code}->{allele} );
      next;
    }
    $found_code = util::Constants::TRUE;
    push( @reduced_set,
      $this->_generateAlleleFromCode( $alleles[0]->{locus}, $code, $code_type )
    );
  }

  return ( $found_code, @reduced_set );
}

sub _detemineAlleleGroups {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;

  my %allele_groups = ();
  foreach my $allele (@alleles) {
    $allele_groups{ $allele->{data}->{nomen}->{allele_group} } =
      util::Constants::EMPTY_STR;
  }
  push(
    @{ $this->{current_steps} },
    'Determined allele group field(s) for alleleSet'
  );

  return sort keys %allele_groups;
}

sub _printStepsProcessed {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ($alleleSet) = @_;

  $this->{error_mgr}->printHeader( "Steps Processed\n"
      . "  Population Area = "
      . $this->{population_area} . "\n"
      . "  Row Num         = "
      . $this->{msgs}->getRowNum . "\n"
      . "  Row id          = "
      . $this->{sample_id} . "\n"
      . "  Col Name        = "
      . $this->{col_name} . "\n"
      . "  alleleSet       = $alleleSet\n"
      . "  Steps           = ("
      . join( ",\n                     ", @{ $this->{current_steps} } )
      . ")" );
}

sub _processSingleton {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ($allele) = @_;

  my $ambiguous_alleleset =
    util::Constants::EMPTY_LINE( $this->{formated_data} )
    ? util::Constants::FALSE
    : util::Constants::TRUE;

  push( @{ $this->{current_steps} }, 'Generated singleton entity' );
  my $type = $allele->{type};
  my $names =
    [ 'entity returned', 'entity type', 'alleleSet', 'steps processed' ];
  my $ret_allele = $allele->{allele};
  $ret_allele =~ s/^\w+\*//;
  ###
  ### Now depending on the allele type different data
  ### will be generated into the message
  ###
  my $msg = undef;
  if ($ambiguous_alleleset) {
    $msg = 'Cell reduced from ambiguous alleleSet';
  }
  else {
    $msg = 'Cell contains a single allele/code';
  }
  ###
  ### write result message
  ###
  $this->{msgs}->addResult(
    $msg, $names,
    {
      alleleSet => $ambiguous_alleleset ? $this->{formated_data} : $ret_allele,
      'entity returned' => $ret_allele,
      'entity type'     => $type,
      'steps processed' => '('
        . join( ",\n                     ", @{ $this->{current_steps} } ) . ')',
    },
    $this->{msgs}->MSG_MSG
  );
  $this->_printStepsProcessed($ret_allele) if ($ambiguous_alleleset);

  return $ret_allele;
}

sub _sortHlaProtein {
  $a->{data}->{nomen}->{allele_group} <=> $b->{data}->{nomen}->{allele_group}
    or $a->{data}->{nomen}->{hla_protein} <=> $b->{data}->{nomen}->{hla_protein}
    or $a->{data}->{nomen}->{coding_region} <=> $b->{data}->{nomen}
    ->{coding_region};
}

sub _lowestHlaProtein {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;

  push(
    @{ $this->{current_steps} },
    'Chose entity with lowest HLA protein field'
  );
  @alleles =
    sort qualityControl::Allele::AllelicAmbiguityReduction::_sortHlaProtein
    @alleles;

  return $this->_processSingleton( $alleles[0] );
}
###
### Note: this gives the descending sort (largest first)
###
sub _sortMrwaf {
  $b->{mrwaf_ratio} <=> $a->{mrwaf_ratio};
}

sub _reduceAllelesByMRWAFFrequency {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;
  ###
  ### ASSUMPTION:  alleleSet has a common allele group
  ###
  ### Determine all codes so that they can be used later
  ### in determining the @reduced_set below
  ###
  ### Also, determine which alleles have non-zero frequencies
  ### and whether all alleles are zero
  ###
  $this->{tools}
    ->debugStruct( "_reduceAllelesByMRWAFFrequency:  alleles", \@alleles );
  my @codes         = ();
  my %mrwaf_alleles = ();
  my $all_zero      = util::Constants::TRUE;
  foreach my $allele (@alleles) {
    if ( $allele->{type} eq $this->ALLELE_TYPE ) {
      if ( $allele->{reg_freq} != 0 ) {
        $mrwaf_alleles{ $allele->{allele} } = $allele;
        $all_zero = util::Constants::FALSE;
      }
    }
    else {
      push( @codes, $allele );
    }
  }
  ###
  ### Return immediately if all frequencies are zero
  ###
  if ($all_zero) {
    push(
      @{ $this->{current_steps} },
      'Determined all MRWAF frequencies are zero'
    );
    return $this->_lowestHlaProtein(@alleles);
  }
  ###
  ### Now compute the MRWAF ratios.
  ###
  my @ratio_subsets    = ();
  my $set_of_alleles   = [ sort keys %mrwaf_alleles ];
  my $alleleSet        = new util::Set( $this->{error_mgr}, $set_of_alleles );
  my @pairwise_subsets = $alleleSet->getPairwiseSubsets;
  $this->{tools}->debugStruct( "MRWAF pairwise subsets", \@pairwise_subsets );
  my $allelesLessThanEqualX = {};
  my $allelesGreaterThanX   = {};
  foreach my $pairwise_subset (@pairwise_subsets) {
    my $allele1     = $mrwaf_alleles{ $pairwise_subset->[0] };
    my $allele2     = $mrwaf_alleles{ $pairwise_subset->[1] };
    my $mrwaf_ratio = undef;
    my $numerator   = undef;
    my $denominator = undef;
    if ( $allele1->{reg_freq} > $allele2->{reg_freq} ) {
      $mrwaf_ratio = $allele1->{reg_freq} / $allele2->{reg_freq};
      $numerator   = $allele1;
      $denominator = $allele2;
    }
    else {
      $mrwaf_ratio = $allele2->{reg_freq} / $allele1->{reg_freq};
      $numerator   = $allele2;
      $denominator = $allele1;
    }
    $this->{error_mgr}->printDebug
      ("(numerator, denominator, ratio) = (" .
        join(util::Constants::COMMA_SEPARATOR,
	     $numerator->{allele},
	     $denominator->{allele},
	     $mrwaf_ratio) . ")");
    ###
    ### Must make sure that any allele in a pair
    ### for which <= X that does not appear in
    ### an ordered pair > X is kept in the reduced
    ### alleleSet
    ###
    my $bin = undef;
    if ( $mrwaf_ratio <= $this->{mrwaf_threshold} ) {
      $bin = $allelesLessThanEqualX;
    }
    else {
      $bin = $allelesGreaterThanX;
    }
    $bin->{$numerator->{allele}}   = util::Constants::EMPTY_STR;
    $bin->{$denominator->{allele}} = util::Constants::EMPTY_STR;

    next if ( $mrwaf_ratio <= $this->{mrwaf_threshold} );
    ###
    ### Add the MRWAF
    ###
    my $ratioSubset = {
      numerator   => $numerator,
      denominator => $denominator,
      mrwaf_ratio => $mrwaf_ratio,
    };
    push( @ratio_subsets, $ratioSubset );
  }
  ###
  ### Determine if there are any ratios
  ### are above the threshold
  ###
  my $process_mrwaf =
    ( scalar @ratio_subsets > 0 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### Return immediately, if there are no MRWAF ratios
  ### above the threshold
  ###
  if ( !$process_mrwaf ) {
    push(
      @{ $this->{current_steps} },
      'No MRWAF ratio found above the threshold for alleleSet'
    );
    return $this->_lowestHlaProtein(@alleles);
  }
  ###
  ### Order MRWAF ratios and determine alleles
  ### to remove
  ###
  push(
    @{ $this->{current_steps} },
    'MRWAF ratio(s) found above threshold for alleleSet'
  );
  @ratio_subsets =
    sort qualityControl::Allele::AllelicAmbiguityReduction::_sortMrwaf
    @ratio_subsets;
  $this->{tools}
    ->debugStruct( "MRWAF ratio subsets (sorted)", \@ratio_subsets );
  my %remove_alleles = ();
  foreach my $ratioSubset (@ratio_subsets) {
    my $dem = $ratioSubset->{denominator}->{allele};
    $remove_alleles{$dem} = util::Constants::EMPTY_STR;
  }
  my @reduced_mrwaf_alleles = ();
  foreach my $mrwaf_allele ( @{$set_of_alleles} ) {
    next if ( defined( $remove_alleles{$mrwaf_allele} ) );
    push( @reduced_mrwaf_alleles, $mrwaf_alleles{$mrwaf_allele} );
  }
  push( @{ $this->{current_steps} }, 'Reduced alleleSet using MRWAF ratios' );
  ###
  ### Determine the reduced set
  ###
  ### Note:  All codes are added back at this point.
  ###        and all alleles in ordered pairs <= X
  ###        that did not appear in the > X ordered
  ###        pairs
  ###
  my @reduced_set = ();
  push( @reduced_set, @codes );
  push( @reduced_set, @reduced_mrwaf_alleles );
  foreach my $allele ( keys %{$allelesLessThanEqualX} ) {
    next if ( defined( $allelesGreaterThanX->{$allele} ) );
    push( @{ $this->{current_steps} }, "Keeping MRWAF allele $allele" );
    push( @reduced_set, $mrwaf_alleles{$allele} );
  }
  ###
  ### If there is only one allele left return
  ### processing singleton
  ###
  return $this->_processSingleton( $reduced_set[0] )
    if ( scalar @reduced_set == 1 );
  ###
  ### Reduce by lowest HLA protein
  ###
  return $this->_lowestHlaProtein(@reduced_set);
}

sub _reduceAmbiguity {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;

  my $tools = $this->{tools};
  $tools->debugStruct( "alleles", \@alleles );
  ###
  ### Reduce by Reg-CWD, CWD, Reg-Rare, in that order
  ###
  my ( $found_reg_cwd, @reg_cwds ) =
    $this->_reduceAllelesByType( 'reg_cwd', @alleles );
  my ( $found_reg_rare, @reg_rares ) =
    $this->_reduceAllelesByType( 'reg_rare', @alleles );
  my ( $found_cwd, @cwds ) = $this->_reduceAllelesByType( 'cwd', @alleles );
  $tools->debugStruct( "reg_cwds",  \@reg_cwds );
  $tools->debugStruct( "reg_rares", \@reg_rares );
  $tools->debugStruct( "cwds",      \@cwds );

  my @reduced_set = @alleles;
  my $step        = undef;
  if ($found_reg_cwd) {
    @reduced_set = @reg_cwds;
    $step        = 'Reg-CWD';
  }
  elsif ($found_cwd) {
    @reduced_set = @cwds;
    $step        = 'CWD';
  }
  elsif ($found_reg_rare) {
    @reduced_set = @reg_rares;
    $step        = 'Reg-Rare';
  }
  if ( defined($step) ) {
    push( @{ $this->{current_steps} }, "Processed $step" );
    $tools->debugStruct(
      "reduced_set ($step--num entities " . scalar @reduced_set . ")",
      \@reduced_set );
    return $this->_processSingleton( $reduced_set[0] )
      if ( @reduced_set == 1 );
  }
  ###
  ### Reduce by G-Code groups
  ###
  $step = 'G-Code';
  my ( $found_gcodes, @gcodes ) =
    $this->_reduceAllelesByCode( $this->GCODE_TYPE, @reduced_set );
  push( @{ $this->{current_steps} }, "Processed $step" )
    if ($found_gcodes);
  return $this->_processSingleton( $gcodes[0] )
    if ( @gcodes == 1 );
  @reduced_set = @gcodes;
  ###
  ### Reduce by P-Code groups
  ###
  $step = 'P-Code';
  my ( $found_pcodes, @pcodes ) =
    $this->_reduceAllelesByCode( $this->PCODE_TYPE, @reduced_set );
  push( @{ $this->{current_steps} }, "Processed $step" )
    if ($found_pcodes);
  return $this->_processSingleton( $pcodes[0] )
    if ( @pcodes == 1 );
  @reduced_set = @pcodes;
  $tools->debugStruct(
    "reduced_set after codes ($step--num entities " . scalar @reduced_set . ")",
    \@reduced_set
  );
  ###
  ### Remove all rare alleles if there are
  ### G-Codes or P-Codes in the alleleSet
  ###
  @reduced_set = $this->_removeRareAlleles(@reduced_set);
  $tools->debugStruct(
    "reduced_set after rare removal ($step--num entities "
      . scalar @reduced_set . ")",
    \@reduced_set
  );
  return $this->_processSingleton( $reduced_set[0] ) if ( @reduced_set == 1 );
  ###
  ### Determine Allelic Group(s)
  ###
  my @allele_groups = $this->_detemineAlleleGroups(@reduced_set);
  if ( @allele_groups == 1 ) {
    push(
      @{ $this->{current_steps} },
      'Determined single allele group field for alleleSet'
    );
    return $this->_reduceAllelesByMRWAFFrequency(@reduced_set);
  }
  else {
    push(
      @{ $this->{current_steps} },
      'ERROR:  Determined multiple allele group fields for alleleSet'
    );
    ###
    ### Error condition
    ###
    my $msgs = $this->{msgs};
    $msgs->registerError(
      ERR_CAT, 2,
      [
        $this->{formated_data},
        $msgs->formatData(
          $this,                      util::Constants::EMPTY_STR,
          util::Constants::EMPTY_STR, ENTITY_SPACER,
          NUM_ENTITIES_PER_ROW,       @reduced_set
        ),
      ],
      util::Constants::TRUE
    );
    $this->_printStepsProcessed;

    return util::Constants::EMPTY_STR;
  }
}

sub _printAlleleSet {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@alleles) = @_;

  my $header =
      "Allele Data\n"
    . "  Population Area = "
    . $this->{population_area} . "\n"
    . "  Row Num         = "
    . $this->{msgs}->getRowNum . "\n"
    . "  Row id          = "
    . $this->{sample_id} . "\n"
    . "  Col Name        = "
    . $this->{col_name};

  $this->{allele_set_table}->setData(@alleles);
  $this->{allele_set_table}->generateTable( $header, $EPILOGUE );
}

sub _removeAlleleGroups {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@comps) = @_;

  my $msgs          = $this->{msgs};
  my @reduced_comps = ();
  foreach my $comp (@comps) {
    if ( $comp->{agroup} ) {
      $msgs->registerError( ERR_CAT, 1, [ $this->generateCompName($comp) ],
        util::Constants::TRUE );
      next;
    }
    push( @reduced_comps, $comp );
  }
  push(
    @{ $this->{current_steps} },
    'Removed alleles with only allele group field'
  ) if ( scalar @reduced_comps != scalar @comps );

  return @reduced_comps;
}

sub _reduceCell {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my (@comps) = @_;
  ###
  ### 1.  Remove all alleles that have only allele group field
  ###     If there are no components left, then return immediately
  ###
  @comps = $this->_removeAlleleGroups(@comps);
  return $this->{reader}->getEmptyVal if ( @comps == 0 );
  ###
  ### 2.  Replace all alleles with HLA protein name
  ###
  my %new_comps   = ();
  my @all_alleles = ();
  foreach my $cell_data (@comps) {
    my $new_cell_data = undef;
    ###
    ### If the component is an IMGT/HLA code, leave the code 'as-is'
    ###
    if ( $cell_data->{type} eq $this->DIGIT_GCODE
      || $cell_data->{type} eq $this->DIGIT_PCODE
      || $cell_data->{type} eq $this->GCODE_NAME
      || $cell_data->{type} eq $this->PCODE_NAME )
    {
      $new_cell_data = $cell_data;
    }
    elsif ( $cell_data->{current} ) {
      ###
      ### At this point, I do not keep suffix
      ### if the cell is a NULL HLA Protein.
      ### Also, At this point, I do not keep duplicates
      ###
      my $nomen  = $cell_data->{nomen};
      my $allele = join( util::Constants::COLON,
        $nomen->{&db::MhcTypes::ALLELE_GROUP_COL},
        $nomen->{&db::MhcTypes::HLA_PROTEIN_COL}
      );
      ###
      ### Now, create the new cell data
      ###
      $new_cell_data         = $this->copyCellData($cell_data);
      $new_cell_data->{cell} = $allele;
      $new_cell_data->{type} = $this->DIGIT_NAME;

      my $new_nomen = $new_cell_data->{nomen};
      $new_nomen->{max_index} = $HLA_PROTEIN_INDEX;
      $new_nomen->{max_comp}  = db::MhcTypes::HLA_PROTEIN_COL;
      $new_nomen->{&db::MhcTypes::ALLELE_GROUP_COL} =
        $nomen->{&db::MhcTypes::ALLELE_GROUP_COL};
      $new_nomen->{&db::MhcTypes::HLA_PROTEIN_COL} =
        $nomen->{&db::MhcTypes::HLA_PROTEIN_COL};
    }
    ###
    ### skip if neither a G-Code, P-Code, or current allele
    ###
    next if ( !defined($new_cell_data) );
    ###
    ### For printing the alleleSet
    ###
    my $allele_data = $this->alleleData($new_cell_data);
    $allele_data->{orig_allele} = $cell_data->{cell};
    $allele_data->{orig_nomen}  = $cell_data->{nomen};
    push( @all_alleles, $allele_data );
    ###
    ### Removing duplicates
    ###
    $new_comps{ $new_cell_data->{cell} } = $new_cell_data;
  }
  my $step = 'Reduced alleles to HLA protein format';
  push( @{ $this->{current_steps} }, $step );
  $this->_printAlleleSet(@all_alleles) if ( scalar @all_alleles > 1 );
  ###
  ### 3.  Determine alleles without duplicates
  ###
  my @alleles = ();
  foreach my $final_allele ( sort keys %new_comps ) {
    my $allele_data = $this->alleleData( $new_comps{$final_allele} );
    push( @alleles, $allele_data );
  }
  my $formatedData =
    $this->{msgs}
    ->formatData( $this, util::Constants::EMPTY_STR, util::Constants::EMPTY_STR,
    ENTITY_SPACER, NUM_ENTITIES_PER_ROW, @all_alleles );
  if ( scalar @alleles != scalar @comps ) {
    $step = 'Removed duplicates';
    push( @{ $this->{current_steps} }, $step );
    ###
    ### Singleton case with duplicates
    ###
    $this->{formated_data} = $formatedData;
    return $this->_processSingleton( $alleles[0] )
      if ( @alleles == 1 );
  }
  ###
  ### 4.  Singleton case with no duplicates
  ###
  $this->{formated_data} = undef;
  return $this->_processSingleton( $alleles[0] ) if ( @alleles == 1 );
  ###
  ### 5.  Ambiguous case
  ###
  $this->{formated_data} = $formatedData;
  return $this->_reduceAmbiguity(@alleles);
}

sub _createAlleleSetTable {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;

  my $table = new util::Table( $this->{error_mgr}, %ALLELE_DATA_COLS );
  $table->setEmptyField(util::Constants::HYPHEN);
  $table->setColumnOrder(@ALLELE_DATA_ORD);
  $table->setInHeader(util::Constants::TRUE);
  $table->setRowOrder($ALLELE_ORD);
  $table->setColumnJustification( 'allele',      $table->LEFT_JUSTIFY );
  $table->setColumnJustification( 'gcode',       $table->LEFT_JUSTIFY );
  $table->setColumnJustification( 'orig_allele', $table->LEFT_JUSTIFY );
  $table->setColumnJustification( 'pcode',       $table->LEFT_JUSTIFY );
  $table->setColumnJustification( 'type',        $table->LEFT_JUSTIFY );

  $this->{allele_set_table} = $table;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  my qualityControl::Allele::AllelicAmbiguityReduction $this =
    $that->SUPER::new( $file_reader, $taxon_id, $tools, $error_mgr );

  $this->_createAlleleSetTable;

  $this->{mrwaf_threshold} = $this->{tools}->getProperty('mrwafThreshold');

  return $this;
}

sub formatDatum {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;
  my ($allele) = @_;

  return $allele->{allele};
}

sub processFile {
  my qualityControl::Allele::AllelicAmbiguityReduction $this = shift;

  my $lookup = $this->{lookup};
  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};
  my $tools  = $this->{tools};
  ###
  ### read the file
  ###
  my $emptyVal = $reader->getEmptyVal;
  $reader->openReader;
  $msgs->resetRowNum;
  ###
  ### Check that Population Area column is defined
  ###
  return if ( $this->populationAreColumnMissing );
  ###
  ### Set the info data to the file to be written
  ###
  my $process_info = "HLA allele ambiguity reduction results";
  $reader->addHeaderInfo( $process_info, $tools->versionInfo );
  ###
  ### process the file
  ###
  foreach my $entity ( $reader->getData ) {
    $msgs->incRowNum;
    $msgs->addDataCapture( $msgs->SUBJECT_TABLE,
      $entity->{ $reader->getIdCol } );
    ###
    ### Check that Population is a a defined population
    ###
    my $unknownPopulationArea = $this->unknownPopulationArea($entity);
    $this->setPopulationArea( $entity->{ $this->{population_col} } )
      if ( !$unknownPopulationArea );

    foreach my $col_name ( $reader->getEntityCols ) {
      ###
      ### reset the current step for the
      ### given sample and alleleSet
      ###
      my $locus_data = $reader->getEntityData($col_name);
      $this->{col_name}      = $locus_data->{col_name};
      $this->{sample_id}     = $entity->{ $reader->getIdCol };
      $this->{current_steps} = [];
      ###
      ### Initialize and components
      ### (remove error components at this point)
      ###
      $msgs->initializeMsgs( $col_name, $entity );
      my @comps = $this->determineComps( $col_name, $entity );
      $msgs->setAmbiguousCell if ( scalar @comps > 1 );
      @comps = $this->removeErrors(@comps);
      ###
      ### If cell is empty, or
      ### there is is no known population,
      ### finalize and skip
      ###
      if ( @comps == 0 ) {
        $entity->{$col_name} = $emptyVal;
        $msgs->finalizeMsgs;
        next;
      }
      elsif ($unknownPopulationArea) {
        $entity->{$col_name} = $emptyVal;
        $msgs->finalizeMsgs;
        next;
      }
      my $cell = $this->_reduceCell(@comps);
      $entity->{$col_name} = $reader->emptyCell($cell) ? $emptyVal : $cell;
      $msgs->finalizeMsgs;
    }
  }

  return if ( !defined( $this->outFile ) );
  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  my $out_file   = $this->outFile;
  $out_file =~ s/$task_infix/$task_id/;
  $reader->writeFile($out_file);
  my @property_data = ();
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Ambiguity Reduced File",
      $tools->VALUE_COL    => basename($out_file),
    },
    {
      $tools->PROPERTY_COL => "MRWAF Frequency Threshold",
      $tools->VALUE_COL    => $this->{mrwaf_threshold},
    }
  );
  $msgs->printStatistics(@property_data);
}

################################################################################

1;

__END__

=head1 NAME

AllelicAmbiguityReduction.pm

=head1 DESCRIPTION

This concrete class defines the allelic ambiguity reduction for an HLA
file.  The parent class is L<qualityControl::Allele>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new qualityControl::Allele::AllelicAmbiguityReduction(file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The file to process is
represented by the B<file_reader> object, an instance of a subclass of
L<file::Mhc::Hla>, the tools object
(L<util::Tools::mhcSeqVar::qualityControl>), and the error logger
(L<util::ErrMgr>).  The taxon_id specifies the species that is being
processed.  Currently, it must be B<9606> (Homo sapiens).

=head2 B<processFile>

This method processes the file to perform allelic ambiguity reduction
for each locus column and sample row cell.  This method assumes that
all data in the file are valid IMGT/HLA version 3 alleles, G-Codes,
and P-Codes.  This method assumes that the 'Population Area' column
exists in the file and contains a valid population area region name or
abbreviation (case-insensitive), otherwise errors are generated into
log, either the file or row is skipped, respectively.

For each cell, the following processing is performed.  For each allele
in the cell, the allele is reduced to it 4-digit format, that is, only
the allele group and HLA protein fields of the allele are retained.
For G-Codes and P-Codes, their names are left 'as-is'.  If the cell
contains only one allele processing is concluded, otherwise the cell
is reduced.  For an ambiguous cell, each component has it allele data
assigned to it using the method B<alleleData>.  Then the allele data
for the the cell is generated as a table B<Allele Data> into the log
containing the following columns:

  Original Name -- name of the entity in the input file
  Peptide-level -- 4-digit name for an (allele group and HLA protein fields only)
                   or G-Codes and P-Code their name 'as-is'
  Type          -- allele, gcode, pcode
  G-Code        -- IMGT/HLA G-Code for entity
  P-Code        -- IMGT/HLA G-Code for entity
  CWD           -- For an allele, whether CWD (1) or not (0)
  Rare          -- For an allele, whether Rare (1) or not (0)
  reg-CWD       -- For an allele, whether Reg-CWD (1), or reg-Rare (0),
                   or unknown (-) for given population area region
  reg-Rare      -- For an allele, whether Reg-Rare (1), or reg-CWD (0),
                   or unknown (-) for given population area region
  Region Freq   -- For an allele, it region-specific frequency for
                   population area region, otherwise 0 if unknown

Once allele reduction to 4-digit format occurred, all duplicate
alleles are removed.  If the cell is a singleton, then it is returned
as the allelic reduction, otherwise the following allelic ambiguity
reduction algorithm is performed on the cell.  The set of
alleles/codes contained in the cell is called an alleleSet.

=over 4

=item B<Reduce by Reg-CWD>

This Step involves keeping only Reg-CWD alleles and all codes in the
alleleSet.  If any Reg-CWD alleles are found, then this step proceeds
to B<Determine Singleton> Step, otherwise it proceeds to the next
Step.

=item B<Reduce by CWD>

This Step involves keeping only CWD alleles and all codes in the
alleleSet.  If any CWd alleles are found, then this step proceeds to
B<Determine Singleton> Step, otherwise it proceeds to the next Step.

=item B<Reduce by Reg-Rare>

This Step involves keeping only Reg-Rare alleles and all codes in the
alleleSet.  Proceed to the next Step.

=item B<Determine Singleton>

If the alleleSet contains a singleton, then processing terminates for
the cell, otherwise continue to the next Step.

=item B<Reduce by G-Code>

Reduce all alleles and G-Codes to G-Codes as follows.  If there are at
least two alleles or an allele and G-Code in the alleleSet that can be
reduced to a single G-Code, then reduce the alleleSet by replacing the
allele(s) and/or G-Code(s) by their G-code.  Leave P-Codes 'as-is'.
If there has been a reduction by G-code and there is only a singleton
entity left, processing terminates for the cell, otherwise go the the
next Step.

=item B<Reduce by P-Code>

Reduce all alleles, G-Codes, P-Codes to P-Codes as follows.  If there
are at least two alleles, an allele and P-Code, an allele and G-Code,
or G-Code and P-Code, that can be reduced to a single P-Code, then
reduce the alleleSet by replacing the allele(s) and/or P-Code(s)
and/or G-Codes by their corresponding P-code.  If there has been a
reduction by P-code and there is only a singleton entity left,
processing terminates for the cell, otherwise go the the next Step.

=item B<Rare Allele Removal>

If the alleleSet contains no G-Codes and/or P-Codes, then proceed to
the Determine Single Allele Group Step.  Otherwise, remove all Rare
alleles that are not reg-CWD nor reg-Rare.  If there is only a
singleton, then processing terminates, otherwise go the Determine
Single Allele Group Step.

=item B<Determine Single Allele Group>

Determine the unique allele groups contained in the alleleSet.  If
there are multiple allele groups, then an error has occurred and
processing terminates.  Otherwise, with a unique allele the allelSet
go to the next Step

=item B<MRWAF Ratio Computation and Allele Elimination>

This Step computes the MRWAF frequency ratios for alleles in the
alleleSet and determines which alleles to eliminate to generate a
reduced alleleSet.  All codes (G-Codes and P-Codes) in the input
alleleSet to this step are passed into the reduced alleleSet ‘as-is’,
and do not take part in this step.  Also, this Step assumes that all
alleles in the alleleSet have the same allele group field.  This step
depends on a MRWAF ratio threshold X.  Currently, X is set at 9.49999.
First, choose all alleles in the alleleSet that have a region-specific
frequency > 0.  For these alleles determine the set of ordered pairs
(a1, a2) where the frequency of a1 > frequency of a2.  For these
ordered pairs compute the ratio freq_a1 / freq_a2.  Keep the ordered
pairs for which the ratio > X.  Now order this reduced set of ordered
pairs in descending order of their ratios.  For each order pair 
(a1, a2) in this order list, remove the allele a2 from the input
alleleSet to determine the reduced alleleSet.  Also, any allele
appearing in an ordered pair for which the ratio <= X and does not
appear in an ordered pair for which the ratio > X, then this allele is
also added to the reduced alleleSet. If the reduced alleleSet has only
one entity, then this is the final result for the alleleSet, otherwise
pass the reduced alleleSet onto the next Step.

If all alleles have frequency = 0 or all ordered pairs have ratio <=
X, then pass the input alleleSet to this Step onto the next Step
unchanged.

=item B<Allele Group and HLA Protein Field Processing>

For a given alleleSet, the following action is performed assuming that
all entities in the alleleSet have the allele group field.  Sort the
entities in the alleleSet by the HLA protein field with the lowest
first (note the HLA protein field is an integer) into a hlaProtein
list.  Choose the first entity in this list and make this the
alleleSet.

=back

=head2 B<formatDatum(allele)>

This method formats an allele (leaves it 'as-is') and is used by the
method B<formatData> in the class L<util::Messaging>.

=cut
