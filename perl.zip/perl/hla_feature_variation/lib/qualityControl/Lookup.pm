package qualityControl::Lookup;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use qualityControl::ErrMsgs;

use fields qw(
  error_mgr
  lookup_tables
  tools
  taxon_id
  region_lookup_tables
);

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Lookup Tables
###
sub DeletedNamesLookup { return 'DeletedNames'; }

sub ImgtHlaCodingRegionGCodesLookup {
  return 'Alleles::ImgtHlaCodes::GCodes::CodingRegion';
}

sub ImgtHlaCodingRegionPCodesLookup {
  return 'Alleles::ImgtHlaCodes::PCodes::CodingRegion';
}
sub ImgtHlaGCodesLookup { return 'Alleles::ImgtHlaCodes::GCodes'; }

sub ImgtHlaHlaProteinPCodesLookup {
  return 'Alleles::ImgtHlaCodes::PCodes::HlaProtein';
}
sub ImgtHlaPCodesLookup { return 'Alleles::ImgtHlaCodes::PCodes'; }
sub NmdpCodesLookup     { return 'NmdpCodes'; }
sub ReplacementAlleles  { return 'ReplacementAlleles'; }
sub ReplacementTypes    { return 'ReplacementTypes'; }
###
### Global Cano CWD Lookup tables
###
sub CwdAllelesLookup             { return 'CanoCwdAlleles'; }
sub CwdAllelesHlaProteinLookup   { return 'CanoCwdAlleles::HlaProtein'; }
sub CwdAllelesCodingRegionLookup { return 'CanoCwdAlleles::CodingRegion'; }
###
### Region/Locus Specific Lookup Tables
###
sub RegionCwdAllelesLookup         { return 'RegionCwdAlleles'; }
###
### Error Category
###
sub ERR_CAT { return qualityControl::ErrMsgs::LOOKUP_CAT; }

################################################################################
#
#                           Private Methods
#
################################################################################

sub _createLookupTable {
  my qualityControl::Lookup $this = shift;
  my ( $lookup_store, $lookup_table, @params ) = @_;

  my @params_array = ();
  foreach my $param (@params) {
    push( @params_array, '"' . $param . '",' );
  }
  my $class =
    join( util::Constants::DOUBLE_COLON, 'lookup::LookupTable', $lookup_table );
  my @eval_array = (
    'use ' . $class . ';',
    '$lookup_store->{$lookup_table} =',
    'new ' . $class,
    '  ($this->{taxon_id},',
    @params_array,
    '   $this->{tools},',
    '   $this->{error_mgr});'
  );
  my $eval_str = join( util::Constants::NEWLINE, @eval_array );
  $this->{error_mgr}->printDebug("Lookup Table:  eval_str = $eval_str");
  eval $eval_str;
  my $status = $@;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ $status, $eval_str ],
    defined($status) && $status
  );
}

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$$$) {
  my qualityControl::Lookup $this = shift;
  my ( $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr}            = $error_mgr;
  $this->{lookup_tables}        = {};
  $this->{region_lookup_tables} = {};
  $this->{taxon_id}             = $taxon_id;
  $this->{tools}                = $tools;

  return $this;
}

sub definedLookup {
  my qualityControl::Lookup $this = shift;
  my ($lookup_name) = @_;

  return util::Constants::TRUE if (CwdAllelesLookup);
  return util::Constants::TRUE if (CwdAllelesHlaProteinLookup);
  return util::Constants::TRUE if (CwdAllelesCodingRegionLookup);
  return util::Constants::TRUE if (DeletedNamesLookup);
  return util::Constants::TRUE if (ImgtHlaCodingRegionGCodesLookup);
  return util::Constants::TRUE if (ImgtHlaCodingRegionPCodesLookup);
  return util::Constants::TRUE if (ImgtHlaGCodesLookup);
  return util::Constants::TRUE if (ImgtHlaHlaProteinPCodesLookup);
  return util::Constants::TRUE if (ImgtHlaPCodesLookup);
  return util::Constants::TRUE if (NmdpCodesLookup);
  return util::Constants::TRUE if (ReplacementAlleles);
  return util::Constants::TRUE if (ReplacementTypes);
  return util::Constants::FALSE;

}

sub getLookupTable {
  my qualityControl::Lookup $this = shift;
  my ($lookup_name) = @_;

  return undef if ( !$this->definedLookup($lookup_name) );
  my $lookup = $this->{lookup_tables}->{$lookup_name};
  if ( !defined($lookup) ) {
    $this->_createLookupTable( $this->{lookup_tables}, $lookup_name );
    $lookup = $this->{lookup_tables}->{$lookup_name};
  }
  return $lookup;
}

sub getRegionLookupTable {
  my qualityControl::Lookup $this = shift;
  my ( $region_lookup_name, $pop_area_name, $locus_name ) = @_;

  my $region_lookup = $this->{region_lookup_tables}->{$pop_area_name};
  if ( !defined($region_lookup) ) {
    $this->{region_lookup_tables}->{$pop_area_name} = {};
    $region_lookup = $this->{region_lookup_tables}->{$pop_area_name};
  }
  my $locus_lookup = $region_lookup->{$locus_name};
  if ( !defined($locus_lookup) ) {
    $region_lookup->{$locus_name} = {};
    $locus_lookup = $region_lookup->{$locus_name};
    $this->_createLookupTable( $locus_lookup, $region_lookup_name,
      $pop_area_name, $locus_name );
  }
  return $locus_lookup->{$region_lookup_name};
}

sub getCwd {
  my qualityControl::Lookup $this = shift;
  my ( $allele, $cwdLookup ) = @_;
  ###
  ### Return immediately, if cwdLookup is not
  ### consistent with determination of CWD status.
  ###
  return undef
    if ( $cwdLookup ne CwdAllelesLookup
    && $cwdLookup ne CwdAllelesHlaProteinLookup
    && $cwdLookup ne CwdAllelesCodingRegionLookup );

  my $lookup      = $this->getLookupTable($cwdLookup);
  my %allele_data = (
    cwd         => util::Constants::FALSE,
    rare        => util::Constants::TRUE,
    full_length => undef,
  );
  if ( $lookup->keyDefined($allele) ) {
    my $data = $lookup->getValue($allele);
    $allele_data{cwd}         = util::Constants::TRUE;
    $allele_data{rare}        = util::Constants::FALSE;
    $allele_data{full_length} = $data->{full_length};
  }

  return %allele_data;
}

sub getPAndGCode {
  my qualityControl::Lookup $this = shift;
  my ($allele) = @_;

  my %allele_data = ();
  my $gCodeLookup = undef;
  my $pCodeLookup = undef;
  if ( $allele =~ /^\w+\*\d+:\d+[A-Z]?$/ ) {
    $gCodeLookup = $this->getLookupTable(ImgtHlaGCodesLookup);
    $pCodeLookup = $this->getLookupTable(ImgtHlaHlaProteinPCodesLookup);
  }
  elsif ( $allele =~ /^\w+\*\d+:\d+:\d+[A-Z]?$/ ) {
    $gCodeLookup = $this->getLookupTable(ImgtHlaCodingRegionGCodesLookup);
    $pCodeLookup = $this->getLookupTable(ImgtHlaCodingRegionPCodesLookup);
  }
  else {
    $gCodeLookup = $this->getLookupTable(ImgtHlaGCodesLookup);
    $pCodeLookup = $this->getLookupTable(ImgtHlaPCodesLookup);
  }
  $allele_data{gcode} = $gCodeLookup->getKey($allele);
  $allele_data{pcode} = $pCodeLookup->getKey($allele);
  ###
  ### Now determine HLA protein and coding region alleles
  ###
  if ( $allele =~ /^(^\w+\*\d+:\d+[A-Z]?)/ ) {
    my $hla_protein = $1;
    $allele_data{hla_protein} = $hla_protein;
  }
  if ( $allele =~ /^(^\w+\*\d+:\d+:\d+[A-Z]?)/ ) {
    my $coding_region = $1;
    $allele_data{coding_region} = $coding_region;
  }

  return %allele_data;
}

sub getRegionCwdRare {
  my qualityControl::Lookup $this = shift;
  my ( $pop_area_name, $locus_name, $allele ) = @_;
  ###
  ### Check to see if 'None of the Above' is the population area
  ###
  my %allele_data = ( reg => util::Constants::FALSE );
  return %allele_data
    if ( $pop_area_name eq db::MhcTypes::NONE_OF_THE_ABOVE_POPULATION );
  ###
  ### Now that it is a real population determine region status
  ###
  my $cwdLookup =
    $this->getRegionLookupTable( RegionCwdAllelesLookup, $pop_area_name,
    $locus_name );
  my $val = $cwdLookup->getValue($allele);
  if ( defined($val)
    && ( $val->{cwd_allele} eq 'Y' || $val->{cwd_allele} eq 'N' ) )
  {
    $allele_data{reg} = util::Constants::TRUE;
    $allele_data{reg_cwd} =
      ( $val->{cwd_allele} eq 'Y' )
      ? util::Constants::TRUE
      : util::Constants::FALSE;
    $allele_data{reg_rare} =
      ( $val->{cwd_allele} eq 'N' )
      ? util::Constants::TRUE
      : util::Constants::FALSE;
  }

  return %allele_data;
}

sub getRegionFrequency {
  my qualityControl::Lookup $this = shift;
  my ( $pop_area_name, $locus_name, $allele ) = @_;
  ###
  ### Check to see if 'None of the Above' is the population area
  ###
  my $frequency = 0;
  return $frequency
    if ( $pop_area_name eq db::MhcTypes::NONE_OF_THE_ABOVE_POPULATION );
  ###
  ### Now that it is a real population determine region frequency
  ###
  my $cwdLookup =
    $this->getRegionLookupTable( RegionCwdAllelesLookup, $pop_area_name,
    $locus_name );
  my $val = $cwdLookup->getValue($allele);
  if ( defined($val) ) { $frequency = $val->{region_frequency}; }

  return $frequency;
}

################################################################################

1;

__END__

=head1 NAME

Lookup.pm

=head1 DESCRIPTION

This class defines the set of lookup tables that are used by quality
control tools.

=head1 STATIC CONSTANTS

The following specific lookup tables are created on an as need basis
by this class (see L<"$lookup_table_obj = getLookupTable(lookup_name)">)
and are subclasses of L<lookup::LookupTable>:

   qualityControl::Lookup::CwdAllelesLookup                -- CanoCwdAlleles
   qualityControl::Lookup::CwdAllelesHlaProteinLookup      -- CanoCwdAlleles::HlaProtein
   qualityControl::Lookup::CwdAllelesCodingRegionLookup    -- CanoCwdAlleles::CodingRegion
   qualityControl::Lookup::DeletedNamesLookup              -- DeletedNames
   qualityControl::Lookup::ImgtHlaCodingRegionGCodesLookup -- Alleles::ImgtHlaCodes::GCodes::CodingRegion
   qualityControl::Lookup::ImgtHlaCodingRegionPCodesLookup -- Alleles::ImgtHlaCodes::PCodes::CodingRegion
   qualityControl::Lookup::ImgtHlaGCodesLookup             -- Alleles::ImgtHlaCodes::GCodes
   qualityControl::Lookup::ImgtHlaHlaProteinPCodesLookup   -- Alleles::ImgtHlaCodes::PCodes::HlaProtein
   qualityControl::Lookup::ImgtHlaPCodesLookup             -- Alleles::ImgtHlaCodes::PCodes
   qualityControl::Lookup::NmdpCodesLookup                 -- NmdpCodes
   qualityControl::Lookup::ReplacementAlleles              -- ReplacementAlleles
   qualityControl::Lookup::ReplacementTypes                -- ReplacementTypes

Also, the following lookup tables are created on an as need basis for
specific population regions and loci (see
L<"$lookup_table_obj = getRegionLookupTable(region_lookup, pop_area_name, locus_name)">.

   qualityControl::Lookup::RegionCwdAllelesLookup         -- lookup::LookupTable::RegionCwdAlleles

=head1 METHODS

The following methods are exported by this class.

=head2 B<new qualityControl::Lookup(taxon_id, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=head2 B<definedLookup(lookup_name)>

This method returns a Boolean indicating whether the lookup name is
part of the controlled vocabulary defined below:

   qualityControl::Lookup::CwdAllelesLookup
   qualityControl::Lookup::CwdAllelesHlaProteinLookup
   qualityControl::Lookup::CwdAllelesCodingRegionLookup
   qualityControl::Lookup::DeletedNamesLookup
   qualityControl::Lookup::ImgtHlaCodingRegionGCodesLookup
   qualityControl::Lookup::ImgtHlaCodingRegionPCodesLookup
   qualityControl::Lookup::ImgtHlaGCodesLookup
   qualityControl::Lookup::ImgtHlaHlaProteinPCodesLookup
   qualityControl::Lookup::ImgtHlaPCodesLookup
   qualityControl::Lookup::NmdpCodesLookup
   qualityControl::Lookup::ReplacementAlleles
   qualityControl::Lookup::ReplacementTypes

=head2 B<$lookup_table_obj = getLookupTable(lookup_name)>

This method returns a lookup table object for the given
B<lookup_name>.  The following lookup tables are available, and are
subclasses of L<lookup::LookupTable>:

   CwdAllelesLookup                -- CanoCwdAlleles
   CwdAllelesHlaProteinLookup      -- CanoCwdAlleles::HlaProtein
   CwdAllelesCodingRegionLookup    -- CanoCwdAlleles::CodingRegion
   DeletedNamesLookup              -- DeletedNames
   ImgtHlaCodingRegionGCodesLookup -- Alleles::ImgtHlaCodes::GCodes::CodingRegion
   ImgtHlaCodingRegionPCodesLookup -- Alleles::ImgtHlaCodes::PCodes::CodingRegion
   ImgtHlaGCodesLookup             -- Alleles::ImgtHlaCodes::GCodes
   ImgtHlaHlaProteinPCodesLookup   -- Alleles::ImgtHlaCodes::PCodes::HlaProtein
   ImgtHlaPCodesLookup             -- Alleles::ImgtHlaCodes::PCodes
   NmdpCodesLookup                 -- NmdpCodes
   ReplacementAlleles              -- ReplacementAlleles
   ReplacementTypes                -- ReplacementTypes

=head2 B<$lookup_table_obj = getRegionLookupTable(region_lookup, pop_area_name, locus_name)>

This method returns the region-specific lookup table object for
the given given B<population_area_name> and B<locus name>.  Currently,
the allowable B<region_lookup> include:

   RegionCwdAllelesLookup         -- lookup::LookupTable::RegionCwdAlleles

=head2 B<%allele_data = getCwd(allele, cwd_lookup)>

This method returns the CWD information on the allele using the one of
the global CWD status classes B<cwd_lookup> and returns a Perl hash
with the following components for a a given allele:

   cwd         -- Boolean indicating whether allele is a CWD allele
                  or not at the HLA protein level
   rare        -- Boolean indicating whether allele is a Rare allele
                  or not at the HLA protein level
   full_length -- The full length CWD allele

The possible values for B<cwd_lookup> are:

   CwdAllelesLookup                -- CanoCwdAlleles
   CwdAllelesHlaProteinLookup      -- CanoCwdAlleles::HlaProtein
   CwdAllelesCodingRegionLookup    -- CanoCwdAlleles::CodingRegion

This method assumes that the allele is in IMGT/HLA version 3 format,
that is

   <locus_name>*<digits>[[:<digits>[:<digits>[:digits]]][<suffix>]]

=head2 B<%allele_data = getPAndGCode(allele)>

This method returns the IMGT/HLA G-Code and P-Code information on the
allele using the B<Alleles::ImgtHlaCodes> lookups:

   ImgtHlaCodingRegionGCodesLookup -- Alleles::ImgtHlaCodes::GCodes::CodingRegion
   ImgtHlaCodingRegionPCodesLookup -- Alleles::ImgtHlaCodes::PCodes::CodingRegion
   ImgtHlaGCodesLookup             -- Alleles::ImgtHlaCodes::GCodes
   ImgtHlaHlaProteinPCodesLookup   -- Alleles::ImgtHlaCodes::PCodes::HlaProtein
   ImgtHlaPCodesLookup             -- Alleles::ImgtHlaCodes::PCodes

and returns a Perl hash with the following components for a a given
allele:

   gcode         -- The IMGT/HLA G-code for the allele, if any
   pcode         -- The IMGT/HLA P-code for the allele, if any
   hla_protein   -- The allele reduced to its HLA protein prefix, if defined
   coding_region -- The allele reduced to its coding region preifx, if defined

This method assumes that the allele is in IMGT/HLA version 3 format,
that is

   <locus_name>*<digits>[[:<digits>[:<digits>[:digits]]][<suffix>]]

This method handles computing G-Code and P-Code for full allele names
and for HLA protein and coding region alleles.

=head2 B<%allele_data = getRegionCwdRare(pop_area_name, locus_name, allele)>

This method returns the region CWD information for an B<allele> within
a given a B<pop_area_name> and B<locus_name> using the class
L<lookup::LookupTable::RegionCwdAlleles>, and returns the hash with the
following components:

   reg           -- Boolean indicating whether allele is in
                    pop_area_name for locus
   cwd           -- Boolean indicating whether allele is a reg-CWD
                    in pop_area_name for locus (undef if not)
   rare          -- Boolean indicating whether allele is a reg-Rare
                    in pop_area_name for locus (undef if not)

This method assumes that the allele is in IMGT/HLA version 3 format,
that is

   <locus_name>*<digits>[[:<digits>[:<digits>[:digits]]][<suffix>]]

This method handles the computing the Region and CWD for full allele
names, HLA protein, and coding region alleles.

This method also handles the pop_area_name B<None of the Above>.  In
this case, it returns the B<reg> as FALSE (0).

=head2 B<%allele_data = getRegionFrequency(pop_area_name, locus_name, allele)>

This method returns the MRWAF frequency for for an B<allele> within
a given a B<pop_area_name> and B<locus_name> using the class
L<lookup::LookupTable::RegionCwdAlleles>.  If the allele does not
have a frequency for the class, then zero (B<0>) is returned.
This method assumes that the allele is in IMGT/HLA version 3 format,
that is

   <locus_name>*<digits>[[:<digits>[:<digits>[:digits]]][<suffix>]]

This method handles the computing the Region and CWD for full allele
names, HLA protein, and coding region alleles.

This method also handles the pop_area_name B<None of the Above>.  In
this case, it returns the frequency zero (0).

=cut
