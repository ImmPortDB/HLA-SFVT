package qualityControl::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'QUALITY-CONTROL-ERROR: '; }

sub ALLELE_CAT          { return 100000; }    ### HLA Abstract Allele Class
sub LOOKUP_CAT          { return 200000; }    ### Lookup Table Manager Class
sub ALLELEVALIDATOR_CAT { return 300000; }    ### HLA Typing allele validator

sub ALLELICAMBIGUITYREDUCTION_CAT {
  return 400000;
}    ### HLA Allelic Ambiguity Reduction Class

sub GENOTYPEAMBIGUITYREDUCTION_CAT {
  return 500000;
}    ### HLA Genotype Ambiguity Reduction Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &ALLELE_CAT => {

      1 => "Output file is not does not have '.txt' suffix\n"
        . "  file = __1__",

      2 => "Allele does not have acceptable allele group syntax\n"
        . "  locus_name  = __1__\n"
        . "  allele comp = __2__",

      3 => "Allele does not conform to IMGT/HLA Version 3.* format\n"
        . "  locus_name = __1__\n"
        . "  allele     = __2__",

      4 => "Allele in cell is not IMGT/HLA Version 3.* format\n"
        . "  allele  = __1__",

      5 => "Unknown IMGT/HLA Version 3.* NMDP suffix\n"
        . "  locus_name  = __1__\n"
        . "  allele comp = __2__",

      8 => "Allele has IMGT/HLA Verion 2.* NMDP format with unknown suffix\n"
        . "  locus_name  = __1__\n"
        . "  allele comp = __2__",

      9 => "Allele has unknown IMGT/HLA Version 2.* format\n"
        . "  locus_name  = __1__\n"
        . "  allele comp = __2__",

      10 =>
"File does not contain the 'Population Area' column, not processing file",

      11 =>
        "Row contains undefined 'Population Area' column value, not processing row\n"
        . "  id      = __1__\n"
        . "  row num = __2__",

      12 =>
        "Row contains unknown 'Population Area' column value, not processing row\n"
        . "  id       = __1__\n"
        . "  row num  = __2__\n"
        . "  pop area = __3__",

      14 => "The Group contains no populations names, not procesing group\n"
        . "  group id = __1__\n"
        . "  row nums = (__2__)",

      15 =>
"The Group contains more than one population names, not procesing group\n"
        . "  group id    = __1__\n"
        . "  row nums    = (__2__)\n"
        . "  populations = (__3__)",

      16 =>
"File contains 'Population Area' column, but the column does not contain a value, not processing file",

    },

    &ALLELICAMBIGUITYREDUCTION_CAT => {

      1 =>
        "An allele group name appears in the alleleSet, removing allele group\n"
        . "  allele group = __1__",

      2 => "Ambiguous allele cannot be reduced to a single allele/code\n"
        . "  allele set  = __1__\n"
        . "  reduced set = __2__",

    },

    &GENOTYPEAMBIGUITYREDUCTION_CAT => {

      1 =>
"Skipping subGentype for given locus since one of the alleleSets is empty\n"
        . "  locus    = __1__\n"
        . "  id       = __2__\n"
        . "  row num  = __3__",

      2 => "Skipping row for given locus since one of the cells is ambiguous\n"
        . "  cell     = __1__\n"
        . "  locus    = __2__\n"
        . "  col name = __3__\n"
        . "  id       = __4__\n"
        . "  row num  = __5__",

      3 =>
"For a given sample (ID) the set of subGentypes for a locus cannot be reduced to a single Genotype\n"
        . "  locus = __1__\n"
        . "  id    = __2__\n"
        . "  step  = __3__\n"
        . "  cell  = __4__",

    },

    &ALLELEVALIDATOR_CAT => {

      1 =>
        "Using ANTT, allele component is not consistent with IMGT/HLA format\n"
        . "  locus name = __1__\n"
        . "  cell       = __2__\n"
        . "  component\n"
        . "    allele   = __3__\n"
        . "    format   = __4__\n"
        . "  error msg  = __5__",

      3 => "The NMDP code cannot be used with locus\n"
        . "  locus name  = __1__\n"
        . "  nmdp allele = __2__\n"
        . "  nmdp code   = __3__\n"
        . "  nmdp data   = (__4__)",

      4 => "Invalid allele group for locus\n"
        . "  locus name   = __1__\n"
        . "  allele group = __2__",

      5 =>
"NMDP codes translates to alleles some of which are not found in IMGT/HLA\n"
        . "  locus                   = __1__\n"
        . "  nmdp code               = __2__\n"
        . "  alleles for code        = (__3__)\n"
        . "  alleles not in IMGT/HLA = (__4__)",

      6 =>
"The deleted allele appearing in an NMDP code has not been replaced any allele in IMGT/HLA\n"
        . "  allele = __1__",

    },

    &LOOKUP_CAT => {

      1 => "Cannot instantiate lookup table object\n"
        . "  eval_status = __1__\n"
        . "  eval_str    =\n__2__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {

    &ALLELEVALIDATOR_CAT => 'qualityControl::Allele::Validator',
    &ALLELE_CAT          => 'qualityControl::Allele',
    &ALLELICAMBIGUITYREDUCTION_CAT =>
      'qualityControl::Allele::AllelicAmbiguityReduction',
    &GENOTYPEAMBIGUITYREDUCTION_CAT =>
      'qualityControl::Allele::GenotypeAmbiguityReduction',
    &LOOKUP_CAT => 'qualityControl::Lookup'
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use qualityControl::ErrMsgs;

   my $error_msgs  = qualityControl::ErrMsgs::ERROR_MSGS;
   my $error_names = qualityControl::ErrMsgs::ERROR_CATS;
   my $err_cat     = qualityControl::ErrMsgs::ALLELEVALIDATOR_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the hla library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   qualityControl::ErrMsgs::ALLELE_CAT                     -- ( 100000) HLA Abstract Allele Class
   qualityControl::ErrMsgs::LOOKUP_CAT                     -- ( 200000) Lookup Table Manager Class
   qualityControl::ErrMsgs::ALLELEVALIDATOR_CAT            -- ( 300000) HLA Typing allele validator
   qualityControl::ErrMsgs::ALLELICAMBIGUITYREDUCTION_CAT  -- ( 400000) HLA Allelic Ambiguity Reduction Class
   qualityControl::ErrMsgs::GENOTYPEAMBIGUITYREDUCTION_CAT -- ( 500000) HLA Genotype Ambiguity Reduction Class

=head1 STATIC CLASS METHODS

=head2 B<qualityControl::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<qualityControl::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
