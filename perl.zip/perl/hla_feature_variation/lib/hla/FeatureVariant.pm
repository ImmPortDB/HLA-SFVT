package hla::FeatureVariant;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PerlObject;

use db::MhcTypes;

use hla::ErrMsgs;

use fields qw (
  alleles
  db_queries
  error_mgr
  feature_map
  generator
  locus_id
  queries
  ref_allele_id
  rep_alleles
  seq_type_id
  serializer
  taxon_id
  variant_id
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Error Category
###
sub ERR_CAT { return hla::ErrMsgs::FEATUREVARIANT_CAT; }

################################################################################
#
#			     Static Class Constants
#
################################################################################

sub ALLELE_QUERY  { return 'FV_alleleQuery'; }
sub FEATURE_QUERY { return 'FV_featureQuery'; }

sub DB_QUERIES {
  return {
    &ALLELE_QUERY => {
      msg => 'Allele Query',
      ord => [ db::MhcTypes::ALLELE_ID_COL, db::MhcTypes::ALLELE_NAME_COL ],
      cmd => "
select   allele_id,
         allele_name
from     allele
where    locus_id = ?
",
    },

    &FEATURE_QUERY => {
      msg => 'Feature Query',
      ord =>
        [ db::MhcTypes::FEATURE_ID_COL, db::MhcTypes::FEATURE_NUMBER_COL, ],
      cmd => "
select   feature_id,
         feature_number
from     feature
where    locus_id    = ?
and      seq_type_id = ?
",
    },

  };
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _getStruct {
  my hla::FeatureVariant $this = shift;
  my ( $query, $row ) = @_;
  my $ord    = $this->{queries}->{$query}->{ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _generateAlleleMap {
  my hla::FeatureVariant $this = shift;

  my $rep_alleles = $this->{rep_alleles};
  $this->{db_queries}->executeQuery( ALLELE_QUERY, $this->{locus_id} );
  while ( my $row_ref = $this->{db_queries}->fetchRowRef(ALLELE_QUERY) ) {
    my $struct = $this->_getStruct( ALLELE_QUERY, $row_ref );
    $struct->{allele_name} =~ /^(.+\*\d+:\d+)/;
    my $rep_allele = $1;
    $this->{alleles}->{ $struct->{&db::MhcTypes::ALLELE_ID_COL} } = $rep_allele;
    if ( !defined( $rep_alleles->{$rep_allele} ) ) {
      $rep_alleles->{$rep_allele} = {};
    }
  }
}

sub _generateFeatureMap {
  my hla::FeatureVariant $this = shift;

  my $feature_map = $this->{feature_map};
  $this->{db_queries}
    ->executeQuery( FEATURE_QUERY, $this->{locus_id}, $this->{seq_type_id} );
  while ( my $row_ref = $this->{db_queries}->fetchRowRef(FEATURE_QUERY) ) {
    my $struct = $this->_getStruct( FEATURE_QUERY, $row_ref );
    $feature_map->{ $struct->{&db::MhcTypes::FEATURE_NUMBER_COL} } = $struct;
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$) {
  my hla::FeatureVariant $this = shift;
  my (
    $locus_name, $taxon_id, $seq_type, $generator,
    $variant_id, $db,       $error_mgr
  ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{alleles}     = {};
  $this->{error_mgr}   = $error_mgr;
  $this->{feature_map} = {};
  $this->{generator}   = $generator;
  $this->{rep_alleles} = {};
  $this->{taxon_id}    = $taxon_id;
  $this->{variant_id}  = int($variant_id);
  ###
  ### Get the sequence type ID
  ###
  $this->{seq_type_id} =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type );
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [" Unknown seq type\n" . "  seq_type = $seq_type"],
    !defined( $this->{seq_type_id} )
  );
  ###
  ### Get the locus ID
  ###
  $this->{locus_id} =
    db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locus_name,
    $taxon_id );
  $this->{error_mgr}->exitProgram(
    ERR_CAT,
    1,
    [" Unknown locus for taxon\n"
      . "  locus name = $locus_name\n"
      . "  taxon id   = $taxon_id"],
    !defined( $this->{locus_id} )
  );
  ###
  ### Determine the reference allele ID
  ###
  my $referenceAlleles = db::MhcTypes::referenceAlleles($taxon_id);
  my $alleleNames      = db::MhcTypes::alleleNames($taxon_id);
  my $locus_references = $referenceAlleles->{ $this->{locus_id} };
  my $reference_allele =
    $alleleNames->{ $locus_references->{ $this->{seq_type_id} } };
  $this->{ref_allele_id} = $reference_allele->{&db::MhcTypes::ALLELE_ID_COL};
  ###
  ### Setup the local queries
  ###
  $this->{db_queries} = new util::DbQuery($db);
  $this->{queries}    = DB_QUERIES;
  foreach my $query ( keys %{ $this->{queries} } ) {
    my $db_struct = $this->{queries}->{$query};
    $this->{db_queries}
      ->createQuery( $query, $db_struct->{cmd}, $db_struct->{msg} );
    $this->{db_queries}->prepareQuery($query);
  }
  ###
  ### Generate the allele and feature maps for the locus ID
  ###
  $this->_generateAlleleMap;
  $this->_generateFeatureMap;

  $this->{serializer} =
    new util::PerlObject( undef, undef, $this->{error_mgr} );

  return $this;
}

sub processFeatures {
  my hla::FeatureVariant $this = shift;
  my ($entities) = @_;
  ###
  ### Get the alleles and representative alleles
  ###
  my $alleles     = $this->{alleles};
  my $rep_alleles = $this->{rep_alleles};
  my $generator   = $this->{generator};
  ###
  ### Get the table names and create row map for VARIANT_TYPE table
  ###   VARIANT_TYPE
  ###   VARIANT_2_ALLELE
  ###
  my $variant_type_table     = lc(db::MhcTypes::VARIANT_TYPE_TABLE);
  my $variant_2_allele_table = lc(db::MhcTypes::VARIANT_2_ALLELE_TABLE);
  my $vr                     = $generator->getRowHash($variant_type_table);
  my @variant_col_map        = sort keys %{$vr};
  ###
  ### Get the feature variation data
  ###
  my $variants     = {};
  my $ref_variants = {};
  foreach my $entity ( @{$entities} ) {
    next
      if (
      util::Constants::EMPTY_LINE(
        $entity->{&db::MhcTypes::FEATURE_NUMBER_COL}
      )
      || $entity->{&db::MhcTypes::FEATURE_NUMBER_COL} =~ /Sequence Feature/
      );
    my $variant = { %{$entity} };
    $variant->{&db::MhcTypes::FEATURE_ID_COL} =
      $this->{feature_map}->{ $variant->{&db::MhcTypes::FEATURE_NUMBER_COL} }
      ->{&db::MhcTypes::FEATURE_ID_COL};
    $variant->{&db::MhcTypes::VARIANT_ID_COL} = $this->{variant_id};
    $this->{variant_id}++;
    $variants->{ $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} } = $variant;
    ###
    ### Determine if variant reference
    ###
    if ( $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} =~ /VT1$/ ) {
      my $ref_variant = { %{$variant} };
      $ref_variant->{&db::MhcTypes::VAR_MOTIF_COL} = $variant->{motif};
      $ref_variants->{ $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} } =
        $ref_variant;
    }
    ###
    ### map the representative alleles
    ###
    my @rep_alleles = split( /,\s*/, $variant->{allele_group} );
    $variant->{allele_group} = [@rep_alleles];
    foreach my $rep_allele (@rep_alleles) {
      next if ( !defined($rep_alleles) );
      my $var_ids = $rep_alleles->{$rep_allele};
      $var_ids->{ $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} } =
        $variant->{&db::MhcTypes::VARIANT_ID_COL};
    }
  }
  ###
  ### Compute the var_motif for the reference variants
  ###
  while ( my ( $variant_type_name, $variant ) = each %{$variants} ) {
    ###
    ### Only for variant type
    ###
    next if ( $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} !~ /VT\d+$/ );
    ###
    ### Get the motif for variant type
    ###
    my $variant = $variants->{$variant_type_name};
    my $motif   = $variant->{motif};
    ###
    ### Get the var_motif for the reference
    ###
    $variant->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} =~ /^(.+)VT\d+$/;
    my $ref_variant_type_name = $1 . 'VT1';
    my $ref_variant           = $ref_variants->{$ref_variant_type_name};
    my $ref_var_motif         = $ref_variant->{var_motif};
    ###
    ### Generate the var_motif for variant type
    ###
    my $var_motif = util::Constants::EMPTY_STR;
    foreach my $index ( 0 .. ( length($ref_var_motif) - 1 ) ) {
      my $aa     = substr( $motif,         $index, 1 );
      my $ref_aa = substr( $ref_var_motif, $index, 1 );
      my $var_aa = undef;
      if ( $aa eq $ref_aa
        && $aa ne util::Constants::DOT
        && $aa ne util::Constants::ASTERISK )
      {
        $var_aa = util::Constants::HYPHEN;
      }
      else { $var_aa = $aa; }
      $var_motif .= $var_aa;
    }
    $variant->{var_motif} = $var_motif;
  }
  ###
  ### Generate the tables
  ###
  while ( my ( $variant_type_name, $struct ) = each %{$variants} ) {
    my $row = $generator->getRowHash($variant_type_table);
    foreach my $col (@variant_col_map) {
      $row->{$col} = $struct->{$col};
    }
    $generator->generateRow( $variant_type_table, $row );
    foreach my $rep_allele ( @{ $struct->{allele_group} } ) {
      my $row = $generator->getRowHash($variant_2_allele_table);
      $row->{&db::MhcTypes::VARIANT_ID_COL} =
        $struct->{&db::MhcTypes::VARIANT_ID_COL};
      $row->{allele_name} = $rep_allele;
      $generator->generateRow( $variant_2_allele_table, $row );
    }
  }
  ###
  ### VARIANT_REFERENCE
  ###
  my $variant_reference_table = lc(db::MhcTypes::VARIANT_REFERENCE_TABLE);
  while ( my ( $variant_type_name, $struct ) = each %{$ref_variants} ) {
    my $row = $generator->getRowHash($variant_reference_table);
    $row->{&db::MhcTypes::ALLELE_ID_COL} = $this->{ref_allele_id};
    foreach my $col (@variant_col_map) {
      $row->{$col} = $struct->{$col};
    }
    $generator->generateRow( $variant_reference_table, $row );
  }
  ###
  ### VARIANT_MAP
  ###
  my $variant_map_table = lc(db::MhcTypes::VARIANT_MAP_TABLE);
  while ( my ( $allele_id, $rep_allele ) = each %{$alleles} ) {
    my $var_ids = $rep_alleles->{$rep_allele};
    while ( my ( $variant_type_name, $variant_id ) = each %{$var_ids} ) {
      my $row = $generator->getRowHash($variant_map_table);
      $row->{&db::MhcTypes::ALLELE_ID_COL}  = $allele_id;
      $row->{&db::MhcTypes::VARIANT_ID_COL} = $variant_id;
      $generator->generateRow( $variant_map_table, $row );
    }
  }
}

sub taxonId {
  my hla::FeatureVariant $this = shift;
  return $this->{taxon_id};
}

sub variantId {
  my hla::FeatureVariant $this = shift;
  return $this->{variant_id};
}
################################################################################

1;

__END__

=head1 NAME

FeatureVariant.pm

=head1 DESCRIPTION

This class defines the generator for the HLA feature variant data given a locus,
sequence type, and taxon id.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new hla::FeatureVariant(hla_file, allele_id, generator, error_mgr)>

This is the constructor for the class.

=head2 B<my $taxon_id = taxonId>

This method returns taxon id generated during this processing.

=head2 B<my $variant_id = variantId>

This method returns the next feature name id to use to load the feature_name
table.

=head2 B<processFeatures>

This method processes the feature names for the given locus_name, taxon_id, and
seq_type and stores the feature variant type and map for them.

=cut
