package hla::PdbPositions;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PerlObject;

use db::MhcTypes;

use hla::ErrMsgs;
use hla::HlaTypes;

use fields
  qw (
  db_queries
  error_mgr
  feature_coords
  all_feature_coords
  generator
  locus_id
  locus_name
  queries
  taxon_id
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################

sub ALL_FEATURES { return 0; }

sub FEATURE_MAP_QUERY { return '__feature_map_query__'; }

sub DB_QUERIES {
  return {
    &FEATURE_MAP_QUERY => {
      msg => 'Feature Map Query',
      ord => [
        db::MhcTypes::FEATURE_ID_COL, db::MhcTypes::FM_START_POS_COL,
        db::MhcTypes::FM_END_POS_COL, db::MhcTypes::FEATURE_TYPE_ID_COL,
      ],
      cmd => "
select   fm.feature_id,
         fm.fm_start_pos,
         fm.fm_end_pos,
         f2t.feature_type_id
from     feature_map    fm,
         feature        ft,
         feature_2_type f2t
where    ft.locus_id   = ?
and      ft.feature_id = fm.feature_id
and      ft.feature_id = f2t.feature_id
order by f2t.feature_type_id,
         fm.feature_id,
         fm.fm_start_pos
",
    },

  };
}

sub ERR_CAT { return hla::ErrMsgs::PDBPOSITIONS_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getStruct {
  my hla::PdbPositions $this = shift;
  my ( $query, $row ) = @_;
  my $ord    = $this->{queries}->{$query}->{ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _getFeatureCoords {
  my hla::PdbPositions $this = shift;

  my $feature_coords = {};
  $this->{db_queries}->executeQuery( FEATURE_MAP_QUERY, $this->{locus_id} );
  while ( my $row_ref = $this->{db_queries}->fetchRowRef(FEATURE_MAP_QUERY) ) {
    my $struct          = $this->_getStruct( FEATURE_MAP_QUERY, $row_ref );
    my $feature_id      = $struct->{feature_id};
    my $feature_type_id = $struct->{feature_type_id};
    if ( !defined( $feature_coords->{$feature_type_id} ) ) {
      $feature_coords->{$feature_type_id} = {};
    }
    my $feature_type = $feature_coords->{$feature_type_id};
    if ( !defined( $feature_type->{$feature_id} ) ) {
      $feature_type->{$feature_id} = [];
    }
    push( @{ $feature_type->{$feature_id} }, $struct );
  }
  $this->{feature_coords} = $feature_coords;
  ###
  ### Now generate all features
  ###
  my $all_feature_coords = {};
  foreach my $feature_type_id ( keys %{$feature_coords} ) {
    my $feature_type = $feature_coords->{$feature_type_id};
    foreach my $feature_id ( keys %{$feature_type} ) {
      if ( !defined( $all_feature_coords->{$feature_id} ) ) {
        $all_feature_coords->{$feature_id} = $feature_type->{$feature_id};
      }
    }
  }
  $this->{all_feature_coords} = $all_feature_coords;
}

sub _addInterval {
  my hla::PdbPositions $this = shift;
  my ( $intervals, $left, $right, $chain_id ) = @_;
  my $interval = util::Constants::EMPTY_STR;
  if ( $left == $right ) {
    $interval .= $left;
  }
  else {
    $interval .= $left . util::Constants::HYPHEN . $right;
  }
  $interval .= util::Constants::COLON . $chain_id;
  push( @{$intervals}, $interval );
}

sub _generatePdbPositions {
  my hla::PdbPositions $this = shift;
  my ( $coords, $mapping ) = @_;
  ###
  ### generate the pdb positions for the feature
  ###
  my $pdb_positions = undef;
  my $intervals     = [];
  foreach my $coord ( @{$coords} ) {
    my $sub_intervals = [];
    my $left          = $coord->{fm_start_pos};
    my $right         = $coord->{fm_end_pos};

  INNER_LOOP:
    foreach my $pdb_interval ( @{$mapping} ) {
      my $pdb_left  = undef;
      my $pdb_right = undef;
      if ( defined( $pdb_interval->{chain_id} ) ) {
        $pdb_left =
          $pdb_interval->{pdb_left} + $left - $pdb_interval->{hla_left};
        $pdb_right =
          $pdb_interval->{pdb_left} + $right - $pdb_interval->{hla_left};
      }
      if ( $left >= $pdb_interval->{hla_left}
        && $left <= $pdb_interval->{hla_right} )
      {
        if ( $right <= $pdb_interval->{hla_right} ) {
          if ( defined( $pdb_interval->{chain_id} ) ) {
            $this->_addInterval( $sub_intervals, $pdb_left, $pdb_right,
              $pdb_interval->{chain_id} );
          }
          last INNER_LOOP;
        }
        else {
          if ( defined( $pdb_interval->{chain_id} ) ) {
            $this->_addInterval(
              $sub_intervals, $pdb_left,
              $pdb_interval->{pdb_right},
              $pdb_interval->{chain_id}
            );
          }
        }
      }
      elsif ( $left < $pdb_interval->{hla_left} ) {
        if ( $right <= $pdb_interval->{hla_right} ) {
          if ( defined( $pdb_interval->{chain_id} ) ) {
            $this->_addInterval(
              $sub_intervals, $pdb_interval->{pdb_left},
              $pdb_right,     $pdb_interval->{chain_id}
            );
          }
          last INNER_LOOP;
        }
        else {
          if ( defined( $pdb_interval->{chain_id} ) ) {
            $this->_addInterval(
              $sub_intervals,             $pdb_interval->{pdb_left},
              $pdb_interval->{pdb_right}, $pdb_interval->{chain_id}
            );
          }
        }
      }
    }
    next if ( scalar @{$sub_intervals} == 0 );
    push( @{$intervals}, @{$sub_intervals} );
  }
  if ( scalar @{$intervals} > 0 ) {
    $pdb_positions = join( util::Constants::COMMA, @{$intervals} );
  }

  return $pdb_positions;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$) {
  my hla::PdbPositions $this = shift;
  my ( $locus_id, $taxon_id, $locus_name, $generator, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr}          = $error_mgr;
  $this->{feature_coords}     = {};
  $this->{all_feature_coords} = {};
  $this->{generator}          = $generator;
  $this->{locus_id}           = $locus_id;
  $this->{locus_name}         = $locus_name;
  $this->{taxon_id}           = $taxon_id;
  $this->{tools}              = $tools;
  ###
  ### Setup the local queries
  ###
  $this->{db_queries} = new util::DbQuery( $this->{tools}->getSession );
  $this->{queries}    = DB_QUERIES;
  foreach my $query ( keys %{ $this->{queries} } ) {
    my $db_struct = $this->{queries}->{$query};
    $this->{db_queries}
      ->createQuery( $query, $db_struct->{cmd}, $db_struct->{msg} );
    $this->{db_queries}->prepareQuery($query);
  }

  return $this;
}

sub processLocus {
  my hla::PdbPositions $this = shift;

  $this->_getFeatureCoords;
  my $pdb_mapping_table = lc(db::MhcTypes::PDB_MAPPING_TABLE);
  ###
  ### Now for each pdb mapping compute data
  ###
  my @mappings = hla::HlaTypes::getPdbMappingData( $this->{locus_name} );
  foreach my $mapping ( @mappings ) {
    ###
    ### compute only if pdb_map is not trivial
    ###    
    next if (@{$mapping->{pdb_map}} == 0);
    foreach my $feature_type_id (ALL_FEATURES)
    {    ### now generate all for all features
      my $features = undef;
      if ( $feature_type_id == 0 ) { $features = $this->{all_feature_coords}; }
      else { $features = $this->{feature_coords}->{$feature_type_id}; }
      foreach my $feature_id ( keys %{$features} ) {
        my $row = $this->{generator}->getRowHash($pdb_mapping_table);
        $row->{pdb_id}     = $mapping->{pdb_id};
        $row->{feature_id} = $feature_id;
        $row->{locus_id}   = $this->{locus_id};
        my $pdb_positions =
          $this->_generatePdbPositions( $features->{$feature_id},
          $mapping->{pdb_map} );
        if ( defined($pdb_positions) ) {
          $row->{pdb_positions} = $pdb_positions;
          $this->{generator}->generateRow( $pdb_mapping_table, $row );
        }
      }
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

PdbPositions.pm

=head1 DESCRIPTION

This class defines the generator to generate the update of the
pdb_positions column in the FEATURE table for a locus

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new hla::PdbPositions(locus_id, taxon_id, locus_name, generator, tools, error_mgr)>

This is the constructor for the class.

=head2 B<processLocus>

This method generates the pdb_positions for the locus.

=cut
