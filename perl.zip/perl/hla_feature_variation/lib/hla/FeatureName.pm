package hla::FeatureName;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::QueryMgr;

use db::MhcTypes;

use hla::ErrMsgs;
use hla::HlaTypes;

use fields qw (
  del_feat
  error_mgr
  feature_id
  locus_id
  locus_name
  generator
  query_mgr
  ruler
  seq_type_id
  taxon_id
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Queries
###
sub REFERENCE_SEQ_QUERY { return '_referenceSeqQuery_'; }

sub DB_QUERIES {
  return {
    &REFERENCE_SEQ_QUERY => {
      key => db::MhcTypes::ALLELE_ID_COL,
      ord => [
        db::MhcTypes::ALLELE_ID_COL, db::MhcTypes::VAR_SEQ_COL,
        db::MhcTypes::VSS_START_POS_COL,
      ],
      cmd => "
select   a.allele_id,
         b.var_seq,
         c.vss_start_pos
from     reference_allele      a,
         variant_seq           b,
         variant_seq_structure c
where    a.locus_id    = ?
and      a.locus_id    = c.locus_id
and      a.allele_id   = b.allele_id
and      a.seq_type_id = ?
and      a.seq_type_id = b.seq_type_id
and      a.seq_type_id = c.seq_type_id
",
    },
  };
}
###
### Error Category
###
sub ERR_CAT { return hla::ErrMsgs::FEATURENAME_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _addFeatureAlleles {
  my hla::FeatureName $this = shift;
  ###
  ### Only process if there are feature alleles
  ###
  my @feature_alleles =
    hla::HlaTypes::getFeatureAlleleData( $this->{locus_name} );
  return if ( @feature_alleles == 0 );

  my $feature_allele_table = lc(db::MhcTypes::FEATURE_ALLELE_TABLE);
  my $alleleNames          = db::MhcTypes::alleleNames( $this->{taxon_id} );
  foreach my $allele_struct (@feature_alleles) {
    my $allele =
      $alleleNames->{ $allele_struct->{&db::MhcTypes::ALLELE_ID_COL} };
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 1,
      [
            "Allele name is not defined\n"
          . "  allele_name = "
          . $allele_struct->{&db::MhcTypes::ALLELE_ID_COL}
      ],
      !defined($allele)
    );
    my $feature_allele_struct = {
      locus_id      => $this->{locus_id},
      allele_id     => $allele->{&db::MhcTypes::ALLELE_ID_COL},
      pdb_id        => $allele_struct->{&db::MhcTypes::PDB_ID_COL},
      pdb_positions => $allele_struct->{&db::MhcTypes::PDB_POSITIONS_COL},
      pdb_map       => $allele_struct->{&db::MhcTypes::PDB_MAP_COL},
    };
    $this->{generator}
      ->generateRow( $feature_allele_table, $feature_allele_struct );
  }
}

sub _generatePubMedIds {
  my hla::FeatureName $this = shift;
  my ( $feature_id, $related_pubs ) = @_;

  return
    if ( util::Constants::EMPTY_LINE($related_pubs)
    || $related_pubs !~ /PMID:\s*(\d+)/ );

  my $feature_2_pubmed_table = lc(db::MhcTypes::FEATURE_2_PUBMED_TABLE);
  my $feature_2_pubmed =
    $this->{generator}->getRowHash($feature_2_pubmed_table);
  while ( length($related_pubs) > 0 ) {
    if ( $related_pubs =~ /PMID:\s*(\d+)/ ) {
      my $pubmed_id = $1;
      $related_pubs = substr( $related_pubs, $+[0] );
      $feature_2_pubmed->{&db::MhcTypes::FEATURE_ID_COL} = $feature_id;
      $feature_2_pubmed->{&db::MhcTypes::PUBMED_ID_COL}  = $pubmed_id;
      $this->{generator}
        ->generateRow( $feature_2_pubmed_table, $feature_2_pubmed );
    }
    else {
      $related_pubs = util::Constants::EMPTY_STR;
    }
  }
}

sub _generateFeatureNames {
  my hla::FeatureName $this = shift;
  my ( $feature_id, $feature_names ) = @_;

  return if ( util::Constants::EMPTY_LINE($feature_names) );

  my $feature_2_name_table = lc(db::MhcTypes::FEATURE_2_NAME_TABLE);
  my $feature_2_name = $this->{generator}->getRowHash($feature_2_name_table);
  my @feature_names = split( /;\s*/, $feature_names );
  foreach my $feature_name (@feature_names) {
    $feature_2_name->{&db::MhcTypes::FEATURE_ID_COL}   = $feature_id;
    $feature_2_name->{&db::MhcTypes::FEATURE_NAME_COL} = $feature_name;
    $this->{generator}->generateRow( $feature_2_name_table, $feature_2_name );
  }
}

sub _generateFeatureTypes {
  my hla::FeatureName $this = shift;
  my ( $feature_id, $feature_types ) = @_;

  return if ( util::Constants::EMPTY_LINE($feature_types) );

  my $feature_2_type_table = lc(db::MhcTypes::FEATURE_2_TYPE_TABLE);
  my $feature_2_type = $this->{generator}->getRowHash($feature_2_type_table);
  my @feature_types = split( /;\s*/, $feature_types );
  foreach my $feature_type (@feature_types) {
    $feature_2_type->{&db::MhcTypes::FEATURE_ID_COL} = $feature_id;
    $feature_2_type->{&db::MhcTypes::FEATURE_TYPE_ID_COL} =
      db::MhcTypes::getId( db::MhcTypes::FEATURE_TYPE_TABLE, $feature_type );
    $this->{generator}->generateRow( $feature_2_type_table, $feature_2_type );
  }
}

sub _addPosition {
  my hla::FeatureName $this = shift;
  my ( $positions, $fm ) = @_;

  return $positions if ( !defined($fm) );

  if ( !util::Constants::EMPTY_LINE($positions) ) {
    $positions .= util::Constants::COMMA_SEPARATOR;
  }
  $positions .= $fm->{&db::MhcTypes::FM_START_POS_COL};
  if ( $fm->{&db::MhcTypes::FM_START_POS_COL} !=
    $fm->{&db::MhcTypes::FM_END_POS_COL} )
  {
    $positions .= '..' . $fm->{&db::MhcTypes::FM_END_POS_COL};
  }
  return $positions;
}

sub _generateFeatureMapBase1 {
  my hla::FeatureName $this = shift;
  my ($feature_map) = @_;

  my $del_feat = $this->{del_feat};
  my $ruler    = $this->{ruler};

  my $feature_map_base1_table = lc(db::MhcTypes::FEATURE_MAP_BASE1_TABLE);
  my $feature_base1_map =
    $this->{generator}->getRowHash($feature_map_base1_table);

  $feature_base1_map->{&db::MhcTypes::FEATURE_ID_COL} =
    $feature_map->{&db::MhcTypes::FEATURE_ID_COL};
  if ( $feature_map->{del_feature} ) {
    my $del_coords =
      $del_feat->{ $feature_map->{&db::MhcTypes::FM_START_POS_COL} };
    $feature_base1_map->{&db::MhcTypes::FM_START_POS_COL} =
      $del_coords->{start};
    $feature_base1_map->{&db::MhcTypes::FM_END_POS_COL} = $del_coords->{end};
  }
  else {
    $feature_base1_map->{&db::MhcTypes::FM_START_POS_COL} =
      $ruler->{ $feature_map->{&db::MhcTypes::FM_START_POS_COL} };
    $feature_base1_map->{&db::MhcTypes::FM_END_POS_COL} =
      $ruler->{ $feature_map->{&db::MhcTypes::FM_END_POS_COL} };
  }
  $this->{generator}
    ->generateRow( $feature_map_base1_table, $feature_base1_map );
}

sub _generateFeatureMap {
  my hla::FeatureName $this = shift;
  my ( $feature_number, $feature_id, $location ) = @_;

  my $tools     = $this->{tools};
  my $positions = util::Constants::EMPTY_STR;
  $this->{error_mgr}->printWarning(
    "Feature Does NOT have Location (will not generate feature map)\n"
      . "  feature number = $feature_number",
    util::Constants::EMPTY_LINE($location)
  );
  return $positions if ( util::Constants::EMPTY_LINE($location) );

  my $feature_map_table = lc(db::MhcTypes::FEATURE_MAP_TABLE);

  $location =~ s/ //g;
  my @locs = split( /,/, $location );
  my $intervals = [];
  foreach my $loc (@locs) {
    my $feature_map = $this->{generator}->getRowHash($feature_map_table);
    $feature_map->{&db::MhcTypes::FEATURE_ID_COL} = $feature_id;
    if ( $loc =~ /^(-?\d+)(del)?$/ ) {
      $feature_map->{&db::MhcTypes::FM_START_POS_COL} = $1;
      $feature_map->{&db::MhcTypes::FM_END_POS_COL}   = $1;
    }
    elsif ( $loc =~ /^(-?\d+)\.\.(-?\d+)$/ ) {
      $feature_map->{&db::MhcTypes::FM_START_POS_COL} = $1;
      $feature_map->{&db::MhcTypes::FM_END_POS_COL}   = $2;
    }
    else {
      $this->{error_mgr}->printMsg( "Unknown location\n"
          . "  feature_number = $feature_number\n"
          . "  location       = $loc " );
      next;
    }
    ###
    ### deletion features are handled specially
    ###
    $feature_map->{del_feature} =
      ( $loc =~ /del$/ ) ? util::Constants::TRUE : util::Constants::FALSE;
    push( @{$intervals}, $feature_map );
  }

  @{$intervals} = sort hla::FeatureName::_sortIntervals @{$intervals};
  my $current_fm = undef;
  while ( @{$intervals} > 0 ) {
    my $fm = shift( @{$intervals} );
    if ( !defined($current_fm) ) { $current_fm = { %{$fm} }; }
    next
      if ( $fm->{&db::MhcTypes::FM_END_POS_COL} <=
      $current_fm->{&db::MhcTypes::FM_END_POS_COL} );
    if ( ( $current_fm->{&db::MhcTypes::FM_END_POS_COL} + 1 ) ==
         $fm->{&db::MhcTypes::FM_START_POS_COL}
      || $current_fm->{&db::MhcTypes::FM_END_POS_COL} == -1
      && $fm->{&db::MhcTypes::FM_START_POS_COL} == 1 )
    {
      $current_fm->{&db::MhcTypes::FM_END_POS_COL} =
        $fm->{&db::MhcTypes::FM_END_POS_COL};
    }
    else {
      $this->{generator}->generateRow( $feature_map_table, $current_fm );
      $this->_generateFeatureMapBase1($current_fm);
      $positions = $this->_addPosition( $positions, $current_fm );
      $current_fm = $fm;
    }
  }
  $this->{generator}->generateRow( $feature_map_table, $current_fm );
  $this->_generateFeatureMapBase1($current_fm);
  $positions = $this->_addPosition( $positions, $current_fm );
  return $positions;
}

sub _generateRuler {
  my hla::FeatureName $this = shift;

  my $del_feat  = $this->{del_feat};
  my $query_mgr = $this->{query_mgr};
  my $ruler     = $this->{ruler};
  my $tools     = $this->{tools};
  ###
  ### Get the sequence and start coordinate.
  ###
  $query_mgr->execute( REFERENCE_SEQ_QUERY, $this->{locus_id},
    $this->{seq_type_id} );
  my @dataKeys = $query_mgr->getDataKeys(REFERENCE_SEQ_QUERY);
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [
          "Locus and seq type do not have a reference sequence\n"
        . "and/or start positions\n"
        . "  locus_id    = "
        . $this->{locus_id} . "\n"
        . "  seq_type_id = "
        . $this->{seq_type_id}
    ],
    @dataKeys != 1
  );
  my $data = $query_mgr->getData( REFERENCE_SEQ_QUERY, $dataKeys[0] );
  ###
  ### First create an array that contains all the entities
  ### in the seq and enumerate them from 1.
  ###
  my $seq_array = [];
  my $seq       = $data->{&db::MhcTypes::VAR_SEQ_COL};
  foreach my $index ( 0 .. ( length($seq) - 1 ) ) {
    my $aa = substr( $seq, $index, 1 );
    my $aa_struct = {
      type => ( $aa eq util::Constants::DOT ) ? 'dot' : 'aa',
      b1_coord  => ( $index + 1 ),
      seq_coord => undef
    };
    push( @{$seq_array}, $aa_struct );
  }
  ###
  ### Generate ruler
  ###
  my $currentCoord = $data->{&db::MhcTypes::VSS_START_POS_COL};
  foreach my $index ( 0 .. $#{$seq_array} ) {
    my $aa_struct = $seq_array->[$index];
    $aa_struct->{seq_coord} = $currentCoord;
    if ( $aa_struct->{type} eq 'aa' ) {
      ###
      ### Create ruler position
      ###
      $ruler->{$currentCoord} = $aa_struct->{b1_coord};
      ###
      ### Setup for next aa
      ###
      $currentCoord++;
      $currentCoord++ if ( $currentCoord == 0 );
    }
  }
  ###
  ### Finally, generate the del feature base-1 coordinates
  ###
  my $currentDelFeat = undef;
  my $startCoord     = undef;
  my $endCoord       = undef;
  foreach my $index ( 0 .. $#{$seq_array} ) {
    my $aa_struct = $seq_array->[$index];
    if ( $aa_struct->{type} eq 'aa' && defined($currentDelFeat) ) {
      ###
      ### Conclude a deletion feature
      ###
      $del_feat->{$currentDelFeat} = {
        start => $startCoord,
        end   => $endCoord,
      };
      $currentDelFeat = undef;
      $startCoord     = undef;
      $endCoord       = undef;
    }
    elsif ( $aa_struct->{type} eq 'dot' && !defined($currentDelFeat) ) {
      ###
      ### Start a deletion feature
      ###
      $currentDelFeat = $aa_struct->{seq_coord} - 1;
      $startCoord     = $aa_struct->{b1_coord};
      $endCoord       = $aa_struct->{b1_coord};
    }
    elsif ( $aa_struct->{type} eq 'dot' && defined($currentDelFeat) ) {
      ###
      ### Continuing a deletion feature
      ###
      $endCoord = $aa_struct->{b1_coord};
    }
  }
  if ( defined($currentDelFeat) ) {
    $del_feat->{$currentDelFeat} = {
      start => $startCoord,
      end   => $endCoord,
    };
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$) {
  my hla::FeatureName $this = shift;
  my (
    $locus_name, $taxon_id, $seq_type, $generator,
    $feature_id, $tools,    $error_mgr
  ) = @_;

  $this = fields::new($this) unless ref($this);

  $this->{del_feat}   = {};
  $this->{error_mgr}  = $error_mgr;
  $this->{feature_id} = int($feature_id);
  $this->{generator}  = $generator;
  $this->{ruler}      = {};
  $this->{taxon_id}   = $taxon_id;
  $this->{tools}      = $tools;

  $this->{seq_type_id} =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type );
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ " Unknown seq type\n" . "  seq_type = $seq_type" ],
    !defined( $this->{seq_type_id} )
  );

  $this->{locus_name} = $locus_name;
  $this->{locus_id} =
    db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locus_name,
    $taxon_id );
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [
          " Unknown locus for taxon\n"
        . "  locus name = $locus_name\n"
        . "  taxon id   = $taxon_id"
    ],
    !defined( $this->{locus_id} )
  );

  $this->{query_mgr} = new util::QueryMgr( $tools->getSession, $error_mgr );
  $this->{query_mgr}->createAll(DB_QUERIES);
  $this->{query_mgr}->prepareQueries;

  return $this;
}

sub _sortIntervals { $a->{fm_start_pos} <=> $b->{fm_start_pos}; }

sub processFile {
  my hla::FeatureName $this = shift;
  my ($entities) = @_;

  my $tools = $this->{tools};
  ###
  ### Compute the ruler to get base-1 coordinates for features
  ### solving the problem of negative coordinates and deletions
  ### (dots--'.'), and del features.
  ###
  $this->_generateRuler;
  ###
  ### First add the feature_allele table using
  ### the featureAlleles provided by the constructor
  ###
  $this->_addFeatureAlleles;
  ###
  ### Now load feature_name and feature_map
  ###
  my $feature_file_ord = hla::HlaTypes::FEATURE_FILE_ORD;
  my $feature_table    = lc(db::MhcTypes::FEATURE_TABLE);
  foreach my $entity ( @{$entities} ) {
    next
      if (
      util::Constants::EMPTY_LINE(
        $entity->{&db::MhcTypes::FEATURE_NUMBER_COL}
      )
      || $entity->{&db::MhcTypes::FEATURE_NUMBER_COL} =~ /Sequence Feature/
      );
    my $feature = $this->{generator}->getRowHash($feature_table);
    ###
    ### Get standard data
    ###
    $feature->{&db::MhcTypes::FEATURE_ID_COL} = $this->{feature_id};
    $this->{feature_id}++;
    $feature->{&db::MhcTypes::SEQ_TYPE_ID_COL} = $this->{seq_type_id};
    $feature->{&db::MhcTypes::LOCUS_ID_COL}    = $this->{locus_id};
    ###
    ### Get data from the file
    ###
    foreach my $col (@{$feature_file_ord}) {
      $feature->{$col} = $entity->{$col};
    }
    ###
    ### Generate the following data:
    ###
    ### 1.  feature names
    ### 2.  feature types
    ### 3.  feature map
    ### 4.  pubmed
    ###
    $this->_generateFeatureNames(
      $feature->{&db::MhcTypes::FEATURE_ID_COL},
      $feature->{&db::MhcTypes::FEATURE_NAMES_COL}
    );
    $this->_generateFeatureTypes(
      $feature->{&db::MhcTypes::FEATURE_ID_COL},
      $feature->{&db::MhcTypes::FEATURE_TYPES_COL}
    );
    $feature->{&db::MhcTypes::POSITIONS_COL} = $this->_generateFeatureMap(
      $feature->{&db::MhcTypes::FEATURE_NUMBER_COL},
      $feature->{&db::MhcTypes::FEATURE_ID_COL},
      $feature->{&hla::HlaTypes::LOCATION_COL}
    );
    $this->_generatePubMedIds(
      $feature->{&db::MhcTypes::FEATURE_ID_COL},
      $feature->{&db::MhcTypes::RELATED_PUBS_COL}
    );
    ###
    ### Now generate feature
    ###
    $this->{generator}->generateRow( $feature_table, $feature );
  }
}

sub taxonId {
  my hla::FeatureName $this = shift;
  return $this->{taxon_id};
}

sub featureId {
  my hla::FeatureName $this = shift;
  return $this->{feature_id};
}
################################################################################

1;

__END__

=head1 NAME

FeatureName.pm

=head1 DESCRIPTION

This class defines the reader for the HLA feature name (MicroSoft Excel file)
list for a given locus/taxon file.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new hla::FeatureName(featureAlleles, locus_name, taxon_id, seq_type,generator, feature_id, error_mgr)>

This is the constructor for the class.

=head2 B<my $taxon_id = taxonId>

This method returns taxon id generated during this processing.

=head2 B<my $feature_id = featureId>

This method returns the next feature name id to use to load the feature_name
table.

=head2 B<processFile($entities)>

This method processes the entities array for given locus_name,
taxon_id, and seq_type and stores the feature names and the feature
map for it.

=cut
