package hla::HlaTypes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use file::Chunk::Bcp::Tab;

use util::Constants;
use util::JSon;

################################################################################
#
#			       Private Constants
#
################################################################################

my $_FEATURE_ALLELE_ = undef;
my $_ERROR_MGR_      = undef;

################################################################################
#
#			Public Constant Methods
#
################################################################################
###
### Infixes
###
sub DEPRECATED_INFIX { return 'deprecated'; }
sub FEATURES_INFIX   { return 'features'; }
sub VARIANTS_INFIX   { return 'variants'; }
###
### Column Names
###
sub ALLELE_COL                     { return 'allele'; }
sub AMINO_ACIDS_COL                { return 'amino_acids'; }
sub CHANGE_TYPE_COL                { return 'change_type'; }
sub COORD_COL                      { return 'feature_coord'; }
sub CURR_POS_MOTIF_COL             { return 'current_position_motif'; }
sub DISPOSITION_COL                { return 'disposition'; }
sub ERROR_TYPE_COL                 { return 'error_type'; }
sub FILE_NAME_COL                  { return 'file_name'; }
sub INTERVAL_COMPONENT_COL         { return 'interval'; }
sub LOCATION_COL                   { return 'feature_coordinates'; }
sub LOCUS_NAME_COL                 { return 'locus_name'; }
sub MIN_COORD_COL                  { return 'min_coord'; }
sub NEW_ALLELE_COL                 { return 'new_allele'; }
sub NEW_MOTIF_COL                  { return 'new_motif'; }
sub NEW_VARIANT_COL                { return 'new_variant'; }
sub PREVIOUS_MOTIF_COL             { return 'previous_motif'; }
sub PREVIOUS_VARIANT_TYPE_NAME_COL { return 'previous_variant_type_name'; }
sub PREV_POS_MOTIF_COL             { return 'previous_position_motif'; }
sub REASON_COL                     { return 'reason'; }
sub REF_ALLELE_COL                 { return 'ref_allele'; }
sub TEST_LOCUS_COL                 { return 'test_locus'; }
sub VARIANT_COL                    { return 'variant'; }
###
### Sequence Alignment Information File
###
sub SEQ_INFO_FILE { return 'seq_info'; }

sub SEQ_INFO_FILE_ORD {
  return [
    LOCUS_NAME_COL, TEST_LOCUS_COL, MIN_COORD_COL,
    REF_ALLELE_COL, FILE_NAME_COL,
  ];
}
###
### Feature File Structure:
###
sub FEATURE_FILE { return FEATURES_INFIX; }

sub FEATURE_DEPRECATED_FILE {
  join( util::Constants::DOT, FEATURES_INFIX, DEPRECATED_INFIX );
}
sub FEATURE_FILES { return ( FEATURE_FILE, FEATURE_DEPRECATED_FILE ); }

sub FEATURE_FILE_ORD {
  return [
    db::MhcTypes::FEATURE_NUMBER_COL, LOCATION_COL,
    db::MhcTypes::FEATURE_NAMES_COL,  db::MhcTypes::FEATURE_TYPES_COL,
    db::MhcTypes::COMMENTS_COL,       db::MhcTypes::RELATED_PUBS_COL,
  ];
}

sub FEATURE_FILE_HEADER {
  return {
    &db::MhcTypes::FEATURE_NUMBER_COL => 'Sequence Feature ID',
    &LOCATION_COL => 'Sequence Feature Location - Amino Acid Position(s)',
    &db::MhcTypes::FEATURE_NAMES_COL => 'Sequence Feature Name(s)',
    &db::MhcTypes::FEATURE_TYPES_COL => 'Sequence Feature Type(s)',
    &db::MhcTypes::COMMENTS_COL      => 'Comments',
    &db::MhcTypes::RELATED_PUBS_COL  => 'References',
  };
}
###
### Variant File Structure:
###
sub VARIANT_FILE { return VARIANTS_INFIX; }

sub VARIANT_DEPRECATED_FILE {
  return join( util::Constants::DOT, VARIANTS_INFIX, DEPRECATED_INFIX );
}
sub VARIANT_FILES { return ( VARIANT_FILE, VARIANT_DEPRECATED_FILE ); }

sub VARIANT_FILE_ORD {
  return [
    db::MhcTypes::FEATURE_NUMBER_COL,    LOCATION_COL,
    db::MhcTypes::FEATURE_NAMES_COL,     db::MhcTypes::FEATURE_TYPES_COL,
    db::MhcTypes::VARIANT_TYPE_NAME_COL, db::MhcTypes::MOTIF_COL,
    db::MhcTypes::POS_MOTIF_COL,         db::MhcTypes::ALLELE_GROUP_COL,
  ];
}

sub VARIANT_DEPRECATED_FILE_ORD {
  return [
    db::MhcTypes::FEATURE_NUMBER_COL,    LOCATION_COL,
    db::MhcTypes::VARIANT_TYPE_NAME_COL, db::MhcTypes::MOTIF_COL,
    db::MhcTypes::POS_MOTIF_COL,
  ];
}

sub VARIANT_FILE_HEADER {
  return {
    &db::MhcTypes::FEATURE_NUMBER_COL => 'Sequence Feature ID',
    &LOCATION_COL => 'Sequence Feature Location - Amino Acid Position(s)',
    &db::MhcTypes::FEATURE_NAMES_COL     => 'Sequence Feature Name(s)',
    &db::MhcTypes::FEATURE_TYPES_COL     => 'Sequence Feature Type(s)',
    &db::MhcTypes::VARIANT_TYPE_NAME_COL => 'Sequence Feature Variant Type',
    &db::MhcTypes::MOTIF_COL             => 'Motif sequence',
    &db::MhcTypes::POS_MOTIF_COL         => 'Variant Type Definition',
    &db::MhcTypes::ALLELE_GROUP_COL      => 'Allele Group',
  };
}

sub VARIANT_DEPRECATED_FILE_HEADER {
  return {
    &db::MhcTypes::FEATURE_NUMBER_COL => 'Sequence Feature ID',
    &LOCATION_COL => 'Sequence Feature Location - Amino Acid Position(s)',
    &db::MhcTypes::VARIANT_TYPE_NAME_COL => 'Sequence Feature Variant Type',
    &db::MhcTypes::MOTIF_COL             => 'Motif sequence',
    &db::MhcTypes::POS_MOTIF_COL         => 'Variant Type Definition',
  };
}
###
###
###
sub SFVT_FILES_READ {
  return {
    &FEATURE_FILE => {
      class          => 'file::Chunk::Excel',
      ord            => FEATURE_FILE_ORD,
      read_method    => 'readExcelFile',
      process_method => 'readExcelData',
      locus_col      => db::MhcTypes::FEATURE_NUMBER_COL,
      locus_pattern  => '^Hsa_(.+)_SF\d+$',
    },
    &VARIANT_FILE => {
      class          => 'file::Chunk::Excel',
      ord            => VARIANT_FILE_ORD,
      read_method    => 'readExcelFile',
      process_method => 'readExcelData',
      locus_col      => db::MhcTypes::FEATURE_NUMBER_COL,
      locus_pattern  => '^Hsa_(.+)_SF\d+$',
    },
    &FEATURE_DEPRECATED_FILE => {
      class          => 'file::Chunk::Excel',
      ord            => FEATURE_FILE_ORD,
      read_method    => 'readExcelFile',
      process_method => 'readExcelData',
      locus_col      => db::MhcTypes::FEATURE_NUMBER_COL,
      locus_pattern  => '^Hsa_(.+)_SF\d+$',
    },
    &VARIANT_DEPRECATED_FILE => {
      class          => 'file::Chunk::Excel',
      ord            => VARIANT_DEPRECATED_FILE_ORD,
      read_method    => 'readExcelFile',
      process_method => 'readExcelData',
      locus_col      => db::MhcTypes::FEATURE_NUMBER_COL,
      locus_pattern  => '^Hsa_(.+)_SF\d+$',
    },
    &SEQ_INFO_FILE => {
      class          => 'file::Chunk::Bcp::Tab',
      ord            => SEQ_INFO_FILE_ORD,
      read_method    => 'readBcpFile',
      process_method => 'readSeqData',
      locus_col      => LOCUS_NAME_COL,
      locus_pattern  => '^(HLA-[A-Z]+[1-9]?)$',
      file_col       => FILE_NAME_COL,
    },
  };
}
###
### The SFVT files generated
###
sub SFVT_FILES_GENERATED {
  return {
    &FEATURE_FILE => {
      header => FEATURE_FILE_HEADER,
      ord    => FEATURE_FILE_ORD,
      suffix => ' SFs',
    },
    &VARIANT_FILE => {
      header => VARIANT_FILE_HEADER,
      ord    => VARIANT_FILE_ORD,
      suffix => ' SFVTs',
    },
    &FEATURE_DEPRECATED_FILE => {
      header => FEATURE_FILE_HEADER,
      ord    => FEATURE_FILE_ORD,
      suffix => ' SFs',
    },
    &VARIANT_DEPRECATED_FILE => {
      header => VARIANT_DEPRECATED_FILE_HEADER,
      ord    => VARIANT_DEPRECATED_FILE_ORD,
      suffix => ' SFVTs',
    },
  };
}
###
### Feature Types
###
sub STRUCTURAL_TYPE { return 'Structural'; }
sub FUNCTIONAL_TYPE { return 'Functional'; }

sub STRUCTURAL_FUNCTIONAL_COMBINATION_TYPE {
  return 'Structural_Functional Combination';
}

sub STRUCTURAL_COMPLETE_PROTEIN_TYPE { return 'Structural - Complete protein'; }

sub STRUCTURAL_DOMAIN_TYPE { return 'Structural - Domain'; }

sub STRUCTURAL_SECONDARY_STRUCTURE_MOTIF_TYPE {
  return 'Structural - Secondary structure motif';
}

sub STRUCTURAL_CLEAVED_PEPTIDE_REGION_TYPE {
  return 'Structural - Cleaved peptide region';
}
sub SEQUENCE_ALTERATION_TYPE { return 'Sequence Alteration'; }

sub SEQUENCE_ALTERATION_SINGLE_AMINO_ACID_VARIATION_TYPE {
  return 'Sequence Alteration - Single amino acid variation';
}

sub SEQUENCE_ALTERATION_INSERTIONS_DELETIONS_TYPE {
  return 'Sequence Alteration - Insertions and Deletions';
}

sub STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE {
  return 'Structural_Sequence Alteration Combination';
}

sub FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE {
  return 'Functional_Sequence Alteration Combination';
}
###
### Structure Functional Feature Types
### for Singleton Sequence Features
###
sub SF_FEATURE_TYPES {
  return [
    STRUCTURAL_TYPE,
    FUNCTIONAL_TYPE,
    STRUCTURAL_COMPLETE_PROTEIN_TYPE,
    STRUCTURAL_DOMAIN_TYPE,
    STRUCTURAL_FUNCTIONAL_COMBINATION_TYPE,
    STRUCTURAL_SECONDARY_STRUCTURE_MOTIF_TYPE,
    STRUCTURAL_CLEAVED_PEPTIDE_REGION_TYPE,
  ];
}
###
### Alteration Feature Types
### for Singleton Sequence Features
###
sub A_FEATURE_TYPES {
  return [
    SEQUENCE_ALTERATION_TYPE,
    SEQUENCE_ALTERATION_SINGLE_AMINO_ACID_VARIATION_TYPE,
    SEQUENCE_ALTERATION_INSERTIONS_DELETIONS_TYPE,
    STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
    FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
  ];
}
###
### Standard Sequence Feature Type and Name
### for NEW Singleton Sequence Feature
###
sub SINGLETON_FEATURE_TYPE {
  return SEQUENCE_ALTERATION_SINGLE_AMINO_ACID_VARIATION_TYPE;
}

sub SINGLETON_FEATURE_NAME_INFIX { return '_variant position '; }

sub SINGLETON_FEATURE_NAME {
  my ($locus_name) = @_;
  return "Hsa_${locus_name}" . SINGLETON_FEATURE_NAME_INFIX;
}
###
### Singleton Feature Type Map
###
sub SINGLETON_FEATURE_TYPE_MAP {
  return {
    &FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE =>
      FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
    &FUNCTIONAL_TYPE => FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,

    &STRUCTURAL_FUNCTIONAL_COMBINATION_TYPE => [
      FUNCTIONAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
      STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE
    ],

    &STRUCTURAL_CLEAVED_PEPTIDE_REGION_TYPE =>
      STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
    &STRUCTURAL_COMPLETE_PROTEIN_TYPE =>
      STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
    &STRUCTURAL_DOMAIN_TYPE => STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,
    &STRUCTURAL_TYPE        => STRUCTURAL_SEQUENCE_ALTERATION_COMBINATION_TYPE,

  };
}
###
### Error Information
###
sub COORDINATE_ERROR { return 'coordinate'; }
sub MOTIF_ERROR      { return 'motif'; }
sub VARIANT_ERROR    { return 'variant'; }

sub ERROR_TYPES {
  return {
    &COORDINATE_ERROR => {
      ord =>
        [ LOCUS_NAME_COL, db::MhcTypes::FEATURE_NUMBER_COL, LOCATION_COL, ],
      sort_ord =>
        [ LOCUS_NAME_COL, db::MhcTypes::FEATURE_NUMBER_COL, LOCATION_COL, ],
    },
    &MOTIF_ERROR => {
      ord => [
        LOCUS_NAME_COL,     db::MhcTypes::VARIANT_TYPE_NAME_COL,
        CURR_POS_MOTIF_COL, PREV_POS_MOTIF_COL,
      ],
      sort_ord => [ LOCUS_NAME_COL, db::MhcTypes::VARIANT_TYPE_NAME_COL, ],
    },
    &VARIANT_ERROR => {
      ord => [
        LOCUS_NAME_COL,                 db::MhcTypes::FEATURE_NUMBER_COL,
        db::MhcTypes::ALLELE_GROUP_COL, ALLELE_COL,
        VARIANT_COL,                    NEW_ALLELE_COL,
        NEW_VARIANT_COL,
      ],
      sort_ord => [
        LOCUS_NAME_COL,
        db::MhcTypes::FEATURE_NUMBER_COL,
        db::MhcTypes::ALLELE_GROUP_COL,
        ALLELE_COL,
        VARIANT_COL,
        NEW_ALLELE_COL,
        NEW_VARIANT_COL,

      ],
    },
  };
}
###
### Sequence feature types during processing
###
sub DEPRECATE_SEQUENCE_FEATURE_TYPE    { return 'Deprecated'; }
sub KEEP_DEPRECATED_FEATURE_TYPE       { return 'Previous Deprecate'; }
sub NEW_SEQUENCE_FEATURE_TYPE          { return 'New'; }
sub PREV_SEQUENCE_FEATURE_TYPE         { return 'Previous'; }
sub UNDEPRECATED_SEQUENCE_FEATURE_TYPE { return 'Undeprecated'; }
###
### Allele group types during validation
###
sub ALLELE_GROUP_DELETED    { return 'Deleted'; }
sub ALLELE_GROUP_MOVED_TYPE { return 'Moved'; }
###
### Allele group moved reasons
###
sub ALLELE_GROUP_MOVED_REASON1 { return 'Allele group motif changed'; }

sub ALLELE_GROUP_MOVED_REASON2 {
  return 'Allele group motif changed and variant deprecated';
}
###
### Motif types during validation
###
sub DEPRECATED_BUT_IN_PREV_VERSION_TYPE {
  return 'Deprecated But In Previous Version';
}
sub DEPRECATE_VARIANT_TYPE       { return 'Deprecated'; }
sub KEEP_DEPRECATED_VARIANT_TYPE { return 'Previous Deprecate'; }
sub NEW_VARIANT_TYPE             { return 'New'; }
sub PREV_VERSION_VARIANT_TYPE    { return 'Previous'; }
sub UNDEPRECATED_VARIANT_TYPE    { return 'Undeprecated'; }
###
### Information Files
###
sub ALLELE_GROUP_DISPOSITION_INFO { return 'allele_groups.disposition'; }
sub FEATURE_DISPOSITION_INFO      { return 'features.disposition'; }
sub VARIANT_DISPOSITION_INFO      { return 'variants.disposition'; }

sub INFO_TYPES {
  return {
    &ALLELE_GROUP_DISPOSITION_INFO => {
      ord => [
        LOCUS_NAME_COL,                 db::MhcTypes::FEATURE_NUMBER_COL,
        LOCATION_COL,                   db::MhcTypes::VARIANT_TYPE_NAME_COL,
        db::MhcTypes::ALLELE_GROUP_COL, DISPOSITION_COL,
        PREVIOUS_VARIANT_TYPE_NAME_COL, REASON_COL,
        PREVIOUS_MOTIF_COL,             NEW_MOTIF_COL,
      ],
      sort_ord => undef,
    },
    &FEATURE_DISPOSITION_INFO => {
      ord => [
        LOCUS_NAME_COL, db::MhcTypes::FEATURE_NUMBER_COL,
        LOCATION_COL,   DISPOSITION_COL,
      ],
      sort_ord => undef,
    },
    &VARIANT_DISPOSITION_INFO => {
      ord => [
        LOCUS_NAME_COL,  db::MhcTypes::FEATURE_NUMBER_COL,
        LOCATION_COL,    db::MhcTypes::VARIANT_TYPE_NAME_COL,
        DISPOSITION_COL, db::MhcTypes::POS_MOTIF_COL,
      ],
      sort_ord => undef,
    },
  };
}
###
### Logging reports for each locus
###
sub SINGLETON_FEATURE_REPORT_COLS {
  return ( db::MhcTypes::FEATURE_NUMBER_COL,
    COORD_COL, AMINO_ACIDS_COL, CHANGE_TYPE_COL );
}

sub VARIANT_CHANGE_REPORT_COLS {
  return ( db::MhcTypes::VARIANT_TYPE_NAME_COL, CHANGE_TYPE_COL );
}

################################################################################
#
#			Public Static Methods
#
################################################################################

sub readFeatureAlleleData {
  my ( $feature_allele_file, $tools ) = @_;

  return if ( defined($_FEATURE_ALLELE_) );

  $_ERROR_MGR_ = $tools->getErrorMgr;

  my $table_name  = db::MhcTypes::FEATURE_ALLELE_TABLE;
  my $table_infos = $tools->getTableInfo;
  my $table_info  = $table_infos->{$table_name};
  my $ord         = [];
  push( @{$ord}, @{ $table_info->{key} } );
  push( @{$ord}, @{ $table_info->{vals} } );
  my $reader = new file::Chunk::Bcp::Tab( undef, $ord, $_ERROR_MGR_ );

  $reader->setSourceFile($feature_allele_file);
  $reader->readBcpFile;
  $_FEATURE_ALLELE_ = {};
  foreach my $entity ( @{ $reader->getEntities } ) {
    my $locus_name = $entity->{locus_id};
    if ( !defined( $_FEATURE_ALLELE_->{$locus_name} ) ) {
      $_FEATURE_ALLELE_->{$locus_name} = [];
    }
    my $data = { %{$entity} };
    push( @{ $_FEATURE_ALLELE_->{$locus_name} }, $data );
  }
}

sub getFeatureAlleleData {
  my ($locus_name) = @_;
  return () if ( !defined($_FEATURE_ALLELE_) );
  my $data = $_FEATURE_ALLELE_->{$locus_name};
  return () if ( !defined($data) );
  return @{$data};
}

sub getPdbMappingData {
  my ($locus_name) = @_;
  return () if ( !defined($_FEATURE_ALLELE_) );
  my @data = getFeatureAlleleData($locus_name);
  return @data if ( @data == 0 );
  my $json = new util::JSon($_ERROR_MGR_);
  foreach my $datum (@data) {
    $datum->{pdb_map} = $json->makePerlObj( $datum->{pdb_map} );
  }
  return @data;
}

sub getLociWithPdbStructures {
  my @loci = ();
  return @loci if ( !defined($_FEATURE_ALLELE_) );
  return keys %{$_FEATURE_ALLELE_};
}

################################################################################

1;

__END__

=head1 NAME

HlaTypes.pm

=head1 DESCRIPTION

The static class defines the special static types that define the PDB
feeature allele data for sequence features including the mapping of
sequence features onto PDB structures

=head1 STATIC METHODS

The following static methods are exported by this class.

=head2 B<readFeatureAlleleData(feature_allele_file, tools)>

Read the feature_allele data from the file B<feature_allele_file> and
process them into an internal data-structure to support the other
static methods of this class.  The B<tools> is a sub-class of
L<util::Tools> and provides access to the structure of the file using
the database table B<FEATURE_ALLELE>.

=head2 B<@pdb_structures = getFeatureAlleleData(locus_name)>

For a given locus name, it returns the reference array of PDB
structures assigned to a given locus.  Each component is a reference
hash with components:

   locus_id      => locus_name
   allele_id     => allele name
   pdb_id        => PDB ID
   pdb_positions => optional string data for specifying allele
                    to pdb mapping for UI
   pdb_mapping   => string data for mapping allele to pdb structure
                    with the following specification once converted
                    to JSon or Perl:
                      referenced array of mapping coordinates where
                      each coordinate is a referenceed hash with
                      components:
                        hla_left
                        hla_right
                        chain_id
                        pdb_left  -- only appear is chain_id is defined 
                        pdb_right -- only appear is chain_id is defined 

=head2 B<@pdb_structures = getPdbMappingData(locus_name)>

For a given locus name, it returns the reference array of PDB
structures assigned to a given locus.  Each component is a reference
hash with components:

   locus_id      => locus_name
   allele_id     => allele name
   pdb_id        => PDB ID
   pdb_positions => optional string data for specifying allele
                    to pdb mapping for UI
   pdb_mapping   => referenced Perl array of mapping coordinates where
                    each coordinate is a referenceed hash with
                    components:
                      hla_left
                      hla_right
                      chain_id
                      pdb_left  -- only appear is chain_id is defined 
                      pdb_right -- only appear is chain_id is defined 

=head2 B<@loci = getLociWithPdbStructures>

Get all the loci with Pdb Structures.

=cut
