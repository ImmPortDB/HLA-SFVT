package hla::HlaGenerateSfvt;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;
use Spreadsheet::WriteExcel;

use hla::ErrMsgs;
use hla::GenerateSfvt;
use hla::HlaTypes;

use util::ErrorInfo;
use util::PathSpecifics;
use util::TableData;

use fields qw (
  deleted_names_map
  error_info
  error_mgr
  file_data
  files
  imgt_release_date
  imgt_release_version
  infix
  info
  seq_dir
  seq_type
  taxon_id
  tools
  workbooks
);

################################################################################
#
#			     Constant Class Methods
#
################################################################################
###
### Error Messages
###
sub ERR_CAT { return hla::ErrMsgs::HLAGENERATESFVT_CAT }

################################################################################
#
#				Private Methods
#
################################################################################

sub _determineDeletedNamesMap {
  my hla::HlaGenerateSfvt $this = shift;

  $this->{deleted_names_map} = {};

  my $tools             = $this->{tools};
  my $deleted_names_map = $this->{deleted_names_map};

  $tools->generateDeletedNamesMap;
  my $deletedMap = $tools->deletedNamesMap;
  foreach my $deleted_item ( $tools->deletedNames ) {
    my $allele = $deleted_item->{deleted_name};
    if ( defined( $deletedMap->{$allele} ) ) {
      $allele = $deletedMap->{$allele};
    }
    $deleted_names_map->{$allele} =
        'The allele '
      . $deleted_item->{deleted_name} . ' ('
      . $deleted_item->{hla_id}
      . ') was deleted from IMGT/HLA for the following reason:  '
      . $deleted_item->{commentary};
  }
}

sub _getLocusName {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $entities, $col, $pattern ) = @_;

  my $locus_name = undef;
  foreach my $entity ( @{$entities} ) {
    next if ( $entity->{"$col"} !~ /$pattern/ );
    $locus_name = $1;
    last;
  }
  return $locus_name;
}

sub _readFiles {
  my hla::HlaGenerateSfvt $this = shift;

  my $imgt_release_date    = $this->{imgt_release_date};
  my $imgt_release_version = $this->{imgt_release_version};

  my $sfvt_files = hla::HlaTypes::SFVT_FILES_READ;
  $this->{file_data} = {};
  foreach my $file_type ( keys %{$sfvt_files} ) {
    my $file = $this->{files}->{$file_type};
    $this->{file_data}->{$file_type} = {
      data => undef,
      ord  => undef,
    };
    next if ( util::Constants::EMPTY_LINE($file) );
    my $file_data  = $this->{file_data}->{$file_type};
    my $sfvt_file  = $sfvt_files->{$file_type};
    my $reader     = undef;
    my $data       = undef;
    my $ord        = undef;
    my @eval_array = (
      'use ' . $sfvt_file->{class} . ';',
      '$reader = new '
        . $sfvt_file->{class}
        . '(undef, $sfvt_file->{ord}, $this->{error_mgr});',
      '$reader->setSourceFile($file);',
      '$reader->' . $sfvt_file->{read_method} . ';',
      '($data, $ord) = $this->'
        . $sfvt_file->{process_method}
        . '($reader, $sfvt_file);'
    );
    my $eval_str = join( util::Constants::NEWLINE, @eval_array );
    eval $eval_str;
    my $status = $@;
    $this->{error_mgr}->hardDieOnError(
      ERR_CAT,
      1,
      [ $imgt_release_version, $imgt_release_date, $file, $status, $eval_str, ],
      ( defined($status) && $status ) || !defined($reader) || !defined($data)
    );
    $file_data->{data} = $data;
    $file_data->{ord}  = $ord;
  }
}

sub _openWorkBooks {
  my hla::HlaGenerateSfvt $this = shift;

  $this->{workbooks} = {};
  my $sfvt_files = hla::HlaTypes::SFVT_FILES_GENERATED;
  foreach my $file_type ( keys %{$sfvt_files} ) {
    my $sfvt_file = $sfvt_files->{$file_type};
    my $file      = join( util::Constants::SLASH,
      $this->{tools}->executionDir,
      join( util::Constants::DOT,
        'FeatureVariants', $file_type,
        $this->{infix},    $this->{imgt_release_date},
        'xls'
      )
    );
    $this->{workbooks}->{$file_type} = {
      workbook  => new Spreadsheet::WriteExcel($file),
      worksheet => undef,
      row       => 0,
      header    => { %{ $sfvt_file->{header} } },
      ord       => [ @{ $sfvt_file->{ord} } ],
      suffix    => $sfvt_file->{suffix},
    };
  }
}

sub _closeWorkBooks {
  my hla::HlaGenerateSfvt $this = shift;

  foreach my $file_type ( keys %{ $this->{workbooks} } ) {
    my $workbook = $this->{workbooks}->{$file_type};
    $workbook->{workbook}->close;
  }
}

sub _writeWorkSheetRow {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $file_type, $entity ) = @_;

  my $workbook = $this->{workbooks}->{$file_type};
  foreach my $index ( 0 .. $#{ $workbook->{ord} } ) {
    my $col_name = $workbook->{ord}->[$index];
    my $col_val  = $entity->{"$col_name"};
    $workbook->{worksheet}->write( $workbook->{row}, $index, $col_val );
  }
  $workbook->{row}++;
}

sub _addWorkSheets {
  my hla::HlaGenerateSfvt $this = shift;
  my ($locus_name) = @_;

  foreach my $file_type ( keys %{ $this->{workbooks} } ) {
    my $workbook       = $this->{workbooks}->{$file_type};
    my $worksheet_name = $locus_name . $workbook->{suffix};
    $workbook->{worksheet} =
      $workbook->{workbook}->add_worksheet($worksheet_name);
    $workbook->{row} = 0;
    $this->_writeWorkSheetRow( $file_type, $workbook->{header} );
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$$$$$) {
  my hla::HlaGenerateSfvt $this = shift;
  my (
    $feature_file,            $variant_file,
    $feature_deprecated_file, $variant_deprecated_file,
    $taxon_id,                $seq_type,
    $seq_dir,                 $seq_info_file,
    $imgt_release_date,       $imgt_release_version,
    $tools,                   $error_mgr
  ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr}            = $error_mgr;
  $this->{file_data}            = undef;
  $this->{imgt_release_date}    = $imgt_release_date;
  $this->{imgt_release_version} = $imgt_release_version;
  $this->{infix}                = $tools->getProperty( $tools->LOG_INFIX_PROP );
  $this->{seq_dir}              = $seq_dir;
  $this->{seq_type}             = $seq_type;
  $this->{taxon_id}             = $taxon_id;
  $this->{tools}                = $tools;
  $this->{workbooks}            = undef;

  $this->_determineDeletedNamesMap;

  $this->{files} = {
    &hla::HlaTypes::FEATURE_FILE => getPath($feature_file),
    &hla::HlaTypes::VARIANT_FILE => getPath($variant_file),
    &hla::HlaTypes::FEATURE_DEPRECATED_FILE =>
      getPath($feature_deprecated_file),
    &hla::HlaTypes::VARIANT_DEPRECATED_FILE =>
      getPath($variant_deprecated_file),
    &hla::HlaTypes::SEQ_INFO_FILE => getPath($seq_info_file),
  };

  my $error_types = hla::HlaTypes::ERROR_TYPES;
  $this->{error_info} =
    new util::ErrorInfo( $this->{infix}, ERR_CAT, $tools, $error_mgr );
  foreach my $error_type ( keys %{$error_types} ) {
    my $data = $error_types->{$error_type};
    $this->{error_info}
      ->setTableData( $error_type, $data->{ord}, $data->{sort_ord} );
  }
  my $info_types = hla::HlaTypes::INFO_TYPES;
  $this->{info} = new util::TableData( 'sfvt', $tools, $error_mgr );
  foreach my $info_type ( keys %{$info_types} ) {
    my $data = $info_types->{$info_type};
    my $file = join( util::Constants::SLASH,
      $tools->executionDir,
      join( util::Constants::DOT,
        $tools->scriptPrefix, $this->{infix}, $info_type, 'xls'
      )
    );
    $this->{info}->setTableData( $info_type, $data->{ord}, $data->{sort_ord} );
    $this->{info}->setFile( $info_type, $file );
  }

  return $this;
}

sub errorInfo {
  my hla::HlaGenerateSfvt $this = shift;
  return $this->{error_info};
}

sub readSeqData {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $reader, $sfvt_file ) = @_;

  my $data          = {};
  my $ord           = [];
  my $file_col      = $sfvt_file->{file_col};
  my $locus_col     = $sfvt_file->{locus_col};
  my $locus_pattern = $sfvt_file->{locus_pattern};
  foreach my $entity ( @{ $reader->getEntities } ) {
    my $locus_val = $entity->{$locus_col};
    next if ( util::Constants::EMPTY_LINE($locus_val) );
    next if ( $locus_val !~ /$locus_pattern/ );
    my $locus_name = $1;
    push( @{$ord}, $locus_name );
    $data->{$locus_name} = $entity;
    $entity->{$file_col} =
      join( util::Constants::SLASH, $this->{seq_dir}, $entity->{$file_col} );
  }
  return ( $data, $ord );
}

sub readExcelData {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $reader, $sfvt_file ) = @_;

  my $data = {};
  my $ord  = [];
  foreach my $worksheet_num ( $reader->getWorksheetNums ) {
    my @entities   = $reader->getWorksheet($worksheet_num);
    my $locus_name = $this->_getLocusName(
      \@entities,
      $sfvt_file->{locus_col},
      $sfvt_file->{locus_pattern}
    );
    push( @{$ord}, $locus_name );
    $data->{$locus_name} = [@entities];
  }
  return ( $data, $ord );
}

sub writeFeature {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $file_type, $entities ) = @_;

  foreach my $entity ( @{$entities} ) {
    $this->_writeWorkSheetRow( $file_type, $entity );
  }
}

sub writeInfo {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $info_type, $data ) = @_;

  foreach my $key ( sort keys %{$data} ) {
    $this->{info}->addTableRow( $info_type, $data->{$key} );
  }
}

sub getDeletionReason {
  my hla::HlaGenerateSfvt $this = shift;
  my ($allele) = @_;

  my $deleted_names_map = $this->{deleted_names_map};
  my $allele_pattern    = $allele;
  $allele_pattern =~ s/\*/\\\*/;
  foreach my $deleted_allele ( keys %{$deleted_names_map} ) {
    my $reason = $deleted_names_map->{$deleted_allele};
    return $reason
      if ( $deleted_allele =~ /^$allele_pattern$/i
      || $deleted_allele =~ /^$allele_pattern/i );
  }
  return util::Constants::EMPTY_STR;
}

sub generateReport {
  my hla::HlaGenerateSfvt $this = shift;
  my ( $title, $data, @cols ) = @_;

  my %cols = ();
  foreach my $col (@cols) { $cols{$col} = $col; }
  my $change_report = new util::Table( $this->{error_mgr}, %cols );
  $change_report->setColumnOrder(@cols);
  foreach my $col (@cols) {
    $change_report->setColumnJustification( $col,
      $change_report->LEFT_JUSTIFY );
  }
  my @data = ();
  foreach my $key ( sort keys %{$data} ) {
    my $datum  = $data->{"$key"};
    my $struct = {};
    foreach my $index ( 0 .. $#cols ) {
      $struct->{ $cols[$index] } = $datum->[$index];
    }
    push( @data, $struct );
  }
  return if ( scalar @data == 0 );
  $change_report->setData(@data);
  $this->{error_mgr}->printMsg("$title:");
  $change_report->generateTable;
}

sub generate {
  my hla::HlaGenerateSfvt $this = shift;
  ###
  ### Get the input data
  ###
  $this->_readFiles;
  my $file_data = $this->{file_data};
  my $feature_deprecated =
    $file_data->{&hla::HlaTypes::FEATURE_DEPRECATED_FILE}->{data};
  my $variant_deprecated =
    $file_data->{&hla::HlaTypes::VARIANT_DEPRECATED_FILE}->{data};
  my $features = $file_data->{&hla::HlaTypes::FEATURE_FILE}->{data};
  my $seq_info = $file_data->{&hla::HlaTypes::SEQ_INFO_FILE}->{data};
  my $variants = $file_data->{&hla::HlaTypes::VARIANT_FILE}->{data};
  ###
  ### Open the Excel workbooks for the
  ### new variant and deprecated data
  ###
  $this->_openWorkBooks;
  ###
  ### Process each (locus)
  ###
  my $loci = $file_data->{&hla::HlaTypes::SEQ_INFO_FILE}->{ord};
  foreach my $locus_name ( @{$loci} ) {
    $this->{error_mgr}->printHeader(
      "Locus Sequence Features\n" . "  locus_name = $locus_name" );
    ###
    ### Generate variants and decprecated data for locus
    ###
    my $generate_sfvt = new hla::GenerateSfvt(
      $locus_name,                        $seq_info->{$locus_name},
      $this->{taxon_id},                  $this->{seq_type},
      $features->{$locus_name},           $variants->{$locus_name},
      $feature_deprecated->{$locus_name}, $variant_deprecated->{$locus_name},
      $this,                              $this->{tools},
      $this->{error_mgr}
    );
    $this->_addWorkSheets($locus_name);
    $generate_sfvt->generateVariants;
  }
  $this->_closeWorkBooks;
  ###
  ### Generate error and information results
  ###
  $this->{error_info}->writeErrorInfo;
  foreach my $info_type ( $this->{info}->tableTypes ) {
    $this->{info}->writeTableInfo($info_type);
  }
}

################################################################################

1;

__END__

=head1 NAME

HlaGenerateSfvt.pm

=head1 DESCRIPTION

This concrete class defines the generator for sequence feature vector
data.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new hla::HlaGenerateSfvt( tools, feature_file, variant_file, deprecated_file, taxon_id, seq_type, seq_dir, seq_info_file, imgt_release_data, imgt_release_version, error_mgr )

This is the constructor for the class.

=head2 B<generate>

This method generates the sequence feature vector data.

=cut
