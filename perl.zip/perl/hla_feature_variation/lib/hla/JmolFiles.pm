package hla::JmolFiles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;

use db::MhcTypes;

use hla::ErrMsgs;

use util::Constants;
use util::PathSpecifics;

use fields qw (
  color_map
  deploy_env_properties
  error_mgr
  feature_allele
  feature_alleles
  initial_chain_submenu
  pdbs
  pdb_structure
  pdb_structure_color_map
  pdb_structure_color_map_prop
  pdb_structures
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Labels
###
sub ALLELE_ID         { return 'ALLELE_ID'; }
sub CHAIN_ID          { return 'CHAIN_ID'; }
sub CHAIN_INTERVAL    { return 'CHAIN_INTERVAL'; }
sub CHAIN_NAME        { return 'CHAIN_NAME'; }
sub COLOR             { return 'COLOR'; }
sub COMPONENT_NAME    { return 'COMPONENT_NAME'; }
sub DESCRIPTION       { return 'DESCRIPTION'; }
sub DESCRIPTIVE_NAME  { return 'DESCRIPTIVE_NAME'; }
sub HLA_INTERVAL      { return 'HLA_INTERVAL'; }
sub INTERVAL_MAP      { return 'INTERVAL_MAP'; }
sub LOCUS_ID          { return 'LOCUS_ID'; }
sub MHC_PROTEIN       { return 'MHC_PROTEIN'; }
sub PDB_ID            { return 'PDB_ID'; }
sub PEPTIDE           { return 'PEPTIDE'; }
sub SELECTED_CHAINS   { return 'SELECTED_CHAINS'; }
sub UNSELECTED_CHAINS { return 'UNSELECTED_CHAINS'; }

sub FEATURE_ALLELE_ORD {
  return [ ALLELE_ID, LOCUS_ID, PDB_ID, ];
}

sub HLA_INTERVAL_ORD {
  return [ HLA_INTERVAL, CHAIN_ID, CHAIN_INTERVAL, CHAIN_NAME, ];
}

sub PDB_STRUCTURE_COLOR_MAP_ORD {
  return [ COMPONENT_NAME, COLOR, ];
}

sub PDB_STRUCTURE_ORD {
  return [ PDB_ID, DESCRIPTION, MHC_PROTEIN, PEPTIDE, UNSELECTED_CHAINS, ];
}

sub CHAIN_ID_ORD {
  return [ CHAIN_ID, DESCRIPTIVE_NAME, COMPONENT_NAME, ];
}

sub NO_DATA       { return '--'; }
sub NULL_VAL      { return 'null'; }
sub COL_SEPARATOR { return '~;~'; }
sub ROW_SEPARATOR { return '~:~'; }
###
### Error Category
###
sub ERR_CAT { return hla::ErrMsgs::JMOLFILES_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getRowStruct {
  my hla::JmolFiles $this = shift;
  my ( $line, $ord ) = @_;

  my $struct = {};
  my @row = split( /\t/, $line );
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row[$index];
  }
  return $struct;
}

sub _getLineStruct {
  my hla::JmolFiles $this = shift;
  my ( $lines, $ord ) = @_;

  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    my $col = $ord->[$index];
    my ( $label, $value ) = split( /\t/, $lines->[$index] );
    $this->{error_mgr}
      ->registerError( ERR_CAT, 2, [ $col, $label ], lc($col) ne lc($label) );
    next if lc($col) ne lc($label);
    $struct->{$col} = $value;
  }
  return $struct;
}

sub _openFile {
  my hla::JmolFiles $this = shift;
  my ( $read_write, $type ) = @_;

  my $fh     = new FileHandle;
  my $file   = $this->{$type};
  my $marker = $read_write eq 'reading' ? '<' : '>';
  if ( $read_write eq 'writing' ) {
    $file = getPath( basename($file) );
    $file =~ s/\.txt/.bcp/;
  }
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ $read_write, $file, $type ],
    !$fh->open( $file, $marker )
  );
  if ( $read_write eq 'writing' ) { $fh->autoflush(util::Constants::TRUE); }
  return $fh;
}

sub _getFeatureAllele {
  my hla::JmolFiles $this = shift;

  my $currLabel       = undef;
  my $fa_struct       = undef;
  my $lines           = undef;
  my $fh              = $this->_openFile( 'reading', 'feature_allele' );
  my $feature_alleles = [];
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    my @row = split( /\t/, $line );
    my $label = $row[0];
    if ( !defined($currLabel) || $label eq ALLELE_ID ) {
      $currLabel = $label;
      $lines     = [];
    }
    if ( $label eq INTERVAL_MAP ) {
      $fa_struct = $this->_getLineStruct( $lines, FEATURE_ALLELE_ORD );
      push( @{$feature_alleles}, $fa_struct );
    }
    elsif ( $label eq HLA_INTERVAL ) {
      $fa_struct->{intervals} = [];
    }
    elsif ( $currLabel eq HLA_INTERVAL ) {
      my $struct = $this->_getRowStruct( $line, HLA_INTERVAL_ORD );
      push( @{ $fa_struct->{intervals} }, $struct );
      next;
    }
    else {
      push( @{$lines}, $line );
    }
    $currLabel = $label;
  }
  $fh->close;

  $this->{feature_alleles} = $feature_alleles;
}

sub _getPdbStructure {
  my hla::JmolFiles $this = shift;

  my $currLabel      = undef;
  my $lines          = undef;
  my $pdb_struct     = undef;
  my $fh             = $this->_openFile( 'reading', 'pdb_structure' );
  my $pdb_structures = [];
  my $pdbs           = {};
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    my @row = split( /\t/, $line );
    my $label = $row[0];
    if ( !defined($currLabel) || $label eq PDB_ID ) {
      $currLabel = $label;
      $lines     = [];
    }
    if ( $label eq SELECTED_CHAINS ) {
      $pdb_struct = $this->_getLineStruct( $lines, PDB_STRUCTURE_ORD );
      $pdbs->{ $pdb_struct->{&PDB_ID} } = util::Constants::EMPTY_STR;
      push( @{$pdb_structures}, $pdb_struct );
    }
    elsif ( $label eq CHAIN_ID ) {
      $pdb_struct->{chains} = [];
    }
    elsif ( $currLabel eq CHAIN_ID ) {
      my $struct = $this->_getRowStruct( $line, CHAIN_ID_ORD );
      push( @{ $pdb_struct->{chains} }, $struct );
      next;
    }
    else {
      push( @{$lines}, $line );
    }
    $currLabel = $label;
  }
  $fh->close;

  $this->{pdb_structures} = $pdb_structures;
  $this->{pdbs}           = $pdbs;
}

sub _getPdbStructureColorMap {
  my hla::JmolFiles $this = shift;

  my $fh = $this->_openFile( 'reading', 'pdb_structure_color_map' );
  my $color_map = {};
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    my ( $label, $color ) = split( /\t/, $line );
    next if ( $label eq COMPONENT_NAME );
    $color_map->{$label} = $color;
  }
  $fh->close;

  $this->{color_map} = $color_map;
}

sub _getOrd {
  my hla::JmolFiles $this = shift;
  my ($table_name) = @_;

  my $tools       = $this->{tools};
  my $table_infos = $tools->getTableInfo;
  my $table_info  = $table_infos->{$table_name};
  my $ord         = [];
  push( @{$ord}, @{ $table_info->{key} } );
  push( @{$ord}, @{ $table_info->{vals} } );

  return $ord;
}

sub _getStruct {
  my hla::JmolFiles $this = shift;
  my ($ord) = @_;

  my $struct = {};
  foreach my $col ( @{$ord} ) {
    $struct->{$col} = util::Constants::EMPTY_STR;
  }

  return $struct;
}

sub _printRow {
  my hla::JmolFiles $this = shift;
  my ( $fh, $struct, $ord ) = @_;
  my @row = ();
  foreach my $col ( @{$ord} ) { push( @row, $struct->{$col} ); }
  $fh->print( join( util::Constants::TAB, @row ) . util::Constants::NEWLINE );
}

sub _addSpaces {
  my hla::JmolFiles $this = shift;
  my ( $digit, $max_len ) = @_;

  return $digit if ( length($digit) >= $max_len );

  my $len    = $max_len - length($digit);
  my $spaces = &util::Constants::SPACE x $len;
  $digit = $spaces . $digit;

  return $digit;
}

sub _getLeftRight {
  my hla::JmolFiles $this = shift;
  my ($interval) = @_;

  $interval =~ s/ //g;
  $interval =~ s/\[//;
  $interval =~ s/]//;
  my ( $left, $right ) = split( /,/, $interval );

  return ( $left, $right );
}

sub _determineMaxLen {
  my hla::JmolFiles $this = shift;
  my ( $interval, $max_left, $max_right ) = @_;

  return ( $max_left, $max_right ) if ( $interval eq NO_DATA );

  my ( $left, $right ) = $this->_getLeftRight($interval);
  if ( length($left) > $max_left )   { $max_left  = length($left); }
  if ( length($right) > $max_right ) { $max_right = length($right); }

  return ( $max_left, $max_right );
}

sub _getIntervalCoords {
  my hla::JmolFiles $this = shift;
  my ($interval) = @_;

  return ( NULL_VAL, NULL_VAL ) if ( $interval eq NO_DATA );

  my ( $left, $right ) = $this->_getLeftRight($interval);

  return ( $left, $right );
}

sub _generateInterval {
  my hla::JmolFiles $this = shift;
  my ( $interval, $max_left, $max_right ) = @_;

  return $interval if ( $interval eq NO_DATA );

  my ( $left, $right ) = $this->_getIntervalCoords($interval);
  $left  = $this->_addSpaces( $left,  $max_left );
  $right = $this->_addSpaces( $right, $max_right );

  return
      util::Constants::OPEN_BRACKET 
    . $left
    . util::Constants::COMMA_SEPARATOR
    . $right
    . util::Constants::CLOSE_BRACKET;
}

sub _computeCoordinates {
  my hla::JmolFiles $this = shift;
  my ($interval) = @_;

  my ( $hla_left, $hla_right ) =
    $this->_getIntervalCoords( $interval->{&HLA_INTERVAL} );
  my ( $pdb_left, $pdb_right ) =
    $this->_getIntervalCoords( $interval->{&CHAIN_INTERVAL} );
  my $coords = {
    hla_left  => $hla_left,
    hla_right => $hla_right,
    pdb_left  => $pdb_left,
    pdb_right => $pdb_right,
    chain_id  => ( $interval->{&CHAIN_ID} eq NO_DATA )
    ? NULL_VAL
    : $interval->{&CHAIN_ID},
  };
  $interval->{coords} = $coords;
}

sub _computePdbPositions {
  my hla::JmolFiles $this = shift;
  my ($intervals) = @_;

  my @intervs = ();
  foreach my $interval ( @{$intervals} ) {
    my $coords   = $interval->{coords};
    my $chain_id = $interval->{&CHAIN_ID};
    my @row      = ( $interval->{&HLA_INTERVAL} );
    if ( $chain_id eq NO_DATA ) {
      push( @row, NO_DATA, NO_DATA, NO_DATA );
    }
    else {
      push( @row,
        $coords->{pdb_left}
          . util::Constants::HYPHEN
          . $coords->{pdb_right}
          . util::Constants::COLON
          . $chain_id,
        $chain_id, $interval->{&CHAIN_NAME} );
    }
    push( @intervs, join( COL_SEPARATOR, @row ) );
  }

  return join( ROW_SEPARATOR, @intervs );
}

sub _addCoord {
  my hla::JmolFiles $this = shift;
  my ( $coords, $coord ) = @_;

  return $coord . util::Constants::COLON . $coords->{$coord};
}

sub _addChainId {
  my hla::JmolFiles $this = shift;
  my ($coords) = @_;

  my $chain_id = $coords->{chain_id};
  if ( $chain_id ne NULL_VAL ) {
    $chain_id =
      util::Constants::SINGLE_QUOTE . $chain_id . util::Constants::SINGLE_QUOTE;
  }

  return 'chain_id' . util::Constants::COLON . $chain_id;
}

sub _computePdbMap {
  my hla::JmolFiles $this = shift;
  my ($intervals) = @_;

  my $pdb_map = util::Constants::OPEN_BRACKET;
  foreach my $interval ( @{$intervals} ) {
    my $coords = $interval->{coords};
    if ( $pdb_map ne util::Constants::OPEN_BRACKET ) {
      $pdb_map .= util::Constants::COMMA;
    }
    $pdb_map .= '{';
    $pdb_map .=
      $this->_addCoord( $coords, 'hla_left' ) . util::Constants::COMMA;
    $pdb_map .=
      $this->_addCoord( $coords, 'hla_right' ) . util::Constants::COMMA;
    $pdb_map .= $this->_addChainId($coords);
    if ( $coords->{chain_id} ne NULL_VAL ) {
      $pdb_map .= util::Constants::COMMA;
      $pdb_map .=
        $this->_addCoord( $coords, 'pdb_left' ) . util::Constants::COMMA;
      $pdb_map .= $this->_addCoord( $coords, 'pdb_right' );
    }
    $pdb_map .= '}';
  }
  $pdb_map .= util::Constants::CLOSE_BRACKET;

  return $pdb_map;
}

sub _generateFeatureAllele {
  my hla::JmolFiles $this = shift;

  my $pdbs = $this->{pdbs};
  my $ord  = $this->_getOrd(db::MhcTypes::FEATURE_ALLELE_TABLE);
  my $fh   = $this->_openFile( 'writing', 'feature_allele' );
  foreach my $feature_allele ( @{ $this->{feature_alleles} } ) {
    my $pdb_id = $feature_allele->{&PDB_ID};
    $this->{error_mgr}
      ->registerError( ERR_CAT, 3, [$pdb_id], !defined( $pdbs->{$pdb_id} ) );
    my $struct = $this->_getStruct($ord);
    $struct->{allele_id} = $feature_allele->{&ALLELE_ID};
    $struct->{locus_id}  = $feature_allele->{&LOCUS_ID};
    $struct->{pdb_id}    = $pdb_id;
    ###
    ### compute the interval spacing and generate intervals;
    ### also compute coordinates
    ###
    my $max_hla_left    = 1;
    my $max_hla_right   = 1;
    my $max_chain_left  = 1;
    my $max_chain_right = 1;
    foreach my $interval ( @{ $feature_allele->{intervals} } ) {
      my $chain_id = $interval->{&CHAIN_ID};
      if ( util::Constants::EMPTY_LINE($chain_id) ) {
        $interval->{&CHAIN_ID}       = NO_DATA;
        $interval->{&CHAIN_INTERVAL} = NO_DATA;
        $interval->{&CHAIN_NAME}     = NO_DATA;
      }
      $this->_computeCoordinates($interval);
      ( $max_hla_left, $max_hla_right ) =
        $this->_determineMaxLen( $interval->{&HLA_INTERVAL},
        $max_hla_left, $max_hla_right );
      ( $max_chain_left, $max_chain_right ) =
        $this->_determineMaxLen( $interval->{&CHAIN_INTERVAL},
        $max_chain_left, $max_chain_right );
    }
    foreach my $interval ( @{ $feature_allele->{intervals} } ) {
      $interval->{&HLA_INTERVAL} =
        $this->_generateInterval( $interval->{&HLA_INTERVAL},
        $max_hla_left, $max_hla_right );
      $interval->{&CHAIN_INTERVAL} =
        $this->_generateInterval( $interval->{&CHAIN_INTERVAL},
        $max_chain_left, $max_chain_right );
    }
    ###
    ### Now compute PDB_POSITIONS_COL and PDB_MAP_COL,
    ###
    $struct->{pdb_positions} =
      $this->_computePdbPositions( $feature_allele->{intervals} );
    $struct->{pdb_map} = $this->_computePdbMap( $feature_allele->{intervals} );

    $this->_printRow( $fh, $struct, $ord );
  }
  $fh->close;
}

sub _generatePdbColorMap {
  my hla::JmolFiles $this = shift;

  my $property  = $this->{pdb_structure_color_map_prop};
  my $file      = $this->{deploy_env_properties};
  my $color_map = $this->{color_map};
  my $fh        = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ 'writing', $file, 'pdb_structure_color_map' ],
    !$fh->open( $file, '>' )
  );
  $fh->autoflush(util::Constants::TRUE);
  my $value = util::Constants::EMPTY_STR;

  foreach my $component_name ( sort keys %{$color_map} ) {
    if ( $value ne util::Constants::EMPTY_STR ) { $value .= ROW_SEPARATOR; }
    $value .=
      join( COL_SEPARATOR, $component_name, $color_map->{$component_name} );
  }
  $fh->print("$property=$value\n");
  $fh->close;
}

sub _generatePdbStructure {
  my hla::JmolFiles $this = shift;

  ###
  ### Initial Chain Submenu
  ###
  my @submenu = ();
  foreach my $menu_item ( @{ $this->{initial_chain_submenu} } ) {
    push(
      @submenu,
      join( COL_SEPARATOR,
        $menu_item->{&CHAIN_ID} . util::Constants::SEMI_COLON,
        $menu_item->{&DESCRIPTIVE_NAME} )
    );
  }
  ###
  ### Generate PDB Structure
  ###
  my $ord = $this->_getOrd(db::MhcTypes::PDB_STRUCTURE_TABLE);
  my $fh = $this->_openFile( 'writing', 'pdb_structure' );
  foreach my $pdb_structure ( @{ $this->{pdb_structures} } ) {
    my $struct = $this->_getStruct($ord);
    $struct->{pdb_id}      = $pdb_structure->{&PDB_ID};
    $struct->{description} = $pdb_structure->{&DESCRIPTION};
    $struct->{mhc_protein} = $pdb_structure->{&MHC_PROTEIN};
    if ( !util::Constants::EMPTY_LINE( $pdb_structure->{&PEPTIDE} ) ) {
      $struct->{peptide} = $pdb_structure->{&PEPTIDE};
    }
    if ( !util::Constants::EMPTY_LINE( $pdb_structure->{&UNSELECTED_CHAINS} ) )
    {
      $struct->{unselected_chains} = $pdb_structure->{&UNSELECTED_CHAINS};
    }
    ###
    ### Chain Submenu and Selected Chains
    ###
    my @menu            = @submenu;
    my @selected_chains = ();
    foreach my $menu_item ( @{ $pdb_structure->{chains} } ) {
      push(
        @menu,
        join( COL_SEPARATOR,
          util::Constants::COLON
            . $menu_item->{&CHAIN_ID}
            . util::Constants::SEMI_COLON,
          $menu_item->{&DESCRIPTIVE_NAME} )
      );
      push(
        @selected_chains,
        join( COL_SEPARATOR,
          $menu_item->{&CHAIN_ID},
          $menu_item->{&COMPONENT_NAME} )
      );
    }
    $struct->{chain_submenu}   = join( ROW_SEPARATOR, @menu );
    $struct->{selected_chains} = join( ROW_SEPARATOR, @selected_chains );
    ###
    ### Write Row
    ###
    $this->_printRow( $fh, $struct, $ord );
  }
  $fh->close;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$) {
  my hla::JmolFiles $this = shift;
  my ( $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr} = $error_mgr;
  $this->{tools}     = $tools;
  ###
  ### set the properties used by this class
  ###
  $this->{feature_allele}        = $tools->getProperty('featureAllele');
  $this->{deploy_env_properties} = $tools->getProperty('deployEnvProperties');
  $this->{pdb_structure}         = $tools->getProperty('pdbStructure');
  $this->{pdb_structure_color_map} =
    $tools->getProperty('pdbStructureColorMap');
  $this->{pdb_structure_color_map_prop} =
    $tools->getProperty('pdbStructureColorMapProp');

  my $initial_chain_submenu = $tools->getProperty('initialChainSubMenu');
  $this->{initial_chain_submenu} = eval $initial_chain_submenu;
  my $status = $@;
  $this->{error_mgr}->exitProgram(
    ERR_CAT,
    4,
    [ $initial_chain_submenu, $status ],
    ( defined($status) && $status )
      || ref( $this->{initial_chain_submenu} ) ne $tools->serializer->ARRAY_TYPE
  );

  return $this;
}

sub generateFiles {
  my hla::JmolFiles $this = shift;
  ###
  ### Read the files
  ###
  $this->_getFeatureAllele;
  $this->_getPdbStructureColorMap;
  $this->_getPdbStructure;
  ###
  ### Generate feature_allele file
  ###
  $this->_generateFeatureAllele;
  ###
  ### Generate the pdb structure color map file
  ###
  $this->_generatePdbColorMap;
  ###
  ### Generate the pdb_structure file
  ###
  $this->_generatePdbStructure;
}

################################################################################

1;

__END__

=head1 NAME

JmolFiles.pm

=head1 DESCRIPTION

This concrete class defines the mechanism for generating the
Jmol files feature_allele.bcp, pdb_structure.bcp,
and deploy_env.properties (containing the property
mhcallele.chain.color.map).

=head1 METHODS

The following methods are exported by this class.

=head2 B<new hla::JmolFiles(tools, error_mgr)>

This is the constructor for the class.  The B<tools> and B<error_mgr>
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
This method obtains the values of the following properties:

   - deployEnvProperties
   - featureAllele
   - initialChainSubMenu
   - pdbStructure
   - pdbStructureColorMap
   - pdbStructureColorMapProp

=head2 B<generateFiles>

This method uses the properties obtained by the the constructor to
generate the Jmol files.

=cut
