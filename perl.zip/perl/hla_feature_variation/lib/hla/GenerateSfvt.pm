package hla::GenerateSfvt;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::PathSpecifics;
use util::Table;

use db::MhcTypes;

use hla::ErrMsgs;
use hla::HlaTypes;

use fields qw (
  alleles
  change_report
  error_info
  error_mgr
  feat_intervals
  feature
  features
  generator
  info_data
  locus_info
  locus_name
  nomen_ord
  pos_motif_map
  ref_allele
  ref_feature
  ruler
  seq_type
  taxon_id
  tools
  variants
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Standard terms in feature, variant, and deprecated files
###
sub DELETE_POS              { return 'del'; }
sub FEATURE_NUMBER_KEY      { return 100000; }
sub FEATURE_NUMBER_ONE      { return 1; }
sub FEATURE_NUMBER_SUFFIX   { return '_SF'; }
sub INSERT_POS              { return 'ins'; }
sub UNKNOWN_MOTIF           { return 'Unknown Motif Sequence'; }
sub UNKNOWN_VARIANT_KEY     { return 999999; }
sub UNKNOWN_VARIANT_SUFFIX  { return '_Type Unknown'; }
sub VARIANT_NUMBER_KEY      { return 100000; }
sub VARIANT_TYPE_NUM_SUFFIX { return '_VT'; }

sub FEATURE_NUMBER_PREFIX {
  my ($locus_name) = @_;
  return "Hsa_${locus_name}_SF";
}
###
### Search patterns in feature, variant, and deprecated files
###
sub DEL_COORD_PATTERN            { return '^(-?\d+)(' . DELETE_POS . ')$'; }
sub DEL_PATTERN                  { return '^' . DELETE_POS . '$'; }
sub FEATURE_NUMBER_PATTERN       { return FEATURE_NUMBER_SUFFIX . '(\d+)$'; }
sub INTERVAL_COORD_PATTERN       { return '^(-?\d+)\.\.(-?\d+)$'; }
sub SEQUENCE_FEATURE_PATTERN     { return 'Sequence Feature'; }
sub SINGLE_COORD_PATTERN         { return '^(-?\d+)$'; }
sub UNKNOWN_VARIANT_TYPE_PATTERN { return UNKNOWN_VARIANT_SUFFIX . '$'; }
sub VARIANT_TYPE_ALLELE_PATTERN  { return '^(.+)\*([0-9:]+)$'; }
sub VARIANT_TYPE_NUM_PATTERN     { return VARIANT_TYPE_NUM_SUFFIX . '(\d+)$'; }
###
### Standard terms in alignment sequence file
###
sub INSERT_DELETE_POS { return util::Constants::DOT; }
sub SAME_AS_REF       { return util::Constants::HYPHEN; }

sub AA_CODON_LINE_PATTERN    { return '^\s*aa codon\s+'; }
sub ALLELES_SKIPPED_PATTERN  { return '[NS]$'; }
sub ALLELE_STRUCTURE_PATTERN { return '^(\w+)\*([0-9:]+)([A-Z]?)$'; }
sub CDNA_COORD_LINE_PATTERN  { return '^\s*cdna\s+'; }
sub LOCUS_PREFIX_PATTERN     { return '^hla-'; }
sub MARKER_LINE_PATTERN      { return '\|'; }
sub PROT_COORD_LINE_PATTERN  { return '^\s*prot\s+'; }
sub REMOVE_NON_SEQ_PATTERN   { return '[ \|]+'; }
sub SEQ_ALIGN_LINE_PATTERN   { return '^(\S+)\s+.*sequence alignments.*$'; }
sub UNKNOWN_POS_PATTERN      { return '\*| '; }
###
### Error Category
###
sub ERR_CAT { return hla::ErrMsgs::GENERATESFVT_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _numSort { $a <=> $b; }

sub _featureNumber {
  my hla::GenerateSfvt $this = shift;
  my ($feature_number) = @_;

  my $feature_number_pattern = FEATURE_NUMBER_PATTERN;
  $feature_number =~ /$feature_number_pattern/;
  return int($1);
}

sub _featureNumberKey {
  my hla::GenerateSfvt $this = shift;
  my ($feature_number) = @_;

  return $this->_featureNumber($feature_number) + FEATURE_NUMBER_KEY;
}

sub _variantTypeKey {
  my hla::GenerateSfvt $this = shift;
  my ($variant_type_name) = @_;

  my $unknown_variant_type_pattern = UNKNOWN_VARIANT_TYPE_PATTERN;
  my $variant_type_allele_pattern  = VARIANT_TYPE_ALLELE_PATTERN;
  my $variant_type_num_pattern     = VARIANT_TYPE_NUM_PATTERN;

  return 0 if ( !defined($variant_type_name) );
  return $this->_getNomenclatureKey($variant_type_name)
    if ( $variant_type_name =~ /$variant_type_allele_pattern/ );
  if ( $variant_type_name =~ /$variant_type_num_pattern/ ) {
    return int($1) + VARIANT_NUMBER_KEY;
  }
  return UNKNOWN_VARIANT_KEY
    if ( $variant_type_name =~ /$unknown_variant_type_pattern/ );
  return 0;
}

sub _fullKey {
  my hla::GenerateSfvt $this = shift;
  my ( $feature_number, $variant_type_name ) = @_;

  my $fkey = $this->_featureNumberKey($feature_number);
  my $vkey = $this->_variantTypeKey($variant_type_name);
  return join( util::Constants::PIPE, $fkey, $vkey );
}

sub _generateNomenclature {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  my $allele_structure_pattern = ALLELE_STRUCTURE_PATTERN;
  $allele =~ /$allele_structure_pattern/;
  my $name   = $1;
  my $comps  = $2;
  my $suffix = $3;

  my $nomen = {
    allele                               => $allele,
    name                                 => $name,
    suffix                               => $suffix,
    max_index                            => -1,
    max_comp                             => undef,
    &db::MhcTypes::ALLELE_GROUP_COL      => undef,
    &db::MhcTypes::HLA_PROTEIN_COL       => undef,
    &db::MhcTypes::CODING_REGION_COL     => undef,
    &db::MhcTypes::NON_CODING_REGION_COL => undef,
  };

  my @comps = split( /:/, $comps );
  $nomen->{max_index} = $#comps;
  $nomen->{max_comp}  = $this->{nomen_ord}->[$#comps];
  foreach my $index ( 0 .. $#comps ) {
    my $name = $this->{nomen_ord}->[$index];
    my $comp = $comps[$index];
    $nomen->{$name} = $comp;
  }
  return $nomen;
}

sub _getNomenclatureKey {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  my $nomen = $this->_generateNomenclature($allele);
  my @comps = ();
  foreach my $col ( @{ $this->{nomen_ord} } ) {
    my $comp = $nomen->{$col};
    $comp =~ s/^0+//;
    my $len = length("$comp");
    push( @comps, '0' x ( 4 - $len ) . $comp );
  }
  return join( util::Constants::COLON, @comps );
}

sub _getNomenIndex {
  my hla::GenerateSfvt $this = shift;
  my ($comp) = @_;

  foreach my $index ( 0 .. $#{ $this->{nomen_ord} } ) {
    return $index if ( $this->{nomen_ord}->[$index] eq $comp );
  }
  return -1;
}

sub _getAlleleGroup {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  my $nomen    = $this->_generateNomenclature($allele);
  my $max_comp = undef;
  if ( $this->{seq_type} eq db::MhcTypes::AA_SEQ ) {
    $max_comp = db::MhcTypes::HLA_PROTEIN_COL;
  }
  elsif ( $this->{seq_type} eq db::MhcTypes::CDS_SEQ ) {
    $max_comp = db::MhcTypes::CODING_REGION_COL;
  }
  else {
    return undef;
  }
  my $comp_index = $this->_getNomenIndex($max_comp);
  my @comps      = ();
  foreach my $index ( 0 .. $comp_index ) {
    my $comp = $this->{nomen_ord}->[$index];
    last if ( !defined( $nomen->{$comp} ) );
    push( @comps, $nomen->{$comp} );
  }
  my $allele_group = join( '*', $nomen->{name}, join( ':', @comps ) );
  return $allele_group;
}

sub _makeAlleleSearchable {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  $allele =~ s/\*/\\\*/;
  return $allele;
}

sub _getSeq {
  my hla::GenerateSfvt $this = shift;
  my ( $lines, $prefixLens ) = @_;

  my $remove_non_seq_pattern = REMOVE_NON_SEQ_PATTERN;
  my $sequence               = util::Constants::EMPTY_STR;
  foreach my $index ( 0 .. $#{$lines} ) {
    my $line = $lines->[$index];
    my $seq = substr( $line, $prefixLens->[$index] );
    $sequence .= $seq;
  }
  $sequence =~ s/$remove_non_seq_pattern//g;
  return $sequence;
}

sub _readSequenceInfo {
  my hla::GenerateSfvt $this = shift;
  ###
  ### Get the data
  ###
  $this->{alleles}    = {};
  $this->{ref_allele} = undef;

  my $locus_info = $this->{locus_info};
  my $locus_name = $this->{locus_name};

  my $aa_codon_line_pattern   = AA_CODON_LINE_PATTERN;
  my $alleles_skipped_pattern = ALLELES_SKIPPED_PATTERN;
  my $cdna_coord_line_pattern = CDNA_COORD_LINE_PATTERN;
  my $locus_prefix_pattern    = LOCUS_PREFIX_PATTERN;
  my $marker_line_pattern     = MARKER_LINE_PATTERN;
  my $prot_coord_line_pattern = PROT_COORD_LINE_PATTERN;
  my $seq_align_line_pattern  = SEQ_ALIGN_LINE_PATTERN;

  my $alleleLinePattern      = undef;
  my $alleles                = {};
  my $codonLines             = [];
  my $coordLines             = [];
  my $foundLine              = util::Constants::FALSE;
  my $foundLocus             = util::Constants::FALSE;
  my $lineLengths            = [];
  my $markerLines            = [];
  my $prefixLengths          = [];
  my $searchRefAllelePattern = undef;
  my $refAllelePattern       = undef;

  if (
    !util::Constants::EMPTY_LINE(
      $locus_info->{&hla::HlaTypes::REF_ALLELE_COL}
    )
    )
  {
    my $ref_allele = $this->_makeAlleleSearchable(
      lc( $locus_info->{&hla::HlaTypes::REF_ALLELE_COL} ) );
    $refAllelePattern = '^\s*(' . $ref_allele . ')\s+';
  }

  my $fh       = new FileHandle;
  my $seq_file = getPath( $locus_info->{&hla::HlaTypes::FILE_NAME_COL} );
  $this->{error_mgr}->hardDieOnError(
    ERR_CAT, 1,
    [ $locus_name, $seq_file, $this->{seq_type} ],
    !$fh->open( $seq_file, '<' )
  );

  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    ###
    ### Find the locus
    ###
    if ( !$foundLocus && $line =~ /$seq_align_line_pattern/i ) {
      my $locus = $1;
      $this->{error_mgr}->hardDieOnError(
        ERR_CAT,
        2,
        [ $locus_name, $locus_info->{&hla::HlaTypes::TEST_LOCUS_COL}, $locus, ],
        $locus ne $locus_info->{&hla::HlaTypes::TEST_LOCUS_COL}
      );
      ###
      ### Must use locus_name since some
      ### loci are contained in the same
      ### file
      ###
      $locus = lc( $this->{locus_name} );
      $locus =~ s/$locus_prefix_pattern//i;
      $alleleLinePattern = '^\s*(' . $locus . '\S+)\s+';
      $foundLocus        = util::Constants::TRUE;
      next;
    }
    ###
    ### Sort lines
    ###
    if (
      (
           $this->{seq_type} eq db::MhcTypes::AA_SEQ
        && $line =~ /$prot_coord_line_pattern/i
      )
      || ( $this->{seq_type} eq db::MhcTypes::CDS_SEQ
        && $line =~ /$cdna_coord_line_pattern/i )
      )
    {
      push( @{$coordLines}, $line );
      $foundLine = util::Constants::TRUE;
    }
    elsif ( $this->{seq_type} eq db::MhcTypes::CDS_SEQ
      && $line =~ /$aa_codon_line_pattern/i )
    {
      push( @{$codonLines}, $line );
      $foundLine = util::Constants::TRUE;
    }
    elsif ( $foundLine
      && defined($refAllelePattern)
      && $line =~ /$refAllelePattern/i )
    {
      my $allele = $1;
      if ( !defined( $alleles->{"$allele"} ) ) {
        $alleles->{"$allele"} = [];
      }
      push( @{ $alleles->{"$allele"} }, $line );
      if ( !defined( $this->{ref_allele} ) ) {
        $this->{ref_allele} = $allele;
        my $refAllele = $this->_makeAlleleSearchable( $this->{ref_allele} );
        $searchRefAllelePattern = '^(\s*' . $refAllele . '\s+)(.+)$';
      }
      push( @{$lineLengths}, length($line) );
      $line =~ /$searchRefAllelePattern/;
      my $prefix = $1;
      push( @{$prefixLengths}, length($prefix) );
    }
    elsif ( $foundLine && $line =~ /$alleleLinePattern/i ) {
      my $allele = $1;
      if ( !defined( $alleles->{"$allele"} ) ) {
        $alleles->{"$allele"} = [];
      }
      push( @{ $alleles->{"$allele"} }, $line );
      ###
      ### Process reference allele
      ###
      if ( !defined( $this->{ref_allele} ) ) {
        $this->{ref_allele} = $allele;
        my $refAllele = $this->_makeAlleleSearchable( $this->{ref_allele} );
        $searchRefAllelePattern = '^(\s*' . $refAllele . '\s+)(.+)$';
      }
      if ( defined( $this->{ref_allele} ) && $allele eq $this->{ref_allele} ) {
        push( @{$lineLengths}, length($line) );
        $line =~ /$searchRefAllelePattern/;
        my $prefix = $1;
        push( @{$prefixLengths}, length($prefix) );
      }
    }
    elsif ( $line =~ /$marker_line_pattern/i ) {
      push( @{$markerLines}, $line );
      $foundLine = util::Constants::TRUE;
    }
  }
  $fh->close;
  ###
  ### Generate the sequences for the given alleles
  ###
  foreach my $allele ( keys %{$alleles} ) {
    ###
    ### Alleles are skipped if not part of variant generation
    ###
    next if ( $allele =~ /$alleles_skipped_pattern/ );

    $this->{alleles}->{"$allele"} = {
      allele_group => $this->_getAlleleGroup($allele),
      seq          => $this->_getSeq( $alleles->{"$allele"}, $prefixLengths ),
    };
  }
}

sub _generateRuler {
  my hla::GenerateSfvt $this = shift;

  $this->{ruler} = {};

  my $seq   = $this->{alleles}->{ $this->{ref_allele} }->{seq};
  my $coord = $this->{locus_info}->{&hla::HlaTypes::MIN_COORD_COL};
  foreach my $sindex ( 0 .. ( length($seq) - 1 ) ) {
    my $entity = substr( $seq, $sindex, 1 );
    next if ( $entity eq INSERT_DELETE_POS );
    $this->{ruler}->{"$coord"} = $sindex;
    $coord++;
    $coord++ if ( $coord == 0 );
  }
}

sub _generateVariantsInfo {
  my hla::GenerateSfvt $this = shift;
  my ( $variants, $deprecated ) = @_;

  my $variant_type_num_pattern     = VARIANT_TYPE_NUM_PATTERN;
  my $variant_type_allele_pattern  = VARIANT_TYPE_ALLELE_PATTERN;
  my $unknown_variant_type_pattern = UNKNOWN_VARIANT_TYPE_PATTERN;
  my $sequence_feature_pattern     = SEQUENCE_FEATURE_PATTERN;
  ###
  ### Initialize variant and deprecated
  ### information from previous version
  ###
  $this->{variants} = {
    info                                    => {},
    deprecated                              => {},
    fvariants                               => {},
    allele_group_map                        => {},
    variant_types                           => {},
    &hla::HlaTypes::VARIANT_FILE            => {},
    &hla::HlaTypes::VARIANT_DEPRECATED_FILE => {}
  };
  my $deprecated_data = $this->{variants}->{deprecated};
  my $variants_info   = $this->{variants}->{info};
  ###
  ### Determine the deprecated data and
  ### the maximum variant type number
  ### for each feature numbers with deprecation
  ###
  my $deprecated_maxs = {};
  if ( defined($deprecated) ) {
    foreach my $entity ( @{$deprecated} ) {
      next
        if (
        util::Constants::EMPTY_LINE(
          $entity->{&db::MhcTypes::FEATURE_NUMBER_COL}
        )
        || $entity->{&db::MhcTypes::FEATURE_NUMBER_COL} =~
        /$sequence_feature_pattern/
        );
      my $feature_number = $entity->{&db::MhcTypes::FEATURE_NUMBER_COL};
      if ( !defined( $deprecated_data->{"$feature_number"} ) ) {
        $deprecated_data->{"$feature_number"} = {};
      }
      my $deprecated_variants = $deprecated_data->{"$feature_number"};
      my $variant_type_name   = $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};
      my $motif               = $entity->{&db::MhcTypes::MOTIF_COL};
      my $variant_num         = undef;
      if ( $variant_type_name =~ /$variant_type_allele_pattern/ ) {
        $motif = $variant_type_name;
      }
      elsif ( $variant_type_name =~ /$variant_type_num_pattern/ ) {
        $variant_num = int($1);
        if ( !defined( $deprecated_maxs->{"$feature_number"} ) ) {
          $deprecated_maxs->{"$feature_number"} = 0;
        }
        if ( $deprecated_maxs->{"$feature_number"} < $variant_num ) {
          $deprecated_maxs->{"$feature_number"} = $variant_num;
        }
      }
      elsif ( $variant_type_name =~ /$unknown_variant_type_pattern/ ) {
        $motif = UNKNOWN_MOTIF;
      }
      $deprecated_variants->{"$motif"} = {
        entity       => $entity,
        motif        => $motif,
        variant_num  => $variant_num,
        variant_type => $variant_type_name,
      };
    }
  }
  ###
  ### Determine the current set of feature variants for the locus
  ###
  return if ( !defined($variants) );
  foreach my $entity ( @{$variants} ) {
    next
      if (
      util::Constants::EMPTY_LINE(
        $entity->{&db::MhcTypes::FEATURE_NUMBER_COL}
      )
      || $entity->{&db::MhcTypes::FEATURE_NUMBER_COL} =~
      /$sequence_feature_pattern/
      );
    my $feature_number = $entity->{&db::MhcTypes::FEATURE_NUMBER_COL};
    if ( !defined( $variants_info->{$feature_number} ) ) {
      $variants_info->{$feature_number} = {
        max_num => defined( $deprecated_maxs->{"$feature_number"} )
        ? $deprecated_maxs->{"$feature_number"}
        : 0,
        allele_group_map => {},
        data             => {},
      };
    }
    my $fvariants        = $variants_info->{$feature_number};
    my $allele_group_map = $fvariants->{allele_group_map};

    my $variant_type_name = $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};
    my $motif             = $entity->{&db::MhcTypes::MOTIF_COL};
    my @allele_groups =
      split( /, /, $entity->{&db::MhcTypes::ALLELE_GROUP_COL} );

    my $variant_num = undef;
    if ( $variant_type_name =~ /$variant_type_allele_pattern/ ) {
      $motif = $variant_type_name;
    }
    elsif ( $variant_type_name =~ /$variant_type_num_pattern/ ) {
      $variant_num = int($1);
      if ( $fvariants->{max_num} < $variant_num ) {
        $fvariants->{max_num} = $variant_num;
      }
    }
    elsif ( $variant_type_name =~ /$unknown_variant_type_pattern/ ) {
      $motif = UNKNOWN_MOTIF;
    }
    my $allele_groups = {};
    foreach my $allele_group (@allele_groups) {
      $allele_groups->{"$allele_group"}    = util::Constants::EMPTY_STR;
      $allele_group_map->{"$allele_group"} = {
        variant => $motif,
        allele  => $allele_group,
      };
    }

    $fvariants->{data}->{"$motif"} = {
      allele_groups => $allele_groups,
      entity        => $entity,
      motif         => $motif,
      variant_num   => $variant_num,
      variant_type  => $variant_type_name,
    };
  }
}

sub _addFeatureInfo {
  my hla::GenerateSfvt $this = shift;
  my ( $feature, $type ) = @_;

  return
    if ( !defined($type)
    || $type eq hla::HlaTypes::PREV_SEQUENCE_FEATURE_TYPE
    || $type eq hla::HlaTypes::KEEP_DEPRECATED_FEATURE_TYPE );

  my $locus_name = $this->{locus_name};

  my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $feature_coords = $feature->{&hla::HlaTypes::LOCATION_COL};
  ###
  ### Add datum
  ###
  my $key = $this->_featureNumberKey($feature_number);
  $this->{info_data}->{&hla::HlaTypes::FEATURE_DISPOSITION_INFO}->{$key} =
    [ $locus_name, $feature_number, $feature_coords, $type, ];
}

sub _generateFeatureInfo {
  my hla::GenerateSfvt $this = shift;
  my ( $entities, $deprecated ) = @_;

  $this->{features} = {
    max_num                                 => 0,
    deprecated                              => {},
    changed                                 => {},
    curr                                    => {},
    singletons                              => {},
    &hla::HlaTypes::FEATURE_DEPRECATED_FILE => {},
    &hla::HlaTypes::FEATURE_FILE            => {},
  };

  my $sequence_feature_pattern = SEQUENCE_FEATURE_PATTERN;
  my $single_coord_pattern     = SINGLE_COORD_PATTERN;

  my $alleles    = $this->{alleles};
  my $features   = $this->{features};
  my $locus_name = $this->{locus_name};
  my $ref_allele = $this->{ref_allele};
  my $ruler      = $this->{ruler};

  my $ref_seq = $alleles->{$ref_allele}->{seq};
  ###
  ### Determine all possible singleton features
  ###
  foreach my $singleton_coord ( keys %{$ruler} ) {
    $features->{singletons}->{$singleton_coord} = {
      amino_acid     => substr( $ref_seq, $ruler->{$singleton_coord}, 1 ),
      feature_number => undef,
      feature        => undef,
      change_type    => undef,
    };
  }
  ###
  ### Add the current features
  ###
  foreach my $feature ( @{$entities} ) {
    my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
    my $feature_coords = $feature->{&hla::HlaTypes::LOCATION_COL};
    next
      if ( util::Constants::EMPTY_LINE($feature_number)
      || $feature_number =~ /$sequence_feature_pattern/ );
    ###
    ### Add the feature
    ###
    my $key = $this->_featureNumberKey($feature_number);
    $features->{curr}->{$key} = $feature;
    ###
    ### Get max feature number
    ###
    my $feat_num = $this->_featureNumber($feature_number);
    if ( $features->{max_num} < $feat_num ) {
      $features->{max_num} = $feat_num;
    }
    ###
    ### Determine current singleton features
    ###
    next if ( $feature_coords !~ /$single_coord_pattern/ );
    my $singleton_coord = int($1);
    my $singleton       = $features->{singletons}->{$singleton_coord};
    $singleton->{feature} = $feature;
    $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} = $feature_number;
    $singleton->{change_type} = hla::HlaTypes::PREV_SEQUENCE_FEATURE_TYPE;
  }
  ###
  ### Add deprecated features
  ###
  return if ( !defined($deprecated) );
  foreach my $feature ( @{$deprecated} ) {
    my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
    my $feature_coords = $feature->{&hla::HlaTypes::LOCATION_COL};
    next
      if ( util::Constants::EMPTY_LINE($feature_number)
      || $feature_number =~ /$sequence_feature_pattern/ );
    $features->{deprecated}->{$feature_number} = { %{$feature} };
    ###
    ### Get max feature number
    ###
    my $feat_num = $this->_featureNumber($feature_number);
    if ( $features->{max_num} < $feat_num ) {
      $features->{max_num} = $feat_num;
    }
    ###
    ### Determine deprecated singleton features
    ###
    next if ( $feature_coords !~ /$single_coord_pattern/ );
    my $singleton_coord = int($1);
    my $singleton       = $features->{singletons}->{$singleton_coord};
    $singleton->{feature} = $feature;
    $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} = $feature_number;
    $singleton->{change_type} = hla::HlaTypes::KEEP_DEPRECATED_FEATURE_TYPE;
  }
}

sub _determineSingletonTypesAndNames {
  my hla::GenerateSfvt $this = shift;
  my ($singleton_coord) = @_;

  my $features   = $this->{features};
  my $locus_name = $this->{locus_name};

  my $del_pattern          = DEL_PATTERN;
  my $single_coord_pattern = SINGLE_COORD_PATTERN;
  my $singleton_feature_name =
    hla::HlaTypes::SINGLETON_FEATURE_NAME($locus_name);
  my $singleton_feature_type     = hla::HlaTypes::SINGLETON_FEATURE_TYPE;
  my $singleton_feature_type_map = hla::HlaTypes::SINGLETON_FEATURE_TYPE_MAP;
  my $singleton_feature_name_infix =
    hla::HlaTypes::SINGLETON_FEATURE_NAME_INFIX;
  ###
  ### Determine Non-Singleton Sequence Features
  ### containing the coordinate.
  ###
  my $in_features = [];
  foreach my $key ( keys %{ $features->{curr} } ) {
    my $feature        = $features->{curr}->{"$key"};
    my $intervals      = $this->_generateFeatureIntervals($feature);
    my $first_interval = $intervals->[0];
    ###
    ### Skip del coordinate and singleton sequence features
    ###
    next
      if (
      (
           $first_interval->[0] =~ /$single_coord_pattern/
        && $first_interval->[1] =~ /$del_pattern/
      )
      || ( scalar @{$intervals} == 1
        && $first_interval->[0] == $first_interval->[1] )
      );
    my $in_feature = util::Constants::FALSE;
    foreach my $interval ( @{$intervals} ) {
      next if ( $interval->[1] < $singleton_coord );
      last if ( $singleton_coord < $interval->[0] );
      if ( $interval->[0] <= $singleton_coord
        && $singleton_coord <= $interval->[1] )
      {
        $in_feature = util::Constants::TRUE;
        last;
      }
    }
    next if ( !$in_feature );
    push( @{$in_features}, $feature );
  }
  ###
  ### Determine the feature types and
  ### names for the singleton feature
  ###
  my $ftypes = {};
  my $fnames = {};
  foreach my $feature ( @{$in_features} ) {
    ###
    ### Process feature names
    ###
    my @feat_names =
      split( /; /, $feature->{&db::MhcTypes::FEATURE_NAMES_COL} );
    foreach my $feat_name (@feat_names) {
      $feat_name .= $singleton_feature_name_infix;
      $fnames->{"$feat_name"} = util::Constants::EMPTY_STR;
    }
    ###
    ### Process feature types
    ###
    my @feat_types =
      split( /; /, $feature->{&db::MhcTypes::FEATURE_TYPES_COL} );
    foreach my $feat_type (@feat_types) {
      my $sftypes = $singleton_feature_type_map->{"$feat_type"};
      next
        if ( !defined($sftypes) );
      if ( ref($sftypes) eq $this->{tools}->serializer->ARRAY_TYPE ) {
        foreach my $sftype ( @{$sftypes} ) {
          $ftypes->{"$sftype"} = util::Constants::EMPTY_STR;
        }
      }
      else {
        $ftypes->{"$sftypes"} = util::Constants::EMPTY_STR;
      }
    }
  }
  my $feature_types = [ sort keys %{$ftypes} ];
  unshift( @{$feature_types}, $singleton_feature_type );
  my $feature_names = [ sort keys %{$fnames} ];
  unshift( @{$feature_names}, $singleton_feature_name );
  foreach my $index ( 0 .. $#{$feature_names} ) {
    $feature_names->[$index] .= $singleton_coord;
  }

  return ( $feature_types, $feature_names );
}

sub _determineSingletonFeatures {
  my hla::GenerateSfvt $this = shift;

  $this->{feature} = {};

  my $locus_name = $this->{locus_name};

  my $feature_file_ord      = hla::HlaTypes::FEATURE_FILE_ORD;
  my $feature_number_prefix = FEATURE_NUMBER_PREFIX($locus_name);
  my $unknown_pos_pattern   = UNKNOWN_POS_PATTERN;

  my $alleles             = $this->{alleles};
  my $features            = $this->{features};
  my $locus_info          = $this->{locus_info};
  my $ref_allele          = $this->{ref_allele};
  my $ruler               = $this->{ruler};
  my $singletons          = $features->{singletons};
  my $deprecated          = $features->{deprecated};
  my $variants_info       = $this->{variants}->{info};
  my $variants_deprecated = $this->{variants}->{deprecated};

  my $ref_seq = $alleles->{$ref_allele}->{seq};

  foreach my $col ( @{$feature_file_ord} ) {
    $this->{feature}->{"$col"} = util::Constants::EMPTY_STR;
  }
  ###
  ### Compute new and undeprecated singleton features
  ###
  foreach
    my $singleton_coord ( sort hla::GenerateSfvt::_numSort keys %{$singletons} )
  {
    my $sindex    = $ruler->{$singleton_coord};
    my $singleton = $singletons->{$singleton_coord};
    next
      if (
      defined( $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} )
      && !defined(
        $deprecated->{ $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} }
      )
      );
    ###
    ### Potentially, a new sequence feature...
    ###
    my $amino_acids = {};
    foreach my $allele ( sort keys %{$alleles} ) {
      my $seq = $alleles->{"$allele"}->{seq};
      next
        if (
        $allele eq $ref_allele
        && !util::Constants::EMPTY_LINE(
          $locus_info->{&hla::HlaTypes::REF_ALLELE_COL}
        )
        );
      my $amino_acid = substr( $seq, $sindex, 1 );
      next if ( util::Constants::EMPTY_LINE($amino_acid) );
      if ( $amino_acid eq SAME_AS_REF ) {
        $amino_acid = substr( $ref_seq, $sindex, 1 );
      }
      next if ( $amino_acid =~ /$unknown_pos_pattern/ );
      $amino_acids->{$amino_acid} = util::Constants::EMPTY_STR;
    }
    my @aas = sort keys %{$amino_acids};
    next if ( scalar @aas == 1 );
    ###
    ### Determine type of singleton feature
    ###
    my $feature_number = undef;
    my $feature        = undef;
    my $feature_type   = undef;
    if (
      defined( $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} )
      && defined(
        $deprecated->{ $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} }
      )
      )
    {
      ###
      ### Undeprecating previously deprecated singleton feature
      ###
      $feature_type   = hla::HlaTypes::UNDEPRECATED_SEQUENCE_FEATURE_TYPE;
      $feature_number = $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL};
      $feature        = $deprecated->{$feature_number};

      $variants_info->{"$feature_number"} = {
        max_num          => 0,
        allele_group_map => {},
        data             => {},
      };
      ###
      ### Determine max_num for variants of
      ### undeprecated sequence feature
      ###
      my $variant_info        = $variants_info->{"$feature_number"};
      my $deprecated_variants = $variants_deprecated->{"$feature_number"};
      foreach my $motif ( keys %{$deprecated_variants} ) {
        my $deprecated_variant = $deprecated_variants->{"$motif"};
        my $variant_num        = $deprecated_variant->{variant_num};
        next if ( !defined($variant_num) );
        if ( $variant_num > $variant_info->{max_num} ) {
          $variant_info->{max_num} = $variant_num;
        }
      }
    }
    elsif ( !defined( $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} ) ) {
      ###
      ### New singleton feature found...
      ###
      $feature_type = hla::HlaTypes::NEW_SEQUENCE_FEATURE_TYPE;
      $features->{max_num}++;
      $feature_number = $feature_number_prefix . $features->{max_num};
      $feature        = $this->_createEntity($feature_file_ord);
      $singleton->{&db::MhcTypes::FEATURE_NUMBER_COL} = $feature_number;
      $singleton->{feature}                           = $feature;
      $feature->{&db::MhcTypes::FEATURE_NUMBER_COL}   = $feature_number;
      $feature->{&hla::HlaTypes::LOCATION_COL}        = $singleton_coord;
      my ( $feature_types, $feature_names ) =
        $this->_determineSingletonTypesAndNames($singleton_coord);
      $feature->{&db::MhcTypes::FEATURE_NAMES_COL} = join(
        util::Constants::SEMI_COLON . util::Constants::SPACE,
        @{$feature_names}
      );
      $feature->{&db::MhcTypes::FEATURE_TYPES_COL} = join(
        util::Constants::SEMI_COLON . util::Constants::SPACE,
        @{$feature_types}
      );
      ###
      ### Set of variant type generation
      ###
      $variants_info->{$feature_number} = {
        max_num          => 0,
        allele_group_map => {},
        data             => {},
      };
    }
    ###
    ### Save the single feature information
    ###
    my $key = $this->_featureNumberKey($feature_number);
    $this->_addFeatureInfo( $feature, $feature_type );
    $singleton->{change_type}      = $feature_type;
    $features->{curr}->{"$key"}    = $feature;
    $features->{changed}->{"$key"} = [
      $feature_number,
      $feature->{&hla::HlaTypes::LOCATION_COL},
      "(" . join( util::Constants::COMMA_SEPARATOR, @aas ) . ")",
      $feature_type
    ];
  }
}

sub _makeVariant {
  my hla::GenerateSfvt $this = shift;

  my $feat = $this->{ref_feature};
  $feat =~ s/[acdefghiklmnpqrstvwy]/-/ig;
  return $feat;
}

sub _setPosMotifMap {
  my hla::GenerateSfvt $this = shift;

  $this->{pos_motif_map} = [];
  my $pos_motif_map = $this->{pos_motif_map};

  my $single_coord_pattern = SINGLE_COORD_PATTERN;
  my $del_pattern          = DEL_PATTERN;

  my $ref_feat  = $this->{ref_feature};
  my $intervals = $this->{feat_intervals};
  ###
  ### Setup del feature
  ###
  if ( scalar @{$intervals} == 1
    && $intervals->[0]->[0] =~ /$single_coord_pattern/
    && $intervals->[0]->[1] =~ /$del_pattern/ )
  {
    my $del_struct = {
      del   => util::Constants::TRUE,
      coord => $intervals->[0]->[0],
      range => [ 0, length($ref_feat) - 1 ],
    };
    push( @{$pos_motif_map}, $del_struct );
    return;
  }
  ###
  ### Get the positions from the coordinates
  ###
  my @positions = ();
  foreach my $interval ( @{$intervals} ) {
    foreach my $pos ( $interval->[0] .. $interval->[1] ) {
      next if ( $pos == 0 );    ### No such thing as position zero! ###
      push( @positions, $pos );
    }
  }
  ###
  ### Now make an index list from reference feature
  ###
  my $index      = 0;
  my $start_del  = util::Constants::FALSE;
  my $del_struct = undef;
  foreach my $rindex ( 0 .. ( length($ref_feat) - 1 ) ) {
    my $char = substr( $ref_feat, $rindex, 1 );
    my $struct = undef;
    if ( $char eq INSERT_DELETE_POS ) {
      if ( !$start_del ) {
        $start_del = util::Constants::TRUE;
        ###
        ### Assume a delete position does
        ### NOT start reference feature!
        ###
        $del_struct = {
          del   => util::Constants::TRUE,
          coord => $positions[ $index - 1 ],
          range => [ $rindex, $rindex ],
        };
      }
      $del_struct->{range}->[1] = $rindex;
      next;
    }
    else {
      if ($start_del) {
        $start_del = util::Constants::FALSE;
        push( @{$pos_motif_map}, $del_struct );
      }
      $struct = {
        del   => util::Constants::FALSE,
        coord => $positions[$index],
        range => [ $rindex, $rindex ],
      };
      $index++;
    }
    push( @{$pos_motif_map}, $struct );
  }
  push( @{$pos_motif_map}, $del_struct ) if ($start_del);
}

sub _intSort { $a->[0] <=> $b->[0] or $b->[1] <=> $a->[1]; }

sub _generateFeatureIntervals {
  my hla::GenerateSfvt $this = shift;
  my ($feature) = @_;

  my $del_coord_pattern      = DEL_COORD_PATTERN;
  my $interval_coord_pattern = INTERVAL_COORD_PATTERN;
  my $single_coord_pattern   = SINGLE_COORD_PATTERN;

  my $locus_name     = $this->{locus_name};
  my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $intervs        = $feature->{&hla::HlaTypes::LOCATION_COL};

  my $intervals = [];
  $intervs =~ s/ +//g;
  if ( $intervs =~ /$del_coord_pattern/ ) {
    my $interval = [ $1, $2 ];
    push( @{$intervals}, $interval );
    return $intervals;
  }

  my @comps = split( /,/, $intervs );
  foreach my $comp (@comps) {
    my $left  = undef;
    my $right = undef;
    if ( $comp =~ /$single_coord_pattern/ ) {
      $left  = $1;
      $right = $left;
    }
    elsif ( $comp =~ /$interval_coord_pattern/ ) {
      $left  = $1;
      $right = $2;
    }
    else {
      $this->{error_info}->addErrorInfo( hla::HlaTypes::COORDINATE_ERROR,
        util::Constants::TRUE, 2,
        [ $locus_name, $feature_number, $intervs, $comp, 'unknown interval' ] );
    }
    if ( $left > $right ) {
      $this->{error_info}->addErrorInfo(
        hla::HlaTypes::COORDINATE_ERROR,
        util::Constants::TRUE,
        2,
        [
          $locus_name, $feature_number, $intervs, $comp, 'end-points switched'
        ]
      );
      my $tmp = $right;
      $left  = $right;
      $right = $left;
    }
    my $interval = [ $left, $right ];
    push( @{$intervals}, $interval );
  }
  @{$intervals} = sort hla::GenerateSfvt::_intSort @{$intervals};
  ###
  ### Check for overlapping intervals
  ###
  my $prev_interv   = undef;
  my $max           = undef;
  my $new_intervals = [];
  foreach my $interval ( @{$intervals} ) {
    if ( !defined($prev_interv) ) {
      $prev_interv = $interval;
      $max         = $interval->[1];
      push( @{$new_intervals}, $interval );
      next;
    }
    $this->{error_info}->addErrorInfo(
      hla::HlaTypes::COORDINATE_ERROR,
      $interval->[0] <= $max,
      2,
      [
        $locus_name,
        $feature_number,
        $intervs,
        '(' . join( util::Constants::COMMA_SEPARATOR, @{$interval} ) . ')',
        'interval overlaps previous interval = ' . '('
          . join( util::Constants::COMMA_SEPARATOR, @{$prev_interv} ) . ')'
      ]
    );
    if ( $interval->[0] > $max ) {
      push( @{$new_intervals}, $interval );
      $max         = $interval->[1];
      $prev_interv = $interval;
    }
  }
  return $new_intervals;
}

sub _getFeature {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  my $single_coord_pattern = SINGLE_COORD_PATTERN;
  my $del_pattern          = DEL_PATTERN;

  my $intervals = $this->{feat_intervals};
  my $ruler     = $this->{ruler};
  my $seq       = $this->{alleles}->{"$allele"}->{seq};

  my $feature = util::Constants::EMPTY_STR;
  if ( scalar @{$intervals} == 1
    && $intervals->[0]->[0] =~ /$single_coord_pattern/
    && $intervals->[0]->[1] =~ /$del_pattern/ )
  {
    my $coord = $intervals->[0]->[0];
    my $left  = $ruler->{$coord};
    $left++;
    my $right = $ruler->{ ( $coord + 1 ) };
    $right--;
    my $len = $right - $left + 1;
    my $subseq = substr( $seq, $left, $len );
    $feature .= $subseq;
    return $feature;
  }
  foreach my $interval ( @{$intervals} ) {
    my $left   = $ruler->{ $interval->[0] };
    my $right  = $ruler->{ $interval->[1] };
    my $len    = $right - $left + 1;
    my $subseq = substr( $seq, $left, $len );
    $feature .= $subseq;
  }
  return $feature;
}

sub _generateFeature {
  my hla::GenerateSfvt $this = shift;
  my ($feat) = @_;

  my $ref_seq = $this->{ref_feature};
  my $ffeat   = util::Constants::EMPTY_STR;
  foreach my $index ( 0 .. ( length($feat) - 1 ) ) {
    my $rentity = substr( $ref_seq, $index, 1 );
    my $entity  = substr( $feat,    $index, 1 );
    if ( $entity eq SAME_AS_REF ) {
      $ffeat .= $rentity;
    }
    else {
      $ffeat .= $entity;
    }
  }
  return $ffeat;
}

sub _addVariant {
  my hla::GenerateSfvt $this = shift;
  my ( $feat, $allele ) = @_;

  my $feature    = $this->{feature};
  my $locus_name = $this->{locus_name};
  my $variants   = $this->{variants};

  my $allele_group_map = $variants->{allele_group_map};
  my $alleles          = $this->{alleles};
  my $feature_number   = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $variant_types    = $variants->{variant_types};

  if ( !defined( $variant_types->{"$feat"} ) ) {
    $variant_types->{"$feat"} = {};
  }
  return if ( util::Constants::EMPTY_LINE($allele) );

  my $feat_variants = $variant_types->{"$feat"};
  my $allele_group  = $alleles->{"$allele"}->{allele_group};
  $feat_variants->{"$allele_group"} = util::Constants::EMPTY_STR;

  return if ( $feat eq UNKNOWN_MOTIF );
  ###
  ### Maintain the allele group map for those
  ### allele_groups with a known variant only
  ###
  if ( !defined( $allele_group_map->{"$allele_group"} ) ) {
    $allele_group_map->{"$allele_group"} = {
      variant => $feat,
      allele  => $allele,
    };
    return;
  }
  $this->{error_info}->addErrorInfo(
    hla::HlaTypes::VARIANT_ERROR,
    $feat ne $allele_group_map->{"$allele_group"}->{variant},
    3,
    [
      $locus_name,
      $feature_number,
      $allele_group,
      $allele_group_map->{"$allele_group"}->{allele},
      $allele_group_map->{"$allele_group"}->{variant},
      $allele,
      $feat,
    ]
  );
}

sub _addVariantOne {
  my hla::GenerateSfvt $this = shift;
  my ($allele) = @_;

  my $variants = $this->{variants};

  my $variant_types    = $variants->{variant_types};
  my $allele_group_map = $variants->{allele_group_map};

  my $allele_group = $this->{alleles}->{"$allele"}->{allele_group};
  $variant_types->{"$allele_group"}->{"$allele_group"} =
    util::Constants::EMPTY_STR;

  if ( !defined( $allele_group_map->{"$allele_group"} ) ) {
    $allele_group_map->{"$allele_group"} = {
      variant => $allele_group,
      allele  => $allele,
    };
    return;
  }
}

sub _setFeatureOne {
  my hla::GenerateSfvt $this = shift;
  my ($feature) = @_;
  ###
  ### Initialize Structure
  ###
  foreach my $col ( keys %{ $this->{variants} } ) {
    next if ( $col eq 'info' || $col eq 'deprecated' );
    $this->{variants}->{$col} = {};
  }
  ###
  ### Set the feature and generate the feature coordinates,
  ### the reference feature, and position motif map
  ###
  $this->{feature}        = $feature;
  $this->{feat_intervals} = [];
  $this->{ref_feature}    = undef;
  $this->{pos_motif_map}  = [];
}

sub _setFeature {
  my hla::GenerateSfvt $this = shift;
  my ($feature) = @_;

  my $locus_info = $this->{locus_info};
  my $ref_allele = $this->{ref_allele};
  ###
  ### Initialize Structure
  ###
  foreach my $col ( keys %{ $this->{variants} } ) {
    next if ( $col eq 'info' || $col eq 'deprecated' );
    $this->{variants}->{$col} = {};
  }
  ###
  ### Set the feature and generate the feature coordinates,
  ### the reference feature, and position motif map
  ###
  $this->{feature}        = $feature;
  $this->{feat_intervals} = $this->_generateFeatureIntervals($feature);
  $this->{ref_feature}    = $this->_getFeature($ref_allele);
  $this->_setPosMotifMap;
  ###
  ### Initialize the variant types and allele group map
  ###
  $this->_addVariant(UNKNOWN_MOTIF);
  $this->_addVariant(
    $this->_makeVariant,
    util::Constants::EMPTY_LINE(
      $locus_info->{&hla::HlaTypes::REF_ALLELE_COL}
      )
    ? $ref_allele
    : undef
  );
}

sub _sortNomens {
       $a->{allele_group} <=> $b->{allele_group}
    or $a->{hla_protein} <=> $b->{hla_protein}
    or $a->{coding_region} <=> $b->{coding_region}
    or $a->{non_coding_region} <=> $b->{non_coding_region};
}

sub _sortAlleleGroups {
  my hla::GenerateSfvt $this = shift;
  my ($allele_groups) = @_;

  my @nomens = ();
  foreach my $allele_group ( keys %{$allele_groups} ) {
    push( @nomens, $this->_generateNomenclature($allele_group) );
  }
  @nomens        = sort hla::GenerateSfvt::_sortNomens @nomens;
  $allele_groups = [];
  foreach my $nomen (@nomens) { push( @{$allele_groups}, $nomen->{allele} ); }

  return $allele_groups;
}

sub _createEntity {
  my hla::GenerateSfvt $this = shift;
  my ($entity_ord) = @_;

  my $feature          = $this->{feature};
  my $feature_file_ord = hla::HlaTypes::FEATURE_FILE_ORD;
  my $entity           = {};
  foreach my $col ( @{$entity_ord} ) {
    $entity->{"$col"} = util::Constants::EMPTY_STR;
  }
  foreach my $col ( @{$feature_file_ord} ) {
    next if ( !defined( $entity->{"$col"} ) );
    $entity->{"$col"} = $feature->{"$col"};
  }
  return $entity;
}

sub _generatePosMotif {
  my hla::GenerateSfvt $this = shift;
  my ($motif) = @_;

  return $motif
    if ( util::Constants::EMPTY_LINE($motif)
    || $motif eq UNKNOWN_MOTIF );

  my $single_coord_pattern = SINGLE_COORD_PATTERN;
  my $del_pattern          = DEL_PATTERN;

  my $pos_motif_map = $this->{pos_motif_map};
  my @pos_motifs    = ();
  foreach my $pos_struct ( @{ $this->{pos_motif_map} } ) {
    my $range     = $pos_struct->{range};
    my $pos_motif = $pos_struct->{coord};
    my $chars = substr( $motif, $range->[0], $range->[1] - $range->[0] + 1 );
    if ( $pos_struct->{del} ) {
      if   ( $chars =~ /^\.+$/ ) { $pos_motif .= DELETE_POS; }
      else                       { $pos_motif .= INSERT_POS . $chars; }
    }
    else {
      if   ( $chars =~ /^\.+$/ ) { $pos_motif .= DELETE_POS; }
      else                       { $pos_motif .= $chars; }
    }
    push( @pos_motifs, $pos_motif );
  }
  return join( util::Constants::UNDERSCORE, @pos_motifs );

}

sub _addEntity {
  my hla::GenerateSfvt $this = shift;
  my ( $entity_type, $entity ) = @_;

  my $variant_type_name = $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};

  my $key = $this->_variantTypeKey($variant_type_name);
  $this->{variants}->{$entity_type}->{"$key"} = $entity;
}

sub _addAlleleGroupInfo {
  my hla::GenerateSfvt $this = shift;
  my ( $entity, $allele_group, $allele_type, $old_entity, $reason ) = @_;

  return if ( !defined($allele_type) );

  my $locus_name = $this->{locus_name};

  my $feature_number             = undef;
  my $feature_coords             = undef;
  my $variant_type_name          = undef;
  my $new_motif                  = undef;
  my $previous_variant_type_name = undef;
  my $previous_motif             = undef;
  if ( defined($entity) ) {
    $feature_number    = $entity->{&db::MhcTypes::FEATURE_NUMBER_COL};
    $feature_coords    = $entity->{&hla::HlaTypes::LOCATION_COL};
    $new_motif         = $entity->{&db::MhcTypes::MOTIF_COL};
    $variant_type_name = $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};
  }
  elsif ( defined($old_entity) ) {
    $feature_number = $old_entity->{&db::MhcTypes::FEATURE_NUMBER_COL};
    $feature_coords = $old_entity->{&hla::HlaTypes::LOCATION_COL};
  }
  if ( defined($old_entity) ) {
    $previous_motif = $old_entity->{&db::MhcTypes::MOTIF_COL};
    $previous_variant_type_name =
      $old_entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};
  }
  return if ( !defined($feature_number) );
  ###
  ### Add the datum
  ###
  my $key = $this->_fullKey( $feature_number, $variant_type_name );
  $this->{info_data}->{&hla::HlaTypes::ALLELE_GROUP_DISPOSITION_INFO}->{$key} =
    [
    $locus_name,                 $feature_number,
    $feature_coords,             $variant_type_name,
    $allele_group,               $allele_type,
    $previous_variant_type_name, $reason,
    $previous_motif,             $new_motif,
    ];
}

sub _addVariantInfo {
  my hla::GenerateSfvt $this = shift;
  my ( $entity, $motif_type ) = @_;

  return
    if ( !defined($motif_type)
    || $motif_type eq hla::HlaTypes::PREV_VERSION_VARIANT_TYPE
    || $motif_type eq hla::HlaTypes::KEEP_DEPRECATED_VARIANT_TYPE );

  my $locus_name = $this->{locus_name};

  my $feature_number    = $entity->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $feature_coords    = $entity->{&hla::HlaTypes::LOCATION_COL};
  my $variant_type_name = $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL};
  my $pos_motif         = $entity->{&db::MhcTypes::POS_MOTIF_COL};
  my $curr_pos_motif =
    $this->_generatePosMotif( $entity->{&db::MhcTypes::MOTIF_COL} );
  ###
  ### Add the datum
  ###
  my $key = $this->_fullKey( $feature_number, $variant_type_name );
  $this->{error_info}
    ->addErrorInfo( hla::HlaTypes::MOTIF_ERROR, $curr_pos_motif ne $pos_motif,
    4, [ $locus_name, $variant_type_name, $curr_pos_motif, $pos_motif, ] );
  $this->{info_data}->{&hla::HlaTypes::VARIANT_DISPOSITION_INFO}->{$key} = [
    $locus_name,        $feature_number, $feature_coords,
    $variant_type_name, $motif_type,     $pos_motif
  ];
  ###
  ### Report changes
  ###
  if ( $motif_type eq hla::HlaTypes::DEPRECATE_VARIANT_TYPE
    || $motif_type eq hla::HlaTypes::NEW_VARIANT_TYPE
    || $motif_type eq hla::HlaTypes::UNDEPRECATED_VARIANT_TYPE )
  {
    $this->{change_report}->{$key} = [ $variant_type_name, $motif_type ];
  }
}

sub _getMotifs {
  my hla::GenerateSfvt $this = shift;

  my $ref_feature   = $this->{ref_feature};
  my $variants      = $this->{variants};
  my $curr_variants = $variants->{fvariants};
  my @curr_motifs   = sort keys %{$curr_variants};
  my $motifs        = [@curr_motifs];
  ###
  ### Return motifs 'as-is' if no reference feature
  ###
  return $motifs if ( !defined($ref_feature) );
  ###
  ### Determine if reference feature appears in motifs
  ###
  my $found_ref_feature = util::Constants::FALSE;
  foreach my $motif (@curr_motifs) {
    next if ( $motif ne $ref_feature );
    $found_ref_feature = util::Constants::TRUE;
    last;
  }
  ###
  ### Return motifs 'as-is' if reference feature is not in motifs
  ###
  return $motifs if ( !$found_ref_feature );
  ###
  ### Since reference feature occurs in motifs,
  ### return it at the head of the motifs
  ###
  $motifs = [$ref_feature];
  foreach my $motif (@curr_motifs) {
    next if ( $motif eq $ref_feature );
    push( @{$motifs}, $motif );
  }
  return $motifs;
}

sub _validateFeature {
  my hla::GenerateSfvt $this = shift;
  ###
  ### Create Change Report
  ###
  $this->{change_report} = {};
  ###
  ### Standard constants
  ###
  my $deprecated_file_ord = hla::HlaTypes::VARIANT_DEPRECATED_FILE_ORD;
  my $variant_file_ord    = hla::HlaTypes::VARIANT_FILE_ORD;
  ###
  ### Setup the data for validating feature
  ###
  my $feature               = $this->{feature};
  my $variants              = $this->{variants};
  my $feature_number        = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $curr_variants         = $variants->{fvariants};
  my $curr_allele_group_map = $variants->{allele_group_map};
  my $prev_variants         = $variants->{info}->{"$feature_number"};
  my $prev_deprecated       = $variants->{deprecated}->{"$feature_number"};
  my $generator             = $this->{generator};
  ###
  ### Set the current maximum variant number
  ### and the previous allele group map
  ###
  my $max_variant_num       = 0;
  my $prev_allele_group_map = {};
  if ( defined($prev_variants) ) {
    $max_variant_num       = $prev_variants->{max_num};
    $prev_allele_group_map = $prev_variants->{allele_group_map};
  }
  ###
  ### Validate against current variants for feature name
  ###
  ### 1.  Determine the set of variants that exist between
  ###     current variants and newly generated variants
  ###     -- check the inclusion/exclusion of allele_groups
  ### 2.  Determine the variants that are new for this release
  ###     -- these need to have new vt definitions
  ### 3.  Determine the variants that deprecated for this release
  ###     -- must make sure that these numbers are captured in
  ###        locus_info dataset so that they do not get reused
  ###
  ### Intialize:
  ### 1.  motifs determined
  ### 2.  allele groups found
  ### 3.  variants that are un-deprecated
  ###
  my $motifs_found          = {};
  my $allele_groups_found   = {};
  my $undeprecated_variants = {};
  my $curr_motifs           = $this->_getMotifs;
  foreach my $motif ( @{$curr_motifs} ) {
    my $curr_allele_groups = $curr_variants->{"$motif"};
    my $entity             = undef;
    my $motif_type         = undef;
    if ( defined($prev_variants)
      && defined( $prev_variants->{data}->{"$motif"} ) )
    {
      ###
      ### Re-use previous variant:
      ### This variant exists between the current
      ### release and the previous release
      ###
      my $prev_data = $prev_variants->{data}->{"$motif"};
      $entity     = $prev_data->{entity};
      $motif_type = hla::HlaTypes::PREV_VERSION_VARIANT_TYPE;
    }
    elsif ( defined($prev_deprecated)
      && defined( $prev_deprecated->{"$motif"} ) )
    {
      ###
      ### This variant is a previously deprecated
      ### variant and must be un-deprecated
      ###
      my $deprecated_data   = $prev_deprecated->{"$motif"};
      my $deprecated_entity = $deprecated_data->{entity};

      $entity     = $this->_createEntity($variant_file_ord);
      $motif_type = hla::HlaTypes::UNDEPRECATED_VARIANT_TYPE;

      foreach my $col ( keys %{$deprecated_entity} ) {
        $entity->{"$col"} = $deprecated_entity->{"$col"};
      }
      $entity->{&db::MhcTypes::FEATURE_NAMES_COL} =
        $feature->{&db::MhcTypes::FEATURE_NAMES_COL};
      $entity->{&db::MhcTypes::FEATURE_TYPES_COL} =
        $feature->{&db::MhcTypes::FEATURE_TYPES_COL};

      $undeprecated_variants->{"$motif"} = util::Constants::EMPTY_STR;
    }
    else {
      ###
      ### This variant is a new variant
      ###
      my $variant_type_name = $feature_number;
      my $feat_num          = $this->_featureNumber($feature_number);
      if ( $feat_num == FEATURE_NUMBER_ONE ) {
        $variant_type_name = $motif;
        $motif             = util::Constants::EMPTY_STR;
      }
      elsif ( $motif eq UNKNOWN_MOTIF ) {
        $variant_type_name .= UNKNOWN_VARIANT_SUFFIX;
      }
      else {
        $max_variant_num++;
        $variant_type_name .= VARIANT_TYPE_NUM_SUFFIX . $max_variant_num;
      }

      $entity     = $this->_createEntity($variant_file_ord);
      $motif_type = hla::HlaTypes::NEW_VARIANT_TYPE;

      $entity->{&db::MhcTypes::VARIANT_TYPE_NAME_COL} = $variant_type_name;
      $entity->{&db::MhcTypes::MOTIF_COL}             = $motif;
      $entity->{&db::MhcTypes::POS_MOTIF_COL} =
        $this->_generatePosMotif($motif);
      ###
      ### For reporting purposes...
      ###
      if ( $feat_num == FEATURE_NUMBER_ONE ) { $motif = $variant_type_name; }
    }
    ###
    ### Set the allele groups for the motif and map this variant
    ###
    $entity->{&db::MhcTypes::ALLELE_GROUP_COL} =
      join( util::Constants::COMMA_SEPARATOR, @{$curr_allele_groups} );
    $this->_addEntity( hla::HlaTypes::VARIANT_FILE, $entity );
    $this->_addVariantInfo( $entity, $motif_type );
    $motifs_found->{"$motif"} = $entity;
    foreach my $allele_group ( @{$curr_allele_groups} ) {
      $allele_groups_found->{"$allele_group"} = $entity;
    }
  }
  ###
  ### Check previous feature variants feature that are accounted
  ### but have allele groups moved to different variants and
  ### variants that are not accounted (these are new deprecated
  ### variants)
  ###
  if ( defined($prev_variants) ) {
    foreach my $motif ( sort keys %{ $prev_variants->{data} } ) {
      my $prev_data          = $prev_variants->{data}->{"$motif"};
      my $prev_allele_groups = [ keys %{ $prev_data->{allele_groups} } ];
      my $prev_entity        = $prev_data->{entity};
      my $motif_type         = undef;
      if ( defined( $motifs_found->{"$motif"} ) ) {
        ###
        ### Determine if allele group(s) are not accounted
        ###
        foreach my $allele_group ( @{$prev_allele_groups} ) {
          my $allele_type = undef;
          my $new_entity  = undef;
          my $old_entity  = undef;
          my $reason      = undef;
          if ( defined( $allele_groups_found->{"$allele_group"} ) ) {
            my $allele_group_motif =
              $allele_groups_found->{"$allele_group"}
              ->{&db::MhcTypes::MOTIF_COL};
            if ( defined($allele_group_motif) && $motif ne $allele_group_motif )
            {
              $allele_type = hla::HlaTypes::ALLELE_GROUP_MOVED_TYPE;
              $new_entity  = $allele_groups_found->{"$allele_group"};
              $old_entity  = $prev_entity;
              $reason      = hla::HlaTypes::ALLELE_GROUP_MOVED_REASON1;
            }
          }
          else {
            $allele_type = hla::HlaTypes::ALLELE_GROUP_DELETED;
            $old_entity  = $prev_entity;
            $reason      = $generator->getDeletionReason($allele_group);
          }
          $this->_addAlleleGroupInfo( $new_entity, $allele_group, $allele_type,
            $old_entity, $reason );
        }
      }
      else {
        ###
        ### Create a new deprecated entity for pervious variant
        ###
        $motif_type = hla::HlaTypes::DEPRECATE_VARIANT_TYPE;
        my $entity = $this->_createEntity($deprecated_file_ord);
        foreach my $col ( keys %{$entity} ) {
          $entity->{"$col"} = $prev_entity->{"$col"};
        }
        $this->_addEntity( hla::HlaTypes::VARIANT_DEPRECATED_FILE, $entity );
        $this->_addVariantInfo( $prev_entity, $motif_type );
        foreach my $allele_group ( @{$prev_allele_groups} ) {
          my $allele_type = undef;
          my $new_entity  = undef;
          my $old_entity  = undef;
          my $reason      = undef;
          if ( defined( $allele_groups_found->{"$allele_group"} ) ) {
            $allele_type = hla::HlaTypes::ALLELE_GROUP_MOVED_TYPE;
            $new_entity  = $allele_groups_found->{"$allele_group"};
            $old_entity  = $prev_entity;
            $reason      = hla::HlaTypes::ALLELE_GROUP_MOVED_REASON2;
          }
          else {
            $allele_type = hla::HlaTypes::ALLELE_GROUP_DELETED;
            $old_entity  = $prev_entity;
            $reason      = $generator->getDeletionReason($allele_group);
          }
          $this->_addAlleleGroupInfo( $new_entity, $allele_group, $allele_type,
            $old_entity, $reason );
        }
      }
    }
  }
  ###
  ### Determine the previous deprecates that are still valid
  ### and add to the deprecates
  ###
  if ( defined($prev_deprecated) ) {
    foreach my $motif ( keys %{$prev_deprecated} ) {
      my $deprecated_data   = $prev_deprecated->{"$motif"};
      my $deprecated_entity = $deprecated_data->{entity};
      my $motif_type        = undef;
      next if ( defined( $undeprecated_variants->{"$motif"} ) );
      if ( defined( $motifs_found->{"$motif"} ) ) {
        $motif_type = hla::HlaTypes::DEPRECATED_BUT_IN_PREV_VERSION_TYPE;
      }
      else {
        ###
        ### Keep Deprecate
        ###
        $motif_type = hla::HlaTypes::KEEP_DEPRECATED_VARIANT_TYPE;
        $this->_addEntity( hla::HlaTypes::VARIANT_DEPRECATED_FILE,
          $deprecated_entity );
      }
      $this->_addVariantInfo( $deprecated_entity, $motif_type );
    }
  }
  $generator->generateReport(
    'Variant Changes',
    $this->{change_report},
    hla::HlaTypes::VARIANT_CHANGE_REPORT_COLS
  );
}

sub _deprecateFeature {
  my hla::GenerateSfvt $this = shift;
  ###
  ### Create Change Report
  ###
  $this->{change_report} = {};
  ###
  ### Standard constants
  ###
  my $deprecated_file_ord = hla::HlaTypes::VARIANT_DEPRECATED_FILE_ORD;
  ###
  ### Setup the data for deprecatation of the feature
  ###
  my $feature         = $this->{feature};
  my $variants        = $this->{variants};
  my $feature_number  = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $prev_variants   = $variants->{info}->{"$feature_number"};
  my $prev_deprecated = $variants->{deprecated}->{"$feature_number"};
  my $generator       = $this->{generator};
  ###
  ### Deprecate the previous feature variants
  ###
  if ( defined($prev_variants) ) {
    foreach my $motif ( sort keys %{ $prev_variants->{data} } ) {
      my $prev_data          = $prev_variants->{data}->{"$motif"};
      my $prev_allele_groups = [ keys %{ $prev_data->{allele_groups} } ];
      my $prev_entity        = $prev_data->{entity};
      my $motif_type         = undef;
      ###
      ### Create a new deprecated entity for pervious variant
      ###
      $motif_type = hla::HlaTypes::DEPRECATE_VARIANT_TYPE;
      my $entity = $this->_createEntity($deprecated_file_ord);
      foreach my $col ( keys %{$entity} ) {
        $entity->{"$col"} = $prev_entity->{"$col"};
      }
      $this->_addEntity( hla::HlaTypes::VARIANT_DEPRECATED_FILE, $entity );
      $this->_addVariantInfo( $prev_entity, $motif_type );
    }
  }
  ###
  ### Keep the previous deprecated feature variants
  ###
  if ( defined($prev_deprecated) ) {
    foreach my $motif ( keys %{$prev_deprecated} ) {
      my $deprecated_data   = $prev_deprecated->{"$motif"};
      my $deprecated_entity = $deprecated_data->{entity};
      my $motif_type        = hla::HlaTypes::KEEP_DEPRECATED_VARIANT_TYPE;
      $this->_addEntity( hla::HlaTypes::VARIANT_DEPRECATED_FILE,
        $deprecated_entity );
      $this->_addVariantInfo( $deprecated_entity, $motif_type );
    }
  }
  $generator->generateReport(
    'Variant Changes',
    $this->{change_report},
    hla::HlaTypes::VARIANT_CHANGE_REPORT_COLS
  );
}

sub _writeVariantsOfFeature {
  my hla::GenerateSfvt $this = shift;
  my ($entity_type) = @_;

  my $feature   = $this->{feature};
  my $data      = $this->{variants}->{$entity_type};
  my $generator = $this->{generator};
  my $entities  = [];

  my @keys = keys %{$data};
  return if ( scalar @keys == 0 );

  my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $feat_num       = $this->_featureNumber($feature_number);
  if ( $feat_num == FEATURE_NUMBER_ONE ) { @keys = sort @keys; }
  else { @keys = sort hla::GenerateSfvt::_numSort keys %{$data}; }
  foreach my $key (@keys) {
    my $entity = $data->{"$key"};
    push( @{$entities}, $data->{"$key"} );
  }
  $generator->writeFeature( $entity_type, $entities );
}

sub _checkFeature {
  my hla::GenerateSfvt $this = shift;

  my $a_feature_types      = hla::HlaTypes::A_FEATURE_TYPES;
  my $sf_feature_types     = hla::HlaTypes::SF_FEATURE_TYPES;
  my $single_coord_pattern = SINGLE_COORD_PATTERN;

  my $feature    = $this->{feature};
  my $features   = $this->{features};
  my $variants   = $this->{variants};
  my $singletons = $features->{singletons};

  my $feature_coords = $feature->{&hla::HlaTypes::LOCATION_COL};
  my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
  my $feature_types  = $feature->{&db::MhcTypes::FEATURE_TYPES_COL};
  my $key            = $this->_featureNumberKey($feature_number);
  if ( $feature_coords !~ /$single_coord_pattern/ ) {
    ###
    ### Add sequence feature to current features and return
    ###
    $features->{&hla::HlaTypes::FEATURE_FILE}->{"$key"} = $feature;
    return util::Constants::FALSE;
  }
  ###
  ### For singleton sequence features, only
  ### those that have only A_FEATURE_TYPES
  ###
  my %ftypes = ();
  foreach my $ftype ( split( /; /, $feature_types ) ) {
    $ftypes{$ftype} = util::Constants::EMPTY_STR;
  }
  my @sf_types = ();
  foreach my $ftype ( @{$sf_feature_types} ) {
    next if ( !defined( $ftypes{$ftype} ) );
    push( @sf_types, $ftype );
    last;
  }
  my @a_types = ();
  foreach my $ftype ( @{$a_feature_types} ) {
    next if ( !defined( $ftypes{$ftype} ) );
    push( @a_types, $ftype );
    last;
  }
  my $found_type =
    ( scalar @a_types > 0 && scalar @sf_types == 0 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  if ( !$found_type ) {
    ###
    ### Add sequence feature to current features and return
    ###
    $features->{&hla::HlaTypes::FEATURE_FILE}->{"$key"} = $feature;
    return util::Constants::FALSE;
  }
  ###
  ### Keep all singleton sequence features
  ### that have more than one known variant
  ###
  my @aas = ();
  foreach my $vfeat ( keys %{ $variants->{fvariants} } ) {
    next if ( $vfeat eq UNKNOWN_MOTIF );
    push( @aas, $vfeat );
  }
  if ( scalar @aas > 1 ) {
    ###
    ### Add sequence feature to current features and return
    ###
    $features->{&hla::HlaTypes::FEATURE_FILE}->{"$key"} = $feature;
    return util::Constants::FALSE;
  }
  ###
  ### Deprecate Singleton Sequence Feature
  ###
  my $singleton = $singletons->{"$feature_coords"};
  $singleton->{change_type} = hla::HlaTypes::DEPRECATE_SEQUENCE_FEATURE_TYPE;
  $this->_addFeatureInfo( $feature,
    hla::HlaTypes::DEPRECATE_SEQUENCE_FEATURE_TYPE );
  $features->{changed}->{"$key"} = [
    $feature_number,
    $feature->{&hla::HlaTypes::LOCATION_COL},
    "(" . join( util::Constants::COMMA_SEPARATOR, @aas ) . ")",
    hla::HlaTypes::DEPRECATE_SEQUENCE_FEATURE_TYPE
  ];

  $features->{&hla::HlaTypes::FEATURE_DEPRECATED_FILE}->{"$key"} = $feature;
  return util::Constants::TRUE;
}

sub _completeFeatureProcessing {
  my hla::GenerateSfvt $this = shift;
  ###
  ### Determine which features are previously deprecated
  ###
  my $features   = $this->{features};
  my $singletons = $features->{singletons};
  foreach my $singleton_coord ( keys %{$singletons} ) {
    my $singleton      = $singletons->{"$singleton_coord"};
    my $change_type    = $singleton->{change_type};
    my $feature        = $singleton->{feature};
    my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
    my $key            = $this->_featureNumberKey($feature_number);
    next
      if ( !defined($change_type)
      || $change_type ne hla::HlaTypes::KEEP_DEPRECATED_FEATURE_TYPE );
    $this->_addFeatureInfo( $feature, $change_type );
    $features->{&hla::HlaTypes::FEATURE_DEPRECATED_FILE}->{"$key"} = $feature;
  }
}

sub _writeFeatures {
  my hla::GenerateSfvt $this = shift;
  my ($entity_type) = @_;

  my $data      = $this->{features}->{$entity_type};
  my $generator = $this->{generator};
  my $entities  = [];

  my @keys = keys %{$data};
  return if ( scalar @keys == 0 );

  foreach my $key ( sort hla::GenerateSfvt::_numSort keys %{$data} ) {
    my $entity = $data->{"$key"};
    push( @{$entities}, $data->{"$key"} );
  }
  $generator->writeFeature( $entity_type, $entities );
}

sub _reportFeature {
  my hla::GenerateSfvt $this = shift;
  my ( $feature_number, $feature_coords ) = @_;

  my $indent      = "                   ";
  my @comps       = split( /, /, $feature_coords );
  my @segments    = ();
  my $group_num   = 10;
  my $group_start = 0;
  foreach my $index ( 0 .. $#comps ) {
    next if ( $index == 0 || $index % $group_num != 0 );
    my $segment = util::Constants::EMPTY_STR;
    if ( $group_start > 0 ) { $segment .= $indent; }
    $segment .= join( util::Constants::COMMA_SEPARATOR,
      @comps[ $group_start .. ( $index - 1 ) ] );
    $group_start = $index;
    push( @segments, $segment );
  }
  my $segment = util::Constants::EMPTY_STR;
  if ( $group_start > 0 ) { $segment .= $indent; }
  $segment .= join( util::Constants::COMMA_SEPARATOR,
    @comps[ $group_start .. ($#comps) ] );
  push( @segments, $segment );

  my $msg =
      "Processing Feature\n"
    . "  feature number = $feature_number\n"
    . "  feature coords = "
    . join(
    util::Constants::COMMA_SEPARATOR . util::Constants::NEWLINE,
    @segments
    );
  $this->{error_mgr}->printHeader($msg);
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$$$) {
  my hla::GenerateSfvt $this = shift;
  my (
    $locus_name,          $locus_info,          $taxon_id,
    $seq_type,            $features,            $variants,
    $features_deprecated, $variants_deprecated, $generator,
    $tools,               $error_mgr
  ) = @_;

  $this = fields::new($this) unless ref($this);

  $this->{alleles}        = undef;
  $this->{error_info}     = $generator->errorInfo;
  $this->{error_mgr}      = $error_mgr;
  $this->{feat_intervals} = undef;
  $this->{features}       = undef;
  $this->{feature}        = undef;
  $this->{generator}      = $generator;
  $this->{locus_info}     = $locus_info;
  $this->{locus_name}     = $locus_name;
  $this->{nomen_ord}      = db::MhcTypes::NOMENCLATURE_ORDER;
  $this->{ref_allele}     = undef;
  $this->{ref_feature}    = undef;
  $this->{ruler}          = undef;
  $this->{seq_type}       = uc($seq_type);
  $this->{taxon_id}       = $taxon_id;
  $this->{tools}          = $tools;
  $this->{variants}       = undef;

  my $info_types = hla::HlaTypes::INFO_TYPES;
  $this->{info_data} = {};
  foreach my $info_type ( keys %{$info_types} ) {
    $this->{info_data}->{$info_type} = {};
  }

  $this->_readSequenceInfo;
  $this->_generateRuler;
  $this->_generateFeatureInfo( $features, $features_deprecated );
  $this->_generateVariantsInfo( $variants, $variants_deprecated );

  return $this;
}

sub generateVariants {
  my hla::GenerateSfvt $this = shift;
  ###
  ### Determine the set of new
  ### and deprecated singleton
  ### features
  ###
  $this->_determineSingletonFeatures;

  my $unknown_pos_pattern = UNKNOWN_POS_PATTERN;

  my $alleles    = $this->{alleles};
  my $features   = $this->{features};
  my $generator  = $this->{generator};
  my $ref_allele = $this->{ref_allele};
  my $variants   = $this->{variants};

  foreach
    my $key ( sort hla::GenerateSfvt::_numSort keys %{ $features->{curr} } )
  {
    my $feature        = $features->{curr}->{"$key"};
    my $feature_coords = $feature->{&hla::HlaTypes::LOCATION_COL};
    my $feature_number = $feature->{&db::MhcTypes::FEATURE_NUMBER_COL};
    my $feat_num       = $this->_featureNumber($feature_number);
    $this->_reportFeature( $feature_number, $feature_coords );
    ###
    ### Feature number one is different from other features
    ###
    if ( $feat_num == FEATURE_NUMBER_ONE ) {
      $this->_setFeatureOne($feature);
      my $feature_variants = $variants->{fvariants};
      foreach my $allele ( sort keys %{$alleles} ) {
        $this->_addVariantOne($allele);
        my $allele_group = $alleles->{"$allele"}->{allele_group};
        $feature_variants->{"$allele_group"} = [$allele_group];
      }
    }
    else {
      ###
      ### Process sequence features with coordinates only as follows
      ###
      next if ( util::Constants::EMPTY_LINE($feature_coords) );
      $feature_coords = strip_whitespace($feature_coords);
      next if ( util::Constants::EMPTY_LINE($feature_coords) );
      ###
      ### generate variants for feature
      ###
      $this->_setFeature($feature);
      my $allele_group_map = $variants->{allele_group_map};
      my $variant_types    = $variants->{variant_types};
      my $feature_variants = $variants->{fvariants};
      ###
      ### Non-null alleles which are not the reference
      ### allele nor containing unknown positions (unknown
      ### motif)
      ###
      foreach my $allele ( sort keys %{$alleles} ) {
        ###
        ### The reference allele and unknown type
        ### are added as variants in _setFeature
        ###
        next if ( $allele eq $ref_allele );
        my $seq  = $alleles->{"$allele"}->{seq};
        my $feat = $this->_getFeature($allele);
        if ( $feat =~ /$unknown_pos_pattern/ ) {
          $feat = UNKNOWN_MOTIF;
        }
        $this->_addVariant( $feat, $allele );
      }
      ###
      ### Remove from the unknown entities
      ### those that do have a defined variant
      ###
      my $unknownMotifs = $variant_types->{&UNKNOWN_MOTIF};
      foreach my $allele_group ( keys %{$allele_group_map} ) {
        delete( $unknownMotifs->{"$allele_group"} );
      }
      ###
      ### Generate the variants for the feature
      ###
      foreach my $feat ( sort keys %{$variant_types} ) {
        my $vfeat = $feat;
        if ( $feat ne UNKNOWN_MOTIF ) {
          $vfeat = $this->_generateFeature($feat);
        }
        ###
        ### This can happen when the reference allele is not
        ### an allele for the locus
        ###
        my $allele_groups =
          $this->_sortAlleleGroups( $variant_types->{"$feat"} );
        next if ( scalar @{$allele_groups} == 0 );

        $feature_variants->{"$vfeat"} = $allele_groups;
      }
    }
    ###
    ### Check the feature:
    ###
    ### Added a sequence feature to the feature file list except
    ### in the following case.  If the sequence feature is a
    ### singleton sequence feature which has only one known variant,
    ### then mark the sequence feature for deprecation.
    ###
    ### If the feature is to be deprecated, then the previous
    ### variants and previous deprecates must be moved into the
    ### deprecated variants file.
    ###
    my $deprecateFeature = $this->_checkFeature;
    $this->_deprecateFeature if ($deprecateFeature);
    ###
    ### Validate the feature if it is not deprecated
    ### Generate error and information results
    ###
    $this->_validateFeature if ( !$deprecateFeature );
    ###
    ### Write variants and deprecated data
    ###
    foreach my $file_type (hla::HlaTypes::VARIANT_FILES) {
      $this->_writeVariantsOfFeature($file_type);
    }
  }
  ###
  ### Complete feature processing:
  ### All deprecated features that have not been
  ### undeprecated will continue to be deprecated
  ###
  $this->_completeFeatureProcessing;
  ###
  ### Write the sequence features (current and deprecated)
  ###
  $generator->generateReport(
    'Changed Singleton Features for Locus ' . $this->{locus_name},
    $features->{changed}, hla::HlaTypes::SINGLETON_FEATURE_REPORT_COLS );
  foreach my $file_type (hla::HlaTypes::FEATURE_FILES) {
    $this->_writeFeatures($file_type);
  }
  ###
  ### Generate information results
  ###
  foreach my $info_type ( keys %{ $this->{info_data} } ) {
    $generator->writeInfo( $info_type, $this->{info_data}->{$info_type} );
  }
}

################################################################################

1;

__END__

=head1 NAME

GenerateSfvt.pm

=head1 DESCRIPTION

This class defines the mechanism for generating sequence feature
variant types using IMGT data and a defined set of features and
variants.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new hla::GenerateSfvt(locus_name, locus_info, taxon_id, seq_type, error_mgr)>

This is the constructor for the class.

=head2 B<generateVariants>

This method generates the variants for a given locus

=cut
