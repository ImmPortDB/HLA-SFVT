package hla::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'HLA-FEATURE-VARIATION: '; }

sub FEATURENAME_CAT     { return 10000; }    ### HLA FeatureName Class
sub FEATUREVARIANT_CAT  { return 11000; }    ### HLA FeatureVariant Class
sub PDBPOSITIONS_CAT    { return 12000; }    ### HLA PDB Positions Class
sub JMOLFILES_CAT       { return 13000; }    ### Jmol Files Class
sub GENERATESFVT_CAT    { return 14000; }    ### Generate SFVT Locus Class
sub HLAGENERATESFVT_CAT { return 15000; }    ### HLA Generate SFVT Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {
    &FEATURENAME_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &FEATUREVARIANT_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &PDBPOSITIONS_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &JMOLFILES_CAT => {
          1 => "Cannot open Jmol file for __1__\n"
        . "  file = __2__\n"
        . "  type = __3__",

      2 => "Label does not coincide with expected order\n"
        . "  expected_label = __1__\n"
        . "  label          = __2__",

      3 => "PDB ID does not appear in PDB structures\n" . "  pdb id = __1__",

      4 => "Initial Chain Menu won't eval\n"
        . "  initial_chain_menu = __1__\n"
        . "  errMsg             = __2__",

    },

    &GENERATESFVT_CAT => {
          1 => "Cannot read sequence alignment file\n"
        . "  locus name = __1__\n"
        . "  file       = __2__\n"
        . "  seq type   = __3__",

      2 => "Locus differs between features and sequence file\n"
        . "  locus name          = __1__\n"
        . "  features locus name = __2__\n"
        . "  file locus name     = __3__",

    },

    &HLAGENERATESFVT_CAT => {
          1 => "Cannot Read File for current IMGT/HLA Release\n"
        . "  IMGT/HLA version = __1__\n"
        . "  IMGT/HLA date    = __2__\n"
        . "  file             = __3__\n"
        . "  status           = __4__\n"
        . "  eval str         = __5__",

      2 => "Feature Location Error\n"
        . "  locus_name     = __1__ \n"
        . "  feature_number = __2__\n"
        . "  intervals      = __3__\n"
        . "  interval       = __4__\n"
        . "  err msg        = __5__",

      3 => "Allele group has been assigned to two variants feature_number\n"
        . "  locus name     = __1__\n"
        . "  feature number = __2__\n"
        . "  allele group   = __3__\n"
        . "  allele         = __4__\n"
        . "  variant        = __5__\n"
        . "  new allele     = __6__\n"
        . "  new variant    = __7__",

      4 => "Variant type position sequence motif differ between versions\n"
        . "  locus name     = __1__\n"
        . "  variant type   = __2__\n"
        . "  prev pos motif = __3__\n"
        . "  curr pos motif = __4__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {

    &FEATURENAME_CAT     => 'hla::FeatureName',
    &FEATUREVARIANT_CAT  => 'hla::FeatureVariant',
    &GENERATESFVT_CAT    => 'hla::GenerateSfvt',
    &HLAGENERATESFVT_CAT => 'hla::HlaGenerateSfvt',
    &JMOLFILES_CAT       => 'hla::JmolFiles',
    &PDBPOSITIONS_CAT    => 'hla::PdbPositions',
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use hla::ErrMsgs;

   my $error_msgs  = hla::ErrMsgs::ERROR_MSGS;
   my $error_names = hla::ErrMsgs::ERROR_CATS;
   my $err_cat     = hla::ErrMsgs::FEATURENAME_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the hla library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   hla::ErrMsgs::FEATURENAME_CAT     -- (10000) HLA FeatureName Class
   hla::ErrMsgs::FEATUREVARIANT_CAT  -- (11000) HLA FeatureVariant Class
   hla::ErrMsgs::PDBPOSITIONS_CAT    -- (12000) HLA PDB Positions Class
   hla::ErrMsgs::JMOLFILES_CAT       -- (13000) Jmol Files Class
   hla::ErrMsgs::GENERATESFVT_CAT    -- (14000) Generate SFVT Locus Class
   hla::ErrMsgs::HLAGENERATESFVT_CAT -- (15000) HLA Generate SFVT Class

=head1 STATIC CLASS METHODS

=head2 B<hla::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<hla::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
