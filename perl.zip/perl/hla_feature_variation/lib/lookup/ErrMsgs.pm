package lookup::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'LOOKUP-ERROR: '; }

sub LOOKUP_CAT   { return 10000000000; } ### Lookup Table Base Class
sub ALLELES_CAT  { return 20000000000; } ### Alleles Lookup

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &ALLELES_CAT => {

      1 => "Cannot instantiate lookup table object\n"
        . "  eval_status = __1__\n"
        . "  eval_str    =\n__2__",

    },

    &LOOKUP_CAT => {

      1 => "Unknown IMGT/HLA Version\n"
        . "  version = __1__",

      2 => "Unknown key for table\n"
        . "  table = __1__\n"
        . "  key   = __2__",

      3 => "Unknown IMGT/HLA code for ALLELE table\n"
        . "  key = __1__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {
      &ALLELES_CAT => 'lookup::Alleles',
      &LOOKUP_CAT  => 'lookup::LookupTable',
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use lookup::ErrMsgs;

   my $error_msgs  = lookup::ErrMsgs::ERROR_MSGS;
   my $error_names = lookup::ErrMsgs::ERROR_CATS;
   my $err_cat     = lookup::ErrMsgs::RUNNER_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the lookup library

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   lookup::ErrMsgs::LOOKUP_CAT   -- ( 10000000000 ) Lookup Table Base
   lookup::ErrMsgs::ALLELES_CAT  -- ( 20000000000 ) Alleles Lookup
   

=head1 STATIC CLASS METHODS

=head2 B<lookup::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<lookup::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
