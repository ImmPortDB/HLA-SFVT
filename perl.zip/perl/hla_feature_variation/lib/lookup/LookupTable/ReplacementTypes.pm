package lookup::LookupTable::ReplacementTypes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::ReplacementTypes $this = shift;

  my $changed_id = db::MhcTypes::getId( db::MhcTypes::REPLACEMENT_TYPE_TABLE,
    db::MhcTypes::CHANGED_ALLELE_TYPE );
  my $deleted_id = db::MhcTypes::getId( db::MhcTypes::REPLACEMENT_TYPE_TABLE,
    db::MhcTypes::DELETED_ALLELE_TYPE );

  my $lookup_table = {};
  foreach my $old_allele_name ( $this->getKeys ) {
    my $value = $this->getValue($old_allele_name);
    if ( $value == $changed_id ) { $value = db::MhcTypes::CHANGED_ALLELE_TYPE; }
    elsif ( $value == $deleted_id ) {
      $value = db::MhcTypes::DELETED_ALLELE_TYPE;
    }
    $lookup_table->{$old_allele_name} = $value;
  }

  $this->{lookup_table} = $lookup_table;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::ReplacementTypes $this = $that->SUPER::new(
    $taxon_id,                              $tools,
    db::MhcTypes::REPLACEMENT_ALLELE_TABLE, db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::REPLACEMENT_ID_COL,       util::Constants::FALSE,
    undef,                                  $error_mgr
  );

  $this->_generateNewLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

ReplacementTypes.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the replacement
type for old allele names.  This class uses the MHC_SEQ_VAR schema
B<REPLACEMENT_ALLELE> table.  The key is the column B<OLD_ALLELE_NAME> and
the value is a singleton B<REPLACEMENT_TYPE> that defines the replacement
type.  The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::ReplacementTypes(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
