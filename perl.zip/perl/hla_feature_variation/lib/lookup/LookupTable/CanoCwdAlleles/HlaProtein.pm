package lookup::LookupTable::CanoCwdAlleles::HlaProtein;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable::CanoCwdAlleles';

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateHlaProteinLookupTable {
  my lookup::LookupTable::CanoCwdAlleles::HlaProtein $this = shift;

  my $lookup_table = {};
  foreach my $allele_name ( $this->getKeys ) {
    my $allele = $this->getValue($allele_name);
    if ( util::Constants::EMPTY_LINE( $allele->{hla_protein_name} ) ) {
      $lookup_table->{$allele_name} = $allele;
      $allele->{full_length} = $allele_name;
    }
    else {
      $lookup_table->{ $allele->{hla_protein_name} } = {
        locus_name  => $allele->{locus_name},
        allele_name => $allele->{hla_protein_name},
        full_length => $allele_name,
      };
    }
  }
  ###
  ### Now we want to make sure that all alleles with
  ### suffixes also have the corresponding allele
  ### without the suffix in the lookup
  ###
  foreach my $allele_name ( keys %{$lookup_table} ) {
    my $allele = $lookup_table->{$allele_name};
    next if ( $allele_name !~ /(.+)[A-Z]$/ );
    $allele_name = $1;
    $lookup_table->{$allele_name} = {
      locus_name  => $allele->{locus_name},
      allele_name => $allele_name,
      full_length => $allele->{full_length},
    };
  }

  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::FALSE;
  $this->_generateValueLookup;
  $this->debugLookup("Cano Peptide-Level CWD Lookup Table");
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;

  my lookup::LookupTable::CanoCwdAlleles::HlaProtein $this =
    $that->SUPER::new( $taxon_id, $tools, $error_mgr );

  $this->_generateHlaProteinLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

HlaProtein.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing Cano CWD status
information at the peptide-level.  This class uses the MHC_SEQ_VAR
schema B<LK_CANO_CWD> table.  The key is peptide-level allele name
that includes the locus name (prefixed by '<locus_name>*') and the
value is a singleton referenced Perl hash containing the following
keys:

    db::MhcTypes::LOCUS_NAME_COL
    db::MhcTypes::ALLELE_NAME_COL
    full_length -- this is a full length CWD allele
                   associated with the peptide-level
                   allele 

Also, for any peptide-level allele that has a suffix the lookup table
also contains the allele without the suffix.  The parent class of this
class is L<lookup::LookupTable::CanoCwdAlleles>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::CanoCwdAlleles::HlaProtein(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
