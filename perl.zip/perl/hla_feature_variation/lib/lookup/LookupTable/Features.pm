package lookup::LookupTable::Features;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $seq_type_id, $tools, $error_mgr ) = @_;
  my $vals = [
    db::MhcTypes::FEATURE_ID_COL,    db::MhcTypes::FEATURE_NUMBER_COL,
    db::MhcTypes::FEATURE_NAMES_COL, db::MhcTypes::LOCUS_ID_COL,
    db::MhcTypes::POSITIONS_COL,
  ];
  my $predicate = "
     seq_type_id = $seq_type_id
and locus_id in
      (select locus_id from mhc_locus
       where  taxonomy_id = $taxon_id)";
  my lookup::LookupTable::Features $this =
    $that->SUPER::new( $taxon_id, $tools, db::MhcTypes::FEATURE_TABLE,
    db::MhcTypes::FEATURE_NUMBER_COL,
    $vals, util::Constants::FALSE, $predicate, $error_mgr );

  return $this;
}

sub prepareKey {
  my lookup::LookupTable::Features $this = shift;
  my ($key) = @_;

  $key =~ s/^(CW|Cw)/C/;
  return $key;
}

################################################################################

1;

__END__

=head1 NAME

Features.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing UTSW Sequence
Feature table.  This class uses the MHC_SEQ_VAR schema B<FEATURE>
table.  The key is the column B<FEATURE_NUMBER> and value is a
singleton referenced Perl hash containing the following keys:

   db::MhcTypes::FEATURE_ID_COL
   db::MhcTypes::FEATURE_NUMBER_COL
   db::MhcTypes::FEATURE_NAMES_COL
   db::MhcTypes::LOCUS_ID_COL
   db::MhcTypes::POSITIONS_COL

The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Features(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=head2 B<$prepared_key = prepareKey(key)>

This method prepares the key for lookup.  It replaces the prefix
B<'CW'> or B<'Cw'> with B<'C'> in the key.

=cut
