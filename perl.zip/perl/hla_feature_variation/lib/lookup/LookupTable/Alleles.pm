package lookup::LookupTable::Alleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use lookup::ErrMsgs;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Private Constants
#
################################################################################

sub ERR_CAT { return lookup::ErrMsgs::LOOKUP_CAT; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $version, $key, $list, $predicate, $tools, $error_mgr )
    = @_;

  $error_mgr->hardDieOnError( ERR_CAT, 2, [db::MhcTypes::ALLELE_TABLE, $key],
         $key ne db::MhcTypes::ALLELE_NAME_COL
      && $key ne db::MhcTypes::OLD_ALLELE_NAME_COL
      && $key ne db::MhcTypes::IMGT_HLA_G_CODE_COL
      && $key ne db::MhcTypes::IMGT_HLA_P_CODE_COL );

  my $vals = [
    db::MhcTypes::ALLELE_ID_COL,       db::MhcTypes::ALLELE_NAME_COL,
    db::MhcTypes::OLD_ALLELE_NAME_COL, db::MhcTypes::LOCUS_ID_COL,
    db::MhcTypes::CWD_ALLELE_COL,      db::MhcTypes::IMGT_HLA_G_CODE_COL,
    db::MhcTypes::IMGT_HLA_P_CODE_COL,
  ];

  if ( !util::Constants::EMPTY_LINE($predicate) ) { $predicate .= ' and '; }
  $predicate .= "locus_id in
  (select locus_id from mhc_locus
   where  taxonomy_id = $taxon_id)
";

  my lookup::LookupTable::Alleles $this =
    $that->SUPER::new( $taxon_id, $tools, db::MhcTypes::ALLELE_TABLE, $key,
    $vals, $list, $predicate, $error_mgr );
  ###
  ### Now set the IMGT/HLA version
  ###
  $this->setImgtHlaVersion($version);

  return $this;
}

sub generateTypeToKeyTable {
  my lookup::LookupTable::Alleles $this = shift;
  my ($type) = @_;

  ###############################
  ### Re-Implementable Method ###
  ###############################
  ###
  ### This default table lookup regeneration
  ### assumes the original table has a value
  ### that is a singleton (not a list)
  ###
  return if ( $this->isList );
  my $lookup_table = {};
  foreach my $key ( $this->getKeys ) {
    my $prefix = $this->generatePrefix( $key, $type );
    if ( !defined( $lookup_table->{$prefix} ) ) {
      $lookup_table->{$prefix} = [];
    }
    push( @{ $lookup_table->{$prefix} }, $key );
  }

  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::TRUE;
  $this->{val_col}      = undef;
  $this->_generateValueLookup;
  $this->debugLookup( "IMGT/HLA Version"
      . $this->getImgtHlaVersion
      . " $type Alleles lookup_table" );
}

sub generateCwdLookupTable {
  my lookup::LookupTable::Alleles $this = shift;
  ###
  ### This table lookup regeneration
  ### takes the key_col and determines
  ### the CWD status of its value.
  ### If the value is 'Y', then it
  ### keeps the (key, value) pair,
  ### otherwise it removes it
  ### Also, it reduces it to HLA protein
  ### level.
  ###
  return if ( $this->isList );
  my $lookup_table = {};
  foreach my $key ( $this->getKeys ) {
    my $value = $this->getValue($key);
    my $cwd   = $value->{&db::MhcTypes::CWD_ALLELE_COL};
    next if ( !defined($cwd) || $cwd eq 'N' );
    $lookup_table->{$key} = $key;
    ###
    ### If the hla protein ends in a suffix.  For example, This 
    ### occurs with the NULL ('N') suffix.  This allows the user
    ### to drop the suffix, but still identify the allele as CWD.
    ### 
    if ($key =~ /[A-Z]$/) {
      $key =~ s/[A-Z]$//;
      $lookup_table->{$key} = $key;
    }
    ###
    ### Based on information from Steve March, also
    ### put in 4 digit version of code marked as CWD
    ###
    $key = $this->generatePrefix( $key, db::MhcTypes::HLA_PROTEIN_COL );
    next if ( !defined($key) );
    $lookup_table->{$key} = $key;
  }

  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::FALSE;
  $this->{val_col}      = undef;
  $this->_generateValueLookup;
  $this->debugLookup(
    "IMGT/HLA Version" . $this->getImgtHlaVersion . " CWD lookup_table" );
}

################################################################################

1;

__END__

=head1 NAME

Alleles.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA Allele
table.  This class uses the MHC_SEQ_VAR schema table B<ALLELE>.  The
key is the is defined by B<colum name> in the ALLELE table and the
value is a referenced Perl hash or list of such hashes containing the
following data:

    db::MhcTypes::ALLELE_ID_COL
    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::LOCUS_ID_COL
    db::MhcTypes::CWD_ALLELE_COL,
    db::MhcTypes::IMGT_HLA_G_CODE_COL,
    db::MhcTypes::IMGT_HLA_P_CODE_COL,

The B<column name> can be anyone one of the following columns:

    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::IMGT_HLA_G_CODE_COL,
    db::MhcTypes::IMGT_HLA_P_CODE_COL,

The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles(taxon_id, version, key, list, predicate, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

The B<taxon_id> must be B<9609> (Homo Sapiens), the B<version> is the
IMGT/HLA version B<2> or B<3>, the B<key> must be one of the key
column names as defined above (L<"DESCRIPTION">, B<list> is a Boolean
indicating whether there is a list of values or not, and an optional
B<predicate> defining the valid SQL predicate restricting the data
from the ALLELE table.  

=head2 B<generateTypeToKeyTable(type)>

This re-implementable method regenerates the lookup table for the
class based on a maximum prefix category type.  The value of the list
attribute for the object must be FALSE (0) for the table to be
regenerated.  The type can be any one of the following:

   db::MhcTypes::ALLELE_GROUP_COL  - allele_group
   db::MhcTypes::HLA_PROTEIN_COL   - hla_protein
   db::MhcTypes::CODING_REGION_COL - coding_region

This method regenerates the lookup table to have a list of scalar
values (IMGT/HLA allele names of the given version of the object) as
follows.  For each key that is contained in the lookup table, it
generates the prefix of the key using the B<type> and the method
B<generatePrefix>.  This prefix is the new key in the regenerated
table and a value in the list of values for it is the key of the
current lookup table.  Once the lookup is regenerated it replaces
the current lookup table and regenerates the value lookup.

=head2 B<generateCwdLookupTable>

This method regenerates the lookup table to be only CWD alleles lookup
table based on the B<CWD_ALLELE> column in the B<ALLELE> table. This
method removes all non-CWD alleles (Rare alleles).  If a CWD allele
has a suffix, then the allele without the suffix is also added to the
lookup.  Also, for all alleles, their hla protein prefix using
the method B<generatePrefix> is also added to the table.  The value of the
regenerated table is a scalar that is equal to the key.

=cut
