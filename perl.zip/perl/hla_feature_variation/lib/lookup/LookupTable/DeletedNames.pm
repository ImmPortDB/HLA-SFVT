package lookup::LookupTable::DeletedNames;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::DeletedNames $this = $that->SUPER::new(
    $taxon_id,                          $tools,
    db::MhcTypes::LK_DELETE_NAME_TABLE, db::MhcTypes::DELETED_ALLELE_NAME_COL,
    db::MhcTypes::IDENTICAL_TO_COL,     util::Constants::FALSE,
    undef,                              $error_mgr
  );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

DeletedNames.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA Deleted
names lookup table.  This class uses the MHC_SEQ_VAR schema
B<LK_DELETE_NAME> table.  The key is the column B<DELETED_ALLELE_NAME>
and the value is a single scalar value which is the column
B<IDENTICAL_TO>.  The parent class of this class is
L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::DeletedNames(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
