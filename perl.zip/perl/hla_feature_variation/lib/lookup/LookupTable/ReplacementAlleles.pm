package lookup::LookupTable::ReplacementAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::ReplacementAlleles $this = shift;

  my $tools = $this->{tools};

  $tools->setAllelesLookup;
  my $alleleLookup =
      $tools->getAllelesLookup->getAlleleLookup(db::MhcTypes::IMGT_HLA_V3);

  my $lookup_table = {};
  foreach my $old_allele_name ( $this->getKeys ) {
    my $value      = [];
    my @allele_ids = $this->getValue($old_allele_name);
    foreach my $allele_id (@allele_ids) {
      push( @{$value}, $alleleLookup->getKey($allele_id) );
    }
    $lookup_table->{$old_allele_name} = $value;
  }

  $this->{lookup_table} = $lookup_table;
  $this->_generateValueLookup;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::ReplacementAlleles $this = $that->SUPER::new(
    $taxon_id,                              $tools,
    db::MhcTypes::REPLACEMENT_ALLELE_TABLE, db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::ALLELE_ID_COL,            util::Constants::TRUE,
    undef,                                  $error_mgr
  );

  $this->_generateNewLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

ReplacementAlleles.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the replacement
alleles.  This class uses the MHC_SEQ_VAR schema B<REPLACEMENT_ALLELE>
table.  The key is the column B<OLD_ALLELE_NAME> and the value is a
list of B<ALLELE_NAME> in the B<ALLELE> table (identified by
B<ALLELE_ID>) that replaces the B<OLD_ALLELE_NAME>.  The parent class
of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::ReplacementAlleles(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
