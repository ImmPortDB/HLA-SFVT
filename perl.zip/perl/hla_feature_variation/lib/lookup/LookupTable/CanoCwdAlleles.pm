package lookup::LookupTable::CanoCwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::CanoCwdAlleles $this = shift;

  my $lookup_table = {};
  foreach my $allele_name ( $this->getKeys ) {
    my $allele = $this->getValue($allele_name);
    if ( !util::Constants::EMPTY_LINE( $allele->{hla_protein_name} ) ) {
      $allele->{hla_protein_name} = join( util::Constants::ASTERISK,
        $allele->{locus_name}, $allele->{hla_protein_name} );
    }
    $lookup_table->{ $allele->{allele_name} } = $allele;
  }
  ###
  ### Now we want to make sure that all alleles with
  ### suffixes also have the corresponding allele
  ### without the suffix in the lookup
  ###
  foreach my $allele_name ( keys %{$lookup_table} ) {
    my $allele = $lookup_table->{$allele_name};
    ###
    ### Only process Null alleles
    ###
    next if ( $allele_name !~ /(.+)[A-Z]$/ );
    $allele_name = $1;
    $lookup_table->{$allele_name} = {
      locus_name       => $allele->{locus_name},
      allele_name      => $allele_name,
      hla_protein_name => $allele->{hla_protein_name},
    };
  }

  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::FALSE;
  $this->_generateValueLookup;
  $this->debugLookup("Cano CWD Lookup Table");
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my $vals = [
    db::MhcTypes::ALLELE_NAME_COL, db::MhcTypes::LOCUS_NAME_COL,
    db::MhcTypes::HLA_PROTEIN_NAME_COL,
  ];
  my lookup::LookupTable::CanoCwdAlleles $this =
    $that->SUPER::new( $taxon_id, $tools, db::MhcTypes::LK_CANO_CWD_TABLE,
    db::MhcTypes::ALLELE_NAME_COL, $vals, util::Constants::FALSE, undef,
    $error_mgr );

  $this->_generateNewLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

CanoCwdAlleles.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing full length Cano
CWD Allele lookup table.  This class uses the MHC_SEQ_VAR schema
B<LK_CANO_CWD> table.  The key is defined by catenation of column
separated by an asterisk ('*') as follows:

  - LOCUS_NAME and ALLELE_NAME
  - LOCUS_NAME and HLA_PROTEIN_NAME

and the value is a singleton referenced Perl hash containing the
following keys:

    db::MhcTypes::LOCUS_NAME_COL
    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::HLA_PROTEIN_NAME_COL

Note that both B<ALLELE_NAME> and B<HLA_PROTEIN_NAME> are prefixed
with the B<LOCUS_NAME> and an asterisk ('*').  Also, for any allele
that has a suffix the lookup table also contains the allele without
the suffix.  The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::CanoCwdAlleles(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
