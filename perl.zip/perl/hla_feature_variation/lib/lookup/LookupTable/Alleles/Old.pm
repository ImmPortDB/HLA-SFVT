package lookup::LookupTable::Alleles::Old;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles';

################################################################################
#
#				Private Methods
#
################################################################################

sub _correctForMissingOldAlleles {
  my lookup::LookupTable::Alleles::Old $this = shift;
  ###
  ### Temporarily IMGT/HLA version to 3
  ###
  $this->{imgt_hla_version} = db::MhcTypes::IMGT_HLA_V3;

  my $lookup_table = {};
  foreach my $key ( $this->getKeys ) {
    my @value_structs = $this->getValue($key);
    if ( @value_structs == 1 ) {
      $lookup_table->{$key} = $value_structs[0];
    }
    else {
      ###
      ### The case where there are no old_allele_names
      ### We will support old allele names that can be
      ### converted to version 2.*
      ###
      foreach my $value_struct (@value_structs) {
        my $allele = $value_struct->{allele_name};
        my $nomen     = $this->generateNomenclature($allele);
        my $allele_ok = util::Constants::TRUE;
        foreach my $index ( 0 .. $nomen->{max_index} ) {
          next
            if ( $nomen->{ $this->{nomen_ord}->[$index] } =~ /^\d\d$/ );
          $allele_ok = util::Constants::FALSE;
          last;
        }
        next if ( !$allele_ok );
        my $digits = undef;
        foreach my $index ( 0 .. $nomen->{max_index} ) {
          $digits .= $nomen->{ $this->{nomen_ord}->[$index] };
        }
        my $allele_key =
            $nomen->{name}
          . util::Constants::ASTERISK
          . $digits
          . $nomen->{suffix};
        $value_struct->{old_allele_name} = $allele_key;
        $lookup_table->{$allele_key} = $value_struct;
      }
    }
  }
  ###
  ### Reset to IMGT/HLA version to 2
  ###
  $this->{imgt_hla_version} = db::MhcTypes::IMGT_HLA_V2;

  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::FALSE;
  $this->_generateValueLookup;
  $this->debugLookup( "IMGT/HLA Version"
      . $this->getImgtHlaVersion . " "
      . $this->keyCol
      . " lookup_table" );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::Alleles::Old $this =
    $that->SUPER::new( $taxon_id, db::MhcTypes::IMGT_HLA_V2,
    db::MhcTypes::OLD_ALLELE_NAME_COL,
    util::Constants::TRUE, undef, $tools, $error_mgr );

  $this->_correctForMissingOldAlleles;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Old.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA B<version 2>
alleles.  This class uses the MHC_SEQ_VAR schema table B<ALLELE>.  The
key is the the column B<OLD_ALLELE_NAME>, and the value is a
referenced Perl hash or list of such hashes containing the following
data:

    db::MhcTypes::ALLELE_ID_COL
    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::LOCUS_ID_COL
    db::MhcTypes::CWD_ALLELE_COL,
    db::MhcTypes::IMGT_HLA_G_CODE_COL,
    db::MhcTypes::IMGT_HLA_P_CODE_COL,

The parent class of this class is L<lookup::LookupTable::Alleles>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles::Old(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
