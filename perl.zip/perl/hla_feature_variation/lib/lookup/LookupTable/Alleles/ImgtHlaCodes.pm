package lookup::LookupTable::Alleles::ImgtHlaCodes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use util::Constants;

use lookup::ErrMsgs;

use base 'lookup::LookupTable::Alleles';

################################################################################
#
#				Private Constants
#
################################################################################

sub ERR_CAT { return lookup::ErrMsgs::LOOKUP_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::Alleles::ImgtHlaCodes $this = shift;

  my $lookup_table = {};
  foreach my $key ( $this->getKeys ) {
    my %values        = ();
    my @value_structs = $this->getValue($key);
    foreach my $value_struct (@value_structs) {
      my $allele = $value_struct->{allele_name};
      $values{$allele} = util::Constants::EMPTY_STR;
      ###
      ### This allows alleles with suffix to
      ### be present in the code swithout suffix also
      ###
      $allele =~ s/[A-Z]$//;
      $values{$allele} = util::Constants::EMPTY_STR;
    }
    my @alleles = sort keys %values;
    next if ( scalar @alleles == 0 );
    $lookup_table->{$key} = [@alleles];
  }
  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::TRUE;
  $this->{val_col}      = undef;
  $this->_generateValueLookup;
  $this->debugLookup( "IMGT/HLA Version"
      . $this->getImgtHlaVersion
      . $this->keyCol
      . " lookup_table" );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $imgt_hla_code_col, $taxon_id, $tools, $error_mgr ) = @_;

  $error_mgr->hardDieOnError( ERR_CAT, 3, [$imgt_hla_code_col],
      $imgt_hla_code_col ne db::MhcTypes::IMGT_HLA_G_CODE_COL
      && $imgt_hla_code_col ne db::MhcTypes::IMGT_HLA_P_CODE_COL );

  my $predicate = $imgt_hla_code_col . ' is not null';

  my lookup::LookupTable::Alleles::ImgtHlaCodes $this =
    $that->SUPER::new( $taxon_id, db::MhcTypes::IMGT_HLA_V3, $imgt_hla_code_col,
    util::Constants::TRUE, $predicate, $tools, $error_mgr );
  ###
  ### Standard P and G codes must make sure that values are
  ### the allele names and that suffix do not matter in
  ### determine membership in the code.
  ###
  $this->_generateNewLookupTable;

  return $this;
}

sub prepareKey {
  my lookup::LookupTable::Alleles::ImgtHlaCodes $this = shift;
  my ($key) = @_;

  $key = uc($key);
  $key =~ s/^CW/C/;

  return $key;
}

sub generateTypeToKeyTable {
  my lookup::LookupTable::Alleles::ImgtHlaCodes $this = shift;
  my ($type) = @_;

  my $lookup_table = {};
  foreach my $key ( $this->getKeys ) {
    my %values  = ();
    my @alleles = $this->getValue($key);
    foreach my $allele (@alleles) {
      my $prefix = $this->generatePrefix( $allele, $type );
      next if ( !defined($prefix) );
      $values{$prefix} = util::Constants::EMPTY_STR;
    }
    @alleles = sort keys %values;
    next if ( scalar @alleles == 0 );
    $lookup_table->{$key} = [@alleles];
  }
  $this->{lookup_table} = $lookup_table;
  $this->_generateValueLookup;
  $this->debugLookup( "IMGT/HLA Version"
      . $this->getImgtHlaVersion
      . " $type for "
      . $this->keyCol
      . " lookup_table" );
}

################################################################################

1;

__END__

=head1 NAME

ImgtHlaCodes.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the IMGT/HLA G and
P Codes from The B<ALLELE> table.  The key is the column
B<imgt_hla_code_col> (IMGT_HLA_G_CODE or IMGT_HLA_P_CODE) in the
B<ALLELE> table and the value is a list of IMGT/HLA version 3
alleles contained in the code group.  The parent class of this class
is L<lookup::LookupTable::Alleles>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles::ImgtHlaCodes(imgt_hla_code_col, taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

The B<imgt_hal_code_col> must be either IMGT_HLA_G_CODE or
IMGT_HLA_P_CODE, otherwise a fatal error occurs.  The B<taxon_id> must
be B<9606>.  This constructor regenerates the lookup table so that the
key is an IMGT/HLA code (G-Code or P-Code) and the value is the list
of verion 3 alleles in the code group.  Further, if an allele in a
code contains a suffix, then the corresponding allele without the
suffix is also in the code group.

=head2 B<generateTypeToKeyTable(type)>

This method re-implements the method declared in the parent class.
This method regenerates the lookup table for the class based on a
maximum prefix category type.  The type can be any one of the
following:

   db::MhcTypes::ALLELE_GROUP_COL  - allele_group
   db::MhcTypes::HLA_PROTEIN_COL   - hla_protein
   db::MhcTypes::CODING_REGION_COL - coding_region

This method regenerates the lookup table so that the key is an
IMGT/HLA code and the value is a list of scalar values (IMGT/HLA
allele names of the given version of the object) as follows.  For each
key that is contained in the lookup table, it generates the prefix of
each of value in the current lookup for the key using the B<type> and
the method B<generatePrefix>.  The key is now associated with the list
of prefix values.  Once the lookup is regenerated, it replaces the
current lookup table and regenerates the value lookup.

=head2 B<$prepared_key = prepareKey(key)>

This method prepares the key for lookup.  It upper-cases the key
replaces the prefix B<'CW'> with B<'C'> in it.

=cut
