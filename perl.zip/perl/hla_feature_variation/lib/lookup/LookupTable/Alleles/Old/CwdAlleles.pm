package lookup::LookupTable::Alleles::Old::CwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles::Old';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;

  my lookup::LookupTable::Alleles::Old::CwdAlleles $this =
    $that->SUPER::new( $taxon_id, $tools, $error_mgr );

  $this->generateCwdLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

CwdAlleles.pm

=head1 DESCRIPTION

This class defines the lookup table to be only CWD alleles in IMGT/HLA
B<version 2> format (B<OLD_ALLELE_NAME> column) in the B<ALLELE> table
based on the B<CWD_ALLELE> column.  Non-CWD alleles (Rare alleles) are
removed.  If a CWD allele has a suffix, then the allele without the
suffix is also added to the lookup.  Also, for all alleles, their hla
protein prefix is also added to the table.  The value of the
regenerated table is a scalar that is equal to the key.

The parent class of this class is L<lookup::LookupTable::Alleles::Current>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles::Old::CwdAlleles(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
