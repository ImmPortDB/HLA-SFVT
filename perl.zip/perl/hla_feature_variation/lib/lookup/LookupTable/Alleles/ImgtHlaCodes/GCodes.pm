package lookup::LookupTable::Alleles::ImgtHlaCodes::GCodes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles::ImgtHlaCodes';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::Alleles::ImgtHlaCodes::GCodes $this =
    $that->SUPER::new( db::MhcTypes::IMGT_HLA_G_CODE_COL,
		       $taxon_id, $tools, $error_mgr );
  return $this;
}

################################################################################

1;

__END__

=head1 NAME

GCodes.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the IMGT/HLA
G-Codes from The B<ALLELE> table.  The key is the column,
B<IMGT_HLA_G_CODE> in the B<ALLELE> table and the value is a list of
IMGT/HLA version 3 alleles contained in the G-Code group including
corresponding alleles without suffix.  The parent class of this class
is L<lookup::LookupTable::Alleles::ImgtHlaCodes>.

=head1 METHODS

The following methods are exported by this class.

head2 B<new lookup::LookupTable::Alleles::ImgtHlaCodes::GCodes(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
