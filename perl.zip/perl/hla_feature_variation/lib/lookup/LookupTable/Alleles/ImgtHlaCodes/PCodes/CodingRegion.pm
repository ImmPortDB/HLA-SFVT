package lookup::LookupTable::Alleles::ImgtHlaCodes::PCodes::CodingRegion;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles::ImgtHlaCodes::PCodes';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::Alleles::ImgtHlaCodes::PCodes::CodingRegion $this =
    $that->SUPER::new( $taxon_id, $tools, $error_mgr );

  $this->generateTypeToKeyTable(db::MhcTypes::CODING_REGION_COL);

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

CodingRegion.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the IMGT/HLA
P-Codes from The B<ALLELE> table with B<coding_region> prefix.  The
key is the column, B<IMGT_HLA_P_CODE> in the B<ALLELE> table and the
value is a list of IMGT/HLA version 3 alleles, contained in the
P-Code group including corresponding alleles without suffix, that have
been prefixed to B<coding_region>.  The parent class of this class is
L<lookup::LookupTable::Alleles::ImgtHlaCodes::PCodes>.

=head1 METHODS

The following methods are exported by this class.

head2 B<new lookup::LookupTable::Alleles::ImgtHlaCodes::PCodes::CodingRegion(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
xrs1
