package lookup::LookupTable::Alleles::Current;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::Alleles::Current $this =
    $that->SUPER::new( $taxon_id, db::MhcTypes::IMGT_HLA_V3,
    db::MhcTypes::ALLELE_NAME_COL, util::Constants::FALSE, undef, $tools,
    $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Current.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA B<version 3>
alleles.  This class uses the MHC_SEQ_VAR schema table B<ALLELE>.  The
key is the the column B<ALLELE_NAME>, and the value is a referenced
Perl hash or list of such hashes containing the following data:

    db::MhcTypes::ALLELE_ID_COL
    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::LOCUS_ID_COL
    db::MhcTypes::CWD_ALLELE_COL,
    db::MhcTypes::IMGT_HLA_G_CODE_COL,
    db::MhcTypes::IMGT_HLA_P_CODE_COL,

The parent class of this class is L<lookup::LookupTable::Alleles>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles::Current(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
