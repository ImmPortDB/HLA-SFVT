package lookup::LookupTable::Alleles::Current::AlleleGroup;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use base 'lookup::LookupTable::Alleles::Current';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;

  my lookup::LookupTable::Alleles::Current::AlleleGroup $this =
    $that->SUPER::new( $taxon_id, $tools, $error_mgr );

  $this->generateTypeToKeyTable(db::MhcTypes::ALLELE_GROUP_COL);

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

AlleleGroup.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing the IMGT/HLA
B<version 3> alleles from The B<ALLELE> table with their B<allele_group>
prefix.  The key is the allele group prefix of the alleles using the
column B<ALLELE_NAME> in the B<ALLELE> table and the value is the key.
The parent class of this class is
L<lookup::LookupTable::Alleles::Current>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::Alleles::Current::AlleleGroup(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> must be B<9606>.

=cut
