package lookup::LookupTable::RegionCwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$) {
  my ( $that, $taxon_id, $pop_area_name, $locus_name, $tools, $error_mgr ) = @_;
  my $vals = [
    db::MhcTypes::ALLELE_NAME_COL, db::MhcTypes::POP_AREA_NAME_COL,
    db::MhcTypes::LOCUS_NAME_COL,  db::MhcTypes::CWD_ALLELE_COL,
    db::MhcTypes::REGION_FREQUENCY_COL,
  ];

  my $predicate =
    "pop_area_name = '$pop_area_name' and locus_name = '$locus_name'";

  my lookup::LookupTable::RegionCwdAlleles $this =
    $that->SUPER::new( $taxon_id, $tools,
    db::MhcTypes::LK_REGION_CWD_ALLELE_TABLE,
    db::MhcTypes::ALLELE_NAME_COL, $vals, util::Constants::FALSE, $predicate,
    $error_mgr );

  return $this;
}

sub prepareKey {
  my lookup::LookupTable::RegionCwdAlleles $this = shift;
  my ($key) = @_;

  my $hlaProtein = $this->generatePrefix($key, db::MhcTypes::HLA_PROTEIN_COL);
  $hlaProtein =~ s/[A-Z]$//;

  return $hlaProtein;
}

################################################################################

1;

__END__

=head1 NAME

RegionCwdAlleles.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing Region specific
CWD Allele lookup table based on population area and locus name.  This
class uses the MHC_SEQ_VAR schema B<LK_REGION_CWD_ALLELE> table.  The
key column is B<ALLELE_NAME> and the value is a singleton referenced
Perl hash containing the following keys:

    db::MhcTypes::POP_AREA_NAME_COL
    db::MhcTypes::ALLELE_NAME_COL
    db::MhcTypes::LOCUS_NAME_COL
    db::MhcTypes::CWD_ALLELE_COL

The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::RegionCwdAlleles(taxon_id, pop_area_name, locus_name, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=head2 B<$prepared_key = prepareKey(key)>

This method prepares the key for lookup.  The key must be an IMGT/HLA
version 3 allele including a short locus name.  The prepared key is
the hla protein prefix without suffix, if there is one.

=cut
