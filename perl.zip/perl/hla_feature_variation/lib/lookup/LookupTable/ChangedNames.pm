package lookup::LookupTable::ChangedNames;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

use fields
  qw (
  patterns
);

################################################################################
#
#				   Constants
#
################################################################################

sub PATTERNS {
  return [
    ###
    ### Generate 5-digit prefixes that do not exist
    ### in the original table for 7 digit data
    ###
    '^(\w+\*\d\d\d\d\d)\d\d[A-Z]?$',
    ###
    ### Generate 4-digit prefixes that do not exist
    ### in the original table for 6 or 8 digit data
    ###
    '^(\w+\*\d\d\d\d)\d\d(\d\d)?[A-Z]?$',
    ###
    ### Generate 6-digit prefixes that do not exist
    ### in the original table for 8 digit data
    ###
    '^(\w+\*\d\d\d\d\d\d)\d\d'
  ];
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::ChangedNames $this = shift;
  ###
  ### Generate the singleton lists for the data in the table
  ###
  my $lookup_table = {};
  foreach my $old_allele_name ( $this->getKeys ) {
    my $new_allele_name = $this->getValue($old_allele_name);
    $lookup_table->{$old_allele_name} = [$new_allele_name];
  }
  ###
  ### Generate the pattern data lists
  ###
  foreach my $old_allele_name ( $this->getKeys ) {
    my $new_allele_name = $this->getValue($old_allele_name);
    foreach my $pattern ( @{ $this->{patterns} } ) {
      if ( $old_allele_name =~ /$pattern/ ) {
        my $short_name = $1;
        ###
        ### Skip the short name if it is already
        ### defined in the original table
        ###
        next if ( $this->keyDefined($short_name) );
        if ( !defined( $lookup_table->{$short_name} ) ) {
          $lookup_table->{$short_name} = [];
        }
        push( @{ $lookup_table->{$short_name} }, $new_allele_name );
      }
    }
  }
  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::TRUE;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my lookup::LookupTable::ChangedNames $this = $that->SUPER::new(
    $taxon_id,                          $tools,
    db::MhcTypes::LK_CHANGE_NAME_TABLE, db::MhcTypes::OLD_ALLELE_NAME_COL,
    db::MhcTypes::NEW_ALLELE_NAME_COL,  util::Constants::FALSE,
    undef,                              $error_mgr
  );
  ###
  ### Find the differing version of allele name codes
  ### and change the list type to TRUE(1).
  ###
  $this->{patterns} = PATTERNS;
  $this->_generateNewLookupTable;

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

ChangedNames.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA changed
name lookup table.  This class uses the MHC_SEQ_VAR schema
B<LK_CHANGE_NAME> table.  The key is based on the column
B<OLD_ALLELE_NAME> and the values are list B<NEW_ALLELE_NAME> column
values defined as follows.  There are four (4) subcases:

For each B<OLD_ALLELE_NAME>, the lists are singleton values consisting
of the B<NEW_ALLELE_NAME> column.

For 5-digit prefixes of B<OLD_ALLELE_NAME> that do not exist in the
the table, but have seven-digit names in the table, the 5-digit prefix
is mapped to the list of 7-digit B<NEW_ALLELE_NAME> that have this
5-digit prefix.

For 6-digit prefixes of B<OLD_ALLELE_NAME> that do not exist in the
table, but have 8-digit names in the table, the 6-digit prefix is
mapped to the list of of 8-digit B<NEW_ALLELE_NAME> that have this
6-digit prefix.

For 4-digit prefixes of B<OLD_ALLELE_NAME> that do not exit in the
table, but have 6-digit or 8-digit names in the table, the 4-digit
prefix is mapped to the of 6-digit and 8-digit B<NEW_ALLELE_NAME> that
have this 4-digit prefix.

The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::ChangedNames(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
