package lookup::LookupTable::NmdpCodes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Private Methods
#
################################################################################

sub _generateNewLookupTable {
  my lookup::LookupTable::NmdpCodes $this = shift;

  my $lookup_table = {};
  foreach my $nmdp_code ( $this->getKeys ) {
    my @nmdp_data = $this->getValue($nmdp_code);
    foreach my $nmdp_datum (@nmdp_data) {
      next
        if (
        !db::MhcTypes::DEFINED_IMGT_HLA_VERSION(
          $nmdp_datum->{imgt_hla_version}
        )
        );
      $nmdp_datum->{subtype} = [ split( /\//, $nmdp_datum->{subtype} ) ];
      my $key = $this->newPrepareKey($nmdp_datum);
      $lookup_table->{$key} = $nmdp_datum;
    }
  }
  $this->{lookup_table} = $lookup_table;
  $this->{list}         = util::Constants::FALSE;
  $this->debugLookup("NMDP Code Lookup Table");
}

sub _isHlaProteinField {
  my lookup::LookupTable::NmdpCodes $this = shift;
  my ( $version, $subtype ) = @_;

  foreach my $comp ( @{$subtype} ) {
    my $len = length($comp);
    return util::Constants::FALSE
      if ( ( $version == db::MhcTypes::IMGT_HLA_V3 && $len != 2 && $len != 3 )
      || ( $version == db::MhcTypes::IMGT_HLA_V2 && $len != 2 ) );
  }

  return util::Constants::TRUE;

}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;

  my $vals = [
    db::MhcTypes::NMDP_CODE_COL, db::MhcTypes::IMGT_HLA_VERSION_COL,
    db::MhcTypes::SUBTYPE_COL,
  ];

  my lookup::LookupTable::NmdpCodes $this =
    $that->SUPER::new( $taxon_id, $tools, db::MhcTypes::LK_NMDP_CODE_TABLE,
    db::MhcTypes::NMDP_CODE_COL, $vals, util::Constants::TRUE, undef,
    $error_mgr );

  $this->_generateNewLookupTable;

  return $this;
}

sub newPrepareKey {
  my lookup::LookupTable::NmdpCodes $this = shift;
  my ($key_comps) = @_;
  return join( util::Constants::COLON,
    $key_comps->{imgt_hla_version},
    $key_comps->{nmdp_code}
  );

}

sub nmdpKeyDefined {
  my lookup::LookupTable::NmdpCodes $this = shift;
  my ( $imgt_hla_version, $nmdp_code ) = @_;

  my $nmdp_key = {
    imgt_hla_version => $imgt_hla_version,
    nmdp_code        => $nmdp_code,
  };
  return $this->keyDefined( $this->newPrepareKey($nmdp_key) );
}

sub getNmdpAlleles {
  my lookup::LookupTable::NmdpCodes $this = shift;
  my ($nmdpCode) = @_;

  my @alleles = ();
  return @alleles if ( !defined($nmdpCode) );
  my $key = {
    digits           => undef,
    imgt_hla_version => undef,
    nmdp_code        => undef,
  };
  if ( $nmdpCode =~ /\*?(\d+)(:?)([A-Z][A-Z]+)$/ ) {
    $key->{digits}    = $1;
    $key->{nmdp_code} = $3;

    my $version = $2;
    $key->{imgt_hla_version} =
      ( !util::Constants::EMPTY_LINE($version)
        && $version eq util::Constants::COLON )
      ? db::MhcTypes::IMGT_HLA_V3
      : db::MhcTypes::IMGT_HLA_V2;
  }
  return @alleles
    if ( !defined( $key->{nmdp_code} )
    || !defined( $key->{digits} )
    || !defined( $key->{imgt_hla_version} )
    || !$this->valueDefined( $this->newPrepareKey($key) ) );
  my $nmdp_data = $this->getValue( $this->newPrepareKey($key) );
  my $subtype   = $nmdp_data->{subtype};
  my $isHlaProteinField =
    $this->_isHlaProteinField( $key->{imgt_hla_version}, $subtype );
  my $found_prefix = util::Constants::FALSE;
  foreach my $nmdp_datum ( @{$subtype} ) {
    if ($isHlaProteinField) {
      $found_prefix = util::Constants::TRUE;
      if ( $key->{imgt_hla_version} eq db::MhcTypes::IMGT_HLA_V3 ) {
        push( @alleles, $key->{digits} . util::Constants::COLON . $nmdp_datum );
      }
      else {
        push( @alleles, $key->{digits} . $nmdp_datum );
      }
    }
    else {
      ###
      ### Sometimes the first allele has been replaced
      ### and its allele group is different.  So
      ### it may be that the other allele group is
      ### is appropriate.  We we err on the side of
      ### accepting, any allele group in the list.
      ###
      my $digits = $key->{digits};
      $found_prefix =
        ( $nmdp_datum =~ /^$digits/ ) ? util::Constants::TRUE : $found_prefix;
      push( @alleles, $nmdp_datum );
    }
  }
  return @alleles if ($found_prefix);
  ###
  ### Failed NMDP code
  ###
  @alleles = ();
  return @alleles;
}

################################################################################

1;

__END__

=head1 NAME

NmdpCodes.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing NMDP Codes lookup
table.  This class uses the MHC_SEQ_VAR schema B<LK_NMDP_CODE> table.
The key is the catenation of the columns B<IMGT_HLA_VERSION> and
B<NMDP_CODE> separated by a colon (':') and the value is a the list
values identified by the column B<SUBTYPE>.  The parent class of this
class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::NmdpCodes(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=head2 B<$nmdp_key = newPrepareKey(key_comps)>

This method constructs the key that needs to be applied before using
the following methods: B<keyDefined>, B<valueDefined>, and
B<getValue>.  The B<key_comps> is a referenced Perl hash that contains
the components:

    imgt_hla_version - IMGT/HLA version 2 or 3
    nmdp_code        - the nmdp code

=head2 B<nmdpKeyDefined(imgt_hla_version, nmdp_code)>

The method can be used instead of using the composition of the methods
B<newPrepareKey> with B<keyDefined>.  It returns a Boolean value that
indicates whether the NMDP code is defined.

=head2 B<@alleles = getNmdpAlleles(nmdp_code)>

The method returns the set of alleles associated with the
B<nmdp_code>.  If the nmdp code is unknown or inconsistent, then an
empty list is returned.  The B<nmdp_code> is case-insensitive.  The
IMGT/HLA version 2 NMDP code is of the format B<02AB> and the version
3 format is B<02:AB>.

=cut
