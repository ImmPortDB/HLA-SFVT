package lookup::LookupTable::CwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'lookup::LookupTable';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $taxon_id, $tools, $error_mgr ) = @_;
  my $vals = [
    db::MhcTypes::CWD_CATEGORY_COL,
    db::MhcTypes::HLA_PROTEIN_NAME_COL,
    db::MhcTypes::IMGT_ACCESSION_COL,
    db::MhcTypes::LOCUS_NAME_COL,
  ];
  my lookup::LookupTable::CwdAlleles $this =
    $that->SUPER::new( $taxon_id, $tools, db::MhcTypes::LK_CWD_ALLELE_TABLE,
    db::MhcTypes::ALLELE_NAME_COL, $vals, util::Constants::FALSE, undef,
    $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

CwdAlleles.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing CWD Allele lookup
table.  This class uses the MHC_SEQ_VAR schema table B<LK_CWD_ALLELE>.
The key is the column B<ALLELE_NAME> and the value is is a singleton 
referenced Perl hash containing the following keys:

    db::MhcTypes::FOUR_DIGIT_CODE_COL
    db::MhcTypes::LOCUS_NAME_COL

The parent class of this class is L<lookup::LookupTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable::CwdAlleles(taxon_id, tools, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
The B<taxon_id> is B<9606>.

=cut
