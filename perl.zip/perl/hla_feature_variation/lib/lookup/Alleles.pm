package lookup::Alleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use lookup::ErrMsgs;

use fields qw (
  allele_suffixes
  common_groups
  error_mgr
  lookup
  taxon_id
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The alleles lookup
###
sub ROOT_PATH { return 'lookup::LookupTable::Alleles'; }

sub ALLELES_LOOKUP       { return 'alleles'; }
sub ALLELE_GROUP_LOOKUP  { return 'AlleleGroup'; }
sub CODING_REGION_LOOKUP { return 'CodingRegion'; }
sub HLA_PROTEIN_LOOKUP   { return 'HlaProtein'; }
###
### Allele Suffixes
###
sub ALLELE_SUFFIXES { return [ 'N', 'C', 'L', 'S', 'A', 'Q', ]; }
###
### Special Loci
###
sub MICA { return 'MICA'; }
sub MICB { return 'MICB'; }

sub COMMON_GROUPS {
  return {
    'A' => { '92' => '02', },
    'B' => { '95' => '15', },
  };
}
###
### Error Category
###
sub ERR_CAT { return lookup::ErrMsgs::ALLELES_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getAllele {
  my lookup::Alleles $this = shift;
  my ( $locus, $allele, $version ) = @_;
  ###
  ### First check the locus
  ###
  my $locus_data = $this->getLocusData($locus);
  return undef if ( !defined($locus_data) );
  ###
  ### If the allele has a locus name, then check to see that
  ### it is consistent with the locus
  ###
  my $locus_name = undef;
  ( $locus_name, $allele ) = $this->getLocusAndName($allele);
  if ( defined($locus_name) ) {
    my $allele_locus_id = $this->getLocusId($locus_name);
    return undef if ( $locus_data->{locus_id} != $allele_locus_id );
  }
  ###
  ### Now return the standard allele name
  ###
  $locus_name = $locus_data->{short_locus_name};
  if ( $version eq db::MhcTypes::IMGT_HLA_V2
    && $locus_name eq 'C' )
  {
    $locus_name = 'Cw';
  }
  return join( util::Constants::ASTERISK, $locus_name, $allele );
}

sub _getLookup {
  my lookup::Alleles $this = shift;
  my ( $version, $lookup_type ) = @_;

  my $lookup = $this->{lookup}->{$version};
  return undef if ( !defined($lookup) );
  if ( !defined( $lookup->{$lookup_type} ) ) {
    my $class_comp = undef;
    if ( $version == db::MhcTypes::IMGT_HLA_V2 ) {
      $class_comp = 'Old';
    }
    elsif ( $version == db::MhcTypes::IMGT_HLA_V3 ) {
      $class_comp = 'Current';
    }
    my $class = join( util::Constants::DOUBLE_COLON, ROOT_PATH, $class_comp );
    if ( $lookup_type ne ALLELES_LOOKUP ) {
      $class .= util::Constants::DOUBLE_COLON . $lookup_type;
    }
    my @eval_array = (
      'use ' . $class . ';',
      '$lookup->{$lookup_type} =',
      'new ' . $class,
      '  ($this->{taxon_id},',
      '   $this->{tools},',
      '   $this->{error_mgr});'
    );
    my $eval_str = join( util::Constants::NEWLINE, @eval_array );
    $this->{error_mgr}->printDebug("Lookup Table:  eval_str = $eval_str");
    eval $eval_str;
    my $status = $@;
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 1,
      [ $status, $eval_str ],
      defined($status) && $status
    );
  }
  return $lookup->{$lookup_type};
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my lookup::Alleles $this = shift;
  my ( $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{allele_suffixes} = ALLELE_SUFFIXES;
  $this->{common_groups}   = COMMON_GROUPS;
  $this->{error_mgr}       = $error_mgr;
  $this->{taxon_id}        = $taxon_id;
  $this->{tools}           = $tools;
  ###
  ### Lookup for alleles
  ###
  $this->{lookup} = {
    &db::MhcTypes::IMGT_HLA_V2 => {
      ALLELE_GROUP_LOOKUP  => undef,
      ALLELES_LOOKUP       => undef,
      CODING_REGION_LOOKUP => undef,
      HLA_PROTEIN_LOOKUP   => undef,
    },
    &db::MhcTypes::IMGT_HLA_V3 => {
      ALLELE_GROUP_LOOKUP  => undef,
      ALLELES_LOOKUP       => undef,
      CODING_REGION_LOOKUP => undef,
      HLA_PROTEIN_LOOKUP   => undef,
    },
  };

  return $this;
}

################################################################################
#
#				 Testing Methods
#
################################################################################

sub alleleExists {
  my lookup::Alleles $this = shift;
  my ( $locus, $allele, $version ) = @_;

  $allele = $this->_getAllele( $locus, $allele, $version );
  return util::Constants::FALSE if ( !defined($allele) );
  my $lookup = $this->getAlleleLookup($version);
  return $lookup->keyDefined($allele);
}

sub alleleSuffix {
  my lookup::Alleles $this = shift;
  my ($suffix) = @_;

  foreach my $allele_suffix ( @{ $this->{allele_suffixes} } ) {
    return util::Constants::TRUE if ( uc($suffix) eq $allele_suffix );
  }
  return util::Constants::FALSE;
}

sub isMIC {
  my lookup::Alleles $this = shift;
  my ($locus) = @_;

  $locus = uc($locus);
  return ( $locus eq MICA || $locus eq MICB )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

################################################################################
#
#				 Lookup Methods
#
################################################################################

sub getAlleleLookup {
  my lookup::Alleles $this = shift;
  my ($version) = @_;

  return $this->_getLookup( $version, ALLELES_LOOKUP );
}

sub getCodingRegionLookup {
  my lookup::Alleles $this = shift;
  my ($version) = @_;

  return $this->_getLookup( $version, CODING_REGION_LOOKUP );
}

sub getHlaProteinLookup {
  my lookup::Alleles $this = shift;
  my ($version) = @_;

  return $this->_getLookup( $version, HLA_PROTEIN_LOOKUP );
}

sub getAlleleGroupLookup {
  my lookup::Alleles $this = shift;
  my ($version) = @_;

  return $this->_getLookup( $version, ALLELE_GROUP_LOOKUP );
}

################################################################################
#
#				 Getter Methods
#
################################################################################

sub getLocusAndName {
  my lookup::Alleles $this = shift;
  my ($allele_name) = @_;

  my $locus = undef;
  my $name  = $allele_name;
  if ( $allele_name =~ /^(.+)\*(.+)$/ ) {
    $locus = $1;
    $name  = uc($2);
  }
  return ( $locus, $name );
}

sub getLocusData {
  my lookup::Alleles $this = shift;
  my ($locus) = @_;
  ###
  ### If there is no locus, then immediate return
  ###
  return undef if ( util::Constants::EMPTY_LINE($locus) );
  ###
  ### If locus is an id, get the locus name
  ### for it from the database, or die
  ###
  if ( $locus =~ /^\d+$/ ) {
    my $locusName =
      db::MhcTypes::getName( db::MhcTypes::MHC_LOCUS_TABLE, $locus );
    return undef if ( util::Constants::EMPTY_LINE($locusName) );
    $locus = $locusName;
  }
  ###
  ### Now process the locus name...
  ###
  my $locusName = uc($locus);
  if ( $locusName !~ /MIC|TAP/ && $locusName !~ /^HLA-/ ) {
    $locusName = 'HLA-' . $locusName;
  }
  if ( $locusName eq 'HLA-CW' ) { $locusName = 'HLA-C'; }

  my $shortLocusName = $locusName;
  $shortLocusName =~ s/^HLA-//;

  my $altLocusName = $shortLocusName;
  if ( $altLocusName eq 'C' ) { $altLocusName = 'Cw'; }
  ###
  ### Determine Locus
  ###
  my $locusId =
    db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locusName,
    $this->{taxon_id} );
  ###
  ### If there is no locus name for the taxon_id, return undef
  ###
  return undef if ( util::Constants::EMPTY_LINE($locusId) );

  my $locusData = {
    full_locus_name  => $locusName,
    short_locus_name => $shortLocusName,
    alt_locus_name   => $altLocusName,
    locus_id         => $locusId,
  };

  return $locusData;
}

sub getLocusId {
  my lookup::Alleles $this = shift;
  my ($locus) = @_;

  my $locusData = $this->getLocusData($locus);
  return undef if ( !defined($locusData) );
  return $locusData->{locus_id};
}

sub getAllele {
  my lookup::Alleles $this = shift;
  my ( $locus, $allele, $version ) = @_;

  return undef if ( !$this->alleleExists( $locus, $allele, $version ) );
  my $lookup = $this->getAlleleLookup($version);
  return $lookup->getValue( $this->_getAllele( $locus, $allele, $version ) );
}

sub getAlleles {
  my lookup::Alleles $this = shift;
  my ( $locus, $allele, $version ) = @_;
  ###
  ### Return immediately if unknown version.
  ###
  my @alleles = ();
  return @alleles if ( !db::MhcTypes::DEFINED_IMGT_HLA_VERSION($version) );
  ###
  ### Generate standard format for allele
  ### Return immediately if unknown format
  ###
  $allele = $this->_getAllele( $locus, $allele, $version );
  return @alleles if ( !defined($allele) );
  ###
  ### Now parse the allele
  ###
  my $lookup   = $this->getAlleleLookup($version);
  my $nomen    = $lookup->generateNomenclature($allele);
  my $max_comp = $nomen->{max_comp};
  ###
  ### Determine lookup to determine the list of
  ### alleles associated with the allele
  ###
  my $alookup = undef;
  if ( $max_comp eq db::MhcTypes::ALLELE_GROUP_COL ) {
    $alookup = $this->getAlleleGroupLookup($version);
  }
  elsif ( $max_comp eq db::MhcTypes::HLA_PROTEIN_COL ) {
    $alookup = $this->getHlaProteinLookup($version);
  }
  elsif ( $max_comp eq db::MhcTypes::CODING_REGION_COL ) {
    $alookup = $this->getCodingRegionLookup($version);
  }
  if ( defined($alookup) ) {
    @alleles = $alookup->getValue($allele);
  }
  else {
    my $alleleData = $lookup->getValue($allele);
    if ( defined($alleleData) ) { @alleles = ($allele); }
  }

  return @alleles;
}

sub convertAllele {
  my lookup::Alleles $this = shift;
  my ( $locus, $allele, $version ) = @_;
  ###
  ### Get the alleles associated with the allele
  ### Return immediately if there are no alleles
  ###
  my @alleles = $this->getAlleles( $locus, $allele, $version );
  return undef if ( @alleles == 0 );
  ###
  ### Now parse the allele
  ###
  $allele = $this->_getAllele( $locus, $allele, $version );
  my $lookup   = $this->getAlleleLookup($version);
  my $nomen    = $lookup->generateNomenclature($allele);
  my $max_comp = $nomen->{max_comp};
  ###
  ### Determine converted allele version information
  ###
  my $ocomp   = undef;
  my $olookup = undef;
  if ( $version == db::MhcTypes::IMGT_HLA_V2 ) {
    $ocomp   = db::MhcTypes::ALLELE_NAME_COL;
    $olookup = $this->getAlleleLookup(db::MhcTypes::IMGT_HLA_V3);
  }
  elsif ( $version == db::MhcTypes::IMGT_HLA_V3 ) {
    $ocomp   = db::MhcTypes::OLD_ALLELE_NAME_COL;
    $olookup = $this->getAlleleLookup(db::MhcTypes::IMGT_HLA_V2);
  }
  ###
  ### Now determine coverted allele
  ###
  my $alleleData = $lookup->getValue( $alleles[0] );
  return $olookup->generatePrefix( $alleleData->{$ocomp}, $max_comp );
}

################################################################################

1;

__END__

=head1 NAME

Alleles.pm

=head1 DESCRIPTION

This class defines the basic allele name lookup for IMGT/HLA human
data using the B<ALLELE> table in the MHC_SEQ_VAR schema.  Both
version 2 and 3 formats are supported.  Allele names require the locus
name.  Besides, the standard allele lookup, there are also reduced
allele lookups.  That is, allele names of the following sorts can be
searched:

   Reduced Allele  Description
   --------------- ---------------------------------------------------
   allele group    allele names with only allele_group field
   hla protein     allele names with only allele_group and hla_protein
                   fields
   coding_region   allele names with only allele_group, hla_protein, 
                   and coding_region fields

An allele lookup table is loaded only when first accessed (that is,
lazy loading).

The current IMGT/HLA version supported include B<2> and B<3>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::Alleles(taxon_id, tools, error_mgr)>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).
Currently the only supported B<taxon_id> is B<9606>.

=head1 TESTING METHODS

The following B<Boolean> return methods are exported by this class:

=head2 B<alleleExists(locus, allele, version)>

This method returns TRUE (1) if the B<allele> is defined for the
B<locus> in the given B<version> format, otherwise it returns FALSE
(0).  The locus and allele are case-insensitive. The B<locus> can be
the locus name or the B<locus_id> (integer ID as defined by the
database).  The B<allele> can either contain the locus name or not,
and have an optional suffix or not.  If the allele has a locus name
prefix, then it must be consistent with the locus provided, otherwise
FALSE (0) will be returned.

=head2 B<alleleSuffix(suffix)>

This method returns TRUE (1) if the B<suffix> is a defined IMGT/HLA suffix,
otherwise it returns FALSE (0).  The suffix is case-insensitive.

=head2 B<isMIC(locus)>

This method returns TRUE (1) if the locus is a B<MICA> or B<MICB>
locus, otherwise it returns FALSE (0).  The locus is case-insensitive.

=head1 LOOKUP METHODS

The following lookup methods return a specific lookup table (subclass
of L<lookup::LookupTable::Alleles>).  If the table is not currently loaded
into the program, the method loads the table.

=head2 B<$alleleLookup = getAlleleLookup(version)>

This method returns allele group lookup table for the B<version>.  
Version 2 returns L<lookup::LookupTable::Alleles::Current>, while version 3
returns L<lookup::LookupTable::Alleles::Old>

=head2 B<$codingRegionLookup = getCodingRegionLookup(version)>

This method returns allele group lookup table for the B<version>.  
Version 2 returns L<lookup::LookupTable::Alleles::Current::CodingRegion>, while version 3
returns L<lookup::LookupTable::Alleles::Old::CodingRegion>

=head2 B<$hlaProteinLookup = getHlaProteinLookup(version)>

This method returns allele group lookup table for the B<version>.  
Version 2 returns L<lookup::LookupTable::Alleles::Current::HlaProtein>, while version 3
returns L<lookup::LookupTable::Alleles::Old::HlaProtein>

=head2 B<$alleleGroupLookup = getAlleleGroupLookup(version)>

This method returns allele group lookup table for the B<version>.  
Version 2 returns L<lookup::LookupTable::Alleles::Current::AlleleGroup>, while version 3
returns L<lookup::LookupTable::Alleles::Old::AlleleGroup>

=head1 GETTER METHODS

The following getter access methods are exported by this class.  The
B<version> parameter is the IMGT/HLA version which is either B<2> or
B<3>.

=head2 B<($locus, $allele) = getLocusAndName(allele_name)>

This method determines the locus name and the allele components of the
B<allele_name>.

=head2 B<$locus_data = getLocusData(locus)>

For a given B<locus> (either locus name or locus id), this method
returns a referenced Perl hash containing the following components:

   full_locus_name  -- the full locus name as defined by IMGT
                       (eg, 'HLA-A', 'HLA-C')
   short_locus_name -- the short locus name that is often used
                       (eg, 'A', 'C')
   alt_locus_name   -- the alternate locus name this is often used
                       (eg, 'A', 'Cw')
   locus_id         -- locus_id from the database for the locus

If there is no locus for the B<taxon_id>, then B<undef> is returned.

=head2 B<$locus_id = getLocusId(locus)>

For a given B<locus> (either locus name or locus id), this method
returns the B<locus ID> as defined in the database for the locus in
the B<taxon_id>.  If there is none, then B<undef> is returned.

=head2 B<$allele = getAllele(locus, allele, version)>

The method takes the locus, allele and version and return the
referenced Perl hash containing the following data:

   allele_name - full allele name for the version
   allele_id   - Unique ID assigned by the database for the allele
   locus_id    - Unique ID assigned by the database for the locus

if the B<allele> is an allele of the B<locus> for the given
B<version>.  Otherwise, B<undef> will be returned.  The locus and
allele are case-insensitive. The B<locus> can be the locus name or the
B<locus_id> (integer ID defined by the database).  The B<allele>
either contains the locus name or not and an optional suffix.  If the
allele has a locus name prefix, then it must be consistent with the
locus provided, otherwise B<undef> will be returned.

=head2 B<@alleles = getAlleles(locus, allele, version )>

This method takes the B<locus>, B<allele>, and B<version> and
determines the set of possible alleles for the locus to return as
follows. The B<locus> can be the locus name (case-insensitive) or the
B<locus_id> (integer ID defined by the database).  The B<allele> can
contain a locus name or not and an optional suffix.  If the locus has
a locus name prefix, then the B<locus> must correspond to the in the
allele.  The list of IMGT/HLA allele names for the version that is
returned is determined by the reduced allele that allele is as follows:

   Reduced Allele  List Returned
   --------------- -------------------------------------------------------------
   allele group    all alleles in the locus containing the allele group field
                   and suffix (if provided) of the allele
   hla protein     all alleles in the locus containing the allele group,
                   hla protein fields, and suffix (if provided) of the allele
   coding region   all alleles in the locus containing the allele group,
                   hla protein, coding region fields and suffix (if provided) of
                   the allele

If the allele is not one of reduced allele types, then the allele that
it exactly represent is returned.  If there are no alleles associated
with the allele, then an empty list is returned.

=head2 B<$converted_allele = convertAllele(locus, allele, version )>

This method takes a B<locus>, B<allele>, and B<version> and converts
the allele from the B<version> to the other version.  That is, if
version == 2, the converts the allele to version 3, otherwise converts
version == 3 to version 2.  This conversion process uses the
conversion table provided by IMGT/HLA.  This method converts reduced
allele and full allele names.

=cut
