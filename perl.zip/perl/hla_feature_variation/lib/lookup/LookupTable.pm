package lookup::LookupTable;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PerlObject;

use db::MhcTypes;

use lookup::ErrMsgs;

use fields qw (
  db_queries
  col_ord
  error_mgr
  imgt_hla_version
  key
  list
  lookup_table
  nomen_ord
  predicate
  table
  taxon_id
  tools
  val_col
  vals
  value_lookup
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Lookup Table data
###
sub HOMO_SAPIENS_TAXON { return 9606; }
###
### Error Category
###
sub ERR_CAT { return lookup::ErrMsgs::LOOKUP_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getStruct {
  my lookup::LookupTable $this = shift;
  my ( $query, $row ) = @_;
  my $struct = {};
  foreach my $index ( 0 .. $#{ $this->{col_ord} } ) {
    $struct->{ $this->{col_ord}->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _generateValueLookup {
  my lookup::LookupTable $this = shift;
  while ( my ( $key, $values ) = each %{ $this->{lookup_table} } ) {
    next if ( util::Constants::EMPTY_LINE($values) );
    if ( !$this->isList ) {
      my $val = $values;
      if ( $this->isHashValue ) {
        $val = $values->{ $this->{val_col} };
      }
      $this->{value_lookup}->{$val} = $key;
    }
    else {
      foreach my $key_val ( @{$values} ) {
        my $val = $key_val;
        if ( $this->isHashValue ) {
          $val = $key_val->{ $this->{val_col} };
        }
        $this->{value_lookup}->{$val} = $key;
      }
    }
  }
}

sub _setLookupTable {
  my lookup::LookupTable $this = shift;
  ###
  ### Currently only Human Lookup data
  ###
  return if ( $this->{taxon_id} != HOMO_SAPIENS_TAXON );
  ###
  ### Execute the query
  ###
  my $table      = $this->{table};
  my $db_queries = $this->{db_queries};
  my $cmd        = join( util::Constants::SPACE,
    'select',
    join( util::Constants::COMMA_SEPARATOR, @{ $this->{col_ord} } ),
    'from',
    $table,
    ( defined( $this->{predicate} ) )
    ? 'where'
    : util::Constants::EMPTY_STR,
    $this->{predicate}
  );
  $db_queries->doQuery( $table, $cmd, 'Lookup on ' . $table );
  my $lookup_table = $this->{lookup_table};
  while ( my $row_ref = $db_queries->fetchRowRef($table) ) {
    ###
    ### Get the structure for the lookup
    ###
    my $struct = $this->_getStruct( $table, $row_ref );
    ###
    ### Determine the key and value for the lookup
    ###
    my $key = $struct->{ $this->{key} };
    my $val = undef;
    if ( $this->isHashValue ) {
      $val = {};
      foreach my $col ( @{ $this->{vals} } ) {
        $val->{$col} = $struct->{$col};
      }
    }
    elsif ( @{ $this->{vals} } != 0 ) {
      $val = $struct->{ $this->{vals}->[0] };
      if ( util::Constants::EMPTY_LINE($val) ) { $val = undef; }
    }
    ###
    ### Based on requirement the lookup is a single value or a list
    ###
    if ( !defined( $lookup_table->{$key} ) ) {
      if   ( $this->isList ) { $lookup_table->{$key} = [$val]; }
      else                   { $lookup_table->{$key} = $val; }
    }
    elsif ( $this->isList ) {
      push( @{ $lookup_table->{$key} }, $val );
    }
  }
  $this->_generateValueLookup;
  $this->debugLookup("lookup_table");
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$) {
  my lookup::LookupTable $this = shift;
  my ( $taxon_id, $tools, $table, $key, $vals, $list, $predicate, $error_mgr ) =
    @_;
  $this = fields::new($this) unless ref($this);

  $error_mgr->printDebug("lookup::LookupTable -> $table, $key");

  $this->{db_queries}       = new util::DbQuery( $tools->getSession );
  $this->{error_mgr}        = $error_mgr;
  $this->{imgt_hla_version} = db::MhcTypes::IMGT_HLA_V3;
  $this->{list} = $list ? util::Constants::TRUE : util::Constants::FALSE;
  $this->{lookup_table} = {};
  $this->{nomen_ord}    = db::MhcTypes::NOMENCLATURE_ORDER;
  $this->{predicate} =
    util::Constants::EMPTY_LINE($predicate) ? undef : $predicate;
  $this->{table}        = $table;
  $this->{taxon_id}     = $taxon_id;
  $this->{tools}        = $tools;
  $this->{value_lookup} = {};
  ###
  ### Determine key, vals, and col_ord
  ###
  $this->{key}     = $key;
  $this->{col_ord} = [$key];
  $this->{vals}    = [];
  $this->{val_col} = undef;
  if ( ref($vals) eq util::PerlObject::ARRAY_TYPE ) {
    push( @{ $this->{vals} }, @{$vals} );
  }
  elsif ( !util::Constants::EMPTY_LINE($vals) ) {
    push( @{ $this->{vals} }, $vals );
  }
  push( @{ $this->{col_ord} }, @{ $this->{vals} } );
  if ( @{ $this->{vals} } > 1 ) {
    $this->{val_col} = $this->{vals}->[0];
  }
  ###
  ### Read the lookup tables
  ###
  $this->_setLookupTable;

  return $this;
}

sub prepareKey {
  my lookup::LookupTable $this = shift;
  my ($key) = @_;
  ###############################
  ### Re-Implementable Method ###
  ###############################
  return $key;
}

sub prepareValue {
  my lookup::LookupTable $this = shift;
  my ($value) = @_;
  ###############################
  ### Re-Implementable Method ###
  ###############################
  return $value;
}

sub debugLookup {
  my lookup::LookupTable $this = shift;
  my ($title) = @_;
  $this->{tools}->debugStruct( $title, $this->{lookup_table} );
}

################################################################################
#
#				 Testing Methods
#
################################################################################

sub isList {
  my lookup::LookupTable $this = shift;
  return $this->{list};
}

sub isHashValue {
  my lookup::LookupTable $this = shift;
  return defined( $this->{val_col} )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

sub keyDefined {
  my lookup::LookupTable $this = shift;
  my ($key) = @_;

  $key = $this->prepareKey($key);
  my $lookup_table = $this->{lookup_table};
  return util::Constants::TRUE
    if ( exists( $lookup_table->{$key} ) );
  return util::Constants::FALSE;
}

sub valueDefined {
  my lookup::LookupTable $this = shift;
  my ($key) = @_;

  $key = $this->prepareKey($key);
  my $lookup_table = $this->{lookup_table};
  return util::Constants::TRUE
    if ( defined( $lookup_table->{$key} ) );
  return util::Constants::FALSE;
}

################################################################################
#
#				 Setter Methods
#
################################################################################

sub setImgtHlaVersion {
  my lookup::LookupTable $this = shift;
  my ($version) = @_;

  $this->{error_mgr}->hardDieOnError( ERR_CAT, 1, [$version],
    !db::MhcTypes::DEFINED_IMGT_HLA_VERSION($version) );

  $this->{imgt_hla_version} = $version;
}

################################################################################
#
#				 Getter Methods
#
################################################################################

sub keyCol {
  my lookup::LookupTable $this = shift;
  return $this->{key};
}

sub getValue {
  my lookup::LookupTable $this = shift;
  my ($key) = @_;
  ###
  ### First determine if the value is defined
  ###
  if ( !$this->valueDefined($key) ) {
    return undef if ( !$this->isList );
    my @values = ();
    return @values;
  }
  ###
  ### Now get the value and return it
  ###
  my $values = $this->{lookup_table}->{ $this->prepareKey($key) };
  ###
  ### return a hash, a scalar, or an array of (scalars or hashes)
  ###
  return { %{$values} } if ( !$this->isList && $this->isHashValue );
  return $values if ( !$this->isList );
  my @values = ();
  foreach my $value ( @{$values} ) {
    my $val = $value;
    if ( $this->isHashValue ) { $val = { %{$value} }; }
    push( @values, $val );
  }
  return @values;
}

sub getKeys {
  my lookup::LookupTable $this = shift;
  return sort keys %{ $this->{lookup_table} };
}

sub getKey {
  my lookup::LookupTable $this = shift;
  my ($value) = @_;

  return undef
    if ( util::Constants::EMPTY_LINE($value)
    || @{ $this->{vals} } == 0 );

  $value = $this->prepareValue($value);
  return $this->{value_lookup}->{$value};
}

sub getImgtHlaVersion {
  my lookup::LookupTable $this = shift;
  my ($version) = @_;

  return $this->{imgt_hla_version};
}

sub getIndex {
  my lookup::LookupTable $this = shift;
  my ($type) = @_;
  foreach my $index ( 0 .. $#{ $this->{nomen_ord} } ) {
    my $nomen_type = $this->{nomen_ord}->[$index];
    return $index if ( $type eq $nomen_type );
  }
  return -1;
}

sub getSeparator {
  my lookup::LookupTable $this = shift;

  return util::Constants::COLON
    if ( $this->getImgtHlaVersion == db::MhcTypes::IMGT_HLA_V3 );
  return util::Constants::EMPTY_STR;
}

################################################################################
#
#				 Versioned Allele Methods
#
################################################################################

sub generateNomenclature {
  my lookup::LookupTable $this = shift;
  my ($allele_name) = @_;

  $allele_name =~ /^(\w+)\*([0-9:]+)([A-Z]?)$/;
  my $name   = $1;
  my $comps  = $2;
  my $suffix = $3;

  my $nomen = {
    name                                 => $name,
    suffix                               => $suffix,
    max_index                            => -1,
    max_comp                             => undef,
    &db::MhcTypes::ALLELE_GROUP_COL      => undef,
    &db::MhcTypes::HLA_PROTEIN_COL       => undef,
    &db::MhcTypes::CODING_REGION_COL     => undef,
    &db::MhcTypes::NON_CODING_REGION_COL => undef,
  };

  if ( $this->getImgtHlaVersion == db::MhcTypes::IMGT_HLA_V3 ) {
    my @comps = split( /:/, $comps );
    $nomen->{max_index} = $#comps;
    $nomen->{max_comp}  = $this->{nomen_ord}->[$#comps];
    foreach my $index ( 0 .. $#comps ) {
      my $name = $this->{nomen_ord}->[$index];
      my $comp = $comps[$index];
      $nomen->{$name} = $comp;
    }
  }
  else {
    if ( $nomen->{name} =~ /^MIC/ ) {
      if ( $comps =~ /^(\d\d\d)/ ) {
        $nomen->{&db::MhcTypes::ALLELE_GROUP_COL} = $1;
        $nomen->{max_index} = 0;
        $nomen->{max_comp} = db::MhcTypes::ALLELE_GROUP_COL;
      }
      if ( $comps =~ /^\d\d\d(\d\d)/ ) {
        $nomen->{&db::MhcTypes::HLA_PROTEIN_COL} = $1;
        $nomen->{max_index} = 1;
        $nomen->{max_comp} = db::MhcTypes::HLA_PROTEIN_COL;
      }
      if ( $comps =~ /^\d\d\d\d\d(\d\d)$/ ) {
        $nomen->{&db::MhcTypes::CODING_REGION_COL} = $1;
        $nomen->{max_index} = 2;
        $nomen->{max_comp} = db::MhcTypes::CODING_REGION_COL;
      }
    }
    else {
      if ( $comps =~ /^(\d\d)/ ) {
        $nomen->{&db::MhcTypes::ALLELE_GROUP_COL} = $1;
        $nomen->{max_index} = 0;
        $nomen->{max_comp} = db::MhcTypes::ALLELE_GROUP_COL;
      }
      if ( $comps =~ /^\d\d(\d\d)/ ) {
        $nomen->{&db::MhcTypes::HLA_PROTEIN_COL} = $1;
        $nomen->{max_index} = 1;
        $nomen->{max_comp} = db::MhcTypes::HLA_PROTEIN_COL;
      }
      if ( $comps =~ /^\d\d\d\d(\d\d)/ ) {
        $nomen->{&db::MhcTypes::CODING_REGION_COL} = $1;
        $nomen->{max_index} = 2;
        $nomen->{max_comp} = db::MhcTypes::CODING_REGION_COL;
      }
      if ( $comps =~ /^\d\d\d\d\d\d(\d\d)$/ ) {
        $nomen->{&db::MhcTypes::NON_CODING_REGION_COL} = $1;
        $nomen->{max_index} = 3;
        $nomen->{max_comp} = db::MhcTypes::NON_CODING_REGION_COL;
      }
    }
  }
  return $nomen;
}

sub generatePrefix {
  my lookup::LookupTable $this = shift;
  my ( $allele_name, $type ) = @_;

  my $nomen  = $this->generateNomenclature($allele_name);
  my $aindex = $this->getIndex($type);

  return undef if ( $aindex == -1 || $aindex > $nomen->{max_index} );

  my $prefix    = $nomen->{name} . util::Constants::ASTERISK;
  my $separator = $this->getSeparator;
  foreach my $index ( 0 .. $aindex ) {
    if ( $index > 0 ) { $prefix .= $separator; }
    $prefix .= $nomen->{ $this->{nomen_ord}->[$index] };
  }
  if ( $aindex == $nomen->{max_index}
    && defined( $nomen->{suffix} ) )
  {
    $prefix .= $nomen->{suffix};
  }

  return $prefix;
}

################################################################################

1;

__END__

=head1 NAME

LookupTable.pm

=head1 DESCRIPTION

This class defines the concrete class for accessing IMGT/HLA human
data using a lookup table.  This method contains a reimplementable
methods: 
L<"$prepared_key = prepareKey(key)">
and 
L<"$prepared_value = prepareValue(value)">
that prepares the key and value, respectively, prior to use in the
methods.

Subclasses of this class can re-adjust the lookup table so that it can
define differing lookup views.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new lookup::LookupTable(taxon_id, tools, table, key, vals, list, predicate, error_mgr )>

This is the constructor for the class.  The tools and error_mgr
parameters define the tools object (a subclass of
L<util::Tools::mhcSeqVar>) and the logging object (L<util::ErrMgr>).

The lookup table is defined by the database table, B<table>, and the
key column, B<key>, of the table.  The value stored for the key is
defined by the B<vals> as follows.  If B<vals> is either undefined, or
an empty referenced Perl array, then undef is stored for the key.  If
B<vals> is a scalar value or a referenced Perl array containing one
value, then the value stored for the key is the column value
represented by the column name defined B<vals> in the table.  If
B<vals> is a referenced Perl array containing more than one value,
then the value stored for key is a referenced Perl hash containing the
columns values for the column names defined by B<vals> in the table.
Further, if the Boolean B<list> is TRUE (1), then value stored for the
key is an array of values as described above, otherwise (B<list> FALSE
(0)) the value is just a single value as described above.  The B<list>
parameter allows multi-row results from the table for a given key to
be stored in the lookup table if that is the requirement of the lookup
table.  The B<predicate> parameter allows a restriction on the
database table for access to the data defining the lookup table.  The
predicate must be a properly formed SQL predicate on the database
table.  If the predicate is empty or undefined (undef), then no
restriction is set on the database table.

By default, the constructor set the IMGT/HLA version attribute
B<imgt_hla_version> to B<'3'>.  Subclasses can change the version.

=head2 B<$prepared_key = prepareKey(key)>

This re-implementable method returns the prepared key for the B<key>.
The default action of this method is a NO-OP to return the key
'as-is'.

=head2 B<$prepared_value = prepareValue(value)>

This re-implementable method returns the prepared value for the B<value>.
The default action of this method is a NO-OP to return the value
'as-is'.

=head2 B<debugLookup(title)>

This method prints a serialized version of the lookup_table
data-structure to the log if logging is in debugging mode.

=head1 TESTING METHODS

The following B<Boolean> valued methods are exported by this class.

=head2 B<isList>

This method returns TRUE (1) if the B<list> attribute is TRUE,
otherwise it returns FALSE (0).  If it is TRUE, then value returned by
a key in the lookup table is a list, otherwise it is a scalar.

=head2 B<isHashValue>

This method returns TRUE (1) if the value returned by a key is a
referenced Perl hash or the components of the list are referenced Perl
hashes, otherwise it returns FALSE (0) in which case the value is
scalar or list of scalars.

=head2 B<keyDefined(key)>

This method returns TRUE (1) if the key exists in the lookup table,
otherwise it returns FALSE (0).  The key is prepared
by L<"$prepared_key = prepareKey(key)">.

=head2 B<valueDefined(key)>

This method returns TRUE (1) if the key exists in the lookup table and
its value is defined, otherwise it returns FALSE (0).  The key is
prepared by L<"$prepared_key = prepareKey(key)">.

=head1 SETTER METHODS

The following setter method is exported by this class.

=head2 B<setImgtHlaVersion(version)>

The method sets the IMGT/HLA attribute B<imgt_hla_version> to the
version.  Currently, the only allowable values are B<2 (two)> or B<3
(three)>.  Otherwise, a terminal error is generated.  By default, the
value of the attribute is B<three (3)>.

=head1 GETTER METHODS

The following getter access methods are exported by this class.

=head2 B<$key_col = keyCol>

The method returns the key column name

=head2 B<@values = getValue(key)>

=head2 B<$value = getValue(key)>

This method returns the value(s) for the key.  If the B<list>
attribute is TRUE (1), then the value returned is a list of values
(B<@values>), otherwise it single value B<$value>.  The list of values
or single value is either a scalar or a referenced Perl hash as
described in the constructor. The key is prepared by 
L<"$prepared_key = prepareKey(key)">.

=head2 B<@keys = getKeys>

The method returns the list of unique keys for the lookup table.

=head2 B<$key = getKey(value)>

This method returns the B<key> associated with the scalar B<value> in
the value lookup table constructed from the lookup table.  The value
is prepared by L<"$prepared_value = prepareValue(value)"> before the
value lookup table is search.  If no key exists for the value, then
B<undef> is returned.

The value lookup table for the lookup table is constructed as follows.

=over 4

=item B<isHashValue is FALSE (0)>

In this case, the key is associated with either a list of scalar
values or a single scalar value.  For a given key, the scalar values
associated with the key is mapped to the key in value loookup table.

=item B<isHashValue is TRUE (1)>

A key is associated with a list of referenced hashes or a single
referenced hash.  In this case, the scalar value the is use in
constructing the value lookup table, is the value of the first column
as defined by the B<vals> parameter in the constructor.  In this
manner, hash defines a value that is mapped to the key.

=back

=head2 B<getImgtHlaVersion>

The method returns the current value of the attribute
B<img_hla_version>.  Currently, the allowed values are version B<2> and
version B<3>.

=head2 B<$index = getIndex(type)>

This method returns the index (integer) of the field category defined
by B<type> as follows:

   allele_group      - 0
   hla_protein       - 1
   coding_region     - 2
   non_coding_region - 3

These field category names are defined by IMGT/HLA in the order
defined above for IMGT/HLA formated allele.

=head2 B<$category_separator = getSeparator>

This method returns the standard category separator.  For IMGT/HLA
version 2, it is an empty string (B<''>) and for version 3 it is a colon
(B<':'>).

=head1 VERSIONED ALLELE METHODS

The following methods define how to manipulate the versioned alleles
that can occur in the lookup table.  These method assume the given
version as defined by the attribute B<imgt_hla_version>

=head2 B<$nomen = generateNomenclature(allele_name)>

The method constructs the nomenclature data-structure (reference Perl
hash) for the allele_name based on whether the IMGT/HLA version is 2
or 3 by the class object.  The allele_name has the format for version
2 is B<'^(\w+)\*([0-9]+)([A-Z]?)$> and for version 3
B<'^(\w+)\*([0-9:]+)([A-Z]?)$>'.  The data-structure contains the
following keys:

    name              - locus name
    suffix            - suffix 
    max_index         - index of maximum field category found (0..3)
    max_comp          - maximum field category name found 
                        (One of the following names:
                          allele_group
                          hla_protein
                          coding_region
                          non_coding_region)
    allele_group      - allele group field category value
    hla_protein       - HLA protein field category value
    coding_region     - coding region field category value
    non_coding_region - non-coding region field category value

=head2 B<$prefix = generatePrefix(allele_name, type)>

The method constructs the prefix allele from the allele_name and the
category field B<type> as the maximum category, where the category
field names include:

   db::MhcTypes::ALLELE_GROUP_COL      - allele_group
   db::MhcTypes::HLA_PROTEIN_COL       - hla_protein
   db::MhcTypes::CODING_REGION_COL     - coding_region
   db::MhcTypes::NON_CODING_REGION_COL - non_coding_region

The allele_name has the format for version 2 is
B<'^(\w+)\*([0-9]+)([A-Z]?)$> and for version 3
B<'^(\w+)\*([0-9:]+)([A-Z]?)$>'.  If the maximum category also
contains a suffix, this suffix is attached to the prefix.

=cut
