package anthonyNolan::Msf;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use FileHandle;
use File::Find ();
use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PathSpecifics;
use util::PerlObject;

use db::MhcTypes;
use perl::Struct::Profile::Allele;

use anthonyNolan::ErrMsgs;

use fields
  qw (
  allele
  allele_names
  db_queries
  error_mgr
  generator
  msf_directory
  queries
  reference_alleles
  seq_types
  serializer
  variant_seq_structs
);
################################################################################
#
#				 Initialization
#
################################################################################
###
### for the convenience of &wanted calls,
### including -eval statements:
###
use vars qw(*FIND_NAME
  *FIND_DIR
  *FIND_PRUNE);
*FIND_NAME  = *File::Find::name;
*FIND_DIR   = *File::Find::dir;
*FIND_PRUNE = *File::Find::prune;

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Queries to compute ALLELE_ALIGNMENT
###
sub GENE_SEQ_STRUCTURE_QUERY { return 'M_gene_seq_structure_query'; }

sub DB_QUERIES {
  return {
    &GENE_SEQ_STRUCTURE_QUERY => {
      msg => 'GENE_SEQ_STRUCTURE Query',
      ord => [
        db::MhcTypes::GSS_START_POS_COL,  db::MhcTypes::GSS_END_POS_COL,
        db::MhcTypes::GENE_STRUCT_ID_COL, db::MhcTypes::ORDER_NUM_COL,
      ],
      cmd => "
select gss_start_pos,
       gss_end_pos,
       gene_struct_id,
       order_num
from   gene_seq_structure
where  allele_id = ?
order  by gss_start_pos
",
    },
  };
}
###
### Pattern Information for msf files
###
sub MSF_FILE_PATTERN { return '.+_(gen|nuc|prot)\.msf'; }
sub MSF_DUP_FILES    { return '^DRB\d+_(nuc|prot)\.msf'; }

sub DNA_FILE  { return '_gen\.msf'; }
sub MRNA_FILE { return '_nuc\.msf$'; }
sub PROT_FILE { return '_prot\.msf$'; }

sub ALLELE_NAME     { return '^\s+Name:\s+(\S+)\s+'; }
sub ALLELE_SEQUENCE { return '^\s*(\S+\*\S+)\s+(.+)$'; }
###
### Error Category
###
sub ERR_CAT { return anthonyNolan::ErrMsgs::MSF_CAT; }

################################################################################
#
#				File Finding Private Method
#
################################################################################
###
### MSF_FILES is the global variable for storing msf
### files found in a File::Find::find operation using
### the _msfWanted function.  This variable should not
### be used in recursive executions of wanted since they
### get re-initialized for each input path directory
### traversed below.
###
my @MSF_FILES = ();

sub _msfWanted {
  my anthonyNolan::Msf $this = shift;
  my $msf_file_pattern = MSF_FILE_PATTERN;
  return sub {
    my ( $dev, $ino, $mode, $nlink, $uid, $gid );
    ( ( $dev, $ino, $mode, $nlink, $uid, $gid ) = lstat($_) )
      && -f _
      && /^$msf_file_pattern\z/s
      && push( @MSF_FILES, $FIND_NAME );
    }
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _determineLocusNames {
  my anthonyNolan::Msf $this = shift;
  my ($taxon_id) = @_;

  my $allele_names = db::MhcTypes::alleleNames($taxon_id);
  $this->{allele_names} = {};
  foreach my $allele_name ( keys %{$allele_names} ) {
    my $allele_data = $allele_names->{$allele_name};
    $this->{allele_names}->{$allele_name} = { %{$allele_data} };
  }

  my $reference_alleles = db::MhcTypes::referenceAlleles($taxon_id);
  $this->{reference_alleles} = {};
  foreach my $locus_id ( keys %{$reference_alleles} ) {
    my $reference_data = $reference_alleles->{$locus_id};
    $this->{reference_alleles}->{$locus_id} = { %{$reference_data} };
  }

  my $variant_seq_structs = db::MhcTypes::variantSeqStructs($taxon_id);
  $this->{variant_seq_structs} = {};
  foreach my $locus_id ( keys %{$variant_seq_structs} ) {
    my $variant_seq_data = $variant_seq_structs->{$locus_id};
    $this->{variant_seq_structs}->{$locus_id} = { %{$variant_seq_data} };
  }
}

sub _parseFile {
  my anthonyNolan::Msf $this = shift;
  my ($file) = @_;

  my $sequences = [];
  my $seq_map   = {};

  my $allele_name_pattern     = ALLELE_NAME;
  my $allele_sequence_pattern = ALLELE_SEQUENCE;

  $file = join( util::Constants::SLASH, $this->{msf_directory}, $file );
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ "Cannot open msf file\n" . "  msf file = $file" ],
    !$fh->open( $file, '<' )
  );
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    if ( $line =~ /$allele_name_pattern/ ) {
      my $allele_name = $1;
      $this->{error_mgr}->printDebug("allele_name = $allele_name");
      my $seq_struct = {
        allele_name => $allele_name,
        seq         => util::Constants::EMPTY_STR,
      };
      $seq_map->{$allele_name} = $seq_struct;
      push( @{$sequences}, $seq_struct );
    }
    elsif ( $line =~ /$allele_sequence_pattern/ ) {
      my $allele_name = $1;
      my $seq         = $2;
      $seq =~ s/ //g;
      my $allele_struct = $seq_map->{$allele_name};
      $allele_struct->{seq} .= $seq;
    }
  }
  $fh->close;
  return $sequences;
}

sub _getStruct {
  my anthonyNolan::Msf $this = shift;
  my ( $query, $row ) = @_;
  my $ord    = $this->{queries}->{$query}->{ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _determineVssStartPos {
  my anthonyNolan::Msf $this = shift;
  my ( $seq_type_id, $seq, $allele_id ) = @_;
  ###
  ### Early return for AA and mRNA
  ###
  my $seq_type =
    db::MhcTypes::getName( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type_id );
  return 1
    if ( $seq_type eq db::MhcTypes::AA_SEQ
    || $seq_type eq db::MhcTypes::MRNA_SEQ );
  ###
  ### DNA processing
  ###
  my $FIVEPRIME_UTR =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::FIVE_PRIME_UTR );
  ###
  ### Compute the start pos for the allele_id
  ###
  my $gene_struct = [];
  $this->{db_queries}->executeQuery( GENE_SEQ_STRUCTURE_QUERY, $allele_id );
  while ( my $row_ref =
    $this->{db_queries}->fetchRowRef(GENE_SEQ_STRUCTURE_QUERY) )
  {
    my $interval = $this->_getStruct( GENE_SEQ_STRUCTURE_QUERY, $row_ref );
    push( @{$gene_struct}, $interval );
  }
  ###
  ### Compute unsequenced initial segment
  ###
  my $unsequenced_length = 0;
  my $vss_start_pos      = undef;
  if ( $seq =~ /^(\.+)/ ) {
    $this->{error_mgr}->printHeader(
      "Allele's DNA has unsequenced start\n" . "  allele_id = $allele_id" );
    my $unseq = $1;
    $unsequenced_length = length($unseq);
  }
  ###
  ### For the DNA type compute the vss_start_pos from
  ### the negative of the utr length if any, otherwise 1
  ###
  if ( @{$gene_struct} == 0 ) {
    if ( $unsequenced_length == 0 ) {
      $vss_start_pos = 1;
    }
    else {
      $vss_start_pos = -$unsequenced_length;
    }
  }
  else {
    my $interval = $gene_struct->[0];
    if ( $interval->{gene_struct_id} == $FIVEPRIME_UTR ) {
      $vss_start_pos =
        -( $interval->{gss_end_pos} - $interval->{gss_start_pos} + 1 ) -
        $unsequenced_length;
    }
    else {
      $vss_start_pos = $interval->{gss_start_pos} - $unsequenced_length;
    }
  }

  return $vss_start_pos;
}

sub _addReferenceData {
  my anthonyNolan::Msf $this = shift;
  my ( $allele_name, $seq_type_id, $seq ) = @_;
  ###
  ### Get the reference data
  ###
  my $ref_data  = $this->{allele_names}->{$allele_name};
  my $locus_id  = $ref_data->{locus_id};
  my $allele_id = $ref_data->{allele_id};
  ###
  ### Check to see if data need to be added
  ###
  $this->{error_mgr}->printMsg( "Msf alignment data\n"
      . "  locus_id      = $locus_id\n"
      . "  seq_type_id   = $seq_type_id\n"
      . "  allele_name   = $allele_name\n"
      . "  allele_id     = $allele_id" );
  my $reference_alleles = $this->{reference_alleles};
  if ( !defined( $reference_alleles->{$locus_id} ) ) {
    $reference_alleles->{$locus_id} = {};
  }
  my $variant_seq_struct = $this->{variant_seq_structs};
  if ( !defined( $variant_seq_struct->{$locus_id} ) ) {
    $variant_seq_struct->{$locus_id} = {};
  }
  my $locus     = $reference_alleles->{$locus_id};
  my $var_locus = $variant_seq_struct->{$locus_id};
  ###
  ### Only add a reference_allele and variant_seq_structure
  ### if it is not already defined
  ###
  return if ( defined( $locus->{$seq_type_id} ) );
  $this->{error_mgr}->printMsg("  ADDING REFERENCE ALLELE");
  ###
  ### Reference allele
  ###
  $locus->{$seq_type_id} = $allele_name;
  ###
  ### get vss_start_pos
  ###
  my $vss_start_pos =
    $this->_determineVssStartPos( $seq_type_id, $seq, $allele_id );
  $this->{error_mgr}->printMsg("  vss_start_pos = $vss_start_pos");
  $var_locus->{$seq_type_id} = $vss_start_pos;
}

sub _writeReferenceData {
  my anthonyNolan::Msf $this = shift;

  while ( my ( $locus_id, $var_data ) = each %{ $this->{variant_seq_structs} } )
  {
    foreach my $seq_type_id ( keys %{$var_data} ) {
      my $variant_seq_struct = {
        locus_id      => $locus_id,
        seq_type_id   => $seq_type_id,
        vss_start_pos => $var_data->{$seq_type_id},
      };
      $this->{generator}
        ->generateRow( lc(db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE),
        $variant_seq_struct );
    }
  }

  while ( my ( $locus_id, $ref_data ) = each %{ $this->{reference_alleles} } ) {
    foreach my $seq_type_id ( keys %{$ref_data} ) {
      my $ref_data = $this->{allele_names}->{ $ref_data->{$seq_type_id} };
      my $reference_allele_struct = {
        locus_id    => $locus_id,
        seq_type_id => $seq_type_id,
        allele_id   => $ref_data->{allele_id},
      };
      $this->{generator}->generateRow( lc(db::MhcTypes::REFERENCE_ALLELE_TABLE),
        $reference_allele_struct );
    }
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my anthonyNolan::Msf $this = shift;
  my ( $taxon_id, $msf_directory, $generator, $db, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{allele_names}        = undef;
  $this->{error_mgr}           = $error_mgr;
  $this->{generator}           = $generator;
  $this->{msf_directory}       = getPath($msf_directory);
  $this->{reference_alleles}   = undef;
  $this->{variant_seq_structs} = undef;

  $this->{seq_types} = {
    &db::MhcTypes::AA_SEQ   => PROT_FILE,
    &db::MhcTypes::DNA_SEQ  => DNA_FILE,
    &db::MhcTypes::MRNA_SEQ => MRNA_FILE,
  };

  ###
  ### Instantiate the allele profile to contain the parse content
  ###
  $this->{allele} =
    new perl::Struct::Profile::Allele( util::Constants::TRUE, 'AnthonNolanHla',
    undef, undef, $error_mgr );
  $this->{allele}->setSkipHash('allele_nomenclature');
  ###
  ### serializer
  ###
  $this->{serializer} =
    new util::PerlObject( undef, undef, $this->{error_mgr} );
  ###
  ### Get the locus specific information.
  ###
  $this->_determineLocusNames($taxon_id);
  ###
  ### setup queries
  ###
  $this->{db_queries} = new util::DbQuery($db);
  $this->{queries}    = DB_QUERIES;
  foreach my $query ( keys %{ $this->{queries} } ) {
    my $db_struct = $this->{queries}->{$query};
    $this->{db_queries}
      ->createQuery( $query, $db_struct->{cmd}, $db_struct->{msg} );
    $this->{db_queries}->prepareQuery($query);
  }

  return $this;
}

sub processFiles {
  my anthonyNolan::Msf $this = shift;

  my $allele = $this->{allele};
  ###
  ### Get the msf files to process
  ###
  my $currentDirectory = $ENV{PWD};
  chdir( $this->{msf_directory} );
  @MSF_FILES = ();
  File::Find::find( { wanted => $this->_msfWanted }, util::Constants::DOT );
  my $duplicate_files = MSF_DUP_FILES;
  my $msf_files       = {};
  foreach my $msf_file ( sort @MSF_FILES ) {
    $msf_file =~ s/^\.\///;
    next if ( $msf_file =~ /$duplicate_files/ );
    foreach my $seq_type ( keys %{ $this->{seq_types} } ) {
      my $file = $this->{seq_types}->{$seq_type};
      if ( $msf_file =~ /$file/ ) {
        if ( !defined( $msf_files->{$seq_type} ) ) {
          $msf_files->{$seq_type} = [];
        }
        $this->{error_mgr}
          ->printMsg("(seq_type, msf_file) = ($seq_type, $msf_file)");
        push( @{ $msf_files->{$seq_type} }, $msf_file );
      }
    }
  }
  foreach my $seq_type ( keys %{$msf_files} ) {
    my $seq_type_id =
      db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type );
    $this->{error_mgr}->printMsg("seq_type = $seq_type");
    my $files = $msf_files->{$seq_type};
    foreach my $file ( @{$files} ) {
      $this->{error_mgr}->printMsg("  file = $file");
      my $sequences = $this->_parseFile($file);
      ###
      ### Add reference data if there is none
      ###
      my $ref_seq = $sequences->[0];
      $this->_addReferenceData( $ref_seq->{allele_name},
        $seq_type_id, $ref_seq->{seq} );
      ###
      ### Process each sequence
      ###
      foreach my $allele_seq ( @{$sequences} ) {
        my $allele_data = $this->{allele_names}->{ $allele_seq->{allele_name} };
        my $allele_id   = $allele_data->{allele_id};
        $this->{error_mgr}->printMsg(
          "    (name, id) = ("
            . join( util::Constants::COMMA_SEPARATOR,
            $allele_seq->{allele_name}, $allele_id )
            . ")"
        );
        my $missing_allele = util::Constants::EMPTY_LINE($allele_id);
        $this->{error_mgr}->printWarning(
          "The allele is not in database\n"
            . "  allele_name   = "
            . $allele_seq->{allele_name},
          $missing_allele
        );
        next if ($missing_allele);
        ###
        ### Initialize profile for generation of alignment sequence
        ###
        my $entity = $allele->initAllele;
        $entity->{allele_id} = $allele_id;
        $this->{error_mgr}
          ->printDebug( "add alignments--" . $entity->{allele_id} );
        ###
        ### Add the alignment sequence
        ###
        $allele->addAlignSeq( $allele_seq->{seq}, $seq_type_id );
        ###
        ### write the alignments for the sequence
        ###
        $allele->setAlignSeqs;
        $allele->moveEntity;
        $allele->writeProfile( $this->{generator}, util::Constants::TRUE );
      }
    }
  }
  $this->_writeReferenceData;
  chdir($currentDirectory);
}

################################################################################

1;

__END__

=head1 NAME

Msf.pm

=head1 DESCRIPTION

This class defines the reader for the Anthony Nolan B<*.msf> files
that contains sequence alignment data.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new anthonyNolan::Msf(taxon_id, msf_directory, generator, error_mgr)>

This is the constructor for the class.

=head2 B<processFiles>

This method processes the msf files and generates the alignments for
all of them.

=cut
