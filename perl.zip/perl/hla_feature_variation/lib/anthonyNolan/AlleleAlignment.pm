package anthonyNolan::AlleleAlignment;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PathSpecifics;
use util::PerlObject;

use db::MhcTypes;

use perl::Struct::Profile::Allele;

use anthonyNolan::ErrMsgs;

use fields
  qw (
  align_directory
  allele
  db_queries
  error_mgr
  generator
  queries
  pseudo_gene_id
  reference_alleles
  serializer
  view_map
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Queries to compute ALLELE_ALIGNMENT
###
sub ALIGNMENT_SEQ_QUERY      { return db::MhcTypes::ALIGNMENT_SEQ_TYPE; }
sub GENE_SEQ_STRUCTURE_QUERY { return 'AA_gene_seq_structure_query'; }
sub VARIANT_SEQ_QUERY        { return db::MhcTypes::VARIANT_SEQ_TYPE; }
sub VSS_START_POS_QUERY      { return 'AA_vss_start_pos_query'; }

sub DB_QUERIES {
  return {
    &GENE_SEQ_STRUCTURE_QUERY => {
      msg => 'GENE_SEQ_STRUCTURE Query',
      ord => [
        db::MhcTypes::GSS_START_POS_COL,  db::MhcTypes::GSS_END_POS_COL,
        db::MhcTypes::GENE_STRUCT_ID_COL, db::MhcTypes::ORDER_NUM_COL,
      ],
      cmd => "
select gss_start_pos,
       gss_end_pos,
       gene_struct_id,
       order_num
from   gene_seq_structure
where  allele_id = ?
order  by gss_start_pos
",
    },

    &VSS_START_POS_QUERY => {
      msg => 'VSS_START_POS Query',
      ord => [db::MhcTypes::VSS_START_POS_COL],
      cmd => "
select vss_start_pos
from   variant_seq_structure
where  locus_id    = ?
and    seq_type_id = ?
",
    },

    &ALIGNMENT_SEQ_QUERY => {
      msg => 'Alignment_Seq Query',
      ord => [ 'seq', ],
      cmd => "
select align_seq
from   alignment_seq
where  allele_id   = ?
and    seq_type_id = ?
",
    },

    &VARIANT_SEQ_QUERY => {
      msg => 'Variant_Seq Query',
      ord => [ 'seq', ],
      cmd => "
select var_seq
from   variant_seq
where  allele_id   = ?
and    seq_type_id = ?
",
    },

  };
}
###
### Order gene and allele_alignment structure
###
sub _sortGene {
  $a->{gss_start_pos} <=> $b->{gss_start_pos}
    or $a->{gss_end_pos} <=> $b->{gss_end_pos};
}

sub _sortAlleleAlignments {
  $a->{ungapped_start_pos} <=> $b->{ungapped_start_pos}
    or $a->{ungapped_end_pos} <=> $b->{ungapped_end_pos};
}
###
### View type map
###
sub VIEW_MAP {
  return {
    &db::MhcTypes::AA_SEQ   => [db::MhcTypes::EXON_VIEW],
    &db::MhcTypes::MRNA_SEQ =>
      [ db::MhcTypes::EXON_VIEW, db::MhcTypes::CODON_EXON_VIEW ],
    &db::MhcTypes::DNA_SEQ => [db::MhcTypes::UTR_EXON_INTRON_VIEW],
  };
}
### Error Category
###
sub ERR_CAT { return anthonyNolan::ErrMsgs::ALLELEALIGNMENT_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _determineReferenceAlleles {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ($taxon_id) = @_;
  $this->{reference_alleles} = {};
  my $alleleNames      = db::MhcTypes::alleleNames($taxon_id);
  my $referenceAlleles = db::MhcTypes::referenceAlleles($taxon_id);
  foreach my $locus_id ( keys %{$referenceAlleles} ) {
    $this->{reference_alleles}->{$locus_id} = {};
    my $locus = $referenceAlleles->{$locus_id};
    foreach my $seq_type_id ( keys %{$locus} ) {
      my $allele_name     = $locus->{$seq_type_id};
      my $allele          = $alleleNames->{$allele_name};
      my $seq_type_struct = {
        allele_name   => $allele_name,
        allele_id     => $allele->{allele_id},
        vss_start_pos => undef,
      };
      $this->{reference_alleles}->{$locus_id}->{$seq_type_id} =
        $seq_type_struct;
      ###
      ### Get the vss_start_pos data
      ###
      $this->{db_queries}
        ->executeQuery( VSS_START_POS_QUERY, $locus_id, $seq_type_id );
      while ( my $row_ref =
        $this->{db_queries}->fetchRowRef(VSS_START_POS_QUERY) )
      {
        my $struct = $this->_getStruct( VSS_START_POS_QUERY, $row_ref );
        $seq_type_struct->{vss_start_pos} = $struct->{vss_start_pos};
      }
    }
  }
}

sub _getStruct {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ( $query, $row ) = @_;
  my $ord    = $this->{queries}->{$query}->{ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _determineRefIntervals {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ($seq) = @_;

  my $seq_struct             = [];
  my $current_gapped_start   = undef;
  my $current_int_type       = undef;
  my $current_ungapped_start = undef;
  foreach my $index ( 0 .. length($seq) - 1 ) {
    my $char = substr( $seq, $index, 1 );
    if ( !defined($current_gapped_start) ) {
      $current_gapped_start   = $index + 1;
      $current_ungapped_start = $index + 1;
      if ( $char eq util::Constants::DOT ) {
        $current_int_type = 'insert';
      }
      elsif ( $char eq util::Constants::ASTERISK ) {
        $current_int_type = 'unsequenced';
      }
      else {
        $current_int_type = 'seq';
      }
    }
    my $int_type = undef;
    if ( $char eq util::Constants::DOT ) {
      $int_type = 'insert';
    }
    elsif ( $char eq util::Constants::ASTERISK ) {
      $int_type = 'unsequenced';
    }
    else {
      $int_type = 'seq';
    }
    if ( $int_type ne $current_int_type ) {
      my $struct = {
        gapped_start   => $current_gapped_start,
        gapped_end     => $index,
        len            => $index - $current_gapped_start + 1,
        type           => $current_int_type,
        ungapped_start => undef,
        ungapped_end   => undef,
      };
      if ( $current_int_type eq 'seq'
        || @{$seq_struct} == 0 )
      {
        $struct->{ungapped_start} = $current_ungapped_start;
        $struct->{ungapped_end} = $current_ungapped_start + $struct->{len} - 1;
        $current_ungapped_start = $struct->{ungapped_end} + 1;
      }
      else {
        $struct->{ungapped_start} = $current_ungapped_start - 1;
        $struct->{ungapped_end}   = $current_ungapped_start;
      }
      push( @{$seq_struct}, $struct );
      $current_int_type     = $int_type;
      $current_gapped_start = $index + 1;
    }
  }
  ###
  ### Must set the last interval
  ###
  my $struct = {
    gapped_start   => $current_gapped_start,
    gapped_end     => length($seq),
    len            => length($seq) - $current_gapped_start + 1,
    type           => $current_int_type,
    ungapped_start => undef,
    ungapped_end   => undef,
  };
  if ( $current_int_type eq 'seq' ) {
    $struct->{ungapped_start} = $current_ungapped_start;
    $struct->{ungapped_end}   = $current_ungapped_start + $struct->{len} - 1;
  }
  else {
    $struct->{ungapped_start} = $current_ungapped_start - 1;
    $struct->{ungapped_end}   = $current_ungapped_start;
  }
  push( @{$seq_struct}, $struct );

  return $seq_struct;
}

sub _getGappedCoord {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ( $ungapped_pos, $vss_start_pos, $seq_struct ) = @_;
  $this->{error_mgr}->printDebug("( $ungapped_pos, $vss_start_pos )");
  if ( ( $vss_start_pos < 0 && $ungapped_pos < 0 )
    || $vss_start_pos > 0 )
  {
    $ungapped_pos += 1 - $vss_start_pos;
  }
  else {
    $ungapped_pos += -$vss_start_pos;
  }
  $this->{error_mgr}->printDebug("( $ungapped_pos, $vss_start_pos )");
  my $gapped_pos = undef;
  foreach my $interval ( @{$seq_struct} ) {
    next
      if (
         $interval->{type} eq 'insert'
      || $interval->{type} eq 'unsequenced'
      || !(
           $ungapped_pos >= $interval->{ungapped_start}
        && $ungapped_pos <= $interval->{ungapped_end}
      )
      );
    $gapped_pos =
      $interval->{gapped_start} +
      ( $ungapped_pos - $interval->{ungapped_start} );
    last;
  }
  return $gapped_pos;
}

sub debugStruct {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ( $title, $struct ) = @_;

  return if ( !$this->{error_mgr}->isDebugging );
  $this->{error_mgr}->printDebug(
    "$title =\n"
      . $this->{serializer}->serializeObject(
      $struct, $this->{serializer}->PERL_OBJECT_WRITE_OPTIONS
      )
  );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ( $taxon_id, $generator, $db, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr}         = $error_mgr;
  $this->{generator}         = $generator;
  $this->{reference_alleles} = undef;
  $this->{view_map}          = VIEW_MAP;
  ###
  ### Get the pseudo gene locus id
  ###
  $this->{pseudo_gene_id} =
    db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE,
    db::MhcTypes::HLA_PSEUDO_GENE, $taxon_id );
  ###
  ### Instantiate the allele profile to contain the parse content
  ###
  $this->{allele} =
    new perl::Struct::Profile::Allele( util::Constants::TRUE, 'AnthonNolanHla',
    undef, undef, $error_mgr );
  $this->{allele}->setSkipHash('allele_nomenclature');
  ###
  ### serializer
  ###
  $this->{serializer} =
    new util::PerlObject( undef, undef, $this->{error_mgr} );
  ###
  ### setup queries
  ###
  $this->{db_queries} = new util::DbQuery($db);
  $this->{queries}    = DB_QUERIES;
  foreach my $query ( keys %{ $this->{queries} } ) {
    my $db_struct = $this->{queries}->{$query};
    $this->{db_queries}
      ->createQuery( $query, $db_struct->{cmd}, $db_struct->{msg} );
    $this->{db_queries}->prepareQuery($query);
  }
  ###
  ### Determine the reference alleles.
  ###
  $this->_determineReferenceAlleles($taxon_id);

  return $this;
}

sub _addPseudoGeneAlignment {
  my anthonyNolan::AlleleAlignment $this = shift;
  my ( $locus_id, $seq_len, $seq_type_id, $view_type_id, $alignment_type_id,
    $allele_alignments )
    = @_;
  ###
  ### Check to see if pseudo gene
  ###
  return
    if ( !defined( $this->{pseudo_gene_id} )
    || $locus_id != $this->{pseudo_gene_id} );
  ###
  ### At this point, we add one feature that is the whole sequence
  ###
  my $PSEUDO_GENE =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::PSEUDO_GENE );
  my $allele = $this->{allele};
  my $struct = $allele->initializeSubstructByComponent('allele_alignments');
  $struct->{seq_type_id}        = $seq_type_id;
  $struct->{ungapped_start_pos} = 1;
  $struct->{ungapped_end_pos}   = $seq_len;
  $struct->{view_type_id}       = $view_type_id;
  $struct->{alignment_type_id}  = $alignment_type_id;
  $struct->{gene_struct_id}     = $PSEUDO_GENE;
  $struct->{gapped_start_pos}   = 1;
  $struct->{gapped_end_pos}     = $seq_len;
  $struct->{interval_name}      = 'Psuedo Gene';
  push( @{$allele_alignments}, $struct );
}

sub processAlignments {
  my anthonyNolan::AlleleAlignment $this = shift;
  ###
  ### Gene Seq Structure Feature Type ID Constants
  ###
  my $AA_SEQ_TYPE_ID =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::AA_SEQ );

  my $CODON = db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::CODON );

  my $EXON = db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::EXON );

  my $FIVEPRIME_UTR =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::FIVE_PRIME_UTR );

  my $INSERT = db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::INSERT );

  my $INTRON = db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::INTRON );

  my $MATURE_PROTEIN =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::MATURE_PROTEIN );

  my $PROTEIN = db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::PROTEIN );

  my $THREEPRIME_UTR =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::THREE_PRIME_UTR );

  my $UNSEQUENCED =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::UNSEQUENCED );

  my $allele            = $this->{allele};
  my $processed_alleles = {};
  foreach my $locus_id ( keys %{ $this->{reference_alleles} } ) {
    $this->{error_mgr}->printMsg("locus_id = $locus_id");
    my $ref_struct = $this->{reference_alleles}->{$locus_id};
    foreach my $alignment_type ( db::MhcTypes::VARIANT_SEQ_TYPE,
      db::MhcTypes::ALIGNMENT_SEQ_TYPE )
    {
      $this->{error_mgr}->printMsg("  alignment_type = $alignment_type");
      my $alignment_type_id =
        db::MhcTypes::getId( db::MhcTypes::ALIGNMENT_TYPE_TABLE,
        $alignment_type );
      ###
      ### Compute the allele_alignment for reference sequence
      ### and the view types:
      ###
      ### 1.  AA_SEQ   - EXON_VIEW
      ### 2.  DNA_SEQ  - UTR_EXON_INTRON_VIEW
      ### 3.  MRNA_SEQ - EXON_VIEW
      ###              - CODON_EXON_VIEW
      ###
      foreach my $seq_type_id ( keys %{$ref_struct} ) {
        my $seq_type_struct = $ref_struct->{$seq_type_id};
        my $allele_id       = $seq_type_struct->{allele_id};
        my $allele_name     = $seq_type_struct->{allele_name};
        my $vss_start_pos   = $seq_type_struct->{vss_start_pos};

        my $seq_type =
          db::MhcTypes::getName( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type_id );

        my $aa_seq_type_struct = $ref_struct->{$AA_SEQ_TYPE_ID};
        my $codon_start_pos    = undef;
        if ( defined($aa_seq_type_struct) ) {
          $codon_start_pos = $aa_seq_type_struct->{vss_start_pos};
        }

        $this->{error_mgr}->printMsg( "    Reference data:\n"
            . "      allele_id       = $allele_id\n"
            . "      allele_name     = $allele_name\n"
            . "      vss_start_pos   = $vss_start_pos\n"
            . "      seq_type        = $seq_type\n"
            . "      codon_start_pos = $codon_start_pos" );

        my $processed_key = join( util::Constants::COLON,
          $alignment_type, $seq_type_id, $allele_id );
        next if ( defined( $processed_alleles->{$processed_key} ) );
        $processed_alleles->{$processed_key} = util::Constants::EMPTY_STR;

        my $seq = undef;
        $this->{db_queries}
          ->executeQuery( $alignment_type, $allele_id, $seq_type_id );
        while ( my $row_ref =
          $this->{db_queries}->fetchRowRef($alignment_type) )
        {
          my $struct = $this->_getStruct( $alignment_type, $row_ref );
          $seq = $struct->{seq};
        }
        $this->{error_mgr}->printMsg("    NO SEQ FOR DATA, SKIPPING...")
          if ( !defined($seq) );
        next if ( !defined($seq) );
        ###
        ### Get gene seq structure features
        ###
        my $gene_struct = [];
        $this->{db_queries}
          ->executeQuery( GENE_SEQ_STRUCTURE_QUERY, $allele_id );
        while ( my $row_ref =
          $this->{db_queries}->fetchRowRef(GENE_SEQ_STRUCTURE_QUERY) )
        {
          my $interval =
            $this->_getStruct( GENE_SEQ_STRUCTURE_QUERY, $row_ref );
          next
            if (
            (
                 $seq_type eq db::MhcTypes::AA_SEQ
              || $seq_type eq db::MhcTypes::MRNA_SEQ
            )
            && $interval->{gene_struct_id} != $EXON
            );
          push( @{$gene_struct}, $interval );
        }
	$this->debugStruct("initial gene_struct", $gene_struct);
        ###
        ### Get the sequence structure
        ###
        my $initial_unseq = undef;
        if ( $seq =~ /^(\*+)/ || $seq =~ /^(\.+)/ ) { $initial_unseq = $1; }
        my $seq_struct = $this->_determineRefIntervals($seq);
        $this->debugStruct("seq_struct", $seq_struct);
        if ( $seq_type eq db::MhcTypes::AA_SEQ
          || $seq_type eq db::MhcTypes::MRNA_SEQ )
        {
          ###
          ### Reset Ungapped Coordinates
          ###
          my $start = $gene_struct->[0]->{gss_start_pos};
          foreach my $interval ( @{$gene_struct} ) {
            $interval->{gss_start_pos} -= ( $start - 1 );
            $interval->{gss_end_pos}   -= ( $start - 1 );
          }
          my $current_end_pos = $gene_struct->[0]->{gss_end_pos};
          foreach my $index ( 1 .. $#{$gene_struct} ) {
            my $interval  = $gene_struct->[$index];
            my $start_pos = $interval->{gss_start_pos};
            my $end_pos   = $interval->{gss_end_pos};
            $interval->{gss_start_pos} = $current_end_pos + 1;
            $interval->{gss_end_pos}   =
              $current_end_pos + ( $end_pos - $start_pos + 1 );
            $current_end_pos = $interval->{gss_end_pos};
          }
          ###
          ### Add Codons
          ###
          my $end_pos       = $gene_struct->[ $#{$gene_struct} ]->{gss_end_pos};
          my $current_start = 1;
          my $next_end      = 0;
          my $num_codons    = $codon_start_pos;
          if ( !defined($num_codons) ) {
            $this->{error_mgr}
              ->printMsg("      num_codons NOT DEFINED, setting to 1");
            $num_codons = 1;
          }
          while ( $current_start < $end_pos ) {
            my $struct = {
              gss_start_pos  => $current_start,
              gss_end_pos    => $current_start + 2,
              gene_struct_id => $CODON,
              order_num      => $num_codons,
            };
            $num_codons++;
            if ( $num_codons == 0 ) { $num_codons++; }
            $current_start += 3;
            push( @{$gene_struct}, $struct );
          }
        }
        if ( $seq_type eq db::MhcTypes::AA_SEQ ) {
          my $tmp_gene_struct = [];
          my $codons          = [];
          my $exons           = [];
          @{$gene_struct} = sort _sortGene @{$gene_struct};
          foreach my $interval ( @{$gene_struct} ) {
            if ( $interval->{gene_struct_id} == $CODON ) {
              push( @{$codons}, $interval );
            }
            elsif ( $interval->{gene_struct_id} == $EXON ) {
              push( @{$exons}, $interval );
            }
          }
          $this->debugStruct("exons", $exons);
	  $this->debugStruct("codons", $codons);
          ###
          ### Process exons to get ungapped protein coordinates
          ###
          foreach my $exon ( @{$exons} ) {
            my $first_codon = $codons->[0];
            $this->{error_mgr}->exitProgram(
              ERR_CAT, 1,
              [
                'start assign to exon',
                'codon = '
                  . join( util::Constants::COMMA_SEPARATOR,
                  $first_codon->{gss_start_pos},
                  $first_codon->{gss_end_pos}
                  ),
                'exon = '
                  . join( util::Constants::COMMA_SEPARATOR,
                  $exon->{gss_start_pos},
                  $exon->{gss_end_pos}
                  )
              ],
              !(
                (
                     $first_codon->{gss_start_pos} >= $exon->{gss_start_pos}
                  && $first_codon->{gss_start_pos} <= $exon->{gss_end_pos}
                )
                || ( $first_codon->{gss_end_pos} >= $exon->{gss_start_pos}
                  && $first_codon->{gss_end_pos} <= $exon->{gss_end_pos} )
              )
            );
            shift( @{$codons} )
              if ( $first_codon->{gss_start_pos} < $exon->{gss_start_pos} );
            my $gss_end_pos = undef;
            while ( util::Constants::TRUE && @{$codons} > 0 ) {
              my $codon = $codons->[0];
              last
                if (
                !(
                     $codon->{gss_start_pos} >= $exon->{gss_start_pos}
                  && $codon->{gss_start_pos} <= $exon->{gss_end_pos}
                )
                );
              $gss_end_pos = $codon->{order_num};
              last
                if (
                !(
                     $codon->{gss_end_pos} >= $exon->{gss_start_pos}
                  && $codon->{gss_end_pos} <= $exon->{gss_end_pos}
                )
                );
              shift( @{$codons} );
            }
            $exon->{gss_start_pos} = $first_codon->{order_num};
            $exon->{gss_end_pos}   = $gss_end_pos;
            push( @{$tmp_gene_struct}, $exon );
          }
          ###
          ### Add the proteins
          ###
          my $gss_start_pos = undef;
          my $gss_end_pos   = undef;
          if ( $vss_start_pos < 0 ) {
            $gss_start_pos = 1;
            $gss_end_pos   = $vss_start_pos + length($seq);
          }
          else {
            $gss_start_pos = $vss_start_pos;
            $gss_end_pos   = $vss_start_pos + length($seq) - 1;
          }
          my $struct = {
            gss_start_pos  => $vss_start_pos,
            gss_end_pos    => $gss_end_pos,
            gene_struct_id => $PROTEIN,
            order_num      => undef,
          };
          push( @{$tmp_gene_struct}, $struct );
          $struct = {
            gss_start_pos  => $gss_start_pos,
            gss_end_pos    => $gss_end_pos,
            gene_struct_id => $MATURE_PROTEIN,
            order_num      => undef,
          };
          push( @{$tmp_gene_struct}, $struct );
          $gene_struct = $tmp_gene_struct;
        }
        @{$gene_struct} = sort _sortGene @{$gene_struct};
        $this->debugStruct("intermediate gene_struct", $gene_struct);
        ###
        ### Fix coordinates for DNA seq and also adjust for initial
        ### unsequenced segment
        ###
        my $dna_start_pos = $vss_start_pos;
        if ( $seq_type eq db::MhcTypes::DNA_SEQ
          && $vss_start_pos < 0 )
        {
          ###
          ### The adjustment depends on whether there is an
          ### initial unsequenced segment
          ###
          if ( !util::Constants::EMPTY_LINE($initial_unseq) ) {
            $dna_start_pos += length($initial_unseq);
            $this->{error_mgr}->printMsg( "Initial Unsequenced Length\n"
                . "  unseq length  = "
                . length($initial_unseq) . "\n"
                . "  dna_start_pos = $dna_start_pos" );
          }
          foreach my $interval ( @{$gene_struct} ) {
            $interval->{gss_start_pos} += $dna_start_pos;
            $interval->{gss_end_pos}   += $dna_start_pos;
            if ( $interval->{gss_start_pos} <= 0 ) {
              $interval->{gss_start_pos}--;
            }
            if ( $interval->{gss_end_pos} <= 0 ) { $interval->{gss_end_pos}--; }
          }
        }
        $this->debugStruct("gene_struct", $gene_struct);
        ###
        ### Compute allele_alignments
        ###
        my $allele_alignments = [];
        foreach my $view_type ( @{ $this->{view_map}->{$seq_type} } ) {
          my $view_type_id =
            db::MhcTypes::getId( db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE,
            $view_type );
          ###
          ### Add inserts and unsequenceds
          ###
          foreach my $interval ( @{$seq_struct} ) {
            next
              if ( $interval->{type} ne 'insert'
              && $interval->{type} ne 'unsequenced' );

            my $ungapped_start = $interval->{ungapped_start} + $vss_start_pos;
            my $ungapped_end   = $interval->{ungapped_end} + $vss_start_pos;
            if ( $ungapped_start <= 0 ) { $ungapped_start--; }
            if ( $ungapped_end <= 0 )   { $ungapped_end--; }
            my $struct =
              $allele->initializeSubstructByComponent('allele_alignments');
            $struct->{seq_type_id}        = $seq_type_id;
            $struct->{ungapped_start_pos} = $ungapped_start;
            $struct->{ungapped_end_pos}   = $ungapped_end;
            $struct->{alignment_type_id}  = $alignment_type_id;
            $struct->{view_type_id}       = $view_type_id;
            $struct->{gene_struct_id}     =
              ( $interval->{type} eq 'insert' ) ? $INSERT : $UNSEQUENCED;
            $struct->{gapped_start_pos} = $interval->{gapped_start};
            $struct->{gapped_end_pos}   = $interval->{gapped_end};
            $struct->{interval_name}    =
              ( $interval->{type} eq 'insert' ) ? 'Insert' : 'Unsequenced';
            push( @{$allele_alignments}, $struct );
          }
          ###
          ### Process For each sort
          ###
          foreach my $interval ( @{$gene_struct} ) {
            $this->{error_mgr}->printDebug( "interval = ("
                . join( util::Constants::COMMA_SEPARATOR, %{$interval} )
                . ')' );
            my $gapped_start =
              $this->_getGappedCoord( $interval->{gss_start_pos},
              $vss_start_pos, $seq_struct );
            $this->{error_mgr}->printDebug("gapped_start = $gapped_start");
            my $gapped_end = $this->_getGappedCoord( $interval->{gss_end_pos},
              $vss_start_pos, $seq_struct );
            $this->{error_mgr}->printDebug("gapped_end = $gapped_end");
            if ( $seq_type eq db::MhcTypes::DNA_SEQ ) {
              ###
              ### NO-OP
              ###
            }
            elsif ( $seq_type eq db::MhcTypes::AA_SEQ ) {
              if ( !defined($gapped_start) ) {
                $this->{error_mgr}->printMsg(
                  "      undefined $seq_type gapped_start, skipping...");
                next;
              }
            }
            elsif ( $seq_type eq db::MhcTypes::MRNA_SEQ ) {
              $this->{error_mgr}->printMsg(
                "      undefined $seq_type gapped_start, skipping...")
                if ( !defined($gapped_start) );
              next
                if (
                !defined($gapped_start)
                || ( $view_type eq db::MhcTypes::EXON_VIEW
                  && $interval->{gene_struct_id} == $CODON )
                );
            }
            ###
            ### If gapped_end is undefined snap it back
            ### to the current sequence end
            ###
            if ( !defined($gapped_end) ) {
              $this->{error_mgr}
                ->printMsg("      undefined $seq_type gapped_end");
              my $sequence = $seq;
              $gapped_end = length($sequence);
              $sequence =~ s/\.|\*//g;
              if ( $seq_type eq db::MhcTypes::DNA_SEQ ) {
                if ( $dna_start_pos < 0 ) {
                  $interval->{gss_end_pos} = length($sequence) + $dna_start_pos;
                }
                else {
                  $interval->{gss_end_pos} =
                    length($sequence) - ( $dna_start_pos - 1 );
                }
              }
              else {
                if ( $vss_start_pos < 0 ) {
                  $interval->{gss_end_pos} = length($sequence) + $vss_start_pos;
                }
                else {
                  $interval->{gss_end_pos} =
                    length($sequence) - ( $vss_start_pos - 1 );
                }
              }

              $this->{error_mgr}
                ->printMsg("      $seq_type gapped_end = $gapped_end");
            }
            ###
            ### Compute the interval name
            ###
            my $interval_name = undef;
            if ( $interval->{gene_struct_id} == $CODON ) {
              $interval_name = $interval->{order_num};
            }
            elsif ( $interval->{gene_struct_id} == $EXON ) {
              $interval_name = 'Exon ' . $interval->{order_num};
            }
            elsif ( $interval->{gene_struct_id} == $INTRON ) {
              $interval_name = 'Intron ' . $interval->{order_num};
            }
            elsif ( $interval->{gene_struct_id} == $FIVEPRIME_UTR ) {
              $interval_name = "5' UTR";
            }
            elsif ( $interval->{gene_struct_id} == $THREEPRIME_UTR ) {
              $interval_name = "3' UTR";
            }
            elsif ( $interval->{gene_struct_id} == $PROTEIN ) {
              $interval_name = 'Full Protein';
            }
            elsif ( $interval->{gene_struct_id} == $MATURE_PROTEIN ) {
              $interval_name = 'Mature Protein';
            }
            my $struct =
              $allele->initializeSubstructByComponent('allele_alignments');
            $struct->{seq_type_id}        = $seq_type_id;
            $struct->{ungapped_start_pos} = $interval->{gss_start_pos};
            $struct->{ungapped_end_pos}   = $interval->{gss_end_pos};
            $struct->{view_type_id}       = $view_type_id;
            $struct->{alignment_type_id}  = $alignment_type_id;
            $struct->{gene_struct_id}     = $interval->{gene_struct_id};
            $struct->{gapped_start_pos}   = $gapped_start;
            $struct->{gapped_end_pos}     = $gapped_end;
            $struct->{interval_name}      = $interval_name;
            push( @{$allele_alignments}, $struct );
          }
          ###
          ### Add the pseudo gene alignment for the pseudo gene
          ###
          $this->_addPseudoGeneAlignment( $locus_id, length($seq), $seq_type_id,
            $view_type_id, $alignment_type_id, $allele_alignments );

          @{$allele_alignments} =
            sort _sortAlleleAlignments @{$allele_alignments};
          $this->debugStruct("allele_alignments", $allele_alignments);
        }
        ###
        ### write the allele alignments for the reference sequence
        ###
        my $entity = $allele->initAllele;
        $entity->{allele_id} = $allele_id;
        $this->{error_mgr}
          ->printMsg( "    add allele alignments--" . $entity->{allele_id} );
        foreach my $allele_alignment ( @{$allele_alignments} ) {
          $allele->addAlignment(
            $allele_alignment->{seq_type_id},
            $allele_alignment->{view_type_id},
            $allele_alignment->{alignment_type_id},
            $allele_alignment->{gene_struct_id},
            $allele_alignment->{ungapped_start_pos},
            $allele_alignment->{ungapped_end_pos},
            $allele_alignment->{gapped_start_pos},
            $allele_alignment->{gapped_end_pos},
            $allele_alignment->{interval_name}
          );
        }
        $allele->setAlignments;
        $allele->moveEntity;
        $allele->writeProfile( $this->{generator}, util::Constants::TRUE );
      }
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

Align.pm

=head1 DESCRIPTION

This class defines the mechanism for generating the features in the
allele_alignment table for the alignment_seq and the variant_seq
alignments.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new anthonyNolan::AlleleAlignment(taxon_id, align_directory, generator, db, error_mgr)>

This is the constructor for the class.

=head2 B<processAlignments>

This method processes the alignments for each alignment type for each
locus.

=cut
