package anthonyNolan::Hla;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::Defline;
use util::PathSpecifics;
use util::PerlObject;

use anthonyNolan::ErrMsgs;

use db::MhcTypes;

use file::Index;

use lookup::LookupTable::CwdAlleles;

use perl::Struct::Profile::Allele;

use fields qw (
  allele
  allele_id
  cwd_lookup
  defline
  error_mgr
  full_length
  gcode_map
  generator
  hla_file
  hla_index
  ids
  kw_pos
  locus_name
  nomenclature_map
  nomenclature_ord
  organism
  pcode_map
  taxon_id
  tools
);

################################################################################
#
#			     Static Class Constants
#
################################################################################

sub ACCESSION_EXPR      { return '^AC\s+(\S+);$'; }
sub DATE_STRUCT         { return '^(\S+) \((.+)\)$'; }
sub END_STRUCT          { return '^\/\/$'; }
sub ENTITY_EXPR         { return 'ID   '; }
sub EXACT_INTERVAL      { return '^(\d+)\.\.(\d+)$'; }
sub GROUP_TAG           { return 'XX'; }
sub INTERVAL_STRUCT     { return '(\d+)\.\.(\d+)'; }
sub KEY_STRUCT          { return '^(\w+)     (.+)$'; }
sub OPEN_LEFT_INTERVAL  { return '^<'; }
sub OPEN_RIGHT_INTERVAL { return '>$'; }
sub PUBMED_STRUCT       { return '^PUBMED; (\d+)\.$'; }
sub SEQ_STRUCT          { return '^([acgt][acgt ]*)\s+(\d+)$'; }
sub TAG_STRUCT          { return '^(XX|FH)$|^(\w+)\s+(.+)$|^(\s+)(.+)$'; }

sub ANNOT_UPDATE { return 'Current Release'; }
sub CREATE_DATE  { return 'Created'; }
sub SEQ_UPDATE   { return 'Sequence Updated'; }

sub CELL_LINE_TAG { return 'cell_line'; }

sub HLA_POS { return 1; }

sub KW_POS {
  return {
    HLA => {
      locus_name  => 3,
      allele_name => 5,
    },
    NON_HLA => {
      locus_name  => 2,
      allele_name => 4,
    },
  };
}

sub ERR_CAT { return anthonyNolan::ErrMsgs::HLA_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################
###
### Initialize the controlled vocabulary ids
### for new entries in the following tables:
###
###  1.  EVIDENCE_AUTHORITY
###  2.  MHC_LOCUS
###
sub _setIds {
  my anthonyNolan::Hla $this = shift;
  $this->{ids} = {};
  foreach my $table ( db::MhcTypes::MHC_LOCUS_TABLE,
    db::MhcTypes::EVIDENCE_AUTHORITY_TABLE )
  {
    $this->{ids}->{$table} = {
      id    => db::MhcTypes::maxId($table) + 1,
      names => {},
    };
  }
}

sub _getId {
  my anthonyNolan::Hla $this = shift;
  my ( $table, $name ) = @_;
  ###
  ### Get it from the database
  ###
  my $id = db::MhcTypes::getId( $table, $name, $this->{taxon_id} );
  return $id if ( !util::Constants::EMPTY_LINE($id) );
  ###
  ### Get it from new names
  ###
  my $struct = $this->{ids}->{$table};
  $id = $struct->{names}->{$name};
  return $id if ( !util::Constants::EMPTY_LINE($id) );
  ###
  ### Create new name
  ###
  $id = $struct->{id};
  $struct->{id}++;
  $struct->{names}->{$name} = $id;
  return $id;
}

sub _checkTaxon {
  my anthonyNolan::Hla $this = shift;
  my $taxon_id =
    db::MhcTypes::getId( db::MhcTypes::TAXONOMY_TABLE, $this->{organism} );
  $this->{error_mgr}->registerError(
    ERR_CAT, 1,
    [
          "Cannot find taxon id for organism\n"
        . "  organism = "
        . $this->{organism}
    ],
    !defined($taxon_id)
  );
  if ( !defined( $this->{taxon_id} ) ) {
    $this->{taxon_id} = $taxon_id;
    $this->{cwd_lookup} =
      new lookup::LookupTable::CwdAlleles( $this->{taxon_id}, $this->{tools},
      $this->{error_mgr} );
  }
  else {
    $this->{error_mgr}->registerError(
      ERR_CAT, 1,
      [
            "Differing taxons in file\n"
          . "  taxon         = "
          . $this->{taxon_id} . "\n"
          . "  current taxon = $taxon_id"
      ],
      $this->{taxon_id} ne $taxon_id
    );
  }
}

sub _processDT {
  my anthonyNolan::Hla $this = shift;
  my ($group) = @_;

  my $allele      = $this->{allele};
  my $entity      = $allele->entity;
  my $date_struct = DATE_STRUCT;

  my $dates   = {};
  my $release = undef;
  foreach my $line ( @{$group} ) {
    next if ( $line->{tag} ne 'DT' );
    my $val = $line->{val};
    $val =~ /$date_struct/;
    my $date = $1;
    my ( $rel, $type, $vers ) = split( /, /, $2 );
    $rel =~ /^Rel\. (.+)$/;
    $release = $1;
    if ( defined($vers) ) {
      $vers =~ /^Version (.+)$/;
      $vers = $1;
    }
    my $struct = {
      date => $date,
      vers => $vers,
    };
    $dates->{$type} = $struct;
  }
  $entity->{release_version}   = $release;
  $entity->{seq_version}       = $dates->{&SEQ_UPDATE}->{vers};
  $entity->{annot_version}     = $dates->{&ANNOT_UPDATE}->{vers};
  $entity->{seq_create_date}   = $dates->{&CREATE_DATE}->{date};
  $entity->{seq_update_date}   = $dates->{&SEQ_UPDATE}->{date};
  $entity->{annot_update_date} = $dates->{&ANNOT_UPDATE}->{date};
}

sub _kwPos {
  my anthonyNolan::Hla $this = shift;
  my ($hla_str) = @_;
  return $this->{kw_pos}->{HLA} if ( $hla_str eq 'HLA' );
  return $this->{kw_pos}->{NON_HLA};
}

sub _processKW {
  my anthonyNolan::Hla $this = shift;
  my ($group) = @_;

  my $allele = $this->{allele};
  my $entity = $allele->entity;

  my $first_line = $group->[0]->{val};
  my @kw_array   = split( /;/, $first_line );
  my $hla_pos    = $kw_array[HLA_POS];
  $hla_pos =~ s/^\s+//;
  my $kw_pos = $this->_kwPos($hla_pos);
  $entity->{allele_name} = $kw_array[ $kw_pos->{allele_name} ];
  $this->{locus_name}    = $kw_array[ $kw_pos->{locus_name} ];
  $entity->{allele_name} =~ s/^\s+//;
  $this->{locus_name}    =~ s/^\s+//;
  ###
  ### Get the old allele name if there is one.
  ###
  $entity->{old_allele_name} = $this->{nomenclature_map}->{$entity->{allele_name}};
  ###
  ### For some reason some MIC loci contain an asterisk.
  ###
  if ( $this->{locus_name} =~ /^(\w+)\*/ ) {
    $this->{locus_name} = $1;
  }
  ###
  ### generate allele_nomenclature
  ###
  my $allele_nomenclature =
    $allele->getCValue( $entity, $allele->ALLELE_NOMENCLATURE_PATH );
  $allele_nomenclature->{allele_id}   = $entity->{allele_id};
  $allele_nomenclature->{allele_name} = $entity->{allele_name};

  $entity->{allele_name} =~ /^(\w+)\*([0-9:]+)([A-Z]?)$/;
  $allele_nomenclature->{locus_name} = $1;
  my $digits = $2;
  $allele_nomenclature->{suffix} = $3;

  my @digits = split( /:/, $digits );
  foreach my $index ( 0 .. $#digits ) {
    $allele_nomenclature->{ $this->{nomenclature_ord}->[$index] } =
      $digits[$index];
  }
  ###
  ### Generate order_allele_name
  ###
  $entity->{order_allele_name} =
    $allele_nomenclature->{locus_name} . util::Constants::ASTERISK;
  foreach my $index ( 0 .. $#digits ) {
    if ( $index > 0 ) {
      $entity->{order_allele_name} .= util::Constants::COLON;
    }
    my $digit = $digits[$index];
    my $len   = length($digit);
    if    ( $len == 1 ) { $digit = '00' . $digit; }
    elsif ( $len == 2 ) { $digit = '0' . $digit; }
    $entity->{order_allele_name} .= $digit;
  }
  if ( defined( $allele_nomenclature->{suffix} ) ) {
    $entity->{order_allele_name} .= $allele_nomenclature->{suffix};
  }
}

sub _processRN {
  my anthonyNolan::Hla $this = shift;
  my ($group) = @_;

  my $allele        = $this->{allele};
  my $pubmed_struct = PUBMED_STRUCT;

  my $pmid  = undef;
  my $title = util::Constants::EMPTY_STR;
  foreach my $line ( @{$group} ) {
    my $tag = $line->{tag};
    my $val = $line->{val};
    if ( $tag eq 'RX' && $val =~ /$pubmed_struct/ ) { $pmid = $1; }
    elsif ( $tag eq 'RT' ) {
      if ( !util::Constants::EMPTY_LINE($title) ) {
        $title .= util::Constants::SPACE;
      }
      $title .= $val;
    }
  }
  $title =~ s/^"//;
  $title =~ s/";$//;
  $allele->addPmid( $pmid, $title );
}

sub _processDR {
  my anthonyNolan::Hla $this = shift;
  my ($group) = @_;

  my $allele = $this->{allele};
  foreach my $line ( @{$group} ) {
    my $tag = $line->{tag};
    my $val = $line->{val};
    next if ( $tag ne 'DR' );
    my ( $authority, $accession, $acc_version ) = split( /;/, $val );
    $authority   =~ s/ //g;
    $accession   =~ s/ //g;
    $accession   =~ s/\.$//;
    $acc_version =~ s/ //g;
    $acc_version =~ s/\.$//;
    my $authority_id =
      $this->_getId( db::MhcTypes::EVIDENCE_AUTHORITY_TABLE, $authority );
    $allele->addEvidence( $accession, $authority_id, $acc_version );
  }
}

sub _processCC {
  my anthonyNolan::Hla $this = shift;
  my ($group) = @_;

  my $allele   = $this->{allele};
  my $entity   = $allele->entity;
  my $comments = util::Constants::EMPTY_STR;
  foreach my $line ( @{$group} ) {
    my $val = $line->{val};
    if ( !util::Constants::EMPTY_LINE($comments) ) {
      $comments .= util::Constants::SPACE;
    }
    $comments .= $val;
  }
  $entity->{comments} = $comments;
}

sub _addFtComp {
  my anthonyNolan::Hla $this = shift;
  my ( $keys, $current_key, $current_val ) = @_;
  return if ( !defined($current_key) );
  if ( !defined( $keys->{$current_key} ) ) {
    $keys->{$current_key} = [];
  }
  my $loc  = undef;
  my $qual = undef;
  if ( $current_val =~ /^(\S+) (.+)$/ ) {
    $loc  = $1;
    $qual = $2;
    $qual =~ s/ \/partial/ \/partial=1/;
    $qual =~ s/ \/pseudo/ \/pseudo=1/;
  }
  else {
    $loc = $current_val;
  }
  push( @{ $keys->{$current_key} }, { loc => $loc, qual => $qual } );
}

sub _parseFtLines {
  my anthonyNolan::Hla $this = shift;
  my ($ft_lines) = @_;
  ###
  ### Key Location/Qualifiers
  ###
  my $current_key     = undef;
  my $current_val     = util::Constants::EMPTY_STR;
  my $found_qualifier = util::Constants::FALSE;
  my $key_struct      = KEY_STRUCT;
  my $keys            = {};
  foreach my $val ( @{$ft_lines} ) {
    ###
    ### Encounter a key line
    ###
    if ( $val =~ /$key_struct/ ) {
      my $key      = $1;
      my $loc_qual = $2;
      $loc_qual =~ s/^\s+//;

      $this->_addFtComp( $keys, $current_key, $current_val );

      $current_key     = $key;
      $current_val     = $loc_qual;
      $found_qualifier = util::Constants::FALSE;
    }
    else {
      if ( $val =~ /^\// ) {
        $found_qualifier = util::Constants::TRUE;
      }
      if ($found_qualifier) { $current_val .= util::Constants::SPACE; }
      $current_val .= $val;
    }
  }
  $this->_addFtComp( $keys, $current_key, $current_val );
  $this->{tools}->debugStruct("ft parse", $keys);
  
  return $keys;
}

sub _addGeneSeqStruct {
  my anthonyNolan::Hla $this = shift;
  my ( $loc, $gene_struct_name, $order_num ) = @_;
  my $allele         = $this->{allele};
  my $exact_interval = EXACT_INTERVAL;
  $loc =~ /$exact_interval/;
  my $gss_start_pos = $1;
  my $gss_end_pos   = $2;
  my $gene_struct_id =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    $gene_struct_name );
  $allele->addGeneSeqStruct( $gss_start_pos, $gss_end_pos, $gene_struct_id,
    $order_num );
}

sub _generateCds {
  my anthonyNolan::Hla $this = shift;
  my ($loc) = @_;

  my $allele      = $this->{allele};
  my $entity      = $allele->entity;
  my $trans_start = undef;
  my $trans_stop  = undef;

  my $exact_interval      = EXACT_INTERVAL;
  my $interval_struct     = INTERVAL_STRUCT;
  my $open_left_inteval   = OPEN_LEFT_INTERVAL;
  my $open_right_interval = OPEN_RIGHT_INTERVAL;

  $loc =~ s/^join\(//;
  $loc =~ s/\)$//;
  my @intervals = split( /,/, $loc );
  foreach my $index ( 0 .. $#intervals ) {
    my $interval = $intervals[$index];
    $interval =~ /$interval_struct/;
    my $css_start_pos   = $1;
    my $css_end_pos     = $2;
    my $cds_struct_name = undef;
    if ( $interval =~ /$exact_interval/ ) {
      $cds_struct_name = db::MhcTypes::EXACT_INTERVAL;
    }
    elsif ( $interval =~ /$open_left_inteval/
      && $interval =~ /$open_right_interval/ )
    {
      $cds_struct_name = db::MhcTypes::OPEN_LEFT_AND_RIGHT_INTERVAL;
    }
    elsif ( $interval =~ /$open_left_inteval/ ) {
      $cds_struct_name = db::MhcTypes::OPEN_LEFT_INTERVAL;
    }
    elsif ( $interval =~ /$open_right_interval/ ) {
      $cds_struct_name = db::MhcTypes::OPEN_RIGHT_INTERVAL;
    }
    my $cds_struct_id =
      db::MhcTypes::getId( db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE,
      $cds_struct_name );
    $allele->addCdsSeqStruct( $css_start_pos, $css_end_pos, $cds_struct_id );
    ###
    ### Determine trans_start and trans_stop
    ###
    if (
      $index == 0
      && ( $cds_struct_name eq db::MhcTypes::EXACT_INTERVAL
        || $cds_struct_name eq db::MhcTypes::OPEN_RIGHT_INTERVAL )
      )
    {
      $trans_start = $css_start_pos;
    }
    if (
      $index == $#intervals
      && ( $cds_struct_name eq db::MhcTypes::EXACT_INTERVAL
        || $cds_struct_name eq db::MhcTypes::OPEN_LEFT_INTERVAL )
      )
    {
      $trans_stop = $css_end_pos;
    }
  }
  return ( $trans_start, $trans_stop );
}

sub _getDeflineTag {
  my anthonyNolan::Hla $this = shift;
  my ($tag) = @_;
  my $vals =
    $this->{defline}->getValueOrNull( $tag, $this->{defline}->DEFLINE_TAG );
  if ( ref($vals) eq util::PerlObject::ARRAY_TYPE ) {
    my $tmp_vals = [];
    foreach my $val ( @{$vals} ) {
      $val =~ s/^"//;
      $val =~ s/"$//;
      push( @{$tmp_vals}, $val );
    }
    $vals = $tmp_vals;
  }
  else {
    $vals =~ s/^"//;
    $vals =~ s/"$//;
  }
  return $vals;
}

sub _processFT {
  my anthonyNolan::Hla $this = shift;
  my ($ft_lines) = @_;

  my $allele = $this->{allele};
  my $entity = $allele->entity;

  my $exact_interval = EXACT_INTERVAL;
  ###
  ### Initialize FT local attributes
  ###
  my $partial = util::Constants::FALSE;
  my $pseudo  = util::Constants::FALSE;
  ###
  ### Process key location/qualifiers
  ###
  my $keys = $this->_parseFtLines($ft_lines);
  while ( my ( $key, $loc_qual_array ) = each %{$keys} ) {
    foreach my $loc_qual ( @{$loc_qual_array} ) {
      my $loc = $loc_qual->{loc};
      $this->{defline}->parseDefline( $loc_qual->{qual}, "$key qualifier" )
        if ( !util::Constants::EMPTY_LINE( $loc_qual->{qual} ) );

      if ( $key eq 'CDS' ) {
        $partial = $this->_getDeflineTag('partial');
        my $codon_start = $this->_getDeflineTag('codon_start');
        my $aa_seq      = $this->_getDeflineTag('translation');

        $this->{full_length} =
          ( $loc =~ /^join\(/ ) ? util::Constants::TRUE : $this->{full_length};
        ###
        ### Generate AA sequence
        ###
        if ( !util::Constants::EMPTY_LINE($aa_seq) ) {
          $aa_seq =~ s/ //g;
          $allele->addMolSeq(
            $aa_seq,
            db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE,
              db::MhcTypes::AA_SEQ
            )
          );
        }
        ###
        ### Compute the CDS coordinates
        ###
        my ( $trans_start, $trans_stop ) = $this->_generateCds($loc);
        ###
        ### Fill in cds columns for entity
        ###
        $entity->{cds_positions} = $loc;
        $entity->{codon_start}   = $codon_start;
        $entity->{trans_start}   = $trans_start;
        $entity->{trans_stop}    = $trans_stop;
      }
      elsif ( $key eq 'UTR' ) {
        $loc =~ /$exact_interval/;
        my $gss_start_pos = $1;
        my $utr_name      = undef;
        if ( $gss_start_pos == 1 ) { $utr_name = db::MhcTypes::FIVE_PRIME_UTR; }
        else { $utr_name = db::MhcTypes::THREE_PRIME_UTR; }
        $this->_addGeneSeqStruct( $loc, $utr_name );
      }
      elsif ( $key eq 'exon' ) {
        my $partial   = $this->_getDeflineTag('partial');
        my $order_num = $this->_getDeflineTag('number');
        my $exon_name = undef;
        if ( !util::Constants::EMPTY_LINE($partial) && $partial ) {
          $exon_name = db::MhcTypes::PARTIAL_EXON;
        }
        else {
          $exon_name = db::MhcTypes::EXON;
        }
        $this->_addGeneSeqStruct( $loc, $exon_name, $order_num );
      }
      elsif ( $key eq 'gene' ) {
        $entity->{cds_positions} = $loc;
        $this->{full_length}     = util::Constants::TRUE;
        $pseudo                  = $this->_getDeflineTag('pseudo');
        $loc =~ /$exact_interval/;
        my $css_start_pos = $1;
        my $css_end_pos   = $2;
        my $cds_struct_id =
          db::MhcTypes::getId( db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE,
          db::MhcTypes::EXACT_INTERVAL );
        $allele->addCdsSeqStruct( $css_start_pos, $css_end_pos,
          $cds_struct_id );
      }
      elsif ( $key eq 'intron' ) {
        my $order_num = $this->_getDeflineTag('number');
        $this->_addGeneSeqStruct( $loc, db::MhcTypes::INTRON, $order_num );
      }
      elsif ( $key eq 'source' ) {
        $this->{organism} = $this->_getDeflineTag('organism');
        my $cell_lines = $this->_getDeflineTag('cell_line');
        next if ( ref($cell_lines) ne util::PerlObject::ARRAY_TYPE );
        foreach my $cell_line ( @{$cell_lines} ) {
          $allele->addBiosource($cell_line);
        }
      }
    }
  }
  ###
  ### Set the booleans values for partial and pseudo
  ###
  if   ($partial) { $entity->{partial_seq} = 'Y'; }
  else            { $entity->{partial_seq} = 'N'; }

  if   ($pseudo) { $entity->{pseudo_gene} = 'Y'; }
  else           { $entity->{pseudo_gene} = 'N'; }

}

sub _orderCdsIntervals { $a->{css_start_pos} <=> $b->{css_start_pos}; }

sub _processSeq {
  my anthonyNolan::Hla $this = shift;
  my ($sq_lines) = @_;

  my $allele     = $this->{allele};
  my $entity     = $allele->entity;
  my $seq_struct = SEQ_STRUCT;

  my $seq = util::Constants::EMPTY_STR;
  foreach my $val ( @{$sq_lines} ) {
    $val =~ /$seq_struct/;
    $seq .= $1;
  }
  $seq =~ s/ //g;
  ###
  ### For full length sequence the seq is the DNA_SEQ and
  ### the CDS_SEQ must be computed from the CDS coordinates.
  ###
  my $seq_type_name = db::MhcTypes::MRNA_SEQ;
  if ( $this->{full_length} ) {
    $seq_type_name = db::MhcTypes::DNA_SEQ;
    my $cds_seq = util::Constants::EMPTY_STR;
    my $cds_seq_structures =
      $allele->getCValue( $entity, $allele->CDS_SEQ_STRUCTURES_LIST );
    @{$cds_seq_structures} =
      sort anthonyNolan::Hla::_orderCdsIntervals @{$cds_seq_structures};
    foreach my $cds_seq_structure ( @{$cds_seq_structures} ) {
      $cds_seq .= substr(
        $seq,
        $cds_seq_structure->{css_start_pos} - 1,
        (
          $cds_seq_structure->{css_end_pos} -
            $cds_seq_structure->{css_start_pos} + 1
        )
      );
    }
    $allele->addMolSeq(
      $cds_seq,
      db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::MRNA_SEQ
      )
    );
  }
  $allele->addMolSeq( $seq,
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type_name ) );
}

sub _processAllele {
  my anthonyNolan::Hla $this = shift;
  my ( $accession, @groups ) = @_;
  my $allele = $this->{allele};
  ###
  ### Initialize allele attributes
  ###
  $this->{full_length} = util::Constants::FALSE;
  $this->{locus_name}  = undef;
  $this->{organism}    = undef;
  my $ft_lines = [];
  my $sq_lines = [];
  ###
  ### Initialize Entity
  ###
  my $entity = $allele->initAllele;
  $entity->{imgt_accession} = $accession;
  $entity->{allele_id}      = $this->{allele_id};
  $this->{allele_id}++;
  ###
  ### Process groups
  ###
  foreach my $group (@groups) {
    $this->{tools}->debugStruct("group", $group);
    my $first_line = $group->[0];
    my $first_tag  = $first_line->{tag};
    if ( $first_tag eq 'DT' ) {
      $this->_processDT($group);
    }
    elsif ( $first_tag eq 'KW' ) {
      $this->_processKW($group);
    }
    elsif ( $first_tag eq 'RN' ) {
      $this->_processRN($group);
    }
    elsif ( $first_tag eq 'DR' ) {
      $this->_processDR($group);
    }
    elsif ( $first_tag eq 'CC' ) {
      $this->_processCC($group);
    }
    elsif ( $first_tag eq 'FH' ) {
      foreach my $line ( @{$group} ) {
        my $tag = $line->{tag};
        push( @{$ft_lines}, $line->{val} ) if ( $tag eq 'FT' );
        push( @{$sq_lines}, $line->{val} ) if ( $tag =~ /\s+/ );
      }
    }
  }
  ###
  ### Process FT and then Seq data.  Before processing Seq data set
  ### all lists except seqs and then set it after processing seqs.
  ###
  $this->_processFT($ft_lines);
  $allele->setPmids;
  $allele->setEvidences;
  $allele->setBiosources;
  $allele->setGeneSeqStruct;
  $allele->setCdsSeqStruct;

  $this->_processSeq($sq_lines);
  $allele->setMolSeqs;
  ###
  ### Post processing
  ###
  ### 1.  Check the taxon_id and set it as necessary; only one
  ###     taxon is allowed per run
  ### 2.  Determine CWD
  ### 3.  Determine G-Code
  ### 4.  Set locus_id in allele_nomenclature
  ###
  $this->_checkTaxon;
  $entity->{locus_id} =
    $this->_getId( db::MhcTypes::MHC_LOCUS_TABLE, $this->{locus_name} );
  $entity->{cwd_allele} =
    ( $this->{cwd_lookup}->keyDefined( $entity->{allele_name} ) ) ? 'Y' : 'N';
  $entity->{imgt_hla_g_code} = $this->{gcode_map}->{ $entity->{allele_name} };
  $entity->{imgt_hla_p_code} = $this->{pcode_map}->{ $entity->{allele_name} };
  my $allele_nomenclature =
    $allele->getCValue( $entity, $allele->ALLELE_NOMENCLATURE_PATH );
  $allele_nomenclature->{locus_id} = $entity->{locus_id};
  ###
  ### Move entity and write bcp-files
  ###
  $this->{tools}->debugStruct("entity", $entity);
  $allele->moveEntity;
  $allele->writeProfile( $this->{generator} );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my anthonyNolan::Hla $this = shift;
  my (
    $hla_file,  $allele_id, $gcode_map, $pcode_map,
    $nomenclature_map,
    $generator, $tools,     $error_mgr
  ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{allele_id}        = $allele_id;
  $this->{cwd_lookup}       = undef;
  $this->{error_mgr}        = $error_mgr;
  $this->{gcode_map}        = $gcode_map;
  $this->{generator}        = $generator;
  $this->{hla_file}         = getPath($hla_file);
  $this->{kw_pos}           = KW_POS;
  $this->{nomenclature_map} = $nomenclature_map;
  $this->{nomenclature_ord} = db::MhcTypes::NOMENCLATURE_ORDER;
  $this->{pcode_map}        = $pcode_map;
  $this->{taxon_id}         = undef;
  $this->{tools}            = $tools;
  ###
  ### Setup ancillary id generation for those
  ### controlled vocabularies that can change
  ### during processing.
  ###
  $this->_setIds;
  ###
  ### Create defline processor
  ###
  $this->{defline} = new util::Defline( $error_mgr, util::Defline::STD_FORMAT );
  $this->{defline}
    ->addDuplicateTag( CELL_LINE_TAG, util::Defline::DEFLINE_TAG );
  ###
  ### Instantiate the allele profile to contain the parse content
  ###
  $this->{allele} =
    new perl::Struct::Profile::Allele( util::Constants::TRUE, 'AnthonNolanHla',
    undef, undef, $error_mgr );
  ###
  ### Check hla file and index it (if necessary), and set the index.
  ###
  $this->{error_mgr}->exitProgram(
    ERR_CAT,
    1,
    [ "Hla text file is inaccessible\n" . "  hla_file = " . $this->{hla_file} ],
    !-e $this->{hla_file} || !-f $this->{hla_file} || !-r $this->{hla_file}
  );
  my $index_file = join( util::Constants::DOT, $this->{hla_file}, 'db' );

  $this->{hla_index} =
    new file::Index( ENTITY_EXPR, ACCESSION_EXPR, $this->{error_mgr} );
  unlink($index_file) if ( -e $index_file );
  $this->{hla_index}->createIndex( $this->{hla_file} );
  $this->{hla_index}->setIndex($index_file);

  return $this;
}

sub processFile {
  my anthonyNolan::Hla $this = shift;
  ###
  ### Process file
  ###
  my $end_struct = END_STRUCT;
  $this->{error_mgr}->printHeader("Processing HLA alleles");
  foreach my $accession ( $this->{hla_index}->orderedAccessions ) {
    $this->{error_mgr}->printMsg( "  " . $accession->[0] );
    my $entity = $this->{hla_index}->readCurrent;
    my @lines = split( /\n/, $entity );
    ###
    ### Split into groups
    ###
    my @groups        = ();
    my $current_group = undef;
    my $tag_struct    = TAG_STRUCT;
    while ( @lines != 0 ) {
      my $line = shift(@lines);
      my $tag  = undef;
      my $val  = undef;
      next if ( $line =~ /$end_struct/ );
      if ( $line =~ /$tag_struct/ ) {
        my $only_tag    = $1;
        my $tag_line    = $2;
        my $tag_value   = $3;
        my $empty_tag   = $4;
        my $empty_value = $5;
        if ( defined($only_tag) ) {
          $tag = $only_tag;
        }
        elsif ( defined($tag_line) ) {
          $tag = $tag_line;
          $val = $tag_value;
        }
        elsif ( defined($empty_tag) ) {
          $tag = $empty_tag;
          $val = $empty_value;
        }
      }
      else {
        $this->{error_mgr}->registerError( ERR_CAT, 1,
          [ "Hla entity line has unknown structure\n" . "  line = '$line'" ],
          util::Constants::TRUE );
        next;
      }
      if ( !defined($current_group) ) { $current_group = []; }
      if ( $tag eq GROUP_TAG ) {
        if ( @{$current_group} != 0 ) {
          push( @groups, $current_group );
          $current_group = [];
        }
        next;
      }
      push( @{$current_group}, { tag => $tag, val => $val } );
    }
    push( @groups, $current_group )
      if ( defined($current_group) && @{$current_group} > 0 );
    ###
    ### Process groups for allele
    ###
    $this->{tools}->debugStruct("groups", \@groups);
    $this->_processAllele( $accession->[0], @groups );
  }
  $this->{hla_index}->finalize;
}

sub alleleId {
  my anthonyNolan::Hla $this = shift;
  return $this->{allele_id};
}

sub evidenceAuthority {
  my anthonyNolan::Hla $this = shift;
  return %{ $this->{ids}->{&db::MhcTypes::EVIDENCE_AUTHORITY_TABLE} };
}

sub generator {
  my anthonyNolan::Hla $this = shift;
  return $this->{generator};
}

sub mhcLocus {
  my anthonyNolan::Hla $this = shift;
  return %{ $this->{ids}->{&db::MhcTypes::MHC_LOCUS_TABLE} };
}

sub taxonId {
  my anthonyNolan::Hla $this = shift;
  return $this->{taxon_id};
}

################################################################################

1;

__END__

=head1 NAME

Hla.pm

=head1 DESCRIPTION

This class defines the reader for the Anthony Nolan B<hla.txt> file
that contains the allele variant sequence annotation.  An allele
annotation is separated in the file by B<'//'> on a line alone.  The
processing of an entity consists of the following steps:

   Step 0:  Get accession and lines for accession from the index
   Step 1:  Break lines into groups via '^XX'
   Step 2:  Groups to process:
     a.  DT -- all create, seq update, annot update
     b.  KW -- locus, class, allele name
     c.  RN -- RX PUBMED  for pmid and RTs for title
     d.  DR -- all
     e.  CC -- all
     f.  FH -- for all FT break down into (key, value) pairs
               The value will consist of <location>[ /tag=value]*.
               The first part is the location and the second part
               is a defline.  Allow cell_line as a duplicate tag.
               The process is to determine the key line of a tag 
               value that has the structure:  '^(\w+)          (.+)$'.
               All succeeding tag values that are not key lines have
               the following structure '^ +(.+)$'.  The lines are joined
               using an optional space (' ') if the non-whitespace starts
               with a slash ('/').
               - source -- /organism
                        -- /cell_line
               - CDS    -- location
                        -- determine the trans_start and trans_stop 
                           from the location, if possible.
                        -- /partial (?)
                        -- /codon_start
               - UTR    -- first one is 5prime and second is 3prime
               - exon   -- start and end from location
                        -- order_num from /number
               - intron -- start and end from location
                        -- order_num from /number
     g.  SQ -- contains the number of base-pairs expected
               The blank lines following are sequence of the format
               '^([acgt][acgt ]*)\s+(\d+)'


=head1 METHODS

The following static methods are exported by this class.

=head2 B<new anthonyNolan::Hla(hla_file, allele_id, gcode_map, pcode_map, tools, error_mgr)>

This is the constructor for the class.

=head2 B<processFile>

This is the method that computes the load for the Anthony Noloan
IMGT/HLA data load.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<my $allele_id = alleleId>

This method returns the next allele_id to be used.

=head2 B<my $taxon_id = taxonId>

This method returns taxon id generated during this processing.

=head2 B<my %evidence_authority = evidenceAuthority>

This method returns the map of new authority name to authority_id
generated during the processing of the file.

=head2 B<my $generator = generator>

This method returns the generator used to process files.

=head2 B<my %mhc_locus = mhcLocus>

This method returns the map of new locus names name to locus_id
generated during the processing of the file.

=cut
