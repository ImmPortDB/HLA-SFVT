package anthonyNolan::Align;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use FileHandle;
use File::Find ();
use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::PathSpecifics;
use util::PerlObject;

use db::MhcTypes;

use perl::Struct::Profile::Allele;

use anthonyNolan::ErrMsgs;

use fields qw (
  align_directory
  allele
  allele_names
  coord_types
  drb_processed
  doa_prot_file_start
  db_queries
  error_mgr
  generator
  queries
  reference_alleles
  seq_types
  serializer
  taxon_id
);

################################################################################
#
#				 Initialization
#
################################################################################
###
### for the convenience of &wanted calls,
### including -eval statements:
###
use vars qw(*FIND_NAME
  *FIND_DIR
  *FIND_PRUNE);
*FIND_NAME  = *File::Find::name;
*FIND_DIR   = *File::Find::dir;
*FIND_PRUNE = *File::Find::prune;

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Queries to compute ALLELE_ALIGNMENT
###
sub GENE_SEQ_STRUCTURE_QUERY { return 'A_gene_seq_structure_query'; }

sub DB_QUERIES {
  return {
    &GENE_SEQ_STRUCTURE_QUERY => {
      msg => 'GENE_SEQ_STRUCTURE Query',
      ord => [
        db::MhcTypes::GSS_START_POS_COL,  db::MhcTypes::GSS_END_POS_COL,
        db::MhcTypes::GENE_STRUCT_ID_COL, db::MhcTypes::ORDER_NUM_COL,
      ],
      cmd => "
select gss_start_pos,
       gss_end_pos,
       gene_struct_id,
       order_num
from   gene_seq_structure
where  allele_id = ?
order  by gss_start_pos
",
    },
  };
}
###
### Pattern Information for alignment files
###
### File Name Specifics
###
sub ALIGN_FILE_PATTERN { return '.+_(gen|nuc|prot)\.txt'; }
sub CLASS_FILE         { return '^Class'; }

sub SEQ_TYPE_FILE_MAP {
  return {
    &db::MhcTypes::AA_SEQ   => '_prot\.txt$',
    &db::MhcTypes::DNA_SEQ  => '_gen\.txt',
    &db::MhcTypes::MRNA_SEQ => '_nuc\.txt$',
  };
}
###
### File Content Specifics
###
sub ALLELE_SEQUENCE { return '^ *(\w+\*[0-9A-Z:]+)\s+(.+)$'; }
sub START_POINT     { return 'Anthony Nolan Research Institute'; }

sub DRB_LOCUS_GROUP { return 'HLA-DRB'; }
sub DRB_PREFIX      { return '^DRB_(.+)\.txt$'; }
sub DRB_NUM_PREFIX  { return '^DRB(\d+)_(.+)\.txt$'; }

sub SEQ_TYPE_COORD_PATTERN_MAP {
  return {
    &db::MhcTypes::AA_SEQ   => '^\s*Prot\s+(\d+)\s*$',
    &db::MhcTypes::DNA_SEQ  => '^\s*gDNA\s+(\d+)\s*$',
    &db::MhcTypes::MRNA_SEQ => '^\s*cDNA\s+(\d+)\s*$',
  };
}
###
### Error Category
###
sub ERR_CAT { return anthonyNolan::ErrMsgs::ALIGN_CAT; }

################################################################################
#
#				File Finding Private Method
#
################################################################################
###
### ALIGN_FILES is the global variable for storing alignment
### files found in a File::Find::find operation using
### the _alignWanted function.  This variable should not
### be used in recursive executions of wanted since they
### get re-initialized for each input path directory
### traversed below.
###
my @ALIGN_FILES = ();

sub _alignWanted {
  my anthonyNolan::Align $this = shift;
  my $align_file_pattern = ALIGN_FILE_PATTERN;
  return sub {
    my ( $dev, $ino, $mode, $nlink, $uid, $gid );
    ( ( $dev, $ino, $mode, $nlink, $uid, $gid ) = lstat($_) )
      && -f _
      && /^$align_file_pattern\z/s
      && push( @ALIGN_FILES, $FIND_NAME );
    }
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _determineLocusNames {
  my anthonyNolan::Align $this = shift;
  my ($taxon_id) = @_;

  my $allele_names = db::MhcTypes::alleleNames($taxon_id);
  $this->{allele_names} = {};
  foreach my $allele_name ( keys %{$allele_names} ) {
    my $allele_data = $allele_names->{$allele_name};
    $this->{allele_names}->{$allele_name} = { %{$allele_data} };
  }
}

sub _parseFile {
  my anthonyNolan::Align $this = shift;
  my ( $seq_type, $file ) = @_;

  my $start_pos = undef;
  my $sequences = [];
  my $seq_map   = {};

  my $allele_sequence_pattern = ALLELE_SEQUENCE;
  my $coord_pattern           = $this->{coord_types}->{$seq_type};
  my $start_point_pattern     = START_POINT;

  $file = join( util::Constants::SLASH, $this->{align_directory}, $file );
  system("dos2unix $file");
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ "Cannot open align file\n" . "  align file = $file" ],
    !$fh->open( $file, '<' )
  );

  my $start_processing = util::Constants::FALSE;
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    $start_processing =
      ( $line =~ /$start_point_pattern/ )
      ? util::Constants::TRUE
      : $start_processing;
    next if ( !$start_processing );
    $line =~ s/\|//g;
    if ( $line =~ /$allele_sequence_pattern/ ) {
      my $allele_name = $1;
      my $seq         = $2;
      $seq =~ s/ //g;
      if ( !defined( $seq_map->{$allele_name} ) ) {
        my $seq_struct = {
          allele_name => $allele_name,
          seq         => util::Constants::EMPTY_STR,
        };
        $seq_map->{$allele_name} = $seq_struct;
        push( @{$sequences}, $seq_struct );
      }
      my $allele_struct = $seq_map->{$allele_name};
      $allele_struct->{seq} .= $seq;
    }
    elsif ( $line =~ /$coord_pattern/ && !defined($start_pos) ) {
      my $coord_pos = int($1);
      if ( @{$sequences} == 0 ) {
        $start_pos = 1;
      }
      else {
        my $first_seq = $sequences->[0];
        my $seq       = $first_seq->{seq};
        $start_pos = -( length($seq) - ( $coord_pos - 1 ) );
      }
    }
  }
  $fh->close;
  return ( $start_pos, $sequences );
}

sub _getStruct {
  my anthonyNolan::Align $this = shift;
  my ( $query, $row ) = @_;
  my $ord    = $this->{queries}->{$query}->{ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _determineDnaVssStartPos {
  my anthonyNolan::Align $this = shift;
  my ( $vss_start_pos, $seq_type, $seq, $allele_id ) = @_;
  ###
  ### Immediate return since not DNA seq type
  ###
  return $vss_start_pos if ( $seq_type ne db::MhcTypes::DNA_SEQ );

  my $FIVEPRIME_UTR =
    db::MhcTypes::getId( db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE,
    db::MhcTypes::FIVE_PRIME_UTR );
  ###
  ### Compute the start pos for the allele_id
  ###
  my $gene_struct = [];
  $this->{db_queries}->executeQuery( GENE_SEQ_STRUCTURE_QUERY, $allele_id );
  while ( my $row_ref =
    $this->{db_queries}->fetchRowRef(GENE_SEQ_STRUCTURE_QUERY) )
  {
    my $interval = $this->_getStruct( GENE_SEQ_STRUCTURE_QUERY, $row_ref );
    push( @{$gene_struct}, $interval );
  }
  ###
  ### Compute unsequenced initial segment
  ###
  my $unsequenced_length = 0;
  if ( $seq =~ /^(\*+)/ ) {
    $this->{error_mgr}->printHeader(
      "Allele's DNA has unsequenced start\n" . "  allele_id = $allele_id" );
    my $unseq = $1;
    $unsequenced_length = length($unseq);
  }
  ###
  ### For the DNA type compute the vss_start_pos from
  ### the negative of the utr length if any, otherwise 1
  ###
  if ( @{$gene_struct} == 0 ) {
    if ( $unsequenced_length == 0 ) {
      $vss_start_pos = 1;
    }
    else {
      $vss_start_pos = -$unsequenced_length;
    }
  }
  else {
    my $interval = $gene_struct->[0];
    if ( $interval->{gene_struct_id} == $FIVEPRIME_UTR ) {
      $vss_start_pos =
        -( $interval->{gss_end_pos} - $interval->{gss_start_pos} + 1 ) -
        $unsequenced_length;
    }
    else {
      $vss_start_pos = $interval->{gss_start_pos} - $unsequenced_length;
    }
  }
  $this->{error_mgr}->printMsg("DNA vss_start_pos = $vss_start_pos");

  return $vss_start_pos;
}

sub _addReferenceData {
  my anthonyNolan::Align $this = shift;
  my ( $allele_id, $locus_id, $seq_type_id, $vss_start_pos ) = @_;
  ###
  ### Add reference data for the following tables:
  ###
  ### 1. reference_allele
  ### 2. variant_seq_structure
  ###
  my $variant_seq_struct = {
    locus_id      => $locus_id,
    seq_type_id   => $seq_type_id,
    vss_start_pos => $vss_start_pos,
  };
  $this->{generator}
    ->generateRow( lc(db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE),
    $variant_seq_struct );

  my $reference_alleles = $this->{reference_alleles};
  if ( !defined( $reference_alleles->{$locus_id} ) ) {
    $reference_alleles->{$locus_id} = {};
  }
  my $loci_alleles = $reference_alleles->{$locus_id};
  ###
  ### Note:  Reference alleles are defined per locus per seq_type
  ###
  return if ( defined( $loci_alleles->{$seq_type_id} ) );

  $loci_alleles->{$seq_type_id} = $allele_id;
  my $reference_allele_struct = {
    locus_id    => $locus_id,
    allele_id   => $allele_id,
    seq_type_id => $seq_type_id,
  };
  $this->{generator}->generateRow( lc(db::MhcTypes::REFERENCE_ALLELE_TABLE),
    $reference_allele_struct );
}

sub _processDrbLocusGroup {
  my anthonyNolan::Align $this = shift;
  my ( $file, $allele_id, $locus_id, $seq_type_id, $vss_start_pos ) = @_;

  my $drb_processed = $this->{drb_processed};

  my $drb_prefix     = DRB_PREFIX;
  my $drb_num_prefix = DRB_NUM_PREFIX;
  if ( $file =~ /$drb_num_prefix/ ) {
    my $drb_num = $1;
    my $type    = $2;
    $drb_processed->{$type}->{$drb_num} = util::Constants::EMPTY_STR;
    return;
  }
  return if ( $file !~ /$drb_prefix/ );
  my $type     = $1;
  my $drb_nums = $drb_processed->{$type};
  my $drb_num  = 1;
  while (util::Constants::TRUE) {
    my $curr_drb_num = $drb_num;
    $drb_num++;
    ###
    ### Already processed by another file
    ###
    next if ( defined( $drb_nums->{$curr_drb_num} ) );

    my $drb_locus = DRB_LOCUS_GROUP . $curr_drb_num;
    my $drb_locus_id =
      db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $drb_locus,
      $this->{taxon_id} );
    ###
    ### No no DRB loci
    ###
    last if ( !defined($drb_locus_id) );
    ###
    ### Already written
    ###
    next if ( $drb_locus_id == $locus_id );
    ###
    ### Add reference data
    ###
    $this->_addReferenceData( $allele_id, $drb_locus_id, $seq_type_id,
      $vss_start_pos );
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my anthonyNolan::Align $this = shift;
  my ( $taxon_id, $align_directory, $doa_prot_file_start, $generator, $db,
    $error_mgr )
    = @_;
  $this = fields::new($this) unless ref($this);

  $this->{align_directory}     = getPath($align_directory);
  $this->{allele_names}        = undef;
  $this->{coord_types}         = SEQ_TYPE_COORD_PATTERN_MAP;
  $this->{doa_prot_file_start} = $doa_prot_file_start;
  $this->{drb_processed}       = undef;
  $this->{error_mgr}           = $error_mgr;
  $this->{generator}           = $generator;
  $this->{reference_alleles}   = undef;
  $this->{seq_types}           = SEQ_TYPE_FILE_MAP;
  $this->{taxon_id}            = $taxon_id;

  ###
  ### Instantiate the allele profile to contain the parse content
  ###
  $this->{allele} =
    new perl::Struct::Profile::Allele( util::Constants::TRUE, 'AnthonNolanHla',
    undef, undef, $error_mgr );
  $this->{allele}->setSkipHash('allele_nomenclature');
  ###
  ### serializer
  ###
  $this->{serializer} =
    new util::PerlObject( undef, undef, $this->{error_mgr} );
  ###
  ### Get the locus specific information.
  ###
  $this->_determineLocusNames($taxon_id);
  ###
  ### setup queries
  ###
  $this->{db_queries} = new util::DbQuery($db);
  $this->{queries}    = DB_QUERIES;
  foreach my $query ( keys %{ $this->{queries} } ) {
    my $db_struct = $this->{queries}->{$query};
    $this->{db_queries}
      ->createQuery( $query, $db_struct->{cmd}, $db_struct->{msg} );
    $this->{db_queries}->prepareQuery($query);
  }

  return $this;
}

sub processFiles {
  my anthonyNolan::Align $this = shift;

  $this->{drb_processed} = {
    gen  => {},
    nuc  => {},
    prot => {},
  };

  my $allele     = $this->{allele};
  my $class_file = CLASS_FILE;
  ###
  ### Get the align files to process
  ###
  my $currentDirectory = $ENV{PWD};
  chdir( $this->{align_directory} );
  @ALIGN_FILES = ();
  File::Find::find( { wanted => $this->_alignWanted }, util::Constants::DOT );
  my $align_files = {};
  foreach my $align_file ( sort @ALIGN_FILES ) {
    $align_file =~ s/^\.\///;
    ###
    ### No processing class files for now
    ###
    next if ( $align_file =~ /$class_file/ );
    foreach my $seq_type ( keys %{ $this->{seq_types} } ) {
      my $file = $this->{seq_types}->{$seq_type};
      if ( $align_file =~ /$file/ ) {
        if ( !defined( $align_files->{$seq_type} ) ) {
          $align_files->{$seq_type} = [];
        }
        $this->{error_mgr}
          ->printMsg("(seq_type, align_file) = ($seq_type, $align_file)");
        push( @{ $align_files->{$seq_type} }, $align_file );
      }
    }
  }
  $this->{reference_alleles} = {};
  foreach my $seq_type ( sort keys %{$align_files} ) {
    my $seq_type_id =
      db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, $seq_type );
    $this->{error_mgr}->printMsg("seq_type = $seq_type");
    my $files = $align_files->{$seq_type};
    foreach my $file ( @{$files} ) {
      $this->{error_mgr}->printMsg("  file = $file");
      ###
      ### Parse the file and get the reference allele data
      ###
      my ( $vss_start_pos, $sequences ) = $this->_parseFile( $seq_type, $file );
      ###
      ### Special processing for DOA since sequence is on one line
      ###
      if ( !defined($vss_start_pos) && $file =~ /DOA_prot.txt/ ) {
        $vss_start_pos = $this->{doa_prot_file_start};
      }
      my $ref_allele = $sequences->[0];
      my $ref_struct = $this->{allele_names}->{ $ref_allele->{allele_name} };
      $this->{error_mgr}->exitProgram(
        ERR_CAT, 1,
        [
              "Reference allele does not exist\n"
            . "  reference allele = "
            . $ref_allele->{allele_name}
        ],
        !defined($ref_struct)
      );
      $this->{error_mgr}->printMsg(
        "  reference allele (name, id) = ("
          . join( util::Constants::COMMA_SEPARATOR,
          $ref_allele->{allele_name},
          $ref_struct->{allele_id}
          )
          . ")"
      );
      ###
      ### Special Case:  Determine vss_start_pos for DNA seq_type
      ###
      $vss_start_pos =
        $this->_determineDnaVssStartPos( $vss_start_pos, $seq_type,
        $ref_allele->{seq}, $ref_struct->{allele_id} );
      ###
      ### Add reference
      ###
      $this->_addReferenceData(
        $ref_struct->{allele_id},
        $ref_struct->{locus_id},
        $seq_type_id, $vss_start_pos
      );
      ###
      ### Special Case:  Process the DRB loci group
      ###
      $this->_processDrbLocusGroup(
        $file,
        $ref_struct->{allele_id},
        $ref_struct->{locus_id},
        $seq_type_id, $vss_start_pos
      );
      ###
      ### Process each sequence
      ###
      foreach my $allele_seq ( @{$sequences} ) {
        my $allele_struct =
          $this->{allele_names}->{ $allele_seq->{allele_name} };
        $this->{error_mgr}->printMsg(
          "    (name, id) = ("
            . join( util::Constants::COMMA_SEPARATOR,
            $allele_seq->{allele_name},
            $allele_struct->{allele_id}
            )
            . ")"
        );
        ###
        ### Missing allele--do not process
        ###
        my $missing_allele =
          util::Constants::EMPTY_LINE( $allele_struct->{allele_id} );
        $this->{error_mgr}->printError(
          "allele does not exist in database\n"
            . "  allele_name = "
            . $allele_seq->{allele_name},
          $missing_allele
        );
        next if ($missing_allele);
        ###
        ### No Sequence for Allele--do not process
        ###
        my $no_sequence = util::Constants::EMPTY_LINE( $allele_seq->{seq} );
        $this->{error_mgr}->printError(
          "allele does not have sequence\n"
            . "  allele_name = "
            . $allele_seq->{allele_name},
          $no_sequence
        );
        next if ($no_sequence);
        ###
        ### Initialize profile for generation of alignments.
        ###
        my $entity = $allele->initAllele;
        $entity->{allele_id} = $allele_struct->{allele_id};
        $this->{error_mgr}
          ->printMsg( "add variant sequence--" . $entity->{allele_id} );
        ###
        ### Add the alignment sequence
        ###
        $allele->addVarSeq( $allele_seq->{seq}, $seq_type_id );
        ###
        ### write the alignments for the sequence
        ###
        $allele->setVarSeqs;
        $allele->moveEntity;
        $allele->writeProfile( $this->{generator}, util::Constants::TRUE );
      }
    }
  }
  chdir($currentDirectory);
}

################################################################################

1;

__END__

=head1 NAME

Align.pm

=head1 DESCRIPTION

This class defines the reader for the Anthony Nolan B<*.txt> sequence
alignment files to generate information for generating the sequence
variance data.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new anthonyNolan::Align(taxon_id, align_directory, generator, db, error_mgr)>

This is the constructor for the class.

=head2 B<processFiles>

This method processes the align files and generates the variant types
and assigns them to the alleles in the variant map.

=cut
