package anthonyNolan::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'ANTHONY-NOLAN-ERROR: '; }

sub HLA_CAT   { return 1000; }    ### Anthony Nolan IMGT Hla Class
sub MSF_CAT   { return 2000; }    ### Anthony Nolan IMGT Msf Class
sub ALIGN_CAT { return 3000; }    ### Anthony Nolan IMGT Alignment Class

sub ALLELEALIGNMENT_CAT {
  return 4000;
}    ### Anthony Nolan Alignment Feature Generation Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {
    &HLA_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &MSF_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &ALIGN_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

    &ALLELEALIGNMENT_CAT => {
      1 => "Terminal Error, exiting....\n" . "  errMsg\n__1__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {

    &HLA_CAT             => 'anthonyNolan::Hla',
    &MSF_CAT             => 'anthonyNolan::Msf',
    &ALIGN_CAT           => 'anthonyNolan::Align',
    &ALLELEALIGNMENT_CAT => 'anthonyNolan::AlleleAlignment',
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use anthonyNolan::ErrMsgs;

   my $error_msgs  = anthonyNolan::ErrMsgs::ERROR_MSGS;
   my $error_names = anthonyNolan::ErrMsgs::ERROR_CATS;
   my $err_cat     = anthonyNolan::ErrMsgs::HLA_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the anthonyNola
library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   anthonyNolan::ErrMsgs::HLA_CAT             -- (1000) Anthony Nolan IMGT Hla Class
   anthonyNolan::ErrMsgs::MSF_CAT             -- (2000) Anthony Nolan IMGT Msf Class
   anthonyNolan::ErrMsgs::ALIGN_CAT           -- (3000) Anthony Nolan IMGT Alignment Class
   anthonyNolan::ErrMsgs::ALLELEALIGNMENT_CAT -- (4000) Anthony Nolan Alignment Feature Generation Class

=head1 STATIC CLASS METHODS

=head2 B<anthonyNolan::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<anthonyNolan::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
