/*********************************************************************/
/*                                                                   */
/*                  Copyright (c) 2007 Northrop Grumman.             */
/*                          All rights reserved.                     */
/*                                                                   */
/* Module: MHC Sequence Variation Schema                             */
/*                                                                   */
/* Description:  This schema defines the sequence variation feature  */
/*               database schema                                     */
/*                                                                   */
/* Assumptions:  This schema is defined  using MySQL DDL             */
/*                                                                   */
/*********************************************************************/

drop database if exists `mhc_seq_var`;

create schema `mhc_seq_var`;

use mhc_seq_var;

CREATE TABLE `SEQ_TYPE` (
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `seq_name`            VARCHAR(5)    NOT NULL,
  `seq_descr`           VARCHAR(255)  NOT NULL,
  PRIMARY KEY (`seq_type_id`),
  UNIQUE INDEX (`seq_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `TAXONOMY` (
  `taxonomy_id`         VARCHAR(210)  NOT NULL,
  `scientific_name`     VARCHAR(255)  NOT NULL,
  PRIMARY KEY (`taxonomy_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `MHC_LOCUS` (
  `locus_id`            INTEGER(10)   NOT NULL,
  `mhc_locus_name`      VARCHAR(30)   NOT NULL,
  `entrez_gene_id`      VARCHAR(210)      NULL,
  `taxonomy_id`         VARCHAR(210)  NOT NULL,
  `class`               VARCHAR(255)  NOT NULL,
  PRIMARY KEY (`locus_id`),
  UNIQUE INDEX (`mhc_locus_name`, `taxonomy_id`),
  UNIQUE INDEX (`entrez_gene_id`),
  FOREIGN KEY (`taxonomy_id`)
    REFERENCES taxonomy(`taxonomy_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `ALLELE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  `order_allele_name`   VARCHAR(60)   NOT NULL,
  `old_allele_name`     VARCHAR(60)       NULL,  
  `locus_id`            INTEGER(10)   NOT NULL,
  `imgt_accession`      VARCHAR(30)   NOT NULL,
  `release_version`     VARCHAR(30)   NOT NULL,
  `seq_version`         INTEGER(4)    NOT NULL,
  `annot_version`       INTEGER(4)    NOT NULL,
  `codon_start`         INTEGER(10)       NULL,
  `seq_create_date`     DATE          NOT NULL,
  `seq_update_date`     DATE              NULL,
  `annot_update_date`   DATE              NULL,
  `cds_positions`       VARCHAR(4000) NOT NULL,
  `trans_start`         INTEGER(10)       NULL,
  `trans_stop`          INTEGER(10)       NULL,
  `partial_seq`         VARCHAR(1)    NOT NULL,
  `pseudo_gene`         VARCHAR(1)    NOT NULL,
  `comments`            VARCHAR(4000)     NULL,
  `cwd_allele`          VARCHAR(1)        NULL,
  `g_code`              VARCHAR(60)       NULL,
  `imgt_hla_g_code`     VARCHAR(60)       NULL,
  `imgt_hla_p_code`     VARCHAR(60)       NULL,
  PRIMARY KEY (`allele_id`),
  UNIQUE KEY (`allele_name`, `locus_id`),
  INDEX (`locus_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `ALLELE_NOMENCLATURE` (
  `allele_id`         INTEGER(10) NOT NULL,
  `locus_id`          INTEGER(10) NOT NULL,
  `allele_name`       VARCHAR(60) NOT NULL,
  `locus_name`        VARCHAR(30) NOT NULL,
  `allele_group`      VARCHAR(5)  NOT NULL,
  `hla_protein`       VARCHAR(5)      NULL,
  `coding_region`     VARCHAR(5)      NULL,
  `non_coding_region` VARCHAR(5)      NULL,
  `suffix`            VARCHAR(1)      NULL,
  PRIMARY KEY (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  INDEX (`locus_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `REPLACEMENT_TYPE` (
  `replacement_id`      INTEGER(4)    NOT NULL,
  `replacement_name`    VARCHAR(30)   NOT NULL,
  PRIMARY KEY (`replacement_id`),
  UNIQUE INDEX (`replacement_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `REPLACEMENT_ALLELE` (
  `old_allele_name`     VARCHAR(60)   NOT NULL,
  `locus_id`            INTEGER(10)   NOT NULL,
  `allele_id`           INTEGER(10)   NOT NULL,
  `replacement_id`      INTEGER(4)    NOT NULL,
  PRIMARY KEY (`old_allele_name`, `locus_id`, `allele_id`, `replacement_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`replacement_id`)
    REFERENCES replacement_type(`replacement_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `PUBMED_REFERENCE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `pubmed_id`           INTEGER(12)   NOT NULL,
  `pubmed_title`        VARCHAR(4000) NOT NULL,
  PRIMARY KEY (`allele_id`, `pubmed_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `EVIDENCE_AUTHORITY` (
  `authority_id`        INTEGER(10)   NOT NULL,
  `authority`           VARCHAR(60)   NOT NULL,
  `auth_descr`          VARCHAR(4000) NOT NULL,
  PRIMARY KEY (`authority_id`),
  UNIQUE INDEX (`authority`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `SEQ_EVIDENCE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `accession`           VARCHAR(60)   NOT NULL,
  `authority_id`        INTEGER(10)   NOT NULL,
  `acc_version`         VARCHAR(60)       NULL,
  PRIMARY KEY (`allele_id`, `accession`, `authority_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`authority_id`)
    REFERENCES evidence_authority(`authority_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `SEQ_BIOSOURCE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `cell_line`           VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`allele_id`, `cell_line`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `GENE_STRUCTURE_TYPE` (
  `gene_struct_id`      INTEGER(4)    NOT NULL,
  `gene_struct_name`    VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`gene_struct_id`),
  UNIQUE INDEX (`gene_struct_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `GENE_SEQ_STRUCTURE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `gss_start_pos`       INTEGER(10)   NOT NULL,
  `gss_end_pos`         INTEGER(10)   NOT NULL,
  `gene_struct_id`      INTEGER(4)    NOT NULL,
  `order_num`           INTEGER(10)       NULL,
  PRIMARY KEY (`allele_id`, `gss_start_pos`),
  UNIQUE INDEX (`allele_id`, `gss_start_pos`, `gss_end_pos`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`gene_struct_id`)
    REFERENCES gene_structure_type(`gene_struct_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `CDS_STRUCTURE_TYPE` (
  `cds_struct_id`       INTEGER(4)    NOT NULL,
  `cds_struct_name`     VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`cds_struct_id`),
  UNIQUE INDEX (`cds_struct_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `CDS_SEQ_STRUCTURE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `css_start_pos`       INTEGER(10)   NOT NULL,
  `css_end_pos`         INTEGER(10)   NOT NULL,
  `cds_struct_id`       INTEGER(4)    NOT NULL,
  PRIMARY KEY (`allele_id`, `css_start_pos`),
  UNIQUE INDEX (`allele_id`, `css_start_pos`, `css_end_pos`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`cds_struct_id`)
    REFERENCES cds_structure_type(`cds_struct_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `REFERENCE_ALLELE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `locus_id`            INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  PRIMARY KEY (`allele_id`, `locus_id`, `seq_type_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

/*******************************************/
/*                                         */
/* MOLECULE_SEQ will at least contain the  */
/* the DNA, transcript (mRNA), and protein */
/* (AA) sequences                          */
/*                                         */
/*******************************************/

CREATE TABLE `MOLECULE_SEQ` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `mol_length`          INTEGER(10)   NOT NULL,
  `mol_seq`             TEXT          NOT NULL,
  PRIMARY KEY (`allele_id`, `seq_type_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;


CREATE TABLE `ALIGNMENT_VIEW_TYPE` (
  `view_type_id`        INTEGER(4)    NOT NULL,
  `view_type_name`      VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`view_type_id`),
  UNIQUE INDEX (`view_type_name`)
) engine=InnoDB DEFAULT charset=latin1;


CREATE TABLE `ALIGNMENT_TYPE` (
  `alignment_type_id`   INTEGER(4)    NOT NULL,
  `alignment_type_name` VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`alignment_type_id`),
  UNIQUE INDEX (`alignment_type_name`)
) engine=InnoDB DEFAULT charset=latin1;


CREATE TABLE `ALLELE_ALIGNMENT` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `ungapped_start_pos`  INTEGER(10)   NOT NULL,
  `view_type_id`        INTEGER(4)    NOT NULL,
  `alignment_type_id`   INTEGER(4)    NOT NULL,
  `gene_struct_id`      INTEGER(4)    NOT NULL,
  `ungapped_end_pos`    INTEGER(10)   NOT NULL,
  `gapped_start_pos`    INTEGER(10)   NOT NULL,
  `gapped_end_pos`      INTEGER(10)   NOT NULL,
  `interval_name`       VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`allele_id`, `seq_type_id`, `ungapped_start_pos`, `ungapped_end_pos`, `view_type_id`, `alignment_type_id`, `gene_struct_id`),
  INDEX (`allele_id`, `seq_type_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`),
  FOREIGN KEY (`alignment_type_id`)
    REFERENCES alignment_type(`alignment_type_id`),
  FOREIGN KEY (`view_type_id`)
    REFERENCES alignment_view_type(`view_type_id`),
  FOREIGN KEY (`gene_struct_id`)
    REFERENCES gene_structure_type(`gene_struct_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `ALIGNMENT_SEQ` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `align_length`        INTEGER(10)   NOT NULL,
  `align_seq`           TEXT          NOT NULL,
  PRIMARY KEY (`allele_id`, `seq_type_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_SEQ` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `var_length`          INTEGER(10)   NOT NULL,
  `var_seq`             TEXT          NOT NULL,
  PRIMARY KEY (`allele_id`, `seq_type_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_SEQ_STRUCTURE` (
  `locus_id`            INTEGER(10)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `vss_start_pos`       INTEGER(10)   NOT NULL,
  PRIMARY KEY (`locus_id`, `seq_type_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

/*CREATE TABLE `SEQUENCE_ONTOLOGY` (*/
/*) engine=InnoDB DEFAULT charset=latin1;*/
/**/

/**/
/*CREATE TABLE `SEQUENCE_ONTOLOGY_TYPE` (*/
/*) engine=InnoDB DEFAULT charset=latin1;*/
/**/

CREATE TABLE `FEATURE_TYPE` (
  `feature_type_id`     INTEGER(4)    NOT NULL,
  `ft_name`             VARCHAR(255)  NOT NULL,
  PRIMARY KEY (`feature_type_id`),
  UNIQUE INDEX (`ft_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `PDB_STRUCTURE` (
  `pdb_id`              VARCHAR(50)   NOT NULL,
  `description`         VARCHAR(4000)     NULL,
  `mhc_protein`         VARCHAR(60)       NULL,
  `peptide`             VARCHAR(4000)     NULL,
  `chain_submenu`       VARCHAR(1000)     NULL, 
  `selected_chains`     VARCHAR(255)      NULL,
  `unselected_chains`   VARCHAR(255)      NULL,
  `move_command`        VARCHAR(1000)     NULL,
  PRIMARY KEY (`pdb_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_ALLELE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `locus_id`            INTEGER(10)   NOT NULL,
  `pdb_id`              VARCHAR(50)   NOT NULL,
  `pdb_positions`       VARCHAR(1000)     NULL,
  `pdb_map`             VARCHAR(4000)     NULL,
  PRIMARY KEY (`allele_id`, `locus_id`, `pdb_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`pdb_id`)
    REFERENCES pdb_structure(`pdb_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `locus_id`            INTEGER(10)   NOT NULL,
  `feature_number`      VARCHAR(50)   NOT NULL,
  `seq_type_id`         INTEGER(4)    NOT NULL,
  `feature_names`       VARCHAR(4000)     NULL,
  `feature_types`       VARCHAR(4000)     NULL,
  `comments`            VARCHAR(4000)     NULL,
  `related_pubs`        VARCHAR(4000)     NULL,
  `positions`           VARCHAR(1000)     NULL,
  PRIMARY KEY (`feature_id`),
  UNIQUE INDEX (`feature_number`),
  INDEX (`locus_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`seq_type_id`)
    REFERENCES seq_type(`seq_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `PDB_MAPPING` (
  `pdb_id`              VARCHAR(50)   NOT NULL,
  `feature_id`          INTEGER(10)   NOT NULL,
  `locus_id`            INTEGER(10)   NOT NULL,
  `pdb_positions`       VARCHAR(1000) NOT NULL,
  PRIMARY KEY (`pdb_id`, `feature_id`),
  INDEX (`locus_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_2_NAME` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `feature_name`        VARCHAR(255)  NOT NULL,
  PRIMARY KEY (`feature_id`, `feature_name`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_2_TYPE` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `feature_type_id`     INTEGER(4)    NOT NULL,
  PRIMARY KEY (`feature_id`, `feature_type_id`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`),
  FOREIGN KEY (`feature_type_id`)
    REFERENCES feature_type(`feature_type_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_2_PUBMED` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `pubmed_id`           INTEGER(12)   NOT NULL,
  PRIMARY KEY (`feature_id`, `pubmed_id`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_MAP` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `fm_start_pos`        INTEGER(10)   NOT NULL,
  `fm_end_pos`          INTEGER(10)   NOT NULL,
  PRIMARY KEY (`feature_id`, `fm_start_pos`),
  UNIQUE KEY (`feature_id`, `fm_start_pos`, `fm_end_pos`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `FEATURE_MAP_BASE1` (
  `feature_id`          INTEGER(10)   NOT NULL,
  `fm_start_pos`        INTEGER(10)   NOT NULL,
  `fm_end_pos`          INTEGER(10)   NOT NULL,
  PRIMARY KEY (`feature_id`, `fm_start_pos`),
  UNIQUE KEY (`feature_id`, `fm_start_pos`, `fm_end_pos`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_TYPE` (
  `variant_id`          INTEGER(10)   NOT NULL,
  `feature_id`          INTEGER(10)   NOT NULL,
  `variant_type_name`   VARCHAR(50)   NOT NULL,
  `motif`               VARCHAR(4000)     NULL,
  `pos_motif`           VARCHAR(4000)     NULL,
  `var_motif`           VARCHAR(4000)     NULL,
  PRIMARY KEY (`variant_id`),
  UNIQUE KEY (`feature_id`, `variant_type_name`),
  INDEX (`feature_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_REFERENCE` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `feature_id`          INTEGER(10)   NOT NULL,
  `variant_id`          INTEGER(10)   NOT NULL,
  `variant_type_name`   VARCHAR(50)   NOT NULL,
  `motif`               VARCHAR(4000) NOT NULL,
  `pos_motif`           VARCHAR(4000) NOT NULL,
  `var_motif`           VARCHAR(4000) NOT NULL,
  PRIMARY KEY (`allele_id`, `feature_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`variant_id`)
    REFERENCES variant_type(`variant_id`),
  FOREIGN KEY (`feature_id`)
    REFERENCES feature(`feature_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_2_ALLELE` (
  `variant_id`          INTEGER(10)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  PRIMARY KEY (`variant_id`, `allele_name`),
  INDEX (`variant_id`),
  FOREIGN KEY (`variant_id`)
    REFERENCES variant_type(`variant_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `VARIANT_MAP` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `variant_id`          INTEGER(10)   NOT NULL,
  PRIMARY KEY (`allele_id`, `variant_id`),
  INDEX (`allele_id`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`),
  FOREIGN KEY (`variant_id`)
    REFERENCES variant_type(`variant_id`)
) engine=InnoDB DEFAULT charset=latin1;

/*******************************************/
/*                                         */
/* Special Lookup Tables for Allele Name   */
/* validation processing                   */
/*                                         */
/*******************************************/

CREATE TABLE `LK_CANO_CWD` (
  `locus_name`          VARCHAR(30)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  `hla_protein_name`    VARCHAR(60)       NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`locus_name`, `allele_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_CHANGE_NAME` (
  `old_allele_name`     VARCHAR(60)   NOT NULL,
  `new_allele_name`     VARCHAR(60)   NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`old_allele_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_DELETE_NAME` (
  `deleted_allele_name` VARCHAR(60)   NOT NULL,
  `date_of_deletion`    DATE              NULL,
  `reason`              VARCHAR(255)  NOT NULL,
  `identical_to`        VARCHAR(60)       NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`deleted_allele_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_NMDP_CODE` (
  `nmdp_code`           VARCHAR(5)    NOT NULL,
  `imgt_hla_version`    VARCHAR(1)    NOT NULL,
  `subtype`             VARCHAR(4000) NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`nmdp_code`, `imgt_hla_version`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_CWD_ALLELE` (
  `allele_name`         VARCHAR(60)   NOT NULL,
  `locus_name`          VARCHAR(30)   NOT NULL,
  `imgt_accession`      VARCHAR(30)   NOT NULL,
  `cwd_category`        VARCHAR(5)        NULL,
  `hla_protein_name`    VARCHAR(60)       NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`allele_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `MHC_HLA_FREQ` (
  `source`              VARCHAR(500)      NULL,
  `subject`             VARCHAR(500)  NOT NULL,
  `population`          VARCHAR(500)      NULL,
  `pop_area`            VARCHAR(500)      NULL,
  `method`              VARCHAR(500)      NULL,
  `ethnic`              VARCHAR(500)      NULL,
  `collect`             VARCHAR(500)      NULL,
  `latitude`            VARCHAR(50)       NULL,
  `longitude`           VARCHAR(50)       NULL,
  `complex`             INTEGER(2)        NULL,
  `hla_a_1`             VARCHAR(500)      NULL,
  `hla_a_2`             VARCHAR(500)      NULL,
  `mismatch1`           VARCHAR(500)      NULL,
  `hla_b_1`             VARCHAR(500)      NULL,
  `hla_b_2`             VARCHAR(500)      NULL,
  `mismatch2`           VARCHAR(500)      NULL,
  `hla_c_1`             VARCHAR(500)      NULL,
  `hla_c_2`             VARCHAR(500)      NULL,
  `mismatch3`           VARCHAR(500)      NULL,
  `hla_drb1_1`          VARCHAR(500)      NULL,
  `hla_drb1_2`          VARCHAR(500)      NULL,
  `mismatch4`           VARCHAR(500)      NULL,
  `hla_dqa1_1`          VARCHAR(500)      NULL,
  `hla_dqa1_2`          VARCHAR(500)      NULL,
  `mismatch5`           VARCHAR(500)      NULL,
  `hla_dqb1_1`          VARCHAR(500)      NULL,
  `hla_dqb1_2`          VARCHAR(500)      NULL,
  `mismatch6`           VARCHAR(500)      NULL,
  `hla_dpa1_1`          VARCHAR(500)      NULL,
  `hla_dpa1_2`          VARCHAR(500)      NULL,
  `mismatch7`           VARCHAR(500)      NULL,
  `hla_dpb1_1`          VARCHAR(500)      NULL,
  `hla_dpb1_2`          VARCHAR(500)      NULL,
  `mismatch8`           VARCHAR(500)      NULL,
  `report`              VARCHAR(500)      NULL,
  `authors`             VARCHAR(2000)     NULL,
  PRIMARY KEY (`subject`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_ALLELE_DATA_TYPE` (
  `data_type_id`        INTEGER(4)    NOT NULL,
  `data_name`           VARCHAR(30)   NOT NULL,
  `data_descr`          VARCHAR(255)  NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`data_type_id`),
  UNIQUE INDEX (`data_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_POP_AREA_TYPE` (
  `pop_area_id`         INTEGER(4)    NOT NULL,
  `pop_area_name`       VARCHAR(30)   NOT NULL,
  `pop_area_abbrv`      VARCHAR(3)    NOT NULL,  
  `pop_area_descr`      VARCHAR(4000) NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`pop_area_id`),
  UNIQUE INDEX (`pop_area_name`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `MHC_HLA_ALLELE_FREQ` (
  `locus_id`            INTEGER(10)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  `pop_area_id`         INTEGER(4)    NOT NULL,
  `data_type_id`        INTEGER(4)    NOT NULL,
  `allele_freq`         FLOAT         NOT NULL,
  `allele_count`        INTEGER(10)   NOT NULL,
  `allele_total`        INTEGER(10)   NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`locus_id`, `allele_name`, `pop_area_id`),
  FOREIGN KEY (`locus_id`)
    REFERENCES mhc_locus(`locus_id`),
  FOREIGN KEY (`data_type_id`)
    REFERENCES lk_allele_data_type(`data_type_id`),
  FOREIGN KEY (`pop_area_id`)
    REFERENCES lk_pop_area_type(`pop_area_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `MHC_HLA_ALLELE_FREQ_MAP` (
  `allele_id`           INTEGER(10)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`allele_id`, `allele_name`),
  FOREIGN KEY (`allele_id`)
    REFERENCES allele(`allele_id`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `PDB_PROTEIN` (
  `pdb_id`              VARCHAR(50)   NOT NULL,
  `chain_id`            VARCHAR(3)    NOT NULL,
  `protein_acc`         VARCHAR(50)   NOT NULL,
  `protein_start`       INTEGER(10)   NOT NULL,
  `protein_end`         INTEGER(10)   NOT NULL,
  `pdb_start`           INTEGER(10)   NOT NULL,
  `pdb_end`             INTEGER(10)   NOT NULL,
  `molecule`            VARCHAR(1000) NOT NULL,
  PRIMARY KEY (`pdb_id`, `chain_id`, `protein_acc`, `protein_start`)
) engine=InnoDB DEFAULT charset=latin1;

CREATE TABLE `LK_REGION_CWD_ALLELE` (
  `pop_area_name`       VARCHAR(30)   NOT NULL,
  `allele_name`         VARCHAR(60)   NOT NULL,
  `locus_name`          VARCHAR(30)   NOT NULL,
  `cwd_allele`          VARCHAR(1)    NOT NULL,
  `region_frequency`    FLOAT         NOT NULL,
  `date_created`        DATE              NULL,
  `created_by`          VARCHAR(12)       NULL,
  `date_last_updated`   DATE              NULL,
  `last_updated_by`     VARCHAR(12)       NULL,
  PRIMARY KEY (`pop_area_name`, `allele_name`)
) engine=InnoDB DEFAULT charset=latin1;
