package db::Schema::Generate::Loader::LoadSequenceVariation;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $bcp_directory, $error_mgr ) = @_;
  ###
  ### Before instantiating class, set the bcp directory
  ###
  $tools->setBcpDir($bcp_directory);
  ###
  ### Now instantiate the class
  ###
  my db::Schema::Generate::Loader::LoadSequenceVariation $this =
    $that->SUPER::new( $tools, $error_mgr );

  return $this;
}

sub generate {
  my db::Schema::Generate::Loader::LoadSequenceVariation $this = shift;
  ###
  ### NO-OP since all database tables will be loaded.
  ###
}

################################################################################

1;

__END__

=head1 NAME

LoadSequenceVariation.pm

=head1 DESCRIPTION

This concrete class loads the entire sequence variation database from
pre-existing bcp files.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::LoadSequenceVariation(tools, bcp_directory, error_mgr)>

This is the constructor for the class.

=head2 B<generate>

This method sets the the files to load as all the files in the schema.

=cut
