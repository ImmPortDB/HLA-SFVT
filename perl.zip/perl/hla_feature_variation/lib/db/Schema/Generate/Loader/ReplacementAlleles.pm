package db::Schema::Generate::Loader::ReplacementAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use lookup::Alleles;
use lookup::LookupTable::ChangedNames;
use lookup::LookupTable::DeletedNames;

use base 'db::Schema::Generate::Loader';

use fields
  qw (
  alleles_lookup
  changed_lookup
  deleted_lookup
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _getCurrentAlleles {
  my db::Schema::Generate::Loader::ReplacementAlleles $this = shift;
  my ($allele) = @_;

  $allele =~ /^(.+)\*/;
  my $locus_name = $1;

  my $allelesLookup = $this->{alleles_lookup};
  my @alleles_found =
      $allelesLookup->getAlleles( $locus_name,
				  $allele,
				  db::MhcTypes::IMGT_HLA_V3 );

  $this->{error_mgr}->printMsg
    ("_getCurrentAlleles:\n"
     . "  allele        = $allele\n"
     . "  alleles found = (" . join( util::Constants::COMMA_SEPARATOR, @alleles_found ) . ")" );

  my $allele_name_pattern = $allele;
  $allele_name_pattern =~ s/\*/\\\*/;

  my $found_allele    = util::Constants::FALSE;
  my @matched_alleles = ();
  foreach my $allele_found (@alleles_found) {
    ###
    ### Found uniquely from a list
    ###
    if ( $allele_found eq $allele ) {
      $found_allele = util::Constants::TRUE;
      last;
    }
    next if ( $allele_found !~ /^$allele_name_pattern/ );
    push( @matched_alleles, $allele_found );
  }
  if ($found_allele) {
    ###
    ### exact match make it the matched alleles
    ###
    @matched_alleles = ($allele);
    $this->{error_mgr}->printMsg("  allele exact match = $allele");
  }
  elsif ( @matched_alleles > 0 ) {
    $this->{error_mgr}->printMsg( "  allele prefix match = ("
        . join( util::Constants::COMMA_SEPARATOR, @matched_alleles )
        . ")" );
  }
  else {
    ###
    ### Report that none were found
    ###
    $this->{error_mgr}->printNote(
      "_getCurrentAlleles:\n  No current alleles found for allele" );
  }
  ###
  ### Return the set of allele_id's
  ###
  my @alleles = ();
  foreach my $matched_allele (@matched_alleles) {
    my $alleleData =
	$allelesLookup->getAllele( $locus_name,
				   $matched_allele,
				   db::MhcTypes::IMGT_HLA_V3 );
    push( @alleles, $alleleData->{allele_id} );
  }
  return @alleles;
}

sub _generateRows {
  my db::Schema::Generate::Loader::ReplacementAlleles $this = shift;
  my ( $old_allele, $locus_id, $replacement_type, @allele_ids ) = @_;

  my $table          = $this->{tables}->[0];
  my $replacement_id =
    db::MhcTypes::getId( db::MhcTypes::REPLACEMENT_TYPE_TABLE,
    $replacement_type );
  foreach my $allele_id (@allele_ids) {
    my $row = $this->getRowHash($table);
    $row->{&db::MhcTypes::ALLELE_ID_COL}       = $allele_id;
    $row->{&db::MhcTypes::LOCUS_ID_COL}        = $locus_id;
    $row->{&db::MhcTypes::OLD_ALLELE_NAME_COL} = $old_allele;
    $row->{&db::MhcTypes::REPLACEMENT_ID_COL}  = $replacement_id;
    $this->generateRow( $table, $row );
  }
}

sub _resolveAllele {
  my db::Schema::Generate::Loader::ReplacementAlleles $this = shift;
  my ( $allele, $replacement_type ) = @_;

  $this->{error_mgr}->printMsg("_resolveAllele:  $replacement_type");
  my $changedLookup = $this->{changed_lookup};
  my $deletedLookup = $this->{deleted_lookup};
  my @alleles       = ();
  if ( $replacement_type eq db::MhcTypes::DELETED_ALLELE_TYPE ) {
    if ( $deletedLookup->valueDefined($allele) ) {
      my $replaced_allele = $deletedLookup->getValue($allele);
      if ( $deletedLookup->valueDefined($replaced_allele) ) {
        ###
        ### First check to see if it is also deleted
        ###
        push(
          @alleles,
          $this->_resolveAllele(
            $replaced_allele, db::MhcTypes::DELETED_ALLELE_TYPE
          )
        );
      }
      else {
        ###
        ### Check the changed alleles
        ###
        my @changed_alleles =
          $this->_resolveAllele( $replaced_allele,
          db::MhcTypes::CHANGED_ALLELE_TYPE );
        if ( @changed_alleles > 0 ) {
          push( @alleles, @changed_alleles );
        }
        else {
          push( @alleles, $replaced_allele );
        }
      }
    }
    else {
      push( @alleles, $allele );
    }
  }
  elsif ( $replacement_type eq db::MhcTypes::CHANGED_ALLELE_TYPE ) {
    if ( $changedLookup->keyDefined($allele) ) {
      foreach my $changed_allele ( $changedLookup->getValue($allele) ) {
        my @resolved_alleles =
          $this->_resolveAllele( $changed_allele,
          db::MhcTypes::DELETED_ALLELE_TYPE );
        if ( @resolved_alleles > 0 ) {
          push( @alleles, @resolved_alleles );
        }
        else {
          push( @alleles, $changed_allele );
        }
      }
    }
    else {
      push( @alleles, $allele );
    }
  }
  return @alleles;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::ReplacementAlleles $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->addTable(db::MhcTypes::REPLACEMENT_ALLELE_TABLE);

  $this->{alleles_lookup} =
    new lookup::Alleles( db::MhcTypes::HOMO_SAPIENS_TAXON, $tools, $error_mgr );
  $this->{changed_lookup} =
    new lookup::LookupTable::ChangedNames( db::MhcTypes::HOMO_SAPIENS_TAXON, $tools,
    $error_mgr );
  $this->{deleted_lookup} =
    new lookup::LookupTable::DeletedNames( db::MhcTypes::HOMO_SAPIENS_TAXON, $tools,
    $error_mgr );

  return $this;
}

sub generate {
  my db::Schema::Generate::Loader::ReplacementAlleles $this = shift;

  my $allelesLookup = $this->{alleles_lookup};
  my $changedLookup = $this->{changed_lookup};
  my $deletedLookup = $this->{deleted_lookup};
  ###
  ### Add the changed alleles
  ###
  foreach my $old_allele ( $changedLookup->getKeys ) {
    $this->{error_mgr}
      ->printHeader( "changed\n" . "  old allele = $old_allele" );
    my @changed_alleles = $changedLookup->getValue($old_allele);
    foreach my $changed_allele (@changed_alleles) {
      $this->{error_mgr}->printMsg("changed allele = $changed_allele");
      ###
      ### Processing changed alleles
      ###
      $changed_allele =~ /^(.+)\*/;
      my $locus_name = $1;
      my $locus_id   = $allelesLookup->getLocusId($locus_name);
      foreach my $resolved_allele (
        $this->_resolveAllele(
          $changed_allele, db::MhcTypes::DELETED_ALLELE_TYPE
        )
        )
      {
        $this->{error_mgr}->printMsg("-->$resolved_allele");
        $this->_generateRows(
          $old_allele, $locus_id,
          db::MhcTypes::CHANGED_ALLELE_TYPE,
          $this->_getCurrentAlleles($resolved_allele)
        );
      }
      $this->{error_mgr}->printMsg("\n");
    }
  }
  ###
  ### Add the deleted alleles
  ###
  foreach my $deleted_allele ( $deletedLookup->getKeys ) {
    $this->{error_mgr}
      ->printHeader( "deleted\n" . "  deleted allele = $deleted_allele" );
    my $replaced_allele = $deletedLookup->getValue($deleted_allele);
    next if ( !defined($replaced_allele) );
    $this->{error_mgr}->printMsg("replaced allele = $replaced_allele");
    $replaced_allele =~ /^(.+)\*/;
    my $locus_name = $1;
    my $locus_id   = $allelesLookup->getLocusId($locus_name);

    $replaced_allele =~ /^.+\*(\d+)/;
    my $replaced_digits     = $1;
    my $num_replaced_digits = length($replaced_digits);
    my @alleles             = ();
    my $msg                 = util::Constants::EMPTY_STR;
    if ( $num_replaced_digits == 5 || $num_replaced_digits == 7 ) {
      ###
      ### Treat the replaced allele as a changed allele
      ###
      $msg = '(change)';
      push(
        @alleles,
        $this->_resolveAllele(
          $replaced_allele, db::MhcTypes::CHANGED_ALLELE_TYPE
        )
      );
    }
    else {
      push(
        @alleles,
        $this->_resolveAllele(
          $replaced_allele, db::MhcTypes::DELETED_ALLELE_TYPE
        )
      );
      $msg = '(deleted)';
    }
    $this->{error_mgr}->printMsg(
      "$msg = (" . join( util::Constants::COMMA_SEPARATOR, @alleles ) . ")\n" );
    foreach my $allele (@alleles) {
      $this->{error_mgr}->printMsg("-->$allele");
      $this->_generateRows(
        $deleted_allele, $locus_id,
        db::MhcTypes::DELETED_ALLELE_TYPE,
        $this->_getCurrentAlleles($allele)
      );
      $this->{error_mgr}->printMsg("\n");
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

ReplacementAllelesFreq.pm

=head1 DESCRIPTION

This concrete class defines the loader for the replacement alleles
data derived from ANT changed and deleted names and a current ANT
release.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::ReplacementAlleles(tools, error_mgr)>

This is the constructor for the class.

=head2 B<generate>

This method generates the bcp-file that maps the changed and deleted
names to alleles in the current release.

=cut
