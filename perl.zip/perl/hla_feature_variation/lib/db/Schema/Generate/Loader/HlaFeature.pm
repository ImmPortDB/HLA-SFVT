package db::Schema::Generate::Loader::HlaFeature;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use file::Chunk::Excel;

use hla::FeatureName;
use hla::HlaTypes;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields qw (
  feature_allele
  feature_file
  feature_id
  locus_ids
  seq_type
  taxon_id
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _hlaFeatureTables {
  my db::Schema::Generate::Loader::HlaFeature $this = shift;
  return [
    db::MhcTypes::VARIANT_2_ALLELE_TABLE,
    db::MhcTypes::VARIANT_MAP_TABLE,
    db::MhcTypes::VARIANT_REFERENCE_TABLE,
    db::MhcTypes::VARIANT_TYPE_TABLE,
    db::MhcTypes::FEATURE_MAP_TABLE,
    db::MhcTypes::FEATURE_MAP_BASE1_TABLE,
    db::MhcTypes::FEATURE_2_NAME_TABLE,
    db::MhcTypes::FEATURE_2_TYPE_TABLE,
    db::MhcTypes::FEATURE_2_PUBMED_TABLE,
    db::MhcTypes::PDB_MAPPING_TABLE,
    db::MhcTypes::FEATURE_TABLE,
    db::MhcTypes::FEATURE_ALLELE_TABLE,
  ];
}

sub _hlaFeaturePredicates {
  my db::Schema::Generate::Loader::HlaFeature $this = shift;

  my $locus_id_list =
      util::Constants::OPEN_PAREN
    . join( util::Constants::COMMA_SEPARATOR, @{ $this->{locus_ids} } )
    . util::Constants::CLOSE_PAREN;

  return {
    &db::MhcTypes::VARIANT_2_ALLELE_TABLE => {
      qarray => [],
      pred   => "
variant_id in
  (select variant_id
   from   variant_type vt,
          feature      fn
   where  fn.locus_id   in $locus_id_list
   and    fn.feature_id =  vt.feature_id)
",
    },

    &db::MhcTypes::VARIANT_MAP_TABLE => {
      qarray => [],
      pred   => "
variant_id in
  (select variant_id
   from   variant_type vt,
          feature      fn
   where  fn.locus_id in $locus_id_list
   and    fn.feature_id = vt.feature_id)
",
    },

    &db::MhcTypes::VARIANT_TYPE_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::VARIANT_REFERENCE_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::FEATURE_MAP_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::FEATURE_MAP_BASE1_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::FEATURE_2_NAME_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::FEATURE_2_TYPE_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::FEATURE_2_PUBMED_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::PDB_MAPPING_TABLE => {
      qarray => [],
      pred   => "
locus_id in $locus_id_list
",
    },

    &db::MhcTypes::FEATURE_TABLE => {
      qarray => [],
      pred   => "
locus_id in $locus_id_list
",
    },

    &db::MhcTypes::FEATURE_ALLELE_TABLE => {
      qarray => [],
      pred   => "
locus_id in $locus_id_list
",
    },
  };
}

sub _getLocusName {
  my db::Schema::Generate::Loader::HlaFeature $this = shift;
  my ($entities) = @_;

  my $locus_name = undef;
  foreach my $entity ( @{$entities} ) {
    if ( $entity->{feature_number} =~ /^Hsa_(.+)_SF\d+$/ ) {
      $locus_name = $1;
      last;
    }
  }
  return $locus_name;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$$$) {
  my ( $that, $tools, $feature_file, $taxon_id, $seq_type, $feature_id,
    $feature_allele, $error_mgr )
    = @_;
  my db::Schema::Generate::Loader::HlaFeature $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{feature_file}   = $feature_file;
  $this->{feature_allele} = $feature_allele;
  $this->{feature_id}     = $feature_id;
  $this->{locus_ids}      = undef;
  $this->{seq_type}       = $seq_type;
  $this->{taxon_id}       = $taxon_id;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::HlaFeature $this = shift;

  $this->{loader}
    ->partialDelete( $this->_hlaFeatureTables, $this->_hlaFeaturePredicates );
}

sub generate {
  my db::Schema::Generate::Loader::HlaFeature $this = shift;

  $this->{locus_ids} = [];
  ###
  ###nn Get all sequence features for all loci in file
  ###
  my $reader = new file::Chunk::Excel( undef, hla::HlaTypes::FEATURE_FILE_ORD,
    $this->{error_mgr} );
  $reader->setSourceFile( $this->{feature_file} );
  $reader->readExcelFile;
  ###
  ### for each worksheet
  ###
  hla::HlaTypes::readFeatureAlleleData( $this->{feature_allele},
    $this->{tools} );
  foreach my $worksheet_num ( $reader->getWorksheetNums ) {
    my @entities   = $reader->getWorksheet($worksheet_num);
    my $locus_name = $this->_getLocusName( \@entities );
    next if ( !defined($locus_name) );
    $this->{error_mgr}->printHeader( "Proccessing Worksheet\n"
        . "  worksheet  = $worksheet_num\n"
        . "  locus_name = $locus_name" );
    my $locus_id =
      db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locus_name,
      $this->{taxon_id} );
    push( @{ $this->{locus_ids} }, $locus_id );
    my $hla =
      new hla::FeatureName( $locus_name, $this->{taxon_id}, $this->{seq_type},
      $this, $this->{feature_id}, $this->{tools}, $this->{error_mgr} );
    $hla->processFile( \@entities );
    $this->{feature_id} = $hla->featureId;
  }
}

################################################################################

1;

__END__

=head1 NAME

HlaFeature.pm

=head1 DESCRIPTION

This concrete class defines the loader for the HLA Feature data for a
given locus.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::HlaFeature(tools, feature_file, feature_alleles, locus_name, taxon_id, seq_type, feature_id, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the HLA Feature data for a given
locus.

=cut
