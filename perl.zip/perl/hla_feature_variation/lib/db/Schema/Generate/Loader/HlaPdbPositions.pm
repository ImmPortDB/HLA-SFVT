package db::Schema::Generate::Loader::HlaPdbPositions;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use hla::PdbPositions;
use hla::HlaTypes;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields qw(
  feature_allele
  locus_ids
  taxon_id
  query_mgr
  seq_type_id
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _pdbPositionsTables {
  my db::Schema::Generate::Loader::HlaPdbPositions $this = shift;

  return [ db::MhcTypes::PDB_MAPPING_TABLE, ];
}

sub _pdbPositionsPredicates {
  my db::Schema::Generate::Loader::HlaPdbPositions $this = shift;

  my $locus_id_list =
      util::Constants::OPEN_PAREN
    . join( util::Constants::COMMA_SEPARATOR, @{ $this->{locus_ids} } )
    . util::Constants::CLOSE_PAREN;

  return {
    &db::MhcTypes::PDB_MAPPING_TABLE => {
      qarray => [],
      pred   => "
locus_id in $locus_id_list
",
    },
  };
}

################################################################################
#
#				 Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $taxon_id, $feature_allele, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::HlaPdbPositions $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{feature_allele} = $feature_allele;
  $this->{locus_ids}      = undef;
  $this->{taxon_id}       = $taxon_id;
  $this->{seq_type_id} =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::AA_SEQ );

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::HlaPdbPositions $this = shift;

  $this->{loader}->partialDelete( $this->_pdbPositionsTables,
    $this->_pdbPositionsPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::HlaPdbPositions $this = shift;

  $this->{locus_ids} = [];
  ###
  ### for all the defined mappings
  ###
  hla::HlaTypes::readFeatureAlleleData( $this->{feature_allele},
    $this->{tools} );
  foreach my $locus_name (hla::HlaTypes::getLociWithPdbStructures) {
    $this->{error_mgr}
      ->printHeader( "Proccessing Locus\n" . "  locus_name = $locus_name" );
    my $locus_id =
      db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locus_name,
      $this->{taxon_id} );
    push( @{ $this->{locus_ids} }, $locus_id );
    my $hla =
      new hla::PdbPositions( $locus_id, $this->{taxon_id}, $locus_name, $this,
      $this->{tools}, $this->{error_mgr} );
    $hla->processLocus();
  }
}

################################################################################

1;

__END__

=head1 NAME

HlaPdbPositions.pm

=head1 SYNOPSIS

   use db::Schema::Generate::Loader::HlaPdbPositions;

=head1 DESCRIPTION

This concrete class generates the update to the FEATURE table for
PDB_POSITIONS. It is a subclass of L<db::Schema::Generate::Loader>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::HlaPdbPositions(that, tools, error_mgr)>

This is the constructor for the class and it requires, tools, a
platform, result, and error manager.

=head2 B<generate>

This method defines how to generate imgt_hla_p_code and
imgt_hla_g_code columns for a each allele that has at least one of the
codes.

=cut
