package db::Schema::Generate::Loader::AntMsfData;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use anthonyNolan::Msf;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields
  qw (
  msf_directory
  taxon_id
);

################################################################################
#
#				Private Methods
#
################################################################################

sub msfTables {
  my db::Schema::Generate::Loader::AntMsfData $this = shift;
  return [
    db::MhcTypes::ALIGNMENT_SEQ_TABLE,
    db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::REFERENCE_ALLELE_TABLE
  ];
}

sub msfPredicates {
  my db::Schema::Generate::Loader::AntMsfData $this = shift;

  return {
    &db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::REFERENCE_ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::ALIGNMENT_SEQ_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },
  };
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $tools, $taxon_id, $msf_directory, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::AntMsfData $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{msf_directory} = $msf_directory;
  $this->{taxon_id}      = $taxon_id;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::AntMsfData $this = shift;
  $this->{loader}->partialDelete( $this->msfTables, $this->msfPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::AntMsfData $this = shift;

  my $msf = new anthonyNolan::Msf(
    $this->{taxon_id}, $this->{msf_directory},
    $this, $this->{tools}->getSession,
    $this->{error_mgr}
  );
  $msf->processFiles;
}

################################################################################

1;

__END__

=head1 NAME

AntMsfData.pm

=head1 DESCRIPTION

This concrete class defines the loader for the Ant Msf Sequence data for a
given release.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::AntMsfData(tools, taxon_id, msf_directory, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the Ant Msf Sequence data for a
release.

=cut
