package db::Schema::Generate::Loader::InitializeDatabase;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

################################################################################
#
#				Private Methods
#
################################################################################

sub otherTables {
  my db::Schema::Generate::Loader::InitializeDatabase $this = shift;

  return (
    db::MhcTypes::MHC_HLA_ALLELE_FREQ_MAP_TABLE,
    db::MhcTypes::MHC_HLA_ALLELE_FREQ_TABLE,
    db::MhcTypes::MHC_HLA_FREQ_TABLE,

    db::MhcTypes::REPLACEMENT_ALLELE_TABLE,

    db::MhcTypes::VARIANT_MAP_TABLE,
    db::MhcTypes::VARIANT_REFERENCE_TABLE,
    db::MhcTypes::VARIANT_2_ALLELE_TABLE,
    db::MhcTypes::VARIANT_TYPE_TABLE,

    db::MhcTypes::FEATURE_MAP_TABLE,
    db::MhcTypes::FEATURE_MAP_BASE1_TABLE,
    db::MhcTypes::FEATURE_2_NAME_TABLE,
    db::MhcTypes::FEATURE_2_PUBMED_TABLE,
    db::MhcTypes::FEATURE_2_TYPE_TABLE,
    db::MhcTypes::PDB_MAPPING_TABLE,

    db::MhcTypes::ALIGNMENT_SEQ_TABLE,
    db::MhcTypes::MOLECULE_SEQ_TABLE,
    db::MhcTypes::VARIANT_SEQ_TABLE,
    db::MhcTypes::ALLELE_ALIGNMENT_TABLE,
    db::MhcTypes::CDS_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::FEATURE_ALLELE_TABLE,
    db::MhcTypes::GENE_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::PUBMED_REFERENCE_TABLE,
    db::MhcTypes::REFERENCE_ALLELE_TABLE,
    db::MhcTypes::SEQ_BIOSOURCE_TABLE,
    db::MhcTypes::SEQ_EVIDENCE_TABLE,
    db::MhcTypes::ALLELE_NOMENCLATURE_TABLE,

    db::MhcTypes::ALLELE_TABLE,
    db::MhcTypes::FEATURE_TABLE,
    db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE
  );
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$) {
  my ( $that, $tools, $error_mgr ) = @_;
  ###
  ### Before instantiating class, set the bcp directory
  ###
  $tools->setBcpDir(
    join( util::Constants::SLASH,
      $ENV{DEVEL_LIB}, 'db', 'controlled_vocabulary'
    )
  );
  ###
  ### Now instantiate the class
  ###
  my db::Schema::Generate::Loader::InitializeDatabase $this =
    $that->SUPER::new( $tools, $error_mgr );

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::InitializeDatabase $this = shift;
  ###
  ### Must delete all tables that are not not lookup
  ### tables (controlled vocabulary and other tables)
  ###
  $this->{loader}->delete( $this->otherTables );
}

sub generate {
  my db::Schema::Generate::Loader::InitializeDatabase $this = shift;
  ###
  ### Must set the files to load to the
  ### set of controlled vocabulary tables
  ###
  my $controlled_vocabularies_str =
    $this->{tools}->getProperty('useControlledVocabulary');
  my @controlled_vocabularies = eval $controlled_vocabularies_str;

  push( @{ $this->{files_loaded} }, @controlled_vocabularies );
}

################################################################################

1;

__END__

=head1 NAME

InitializeDatabase.pm

=head1 DESCRIPTION

This concrete class deletes all tables except the lookup tables and
then loads the controlled vocabularies from the standard location in
the file system B<$DEVEL_LIB/db/controlled_vocabulary>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::InitializeDatabase(tools, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the deletion of all tables except the lookup tables.

=head2 B<generate>

This method sets the set of files to be loaded to the controlled vocabulary
files.

=cut
