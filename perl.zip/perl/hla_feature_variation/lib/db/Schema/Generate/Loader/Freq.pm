package db::Schema::Generate::Loader::Freq;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::DbQuery;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields
  qw (
  col_map
  data_types
  pop_areas
  queries
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Lookup Table data
###
sub HOMO_SAPIENS_TAXON { return 9606; }
###
### The data from the MHC_HLA_FREQ
###
sub DB_QUERIES {
  return {
    &db::MhcTypes::MHC_HLA_FREQ_TABLE => {
      msg     => db::MhcTypes::MHC_HLA_FREQ_TABLE . ' Query',
      col_ord => [
        db::MhcTypes::POP_AREA_COL,   db::MhcTypes::HLA_A_1_COL,
        db::MhcTypes::HLA_A_2_COL,    db::MhcTypes::HLA_B_1_COL,
        db::MhcTypes::HLA_B_2_COL,    db::MhcTypes::HLA_C_1_COL,
        db::MhcTypes::HLA_C_2_COL,    db::MhcTypes::HLA_DRB1_1_COL,
        db::MhcTypes::HLA_DRB1_2_COL, db::MhcTypes::HLA_DQA1_1_COL,
        db::MhcTypes::HLA_DQA1_2_COL, db::MhcTypes::HLA_DQB1_1_COL,
        db::MhcTypes::HLA_DQB1_2_COL, db::MhcTypes::HLA_DPA1_1_COL,
        db::MhcTypes::HLA_DPA1_2_COL, db::MhcTypes::HLA_DPB1_1_COL,
        db::MhcTypes::HLA_DPB1_2_COL,
      ],
    },
  };
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _alleleDataTypePatterns {
  my db::Schema::Generate::Loader::Freq $this = shift;

  my $tools         = $this->{tools};
  my $allelesLookup = $tools->getAllelesLookup;
  $this->{data_types} = {
    &db::MhcTypes::HLA_PROTEIN_DATA_TYPE => {
      pattern => '^(\w+\*\d+:\d+)',
      lookup  => $allelesLookup->getHlaProteinLookup(db::MhcTypes::IMGT_HLA_V3),
      map     => {},
    },

    &db::MhcTypes::ALLELE_GROUP_DATA_TYPE => {
      pattern => '^(\w+\*\d+)',
      lookup  => $allelesLookup->getAlleleGroupLookup(db::MhcTypes::IMGT_HLA_V3),
      map     => {},

    },
  };
}

sub _getStruct {
  my db::Schema::Generate::Loader::Freq $this = shift;
  my ( $query, $row ) = @_;

  my $ord    = $this->{queries}->{$query}->{col_ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _computeColMap {
  my db::Schema::Generate::Loader::Freq $this = shift;

  my $mhc_hla_freq  = db::MhcTypes::MHC_HLA_FREQ_TABLE;
  my $tools         = $this->{tools};
  my $query         = $this->{queries}->{$mhc_hla_freq};
  my $col_map       = $this->{col_map};
  my $allelesLookup = $tools->getAllelesLookup;
  foreach my $col ( @{ $query->{col_ord} } ) {
    next if ( $col !~ /^hla_/ );
    $col =~ /^(hla_.+)_\d$/;
    my $locus_name = $1;
    $locus_name =~ s/_/-/;
    my $locus_data = $allelesLookup->getLocusData($locus_name);
    next if ( !defined($locus_data) );
    my $locus_id = $locus_data->{locus_id};
    if ( !defined( $col_map->{$locus_id} ) ) {
      $col_map->{$locus_id} = [];
    }
    push( @{ $col_map->{$locus_id} }, $col );
  }
}

sub _getPopData {
  my db::Schema::Generate::Loader::Freq $this = shift;

  my $mhc_hla_freq = db::MhcTypes::MHC_HLA_FREQ_TABLE;
  my $query        = $this->{queries}->{$mhc_hla_freq};
  my $cmd          = join(
    util::Constants::SPACE,
    'select',
    join(
      util::Constants::COMMA . util::Constants::NEWLINE,
      @{ $query->{col_ord} }
    ),
    "from $mhc_hla_freq"
  );
  my $pop_areas  = $this->{pop_areas};
  my $db_queries = new util::DbQuery( $this->{tools}->getSession );
  $db_queries->doQuery( $mhc_hla_freq, $cmd, $query->{msg} );
  while ( my $row_ref = $db_queries->fetchRowRef($mhc_hla_freq) ) {
    my $struct = $this->_getStruct( $mhc_hla_freq, $row_ref );
    my $pop_area = $struct->{&db::MhcTypes::POP_AREA_COL};
    if ( !defined( $pop_areas->{$pop_area} ) ) {
      $pop_areas->{$pop_area} = [];
    }
    push( @{ $pop_areas->{$pop_area} }, $struct );
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::Freq $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{col_map}    = {};
  $this->{data_types} = undef;
  $this->{pop_areas}  = {};
  $this->{queries}    = DB_QUERIES;
  ###
  ### Add the tables for the loader
  ###
  $this->addTable(db::MhcTypes::MHC_HLA_ALLELE_FREQ_TABLE);
  $this->addTable(db::MhcTypes::MHC_HLA_ALLELE_FREQ_MAP_TABLE);
  ###
  ### create alleles lookup
  ###
  $this->{tools}->setAllelesLookup(HOMO_SAPIENS_TAXON);
  $this->_alleleDataTypePatterns;
  ###
  ### Now generate column map and get population area data
  ###
  $this->_computeColMap;
  $this->_getPopData;

  $this->{tools}->debugStruct("col_map",$this->{col_map});
  $this->{tools}->debugStruct("pop_areas", $this->{pop_areas});

  return $this;
}

sub generate {
  my db::Schema::Generate::Loader::Freq $this = shift;
  ###
  ### Compute each allele data type separately
  ###
  my $tools         = $this->{tools};
  my $allelesLookup = $tools->getAllelesLookup;
  my $allele_lookup = $allelesLookup->getAlleleLookup(db::MhcTypes::IMGT_HLA_V3);
  
  my $mhc_hla_allele_freq     = $this->{tables}->[0];
  my $mhc_hla_allele_freq_map = $this->{tables}->[1];
  while ( my ( $pop_area, $data ) = each %{ $this->{pop_areas} } ) {
    ###
    ### Computing for a single population area
    ###
    my $pop_id =
      db::MhcTypes::getId( db::MhcTypes::LK_POP_AREA_TYPE_TABLE, $pop_area );
    while ( my ( $locus_id, $cols ) = each %{ $this->{col_map} } ) {
      ###
      ### Computing for a single locus;
      ###
      while ( my ( $data_type, $type_info ) = each %{ $this->{data_types} } ) {
        ###
        ### Computing for a single allele data_type
        ###
        my $data_type_id =
          db::MhcTypes::getId( db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE,
          $data_type );
        my $counts  = {};
        my $pattern = $type_info->{pattern};
        my $map     = $type_info->{map};
        my $lookup  = $type_info->{lookup};
        my $total   = 0;
        foreach my $datum ( @{$data} ) {
          ###
          ### Run through the columns of interest
          ###
          foreach my $col ( @{$cols} ) {
            my $allele = $datum->{$col};
            next if ( util::Constants::EMPTY_LINE($allele) );
            if ( $allele =~ /$pattern/ ) {
              $allele = $1;
              if ( !defined( $counts->{$allele} ) ) {
                $counts->{$allele} = 0;
              }
              $counts->{$allele}++;
              $total++;
            }
          }
        }
        ###
        ### Now that have counts can compute frequencies
        ### for a population area, locus_id, and data_type
        ### and
        ### generate rows in MHC_HLA_ALLELE_FREQ and
        ### MHC_HLA_ALLELE_FREQ_MAP tables
        ###
        while ( my ( $allele, $allele_count ) = each %{$counts} ) {
          my $freq     = $allele_count / $total;
          my $freq_row = $this->getRowHash($mhc_hla_allele_freq);
          $freq_row->{&db::MhcTypes::LOCUS_ID_COL}        = $locus_id;
          $freq_row->{&db::MhcTypes::ALLELE_NAME_COL}     = $allele;
          $freq_row->{&db::MhcTypes::POP_AREA_ID_COL}     = $pop_id;
          $freq_row->{&db::MhcTypes::DATA_TYPE_ID_COL}    = $data_type_id;
          $freq_row->{&db::MhcTypes::ALLELE_COUNT_COL}    = $allele_count;
          $freq_row->{&db::MhcTypes::ALLELE_TOTAL_COL}    = $total;
          $freq_row->{&db::MhcTypes::ALLELE_FREQ_COL}     = $freq;
          $freq_row->{&db::MhcTypes::LAST_UPDATED_BY_COL} = $tools->getUserName;
          $freq_row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} =
            $this->getLoadTime;

          $this->generateRow( $mhc_hla_allele_freq, $freq_row );
          ###
          ### Now get the current alleles associated with the allele
          ###
          my @curr_alleles = $lookup->getValue($allele);
          foreach my $curr_allele (@curr_alleles) {
            my $curr_data = $allele_lookup->getValue($curr_allele);
            my $allele_id = $curr_data->{allele_id};
            next if ( defined( $map->{$allele_id} ) );
            $map->{$allele_id} = $allele;
            my $map_row = $this->getRowHash($mhc_hla_allele_freq_map);
            $map_row->{&db::MhcTypes::ALLELE_NAME_COL}     = $allele;
            $map_row->{&db::MhcTypes::ALLELE_ID_COL}       = $allele_id;
            $map_row->{&db::MhcTypes::LAST_UPDATED_BY_COL} =
              $tools->getUserName;
            $map_row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} =
              $this->getLoadTime;

            $this->generateRow( $mhc_hla_allele_freq_map, $map_row );
          }
        }
      }
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

Freq.pm

=head1 DESCRIPTION

This concrete class defines the loader for computed allele frequency
data from the dbMHC allele population data.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::Freq(tools, error_mgr)>

This is the constructor for the class.

=head2 B<generate>

This method generates the bcp file for loading the computed allele
frequencies form the dbMHC allele population data.

=cut
