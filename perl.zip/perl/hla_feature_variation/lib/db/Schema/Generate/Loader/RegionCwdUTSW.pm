package db::Schema::Generate::Loader::RegionCwdUTSW;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::DbQuery;

use db::MhcTypes;

use file::Struct::Excel::RegionCwdUTSW;

use lookup::LookupTable::ReplacementAlleles;

use base 'db::Schema::Generate::Loader';

use fields qw (
  file
  pop_areas
  queries
  replacement
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Lookup Table data
###
sub HOMO_SAPIENS_TAXON { return 9606; }
###
### Region Status Notations
###
sub REGION_CWD  { return 'reg-CWD'; }
sub REGION_RARE { return 'reg-Rare'; }
sub NEITHER     { return 'Neither reg-CWD nor reg-Rare'; }

sub CWD_STATUS {
  my ($status) = @_;
  return 'Y' if ( $status eq REGION_CWD );
  return 'N' if ( $status eq REGION_RARE );
  return 'U' if ( $status eq NEITHER );
  return undef;
}

###
### The data from the population table.
###
sub DB_QUERIES {
  return {
    &db::MhcTypes::LK_POP_AREA_TYPE_TABLE => {
      msg => db::MhcTypes::LK_POP_AREA_TYPE_TABLE . ' Query',
      col_ord =>
        [ db::MhcTypes::POP_AREA_NAME_COL, db::MhcTypes::POP_AREA_ABBRV_COL, ],
    },
  };
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _getStruct {
  my db::Schema::Generate::Loader::RegionCwdUTSW $this = shift;
  my ( $query, $row ) = @_;

  my $ord    = $this->{queries}->{$query}->{col_ord};
  my $struct = {};
  foreach my $index ( 0 .. $#{$ord} ) {
    $struct->{ $ord->[$index] } = $row->[$index];
  }
  return $struct;
}

sub _getPopAreaData {
  my db::Schema::Generate::Loader::RegionCwdUTSW $this = shift;

  my $pop_area_data = db::MhcTypes::LK_POP_AREA_TYPE_TABLE;
  my $query         = $this->{queries}->{$pop_area_data};
  my $cmd           = join(
    util::Constants::SPACE,
    'select',
    join(
      util::Constants::COMMA . util::Constants::NEWLINE,
      @{ $query->{col_ord} }
    ),
    "from $pop_area_data"
  );
  my $pop_areas  = $this->{pop_areas};
  my $db_queries = new util::DbQuery( $this->{tools}->getSession );
  $db_queries->doQuery( $pop_area_data, $cmd, $query->{msg} );
  while ( my $row_ref = $db_queries->fetchRowRef($pop_area_data) ) {
    my $struct = $this->_getStruct( $pop_area_data, $row_ref );
    $pop_areas->{ $struct->{pop_area_abbrv} } = $struct->{pop_area_name};
  }
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::RegionCwdUTSW $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{pop_areas} = {};
  $this->{queries}   = DB_QUERIES;
  ###
  ### Add the file
  ###
  $this->{file} = $tools->getProperty('regionData');
  ###
  ### Add the tables for the loader
  ###
  $this->addTable(db::MhcTypes::LK_REGION_CWD_ALLELE_TABLE);
  ###
  ### create alleles lookup
  ###
  $this->{tools}->setAllelesLookup(HOMO_SAPIENS_TAXON);
  ###
  ### Setup Replacement Lookup
  ###
  $this->{replacement} =
    new lookup::LookupTable::ReplacementAlleles( HOMO_SAPIENS_TAXON, $tools,
    $error_mgr );
  ###
  ### Now generate column map and get population area data
  ###
  $this->_getPopAreaData;
  $this->{tools}->debugStruct( "pop_areas", $this->{pop_areas} );

  return $this;
}

sub generate {
  my db::Schema::Generate::Loader::RegionCwdUTSW $this = shift;

  my $tools         = $this->{tools};
  my $allelesLookup = $tools->getAllelesLookup;
  ###
  ### Create the reader
  ###
  my $reader =
    new file::Struct::Excel::RegionCwdUTSW( $this->{file}, $this->{error_mgr} );
  ###
  ### Now load the region data.
  ###
  my $lk_region_cwd_allele = $this->{tables}->[0];
  my $component_list       = $reader->POPULATION_ALLELE_NAME;
  foreach my $entity_id ( $reader->getEntityIds($component_list) ) {
    my $entity = $reader->getObjectByEntityId( $component_list, $entity_id );
    my $region_status = $entity->{ $reader->REGION_CWD_STATUS_COL };
    next
      if ( $region_status ne REGION_CWD
      && $region_status ne REGION_RARE
      && $region_status ne NEITHER );
    my $orig_allele = $entity->{ $reader->ALLELE_COL };
    my ( $locus_name, $digits ) = split( /\*/, $orig_allele );
    ###
    ### Convert the allele to 3.0 notation
    ###
    ### There may be alleles that are really
    ### NULL suffixed or have been deleted
    ### These are taken care of in the following
    ### subcases:
    ### 1.  direct conversion
    ### 2.  conversion using NULL suffix
    ### 3.  determination of singleton replacement
    ###
    ### subcase 1.
    ###
    my $allele = $allelesLookup->convertAllele( $locus_name, $digits,
      db::MhcTypes::IMGT_HLA_V2 );
    if ( !defined($allele) ) {
      ###
      ### subcase 2.
      ###
      $allele = $allelesLookup->convertAllele( $locus_name, $digits . 'N',
        db::MhcTypes::IMGT_HLA_V2 );
      if ( defined($allele) ) {
        $allele =~ s/N$//;
        $this->{error_mgr}
          ->printWarning( "Found allele with NULL suffix = $orig_allele",
          util::Constants::TRUE );
      }
      else {
        ###
        ### subcase 3.
        ###
        $allele = $orig_allele;
        $allele =~ s/^HLA-//;
        $allele =~ s/^C\*/Cw\*/;
        my @alleles = $this->{replacement}->getValue($allele);
        if ( scalar @alleles == 0 ) {
          $this->{error_mgr}->printError( "Cannot Find Allele = $orig_allele",
            util::Constants::TRUE );
          next;
        }
        elsif ( scalar @alleles == 1 ) {
          $allele = $alleles[0];
          $this->{error_mgr}->printWarning(
            "Found allele as replacement = $orig_allele ($allele)",
            util::Constants::TRUE );
        }
        else {
          $this->{error_mgr}->printWarning(
            "Checking Protein = $orig_allele ("
              . join( util::Constants::COMMA_SEPARATOR, @alleles ) . ")",
            util::Constants::TRUE
          );
          my %proteins = ();
          foreach my $rallele (@alleles) {
            $rallele =~ /^(.+)\*(.+)[a-z]?$/;
            my $rlocus  = $1;
            my $rdigits = $2;
            my @comps   = split( /:/, $rdigits );
            my $protein = join( util::Constants::ASTERISK,
              $rlocus, join( util::Constants::COLON, $comps[0], $comps[1] ) );
            $proteins{$protein} = util::Constants::EMPTY_STR;
          }
          my @keys = keys %proteins;
          if ( scalar @keys > 1 ) {
            $this->{error_mgr}->printError(
              "Cannot Find Allele = $orig_allele ("
                . join( util::Constants::COMMA_SEPARATOR, @keys ) . ")",

            );
            next;
          }
          $allele = $keys[0];
          $this->{error_mgr}
            ->printWarning( "Checked Protein = $orig_allele ($allele)",
            util::Constants::TRUE );
        }
      }
    }
    my $row = $this->getRowHash($lk_region_cwd_allele);
    $row->{&db::MhcTypes::ALLELE_NAME_COL} = $allele;
    $row->{&db::MhcTypes::POP_AREA_NAME_COL} =
      $this->{pop_areas}->{ $entity->{ $reader->REGION_COL } };
    $row->{&db::MhcTypes::LOCUS_NAME_COL} = $locus_name;
    $row->{&db::MhcTypes::CWD_ALLELE_COL} = CWD_STATUS($region_status);
    $row->{&db::MhcTypes::REGION_FREQUENCY_COL} =
      $entity->{ $reader->REGION_FREQUENCY_COL };
    $row->{&db::MhcTypes::LAST_UPDATED_BY_COL}   = $tools->getUserName;
    $row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} = $this->getLoadTime;

    $this->generateRow( $lk_region_cwd_allele, $row );
  }
}

################################################################################

1;

__END__

=head1 NAME

RegionCwdUTSW.pm

=head1 DESCRIPTION

This concrete class defines the loader for the computed region
specific CWD and rare allele data using UTSW results into the table
B<LK_REGION_CWD_ALLELE>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::RegionCwdUTSW(tools, error_mgr)>

This is the constructor for the class.

=head2 B<generate>

This method generates the bcp file for loading the table
B<LK_REGION_CWD_ALLELE>.

=cut
