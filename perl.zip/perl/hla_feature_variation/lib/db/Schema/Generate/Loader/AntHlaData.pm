package db::Schema::Generate::Loader::AntHlaData;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::ErrMsgs;
use util::PathSpecifics;

use anthonyNolan::Hla;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields qw (
  allele_id
  gcodes_file
  hla_file
  nomenclature_file
  pcodes_file
  taxon_id
);

################################################################################
#
#				Private Constants
#
################################################################################
###
### code types
###
sub G_CODE { return 'G'; }
sub P_CODE { return 'P'; }
###
### Error Category
###
sub ERR_CAT { return util::ErrMsgs::PROG_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub hlaTables {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;
  return [
    db::MhcTypes::ALIGNMENT_SEQ_TABLE,
    db::MhcTypes::ALLELE_ALIGNMENT_TABLE,
    db::MhcTypes::CDS_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::FEATURE_ALLELE_TABLE,
    db::MhcTypes::GENE_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::MOLECULE_SEQ_TABLE,
    db::MhcTypes::PUBMED_REFERENCE_TABLE,
    db::MhcTypes::REFERENCE_ALLELE_TABLE,
    db::MhcTypes::SEQ_BIOSOURCE_TABLE,
    db::MhcTypes::SEQ_EVIDENCE_TABLE,
    db::MhcTypes::VARIANT_MAP_TABLE,
    db::MhcTypes::VARIANT_SEQ_TABLE,
    db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::MHC_HLA_ALLELE_FREQ_MAP_TABLE,
    db::MhcTypes::REPLACEMENT_ALLELE_TABLE,
    db::MhcTypes::ALLELE_NOMENCLATURE_TABLE,
    db::MhcTypes::ALLELE_TABLE,
  ];
}

sub hlaPredicates {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;

  return {
    &db::MhcTypes::ALIGNMENT_SEQ_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::ALLELE_ALIGNMENT_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::CDS_SEQ_STRUCTURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::FEATURE_ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::GENE_SEQ_STRUCTURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::MOLECULE_SEQ_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::PUBMED_REFERENCE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::REFERENCE_ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::SEQ_BIOSOURCE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::SEQ_EVIDENCE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::VARIANT_MAP_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::VARIANT_SEQ_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::MHC_HLA_ALLELE_FREQ_MAP_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::REPLACEMENT_ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::ALLELE_NOMENCLATURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

    &db::MhcTypes::ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

  };
}

sub _generateCodes {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;
  my ( $code_type, $file ) = @_;
  ###
  ### Initialization
  ###
  my $code_map = {};
  $file = getPath($file);
  return $code_map if ( !-e $file || !-f $file || !-r $file );
  ###
  ### Now open and process the file
  ###
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ 'open file', 'text file', $file, 'unable to open file' ],
    !$fh->open( $file, "<" )
  );
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    next if ( $line !~ /\*/ || $line !~ /$code_type$/ );
    my @row          = split( /;/, $line );
    my $locus_prefix = $row[0];
    my @alleles      = split( /\//, $row[1] );
    my $code         = $row[2];
    foreach my $allele (@alleles) {
      $code_map->{ $locus_prefix . $allele } = $locus_prefix . $code;
    }
  }
  $fh->close;

  return $code_map;
}

sub _generateNomenclatureMap {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;
  ###
  ### Initialization
  ###
  my $map  = {};
  my $file = getPath( $this->{nomenclature_file} );
  return $map if ( !-e $file || !-f $file || !-r $file );
  ###
  ### Now open and process the file
  ###
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 1,
    [ 'open file', 'text file', $file, 'unable to open file' ],
    !$fh->open( $file, "<" )
  );
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    next if ( $line !~ /\*/ || $line =~ /None/ );
    my @row = split( / +/, $line );
    $map->{ $row[1] } = $row[0];
  }
  $fh->close;

  return $map;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $tools, $hla_file, $allele_id, $gcodes_file, $pcodes_file,
    $nomenclature_file, $error_mgr )
    = @_;
  my db::Schema::Generate::Loader::AntHlaData $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{allele_id}         = $allele_id;
  $this->{gcodes_file}       = $gcodes_file;
  $this->{hla_file}          = $hla_file;
  $this->{nomenclature_file} = $nomenclature_file;
  $this->{pcodes_file}       = $pcodes_file;
  $this->{taxon_id}          = undef;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;
  $this->{loader}->partialDelete( $this->hlaTables, $this->hlaPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::AntHlaData $this = shift;

  my $gcode_map = $this->_generateCodes( G_CODE, $this->{gcodes_file} );
  my $pcode_map = $this->_generateCodes( P_CODE, $this->{pcodes_file} );
  my $nomenclature_map = $this->_generateNomenclatureMap;

  my $hla =
    new anthonyNolan::Hla( $this->{hla_file}, $this->{allele_id}, $gcode_map,
    $pcode_map, $nomenclature_map, $this, $this->{tools}, $this->{error_mgr} );
  $hla->processFile;
  $this->{taxon_id} = $hla->taxonId;
  $this->{error_mgr}->printHeader( "Alleles Processed\n"
      . "  processed = "
      . ( $hla->alleleId - $this->{allele_id} ) . "\n"
      . "  taxon_id  = "
      . $this->{taxon_id} );
  ###
  ### Report new ancillary ids
  ###
  $this->{error_mgr}->printHeader("New Ids Generated");
  my %evidence    = $hla->evidenceAuthority;
  my @authorities = keys %{ $evidence{names} };
  if ( @authorities > 0 ) {
    $this->{error_mgr}
      ->printError( "New Evidence Authorities Data", util::Constants::TRUE );
    foreach my $authority (@authorities) {
      $this->{error_mgr}->printError(
        join( util::Constants::TAB, $evidence{names}->{$authority}, $authority
        ),
        util::Constants::TRUE
      );
    }
  }

  my %mhc_loci    = $hla->mhcLocus;
  my @locus_names = keys %{ $mhc_loci{names} };
  if ( @locus_names > 0 ) {
    $this->{error_mgr}
      ->printError( "New Mhc Loci Data", util::Constants::TRUE );
    foreach my $locus_name (@locus_names) {
      $this->{error_mgr}->printError(
        join( util::Constants::TAB,
          $mhc_loci{names}->{$locus_name}, $locus_name
        ),
        util::Constants::TRUE
      );
    }
  }
  ###
  ### Die if there is a controlled vocabulary error
  ###
  $this->closeBcpHandles if ( @authorities > 0 || @locus_names > 0 );
  $this->{error_mgr}->hardDieOnError(
    ERR_CAT, 1,
    [ "controlled vocabularies", "missing data", "see error messages above" ],
    @authorities > 0 || @locus_names > 0
  );
}

################################################################################

1;

__END__

=head1 NAME

AntHlaData.pm

=head1 DESCRIPTION

This concrete class defines the loader for the Ant Hla Data for a
given release.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::AntHlaData(tools, hla_file, allele_id, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the Ant Hla data for a
release.

=cut
