package db::Schema::Generate::Loader::File::DbMhc;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use file::Struct::Bcp::Tab::DbMhcAlleleFreq;

use base 'db::Schema::Generate::Loader::File';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$) {
  my ( $that, $file, $tools, $error_mgr ) = @_;    
  my db::Schema::Generate::Loader::File::DbMhc $this =
    $that->SUPER::new( $file, $tools, $error_mgr );

  $this->addTable(db::MhcTypes::MHC_HLA_FREQ_TABLE);

  return $this;
}

sub readFile {
  my db::Schema::Generate::Loader::File::DbMhc $this = shift;
  $this->{reader} =
    new file::Struct::Bcp::Tab::DbMhcAlleleFreq( $this->{file},
    $this->{error_mgr} );
  $this->addComponentList( $this->{reader}->SUBJECT_ID );
}

################################################################################

1;

__END__

=head1 NAME

DbMhc.pm

=head1 DESCRIPTION

This concrete class defines the loader for loading the dbMhc allele
population data into the B<MHC_SEQ_VAR> schema table B<MHC_HLA_FREQ>.
This class is a subclass of L<db::Schema::Generate::Loader::File>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::File::DbMhc(file, tools, error_mgr)>

This is the constructor for the class.

=cut
