package db::Schema::Generate::Loader::NmdpCodes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use file::Struct::Bcp::Spaces::AlleleList;
use file::Struct::Bcp::Spaces::ChangedNames;
use file::Struct::Bcp::Tab::DeletedNames;
use file::Struct::Bcp::Tab::NmdpCodes;

use util::Statistics;

use base 'db::Schema::Generate::Loader';

use fields qw (
  count_cols
  counter
  deleted_alleles
  nmdp_files
  four_header
  hla_proteins
  loci
  process_cols
  reader
);

################################################################################
#
#				Constants
#
################################################################################
###
### Count Statistic
###
sub COUNT_COL   { return 'Code Type'; }
sub PROCESS_COL { return 'Processing Type'; }

sub COUNT_COLS { return [ 'Two Digit', 'Four Digit', ]; }

sub PROCESS_COLS {
  return [ 'All Found', 'Max Used', 'Found Singleton', 'None Found', ];
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _setFiles {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;

  my $tools         = $this->{tools};
  my $nmdpDirectory = $tools->getProperty('nmdpDirectory');
  my $files         = eval $tools->getProperty('nmdpFiles');
  foreach my $version ( keys %{ $this->{nmdp_files} } ) {
    $this->{nmdp_files}->{$version} =
      join( util::Constants::SLASH, $nmdpDirectory, $files->{$version} );
  }
}

sub _setData {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;

  my $tools           = $this->{tools};
  my $hla_proteins    = $this->{hla_proteins};
  my $deleted_alleles = $this->{deleted_alleles};

  my $alleleListFile     = $tools->getProperty('alleleListFile');
  my $changedNamesFile   = $tools->getProperty('changedNamesFile');
  my $deletedAllelesFile = $tools->getProperty('deletedAllelesFile');
  ###
  ### Read the contents of the release allele list
  ###
  my $loci_v3 = {};
  my $loci_v2 = {};
  my $allele_reader =
    new file::Struct::Bcp::Spaces::AlleleList( $alleleListFile,
    $this->{error_mgr} );
  foreach my $entity_id (
    $allele_reader->getEntityIds( $allele_reader->ALLELE_NAME ) )
  {
    my $entity =
      $allele_reader->getObjectByEntityId( $allele_reader->ALLELE_NAME,
      $entity_id );

    my $allele_name = $entity->{&db::MhcTypes::ALLELE_NAME_COL};
    $allele_name =~ /^(\w+)\*([0-9:]+)([A-Z]?)$/;

    my $locus  = $1;
    my $digits = $2;
    my $suffix = $3;
    my @comps  = split( /:/, $digits );

    $loci_v3->{$locus} = util::Constants::EMPTY_STR;
    my $locus_v2 = $locus;
    if ( $locus eq 'C' ) { $locus_v2 = 'Cw'; }
    $loci_v2->{$locus_v2} = util::Constants::EMPTY_STR;
    my $hla_protein_v3         = undef;
    my $hla_protein_v3_wsuffix = undef;
    my $hla_protein_v2         = undef;
    my $hla_protein_v2_wsuffix = undef;
    if ( $#comps >= 1 ) {
      $hla_protein_v3 = join( util::Constants::ASTERISK,
        $locus, join( util::Constants::COLON, $comps[0], $comps[1] ) );
      if ( defined($suffix) && $#comps == 1 ) {
        $hla_protein_v3_wsuffix = $hla_protein_v3 . $suffix;
      }
      if ( $comps[0] < 100 && $comps[1] < 100 ) {
        $hla_protein_v2 = join( util::Constants::ASTERISK,
          $locus_v2, join( util::Constants::EMPTY_STR, $comps[0], $comps[1] ) );
        if ( defined($hla_protein_v3_wsuffix) ) {
          $hla_protein_v2_wsuffix = $hla_protein_v2 . $suffix;
        }
      }
    }

    if (
      defined($hla_protein_v3)
      && !defined(
        $hla_proteins->{&db::MhcTypes::IMGT_HLA_V3}->{$hla_protein_v3}
      )
      )
    {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V3}->{$hla_protein_v3} = $locus;

    }
    if ( defined($hla_protein_v3_wsuffix) ) {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V3}->{$hla_protein_v3_wsuffix} =
        $locus;
    }
    if (
      defined($hla_protein_v2)
      && !defined(
        $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein_v2}
      )
      )
    {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein_v2} =
        $locus_v2;

    }
    if ( defined($hla_protein_v2_wsuffix) ) {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein_v2_wsuffix} =
        $locus_v2;
    }
  }
  push(
    @{ $this->{loci}->{&db::MhcTypes::IMGT_HLA_V3} },
    sort keys %{$loci_v3}
  );
  ###
  ### Read the contents of the changed names file
  ###
  my $changed_reader =
    new file::Struct::Bcp::Spaces::ChangedNames( $changedNamesFile,
    $this->{error_mgr} );
  foreach my $entity_id (
    $changed_reader->getEntityIds( $changed_reader->ALLELE_NAME ) )
  {
    my $entity =
      $changed_reader->getObjectByEntityId( $changed_reader->ALLELE_NAME,
      $entity_id );

    my $allele_name = $entity->{&db::MhcTypes::OLD_ALLELE_NAME_COL};
    ###
    ### remove old 5 or 7 notation
    ###
    next
      if (
      ( $allele_name !~ /^MIC/ && $allele_name =~ /^\w+\*\d\d\d\d\d[A-Z]?$/ )
      || $allele_name =~ /^\w+\*\d\d\d\d\d\d\d[A-Z]?$/ );
    ###
    ### Now determine hla protein
    ###
    my $allele_pattern;
    if ( $allele_name =~ /^MIC/ ) {
      $allele_pattern = '^(\w+)\*(\d\d\d\d\d)([A-Z]?)';
    }
    else {
      $allele_pattern = '^(\w+)\*(\d\d\d\d)([A-Z]?)';
    }
    $allele_name =~ /$allele_pattern/;
    my $locus  = $1;
    my $digits = $2;
    my $suffix = $3;

    $loci_v2->{$locus} = util::Constants::EMPTY_STR;
    my $hla_protein = join( util::Constants::ASTERISK, $locus, $digits );
    my $hla_protein_wsuffix = undef;
    if ( defined($suffix) ) {
      $hla_protein_wsuffix = $hla_protein . $suffix;
    }

    if ( defined($hla_protein)
      && !defined( $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein} )
      )
    {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein} = $locus;

    }
    if ( defined($hla_protein_wsuffix) ) {
      $hla_proteins->{&db::MhcTypes::IMGT_HLA_V2}->{$hla_protein_wsuffix} =
        $locus;
    }
  }
  push(
    @{ $this->{loci}->{&db::MhcTypes::IMGT_HLA_V2} },
    sort keys %{$loci_v2}
  );
  ###
  ### Read the contents of the deleted names file
  ###
  my $delete_reader =
    new file::Struct::Bcp::Tab::DeletedNames( $deletedAllelesFile,
    $this->{error_mgr} );
  foreach my $entity_id (
    $delete_reader->getEntityIds( $delete_reader->ALLELE_NAME ) )
  {
    my $entity =
      $delete_reader->getObjectByEntityId( $delete_reader->ALLELE_NAME,
      $entity_id );
    my $deleted_name = $entity->{&db::MhcTypes::DELETED_ALLELE_NAME_COL};
    ###
    ### assign hla proteins to appropriate version
    ###
    my $version = undef;
    my $locus   = undef;
    if ( $deleted_name =~ /:/ ) {
      $version = db::MhcTypes::IMGT_HLA_V3;
      $deleted_name =~ /^(\w+)\*([0-9:]+)[A-Z]?$/;
      $locus = $1;
      my $digits = $2;
      my @comps = split( /:/, $digits );
      next if ( @comps != 2 );
    }
    else {
      next if ( $deleted_name !~ /^(\w+)\*\d\d\d\d[A-Z]?$/ );
      $version = db::MhcTypes::IMGT_HLA_V2;
      $locus   = $1;
    }
    ###
    ### keep the deleted name 'as-is'
    ###
    $deleted_alleles->{$version}->{$deleted_name} = $locus;
  }
}

sub _correctHlaProteinSubType {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  my ( $version, $nmdp_code, @comps ) = @_;

  my $hla_proteins    = $this->{hla_proteins}->{$version};
  my $deleted_alleles = $this->{deleted_alleles}->{$version};
  ###
  ### First:  initialize locus counts
  ###
  my $locus_counts = {};
  foreach my $locus ( @{ $this->{loci}->{$version} } ) {
    $locus_counts->{$locus} = 0;
  }
  foreach my $locus ( @{ $this->{loci}->{$version} } ) {
    foreach my $comp (@comps) {
      my $name = $locus . '*' . $comp;
      $locus_counts->{$locus}++
        if ( defined( $hla_proteins->{$name} )
        || defined( $deleted_alleles->{$name} ) );
    }
  }
  ###
  ### Second:  Determine the common locus
  ###
  my $common_locus  = undef;
  my $maximum_locus = undef;
  foreach my $locus ( @{ $this->{loci}->{$version} } ) {
    if ( !defined($common_locus)
      && $locus_counts->{$locus} == scalar @comps )
    {
      $common_locus = $locus;
    }
    if ( !defined($maximum_locus) ) {
      $maximum_locus = $locus;
    }
    elsif ( $locus_counts->{$locus} > $locus_counts->{$maximum_locus} ) {
      $maximum_locus = $locus;
    }
  }
  if ( $locus_counts->{$maximum_locus} == 0 ) { $maximum_locus = undef; }
  ###
  ### Third:  This pass determines the kept and not kept column
  ###
  my @keep_comps    = ();
  my @no_keep_comps = ();
  if ( defined($common_locus) ) {
    @keep_comps = @comps;
  }
  elsif ( defined($maximum_locus) ) {
    foreach my $comp (@comps) {
      my $name = $maximum_locus . '*' . $comp;
      if ( defined( $hla_proteins->{$name} )
        || defined( $deleted_alleles->{$name} ) )
      {
        push( @keep_comps, $comp );
      }
      else {
        push( @no_keep_comps, $comp );
      }
    }
  }
  else {
    @no_keep_comps = @comps;
  }
  ###
  ### Fourth:  Determine Processing Mechanism
  ###
  my $process_col = undef;
  if ( !defined($common_locus) ) {
    if ( defined($maximum_locus) ) {
      if ( $locus_counts->{$maximum_locus} == 1 ) {
        $process_col = $this->{process_cols}->[2];
        $this->{error_mgr}->printWarning(
          "Found Singleton\n"
            . "  nmdp code    = $nmdp_code\n"
            . "  comps        = "
            . join( '/', @comps ) . "\n"
            . "  num comps    = "
            . scalar @comps . "\n"
            . "  max comps    = "
            . $locus_counts->{$maximum_locus} . "\n"
            . "  diff comps   = "
            . ( scalar @comps - $locus_counts->{$maximum_locus} ) . "\n"
            . "  max locus    = $maximum_locus",
          util::Constants::TRUE
        );
      }
      else {
        $process_col = $this->{process_cols}->[1];
        my @count_loci = keys %{$locus_counts};
        foreach my $locus (@count_loci) {
          next if ( $locus_counts->{$locus} > 0 );
          delete( $locus_counts->{$locus} );
        }
        $this->{error_mgr}->printWarning(
          "Using the maximum locus since NOT\n"
            . "all HLA proteins found in a single locus\n"
            . "  nmdp code    = $nmdp_code\n"
            . "  comps        = "
            . join( '/', @comps ) . "\n"
            . "  num comps    = "
            . scalar @comps . "\n"
            . "  keep comps   = "
            . join( '/', @keep_comps ) . "\n"
            . "  nokeep comps = "
            . join( '/', @no_keep_comps ) . "\n"
            . "  max comps    = "
            . $locus_counts->{$maximum_locus} . "\n"
            . "  diff comps   = "
            . ( scalar @comps - $locus_counts->{$maximum_locus} ) . "\n"
            . "  max locus    = $maximum_locus\n"
            . "  locus counts = ("
            . join( util::Constants::COMMA_SEPARATOR, %{$locus_counts} ) . ")",
          util::Constants::TRUE
        );
      }
    }
    else {
      ###
      ### No data found!!
      ###
      $process_col = $this->{process_cols}->[3];
      $this->{error_mgr}->printError(
        "!!!!!No locus found!!!!!\n"
          . "  nmdp code    = $nmdp_code\n"
          . "  comps        = "
          . join( '/', @comps ) . "\n"
          . "  num comps    = "
          . scalar @comps . "\n"
          . "  keep comps   = "
          . join( '/', @keep_comps ) . "\n"
          . "  nokeep comps = "
          . join( '/', @no_keep_comps ) . "\n"
          . "  locus counts = ("
          . join( util::Constants::COMMA_SEPARATOR, %{$locus_counts} ) . ")",
        util::Constants::TRUE
      );
    }
  }
  else {
    $process_col = $this->{process_cols}->[0];
  }
  ###
  ### Fifth:  Count the processing and return components
  ###
  $this->{counter}->increment( COUNT_COL, $this->{count_cols}->[1],
    PROCESS_COL, $process_col );

  return @keep_comps;
}

sub _isHlaProteinField {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  my ( $version, $subtype ) = @_;

  my @comps = split( /\//, $subtype );
  foreach my $comp (@comps) {
    $comp =~ /^(\d+)/;
    $comp = $1;
    my $len = length($comp);
    return util::Constants::FALSE
      if ( ( $version == db::MhcTypes::IMGT_HLA_V3 && $len != 2 && $len != 3 )
      || ( $version == db::MhcTypes::IMGT_HLA_V2 && $len != 2 ) );
  }

  return util::Constants::TRUE;

}

sub _correctSubtype {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  my ( $version, $nmdp_code, $subtype ) = @_;

  my @comps = split( /\//, $subtype );
  if ( $this->_isHlaProteinField( $version, $subtype ) ) {
    $this->{counter}->increment(
      COUNT_COL,   $this->{count_cols}->[0],
      PROCESS_COL, $this->{process_cols}->[0]
    );
  }
  else {
    @comps = $this->_correctHlaProteinSubType( $version, $nmdp_code, @comps );
  }
  return join( util::Constants::SLASH, @comps );
}

sub _setStatistics {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  my ($version) = @_;

  $this->{counter} = new util::Statistics(
    "Process Code Determination For IMGT/HLA Version $version", undef,
    $this->{error_mgr},                                         COUNT_COL,
    $this->{count_cols},                                        PROCESS_COL,
    $this->{process_cols}
  );
  $this->{counter}->setShowTotal(util::Constants::TRUE);
  $this->{counter}->setCountColName('Number of Codes');
}

sub _readFile {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  my ($version) = @_;

  my $reader =
    new file::Struct::Bcp::Tab::NmdpCodes( $this->{nmdp_files}->{$version},
    $this->{error_mgr} );

  $this->_setStatistics($version);
  foreach my $entity_id ( $reader->getEntityIds( $reader->NMDP_CODE ) ) {
    my $entity = $reader->getObjectByEntityId( $reader->NMDP_CODE, $entity_id );
    $entity->{&db::MhcTypes::SUBTYPE_COL} = $this->_correctSubtype(
      $version,
      $entity->{&db::MhcTypes::NMDP_CODE_COL},
      $entity->{&db::MhcTypes::SUBTYPE_COL}
    );
  }
  $this->{counter}->print;
  $this->{reader} = $reader;
}

sub _getEntities {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;

  my $reader         = $this->{reader};
  my $component_list = $reader->NMDP_CODE;
  my @entities       = ();
  foreach my $entity_id ( $reader->getEntityIds($component_list) ) {
    push( @entities,
      $reader->getObjectByEntityId( $component_list, $entity_id ) );
  }
  return @entities;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::NmdpCodes $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->addTable(db::MhcTypes::LK_NMDP_CODE_TABLE);

  $this->{count_cols} = COUNT_COLS;
  $this->{counter}    = undef;
  $this->{nmdp_files} = {
    &db::MhcTypes::IMGT_HLA_V2 => undef,
    &db::MhcTypes::IMGT_HLA_V3 => undef
  };
  $this->{process_cols} = PROCESS_COLS;
  $this->{deleted_alleles} =
    { &db::MhcTypes::IMGT_HLA_V2 => {}, &db::MhcTypes::IMGT_HLA_V3 => {} };
  $this->{hla_proteins} =
    { &db::MhcTypes::IMGT_HLA_V2 => {}, &db::MhcTypes::IMGT_HLA_V3 => {} };
  $this->{loci} =
    { &db::MhcTypes::IMGT_HLA_V2 => [], &db::MhcTypes::IMGT_HLA_V3 => [] };

  $this->_setFiles;
  $this->_setData;

  return $this;
}

sub generate {
  my db::Schema::Generate::Loader::NmdpCodes $this = shift;
  ###
  ### Determine the load time from the start time
  ###
  my $tools = $this->{tools};
  ###
  ### now read the files and generate the table
  ###
  my $table = $this->{tables}->[0];
  foreach my $version ( sort keys %{ $this->{nmdp_files} } ) {
    $this->_readFile($version);
    foreach my $entity ( $this->_getEntities ) {
      my $row = $this->getRowHash($table);
      ###
      ### get data
      ###
      foreach my $col ( keys %{$row} ) {
        next if ( util::Constants::EMPTY_LINE( $entity->{$col} ) );
        $row->{$col} = $entity->{$col};
      }
      $row->{&db::MhcTypes::IMGT_HLA_VERSION_COL}  = $version;
      $row->{&db::MhcTypes::LAST_UPDATED_BY_COL}   = $tools->getUserName;
      $row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} = $this->getLoadTime;
      $this->generateRow( $table, $row );
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

NmdpCodes.pm

=head1 DESCRIPTION

This concrete class defines the class for generating the bcp-file for
the nmdp codes lookup table.  It is a subclass of
L<db::Schema::Generate::Loader>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::NmdpCodes(tools, error_mgr)>

This is the constructor for the class.

=head2 B<readFile>

This method reads the source file into the object.

=cut
