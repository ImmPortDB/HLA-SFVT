package db::Schema::Generate::Loader::File;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields
  qw (
  component_list
  file
  reader
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _getEntities {
  my db::Schema::Generate::Loader::File $this = shift;

  my $reader         = $this->{reader};
  my $component_list = $this->{component_list};
  my @entities       = ();
  foreach my $entity_id ( $reader->getEntityIds($component_list) ) {
    push( @entities,
      $reader->getObjectByEntityId( $component_list, $entity_id ) );
  }
  return @entities;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::File $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{component_list} = undef;
  $this->{file}           = $file;
  $this->{reader}         = undef;

  return $this;
}

sub addComponentList {
  my db::Schema::Generate::Loader::File $this = shift;
  my ($component_list) = @_;
  $this->{component_list} = $component_list;
}

sub readFile {
  my db::Schema::Generate::Loader::File $this = shift;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}->printDebug(
    "Abstract method db::Schema::Generate::Loader::File::readFile");
}

sub generate {
  my db::Schema::Generate::Loader::File $this = shift;
  ###
  ### Determine the load time from the start time
  ###
  my $tools = $this->{tools};
  ###
  ### now read the file and generate the table
  ###
  $this->readFile;
  my $table = $this->{tables}->[0];
  foreach my $entity ( $this->_getEntities ) {
    my $row = $this->getRowHash($table);
    ###
    ### get data
    ###
    foreach my $col ( keys %{$row} ) {
      next if ( util::Constants::EMPTY_LINE( $entity->{$col} ) );
      $row->{$col} = $entity->{$col};
    }
    ###
    ### Get special data if they are defined for the table
    ###
    ### 1.  load_time
    ### 2.  username
    ###
    if ( exists( $row->{&db::MhcTypes::LAST_UPDATED_BY_COL} ) ) {
      $row->{&db::MhcTypes::LAST_UPDATED_BY_COL} = $tools->getUserName;
    }
    if ( exists( $row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} ) ) {
      $row->{&db::MhcTypes::DATE_LAST_UPDATED_COL} = $this->getLoadTime;
    }
    ###
    ### Generate row
    ###
    $this->generateRow( $table, $row );
  }
}

################################################################################

1;

__END__

=head1 NAME

File.pm

=head1 DESCRIPTION

This abstract class defines the class for generating the bcp-file for
a singleton table and for loading it.  This class requires the following
abstract method to be implemented by the subclass, B<readFile>.  The
constructor of a subclass must add the table that it will be loading.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::File(file, tools, error_mgr)>

This is the constructor for the class.

=head2 B<addComponentList(component_list)>

This method sets the component list that will be used with the reader
to get the file-data for loading.  Normally, L<"readFile"> will the
the component list since the subclass will know what list to use.

=head2 B<readFile>

This abstract method reads the source file into the B<reader> object
(a subclass of L<file::Struct>) and set the B<component_list>
attribute using L<"addComponentList(component_list)"> from the reader
for getting the entities from the reader.

=head2 B<generate>

This method implements the generation of the bcp-file for a single
table that was add by the constructor of the subclass using the data
in the the file.  The method uses the method L<"readFile"> to obtain
the file data.  This method assigns values for the following columns
if they are defined in the table.

  db::MhcTypes::LAST_UPDATED_BY_COL
  db::MhcTypes::DATE_LAST_UPDATED_COL

=cut
