package db::Schema::Generate::Loader::HlaFeatureVariation;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use hla::FeatureVariant;
use hla::HlaTypes;

use db::MhcTypes;

use file::Chunk::Excel;

use base 'db::Schema::Generate::Loader';

use fields qw (
  locus_ids
  seq_type
  taxon_id
  variant_file
  variant_id
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _hlaFeatureVariationTables {
  my db::Schema::Generate::Loader::HlaFeatureVariation $this = shift;

  return [
    db::MhcTypes::VARIANT_2_ALLELE_TABLE,  db::MhcTypes::VARIANT_MAP_TABLE,
    db::MhcTypes::VARIANT_REFERENCE_TABLE, db::MhcTypes::VARIANT_TYPE_TABLE,
  ];
}

sub _hlaFeatureVariationPredicates {
  my db::Schema::Generate::Loader::HlaFeatureVariation $this = shift;

  my $locus_id_list =
      util::Constants::OPEN_PAREN
    . join( util::Constants::COMMA_SEPARATOR, @{ $this->{locus_ids} } )
    . util::Constants::CLOSE_PAREN;

  return {
    &db::MhcTypes::VARIANT_2_ALLELE_TABLE => {
      qarray => [],
      pred   => "
variant_id in
  (select variant_id
   from   variant_type vt,
          feature      fn
   where  fn.locus_id   in $locus_id_list
   and    fn.feature_id =  vt.feature_id)
",
    },

    &db::MhcTypes::VARIANT_MAP_TABLE => {
      qarray => [],
      pred   => "
variant_id in
  (select variant_id
   from   variant_type vt,
          feature      fn
   where  fn.locus_id   in $locus_id_list
   and    fn.feature_id  = vt.feature_id)
",
    },

    &db::MhcTypes::VARIANT_REFERENCE_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },

    &db::MhcTypes::VARIANT_TYPE_TABLE => {
      qarray => [],
      pred   => "
feature_id in
  (select feature_id
   from   feature
   where  locus_id in $locus_id_list)
",
    },
  };
}

sub _getLocusName {
  my db::Schema::Generate::Loader::HlaFeatureVariation $this = shift;
  my ($entities) = @_;

  my $locus_name = undef;
  foreach my $entity ( @{$entities} ) {
    if ( $entity->{feature_number} =~ /^Hsa_(.+)_SF\d+$/ ) {
      $locus_name = $1;
      last;
    }
  }
  return $locus_name;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$) {
  my ( $that, $tools, $variant_file, $taxon_id, $seq_type, $variant_id,
    $error_mgr )
    = @_;
  my db::Schema::Generate::Loader::HlaFeatureVariation $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{variant_file} = $variant_file;
  $this->{locus_ids}    = undef;
  $this->{seq_type}     = $seq_type;
  $this->{taxon_id}     = $taxon_id;
  $this->{variant_id}   = $variant_id;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::HlaFeatureVariation $this = shift;

  $this->{loader}->partialDelete( $this->_hlaFeatureVariationTables,
    $this->_hlaFeatureVariationPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::HlaFeatureVariation $this = shift;

  $this->{locus_ids} = [];
  ###
  ### Get all sequence features for all loci in file
  ###
  my $reader = new file::Chunk::Excel( undef, hla::HlaTypes::VARIANT_FILE_ORD,
    $this->{error_mgr} );
  $reader->setSourceFile( $this->{variant_file} );
  $reader->readExcelFile;
  ###
  ### for each worksheet
  ###
  foreach my $worksheet_num ( $reader->getWorksheetNums ) {
    my @entities   = $reader->getWorksheet($worksheet_num);
    my $locus_name = $this->_getLocusName( \@entities );
    next if ( !defined($locus_name) );
    $this->{error_mgr}->printHeader( "Proccessing Worksheet\n"
        . "  worksheet  = $worksheet_num\n"
        . "  locus_name = $locus_name" );
    my $locus_id =
      db::MhcTypes::getId( db::MhcTypes::MHC_LOCUS_TABLE, $locus_name,
      $this->{taxon_id} );
    push( @{ $this->{locus_ids} }, $locus_id );
    my $hla =
      new hla::FeatureVariant( $locus_name, $this->{taxon_id},
      $this->{seq_type}, $this, $this->{variant_id}, $this->{tools}->getSession,
      $this->{error_mgr} );
    $hla->processFeatures( \@entities );
    $this->{variant_id} = $hla->variantId;
  }
}

################################################################################

1;

__END__

=head1 NAME

HlaFeatureVariation.pm

=head1 DESCRIPTION

This concrete class defines the loader for the HLA Feature Variation
data for a given locus.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::HlaFeatureVariation(tools, locus_name, taxon_id, seq_type, variant_id, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the HLA Feature Variation data
for a given locus.

=cut
