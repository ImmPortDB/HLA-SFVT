package db::Schema::Generate::Loader::AntAlignData;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use anthonyNolan::Align;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields qw (
  taxon_id
  alignment_directory
  doa_prot_file_start
);

################################################################################
#
#				Private Methods
#
################################################################################

sub variantSeqTables {
  my db::Schema::Generate::Loader::AntAlignData $this = shift;
  return [
    db::MhcTypes::VARIANT_SEQ_TABLE,
    db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE,
    db::MhcTypes::REFERENCE_ALLELE_TABLE
  ];
}

sub variantSeqPredicates {
  my db::Schema::Generate::Loader::AntAlignData $this = shift;

  return {
    &db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::REFERENCE_ALLELE_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
locus_id in
  (select locus_id
   from   mhc_locus
   where  taxonomy_id = ?)
",
    },

    &db::MhcTypes::VARIANT_SEQ_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },
  };
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $tools, $taxon_id, $alignment_directory, $doa_prot_file_start,
    $error_mgr )
    = @_;
  my db::Schema::Generate::Loader::AntAlignData $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{taxon_id}            = $taxon_id;
  $this->{alignment_directory} = $alignment_directory;
  $this->{doa_prot_file_start} = $doa_prot_file_start;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::AntAlignData $this = shift;
  $this->{loader}
    ->partialDelete( $this->variantSeqTables, $this->variantSeqPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::AntAlignData $this = shift;
  my $align = new anthonyNolan::Align(
    $this->{taxon_id},
    $this->{alignment_directory},
    $this->{doa_prot_file_start},
    $this, $this->{tools}->getSession,
    $this->{error_mgr}
  );
  $align->processFiles;
}

################################################################################

1;

__END__

=head1 NAME

AntAlignData.pm

=head1 DESCRIPTION

This concrete class defines the loader for the Ant Alignment Data for
a given release.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::AntAlignData(tools, taxon_id, alignment_directory, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the Ant Alignment data for a release.

=cut
