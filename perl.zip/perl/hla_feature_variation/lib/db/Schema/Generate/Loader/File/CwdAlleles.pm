package db::Schema::Generate::Loader::File::CwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use file::Struct::Bcp::Tab::Cwd;

use base 'db::Schema::Generate::Loader::File';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $tools, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::File::CwdAlleles $this =
    $that->SUPER::new( $file, $tools, $error_mgr );

  $this->addTable(db::MhcTypes::LK_CWD_ALLELE_TABLE);

  return $this;
}

sub readFile {
  my db::Schema::Generate::Loader::File::CwdAlleles $this = shift;
  $this->{reader} =
    new file::Struct::Bcp::Tab::Cwd( $this->{file}, $this->{error_mgr} );
  $this->addComponentList( $this->{reader}->ALLELE_NAME );
}

################################################################################

1;

__END__

=head1 NAME

CwdAlleles.pm

=head1 DESCRIPTION

This concrete class defines the class for generating the bcp-file for
the cwd allele names lookup table.  It is a subclass of
L<db::Schema::Generate::Loader::File>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::File::CwdAlleles(file, tools, error_mgr)>

This is the constructor for the class.

=head2 B<readFile>

This method reads the source file into the object.

=cut
