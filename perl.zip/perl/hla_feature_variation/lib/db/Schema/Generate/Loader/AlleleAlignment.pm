package db::Schema::Generate::Loader::AlleleAlignment;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use anthonyNolan::AlleleAlignment;

use db::MhcTypes;

use base 'db::Schema::Generate::Loader';

use fields
  qw (
  taxon_id
);

################################################################################
#
#				Private Methods
#
################################################################################

sub alleleAlignmentTables {
  my db::Schema::Generate::Loader::AlleleAlignment $this = shift;
  return [db::MhcTypes::ALLELE_ALIGNMENT_TABLE];
}

sub alleleAlignmentPredicates {
  my db::Schema::Generate::Loader::AlleleAlignment $this = shift;

  return {
    &db::MhcTypes::ALLELE_ALIGNMENT_TABLE => {
      qarray => [ $this->{taxon_id} ],
      pred   => "
allele_id in
  (select alle.allele_id
   from   allele    alle,
          mhc_locus mhcl
   where  mhcl.locus_id    = alle.locus_id
   and    mhcl.taxonomy_id = ?)
",
    },

  };
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tools, $taxon_id, $error_mgr ) = @_;
  my db::Schema::Generate::Loader::AlleleAlignment $this =
    $that->SUPER::new( $tools, $error_mgr );

  $this->{taxon_id} = $taxon_id;

  return $this;
}

sub delete {
  my db::Schema::Generate::Loader::AlleleAlignment $this = shift;
  $this->{loader}->partialDelete( $this->alleleAlignmentTables,
    $this->alleleAlignmentPredicates );
}

sub generate {
  my db::Schema::Generate::Loader::AlleleAlignment $this = shift;
  my $align =
    new anthonyNolan::AlleleAlignment( $this->{taxon_id}, $this,
    $this->{tools}->getSession,
    $this->{error_mgr} );
  $align->processAlignments;
}

################################################################################

1;

__END__

=head1 NAME

AlleleAlignment.pm

=head1 DESCRIPTION

This concrete class defines the loader for the Ant Allele Alignment
Data for a given release.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new db::Schema::Generate::Loader::AlleleAlignment(tools, taxon_id, error_mgr)>

This is the constructor for the class.

=head2 B<delete>

This method provides the partial delete of tables that are loaded and other
associated tables.

=head2 B<generate>

This method generates the bcp-files for the Ant Allele Alignment data
for a release.

=cut
