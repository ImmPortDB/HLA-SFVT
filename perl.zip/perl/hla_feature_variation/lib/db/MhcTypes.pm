package db::MhcTypes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::FileTime;

use db::Types;

################################################################################
#
#			      Private Global Data
#
################################################################################

my $_GLOBALS_ = {
  infinite_time       => 99999999999,
  mappings            => undef,
  queries             => undef,
  mhc_loci            => {},
  reference_alleles   => {},
  allele_names        => {},
  variant_seq_structs => {},
};

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
###  Sequence Variation Tables
###
sub ALIGNMENT_SEQ_TABLE         { return 'ALIGNMENT_SEQ'; }
sub ALIGNMENT_TYPE_TABLE        { return 'ALIGNMENT_TYPE'; }
sub ALIGNMENT_VIEW_TYPE_TABLE   { return 'ALIGNMENT_VIEW_TYPE'; }
sub ALLELE_ALIGNMENT_TABLE      { return 'ALLELE_ALIGNMENT'; }
sub ALLELE_NOMENCLATURE_TABLE   { return 'ALLELE_NOMENCLATURE'; }
sub ALLELE_TABLE                { return 'ALLELE'; }
sub CDS_SEQ_STRUCTURE_TABLE     { return 'CDS_SEQ_STRUCTURE'; }
sub CDS_STRUCTURE_TYPE_TABLE    { return 'CDS_STRUCTURE_TYPE'; }
sub EVIDENCE_AUTHORITY_TABLE    { return 'EVIDENCE_AUTHORITY'; }
sub FEATURE_2_NAME_TABLE        { return 'FEATURE_2_NAME'; }
sub FEATURE_2_PUBMED_TABLE      { return 'FEATURE_2_PUBMED'; }
sub FEATURE_2_TYPE_TABLE        { return 'FEATURE_2_TYPE'; }
sub FEATURE_ALLELE_TABLE        { return 'FEATURE_ALLELE'; }
sub FEATURE_MAP_BASE1_TABLE     { return 'FEATURE_MAP_BASE1'; }
sub FEATURE_MAP_TABLE           { return 'FEATURE_MAP'; }
sub FEATURE_TABLE               { return 'FEATURE'; }
sub FEATURE_TYPE_TABLE          { return 'FEATURE_TYPE'; }
sub GENE_SEQ_STRUCTURE_TABLE    { return 'GENE_SEQ_STRUCTURE'; }
sub GENE_STRUCTURE_TYPE_TABLE   { return 'GENE_STRUCTURE_TYPE'; }
sub MHC_LOCUS_TABLE             { return 'MHC_LOCUS'; }
sub MOLECULE_SEQ_TABLE          { return 'MOLECULE_SEQ'; }
sub PDB_MAPPING_TABLE           { return 'PDB_MAPPING'; }
sub PDB_PROTEIN_TABLE           { return 'PDB_PROTEIN'; }
sub PDB_STRUCTURE_TABLE         { return 'PDB_STRUCTURE'; }
sub PUBMED_REFERENCE_TABLE      { return 'PUBMED_REFERENCE'; }
sub REFERENCE_ALLELE_TABLE      { return 'REFERENCE_ALLELE'; }
sub REPLACEMENT_ALLELE_TABLE    { return 'REPLACEMENT_ALLELE'; }
sub REPLACEMENT_TYPE_TABLE      { return 'REPLACEMENT_TYPE'; }
sub SEQ_BIOSOURCE_TABLE         { return 'SEQ_BIOSOURCE'; }
sub SEQ_EVIDENCE_TABLE          { return 'SEQ_EVIDENCE'; }
sub SEQ_TYPE_TABLE              { return 'SEQ_TYPE'; }
sub TAXONOMY_TABLE              { return 'TAXONOMY'; }
sub VARIANT_2_ALLELE_TABLE      { return 'VARIANT_2_ALLELE'; }
sub VARIANT_MAP_TABLE           { return 'VARIANT_MAP'; }
sub VARIANT_REFERENCE_TABLE     { return 'VARIANT_REFERENCE'; }
sub VARIANT_SEQ_STRUCTURE_TABLE { return 'VARIANT_SEQ_STRUCTURE'; }
sub VARIANT_SEQ_TABLE           { return 'VARIANT_SEQ'; }
sub VARIANT_TYPE_TABLE          { return 'VARIANT_TYPE'; }
###
### Sequence Variation Columns
###
sub ACCESSION_COL           { return 'accession'; }
sub ACC_VERSION_COL         { return 'acc_version'; }
sub ALIGNMENT_TYPE_ID_COL   { return 'alignment_type_id'; }
sub ALIGNMENT_TYPE_NAME_COL { return 'alignment_type_name'; }
sub ALIGN_LENGTH_COL        { return 'align_length'; }
sub ALIGN_SEQ_COL           { return 'align_seq'; }
sub ALLELE_GROUP_COL        { return 'allele_group'; }
sub ALLELE_ID_COL           { return 'allele_id'; }
sub ALLELE_NAME_COL         { return 'allele_name'; }
sub AMONG_CWD_COL           { return 'among_cwd'; }
sub ANNOT_UPDATE_DATE_COL   { return 'annot_update_date'; }
sub ANNOT_VERSION_COL       { return 'annot_version'; }
sub AUTHORITY_COL           { return 'authority'; }
sub AUTHORITY_ID_COL        { return 'authority_id'; }
sub AUTH_DESCR_COL          { return 'auth_descr'; }
sub CDS_POSITIONS_COL       { return 'cds_positions'; }
sub CDS_STRUCT_ID_COL       { return 'cds_struct_id'; }
sub CDS_STRUCT_NAME_COL     { return 'cds_struct_name'; }
sub CELL_LINE_COL           { return 'cell_line'; }
sub CHAIN_ID_COL            { return 'chain_id'; }
sub CHAIN_SUBMENU_COL       { return 'chain_submenu'; }
sub CLASS_COL               { return 'class'; }
sub CODON_START_COL         { return 'codon_start'; }
sub CODING_REGION_COL       { return 'coding_region'; }
sub COMMENTS_COL            { return 'comments'; }
sub COMMON_IN_US_COL        { return 'common_in_us'; }
sub CSS_END_POS_COL         { return 'css_end_pos'; }
sub CSS_START_POS_COL       { return 'css_start_pos'; }
sub CWD_ALLELE_COL          { return 'cwd_allele'; }
sub CWD_CATEGORY_COL        { return 'cwd_category'; }
sub DESCRIPTION_COL         { return 'description'; }
sub ENTREZ_GENE_ID_COL      { return 'entrez_gene_id'; }
sub FEATURE_ID_COL          { return 'feature_id'; }
sub FEATURE_NAMES_COL       { return 'feature_names'; }
sub FEATURE_NAME_COL        { return 'feature_name'; }
sub FEATURE_NUMBER_COL      { return 'feature_number'; }
sub FEATURE_TYPES_COL       { return 'feature_types'; }
sub FEATURE_TYPE_ID_COL     { return 'feature_type_id'; }
sub FM_END_POS_COL          { return 'fm_end_pos'; }
sub FM_START_POS_COL        { return 'fm_start_pos'; }
sub FT_NAME_COL             { return 'ft_name'; }
sub GAPPED_END_POS_COL      { return 'gapped_end_pos'; }
sub GAPPED_START_POS_COL    { return 'gapped_start_pos'; }
sub GCODE_NAME_COL          { return 'gcode_name'; }
sub GENE_STRUCT_ID_COL      { return 'gene_struct_id'; }
sub GENE_STRUCT_NAME_COL    { return 'gene_struct_name'; }
sub GSS_END_POS_COL         { return 'gss_end_pos'; }
sub GSS_START_POS_COL       { return 'gss_start_pos'; }
sub G_CODE_COL              { return 'g_code'; }
sub HLA_PROTEIN_COL         { return 'hla_protein'; }
sub IMGT_ACCESSION_COL      { return 'imgt_accession'; }
sub IMGT_HLA_G_CODE_COL     { return 'imgt_hla_g_code'; }
sub IMGT_HLA_P_CODE_COL     { return 'imgt_hla_p_code'; }
sub INTERVAL_NAME_COL       { return 'interval_name'; }
sub LOCUS_ID_COL            { return 'locus_id'; }
sub LOCUS_NAME_COL          { return 'locus_name'; }
sub MHC_LOCUS_NAME_COL      { return 'mhc_locus_name'; }
sub MHC_PROTEIN_COL         { return 'mhc_protein'; }
sub MOLECULE_COL            { return 'molecule'; }
sub MOL_LENGTH_COL          { return 'mol_length'; }
sub MOL_SEQ_COL             { return 'mol_seq'; }
sub MOTIF_COL               { return 'motif'; }
sub MOVE_COMMAND_COL        { return 'move_command'; }
sub NON_CODING_REGION_COL   { return 'non_coding_region'; }
sub NUM_POSITIONS_COL       { return 'num_positions'; }
sub OLD_ALLELE_NAME_COL     { return 'old_allele_name'; }
sub ORDER_ALLELE_NAME_COL   { return 'order_allele_name'; }
sub ORDER_NUM_COL           { return 'order_num'; }
sub PARTIAL_SEQ_COL         { return 'partial_seq'; }
sub PDB_END_COL             { return 'pdb_end'; }
sub PDB_ID_COL              { return 'pdb_id'; }
sub PDB_MAP_COL             { return 'pdb_map'; }
sub PDB_POSITIONS_COL       { return 'pdb_positions'; }
sub PDB_START_COL           { return 'pdb_start'; }
sub PEPTIDE_COL             { return 'peptide'; }
sub POSITIONS_COL           { return 'positions'; }
sub POS_MOTIF_COL           { return 'pos_motif'; }
sub PROTEIN_ACC_COL         { return 'protein_acc'; }
sub PROTEIN_END_COL         { return 'protein_end'; }
sub PROTEIN_START_COL       { return 'protein_start'; }
sub PSEUDO_GENE_COL         { return 'pseudo_gene'; }
sub PUBMED_ID_COL           { return 'pubmed_id'; }
sub PUBMED_TITLE_COL        { return 'pubmed_title'; }
sub RELATED_PUBS_COL        { return 'related_pubs'; }
sub RELEASE_VERSION_COL     { return 'release_version'; }
sub REPLACEMENT_ID_COL      { return 'replacement_id'; }
sub REPLACEMENT_NAME_COL    { return 'replacement_name'; }
sub SCIENTIFIC_NAME_COL     { return 'scientific_name'; }
sub SELECTED_CHAINS_COL     { return 'selected_chains'; }
sub SEQ_CREATE_DATE_COL     { return 'seq_create_date'; }
sub SEQ_DESCR_COL           { return 'seq_descr'; }
sub SEQ_NAME_COL            { return 'seq_name'; }
sub SEQ_TYPE_ID_COL         { return 'seq_type_id'; }
sub SEQ_UPDATE_DATE_COL     { return 'seq_update_date'; }
sub SEQ_VERSION_COL         { return 'seq_version'; }
sub SUFFIX_COL              { return 'suffix'; }
sub TAXONOMY_ID_COL         { return 'taxonomy_id'; }
sub TRANS_START_COL         { return 'trans_start'; }
sub TRANS_STOP_COL          { return 'trans_stop'; }
sub UNGAPPED_END_POS_COL    { return 'ungapped_end_pos'; }
sub UNGAPPED_START_POS_COL  { return 'ungapped_start_pos'; }
sub UNSELECTED_CHAINS_COL   { return 'unselected_chains'; }
sub VARIANT_ID_COL          { return 'variant_id'; }
sub VARIANT_TYPE_NAME_COL   { return 'variant_type_name'; }
sub VAR_LENGTH_COL          { return 'var_length'; }
sub VAR_MOTIF_COL           { return 'var_motif'; }
sub VAR_SEQ_COL             { return 'var_seq'; }
sub VIEW_TYPE_ID_COL        { return 'view_type_id'; }
sub VIEW_TYPE_NAME_COL      { return 'view_type_name'; }
sub VSS_START_POS_COL       { return 'vss_start_pos'; }
###
### Pypop HLA QC Pipeline Tables
###
sub LK_CANO_CWD_TABLE    { return 'LK_CANO_CWD'; }
sub LK_CHANGE_NAME_TABLE { return 'LK_CHANGE_NAME'; }
sub LK_CWD_ALLELE_TABLE  { return 'LK_CWD_ALLELE'; }
sub LK_DELETE_NAME_TABLE { return 'LK_DELETE_NAME'; }
sub LK_NMDP_CODE_TABLE   { return 'LK_NMDP_CODE'; }
###
### Pypop HLA QC Pipeline Columns
###
###sub ALLELE_NAME_COL         { return 'allele_name'; }
###sub G_CODE_COL              { return 'g_code'; }
###sub OLD_ALLELE_NAME_COL     { return 'old_allele_name'; }
sub CREATED_BY_COL          { return 'created_by'; }
sub DATE_CREATED_COL        { return 'date_created'; }
sub DATE_LAST_UPDATED_COL   { return 'date_last_updated'; }
sub DATE_OF_DELETION_COL    { return 'date_of_deletion'; }
sub DELETED_ALLELE_NAME_COL { return 'deleted_allele_name'; }
sub GROUP_CODE_COL          { return 'group_code'; }
sub HLA_PROTEIN_NAME_COL    { return 'hla_protein_name'; }
sub IDENTICAL_TO_COL        { return 'identical_to'; }
sub IMGT_HLA_VERSION_COL    { return 'imgt_hla_version'; }
sub LAST_UPDATED_BY_COL     { return 'last_updated_by'; }
sub NEW_ALLELE_NAME_COL     { return 'new_allele_name'; }
sub NMDP_CODE_COL           { return 'nmdp_code'; }
sub REASON_COL              { return 'reason'; }
sub SUBTYPE_COL             { return 'subtype'; }
sub SUGGESTED_NAME_COL      { return 'suggested_name'; }
###
### Allele Population Data Tables
###
sub LK_ALLELE_DATA_TYPE_TABLE     { return 'LK_ALLELE_DATA_TYPE'; }
sub LK_POP_AREA_TYPE_TABLE        { return 'LK_POP_AREA_TYPE'; }
sub LK_REGION_CWD_ALLELE_TABLE    { return 'LK_REGION_CWD_ALLELE'; }
sub MHC_HLA_ALLELE_FREQ_MAP_TABLE { return 'MHC_HLA_ALLELE_FREQ_MAP'; }
sub MHC_HLA_ALLELE_FREQ_TABLE     { return 'MHC_HLA_ALLELE_FREQ'; }
sub MHC_HLA_FREQ_TABLE            { return 'MHC_HLA_FREQ'; }
###
### Allele Population Data Columns
###
###sub ALLELE_ID_COL           { return 'allele_id'; }
###sub ALLELE_NAME_COL         { return 'allele_name'; }
###sub CWD_ALLELE_COL          { return 'cwd_allele'; }
###sub LOCUS_ID_COL            { return 'locus_id'; }
###sub LOCUS_NAME_COL          { return 'locus_name'; }
sub ALLELE_COUNT_COL     { return 'allele_count'; }
sub ALLELE_FREQ_COL      { return 'allele_freq'; }
sub ALLELE_TOTAL_COL     { return 'allele_total'; }
sub AUTHORS_COL          { return 'authors'; }
sub COLLECT_COL          { return 'collect'; }
sub COMPLEX_COL          { return 'complex'; }
sub DATA_DESCR_COL       { return 'data_descr'; }
sub DATA_NAME_COL        { return 'data_name'; }
sub DATA_TYPE_ID_COL     { return 'data_type_id'; }
sub ETHNIC_COL           { return 'ethnic'; }
sub HLA_A_1_COL          { return 'hla_a_1'; }
sub HLA_A_2_COL          { return 'hla_a_2'; }
sub HLA_B_1_COL          { return 'hla_b_1'; }
sub HLA_B_2_COL          { return 'hla_b_2'; }
sub HLA_C_1_COL          { return 'hla_c_1'; }
sub HLA_C_2_COL          { return 'hla_c_2'; }
sub HLA_DPA1_1_COL       { return 'hla_dpa1_1'; }
sub HLA_DPA1_2_COL       { return 'hla_dpa1_2'; }
sub HLA_DPB1_1_COL       { return 'hla_dpb1_1'; }
sub HLA_DPB1_2_COL       { return 'hla_dpb1_2'; }
sub HLA_DQA1_1_COL       { return 'hla_dqa1_1'; }
sub HLA_DQA1_2_COL       { return 'hla_dqa1_2'; }
sub HLA_DQB1_1_COL       { return 'hla_dqb1_1'; }
sub HLA_DQB1_2_COL       { return 'hla_dqb1_2'; }
sub HLA_DRB1_1_COL       { return 'hla_drb1_1'; }
sub HLA_DRB1_2_COL       { return 'hla_drb1_2'; }
sub LATITUDE_COL         { return 'latitude'; }
sub LONGITUDE_COL        { return 'longitude'; }
sub METHOD_COL           { return 'method'; }
sub MISMATCH1_COL        { return 'mismatch1'; }
sub MISMATCH2_COL        { return 'mismatch2'; }
sub MISMATCH3_COL        { return 'mismatch3'; }
sub MISMATCH4_COL        { return 'mismatch4'; }
sub MISMATCH5_COL        { return 'mismatch5'; }
sub MISMATCH6_COL        { return 'mismatch6'; }
sub MISMATCH7_COL        { return 'mismatch7'; }
sub MISMATCH8_COL        { return 'mismatch8'; }
sub MRWAF_FREQUENCY_COL  { return 'mrwaf_frequency'; }
sub POPULATION_COL       { return 'population'; }
sub POP_AREA_ABBRV_COL   { return 'pop_area_abbrv'; }
sub POP_AREA_COL         { return 'pop_area'; }
sub POP_AREA_DESCR_COL   { return 'pop_area_descr'; }
sub POP_AREA_ID_COL      { return 'pop_area_id'; }
sub POP_AREA_NAME_COL    { return 'pop_area_name'; }
sub REGION_FREQUENCY_COL { return 'region_frequency'; }
sub REPORT_COL           { return 'report'; }
sub SOURCE_COL           { return 'source'; }
sub SUBJECT_COL          { return 'subject'; }
###
### HLA Allele References (hla.allele.org) Columns
###
### sub ALLELE_ID_COL         { return 'allele_id'; }
### sub ALLELE_NAME_COL       { return 'allele_name'; }
### sub IMGT_ACCESSION_COL    { return 'imgt_accession'; }
### sub AUTHORS_COL           { return 'authors'; }
### sub PUBMED_ID_COL         { return 'pubmed_id'; }
### sub DATE_CREATED_COL      { return 'date_created'; }
### sub CREATED_BY_COL        { return 'created_by'; }
### sub DATE_LAST_UPDATED_COL { return 'date_last_updated'; }
### sub LAST_UPDATED_BY_COL   { return 'last_updated_by'; }
sub ENTRY_ID_COL  { return 'entry_id'; }
sub CELL_ID_COL   { return 'cell_id'; }
sub TITLE_COL     { return 'title'; }
sub JOURNAL_COL   { return 'journal'; }
sub YEAR_NUM_COL  { return 'year_num'; }
sub VOLUME_COL    { return 'volume'; }
sub PAGE_NUMS_COL { return 'page_nums'; }
sub CONTACT_COL   { return 'contact'; }
###
### Specification of the schema
###
sub sequenceVariationTableInfo {
  return {
    &ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, ],
      vals      => [
        ALLELE_NAME_COL,     ORDER_ALLELE_NAME_COL,
        OLD_ALLELE_NAME_COL, LOCUS_ID_COL,
        IMGT_ACCESSION_COL,  RELEASE_VERSION_COL,
        SEQ_VERSION_COL,     ANNOT_VERSION_COL,
        CODON_START_COL,     SEQ_CREATE_DATE_COL,
        SEQ_UPDATE_DATE_COL, ANNOT_UPDATE_DATE_COL,
        CDS_POSITIONS_COL,   TRANS_START_COL,
        TRANS_STOP_COL,      PARTIAL_SEQ_COL,
        PSEUDO_GENE_COL,     COMMENTS_COL,
        CWD_ALLELE_COL,      G_CODE_COL,
        IMGT_HLA_G_CODE_COL, IMGT_HLA_P_CODE_COL,
      ],
      not_null => [
        ALLELE_NAME_COL,       LOCUS_ID_COL,
        IMGT_ACCESSION_COL,    RELEASE_VERSION_COL,
        SEQ_VERSION_COL,       ANNOT_VERSION_COL,
        SEQ_CREATE_DATE_COL,   SEQ_UPDATE_DATE_COL,
        ANNOT_UPDATE_DATE_COL, CDS_POSITIONS_COL,
        PARTIAL_SEQ_COL,       PSEUDO_GENE_COL,
      ],
    },

    &ALLELE_NOMENCLATURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, ],
      vals      => [
        LOCUS_ID_COL,          ALLELE_NAME_COL,
        LOCUS_NAME_COL,        ALLELE_GROUP_COL,
        HLA_PROTEIN_COL,       CODING_REGION_COL,
        NON_CODING_REGION_COL, SUFFIX_COL,
      ],
      not_null =>
        [ LOCUS_ID_COL, ALLELE_NAME_COL, LOCUS_NAME_COL, ALLELE_GROUP_COL, ],
    },

    &GENE_STRUCTURE_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ GENE_STRUCT_ID_COL, ],
      vals      => [ GENE_STRUCT_NAME_COL, ],
      not_null  => [ GENE_STRUCT_NAME_COL, ],
    },

    &ALIGNMENT_VIEW_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ VIEW_TYPE_ID_COL, ],
      vals      => [ VIEW_TYPE_NAME_COL, ],
      not_null  => [ VIEW_TYPE_NAME_COL, ],
    },

    &ALIGNMENT_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALIGNMENT_TYPE_ID_COL, ],
      vals      => [ ALIGNMENT_TYPE_NAME_COL, ],
      not_null  => [ ALIGNMENT_TYPE_NAME_COL, ],
    },

    &ALLELE_ALIGNMENT_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [
        ALLELE_ID_COL,          SEQ_TYPE_ID_COL,
        UNGAPPED_START_POS_COL, UNGAPPED_END_POS_COL,
        ALIGNMENT_TYPE_ID_COL,  VIEW_TYPE_ID_COL,
        GENE_STRUCT_ID_COL,
      ],
      vals => [ GAPPED_START_POS_COL, GAPPED_END_POS_COL, INTERVAL_NAME_COL ],
      not_null =>
        [ GAPPED_START_POS_COL, GAPPED_END_POS_COL, INTERVAL_NAME_COL ],
    },

    &EVIDENCE_AUTHORITY_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ AUTHORITY_ID_COL, ],
      vals      => [ AUTHORITY_COL, AUTH_DESCR_COL, ],
      not_null  => [ AUTHORITY_COL, AUTH_DESCR_COL, ],
    },

    &FEATURE_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_TYPE_ID_COL, ],
      vals      => [ FT_NAME_COL, ],
      not_null  => [ FT_NAME_COL, ],
    },

    &FEATURE_MAP_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, FM_START_POS_COL, ],
      vals      => [ FM_END_POS_COL, ],
      not_null  => [ FM_END_POS_COL, ],
    },

    &FEATURE_MAP_BASE1_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, FM_START_POS_COL, ],
      vals      => [ FM_END_POS_COL, ],
      not_null  => [ FM_END_POS_COL, ],
    },

    &FEATURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, ],
      vals      => [
        LOCUS_ID_COL,      FEATURE_NUMBER_COL,
        SEQ_TYPE_ID_COL,   FEATURE_NAMES_COL,
        FEATURE_TYPES_COL, COMMENTS_COL,
        RELATED_PUBS_COL,  POSITIONS_COL,
      ],
      not_null => [ LOCUS_ID_COL, FEATURE_NUMBER_COL, SEQ_TYPE_ID_COL, ],
    },

    &FEATURE_2_NAME_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, FEATURE_NAME_COL ],
      vals      => [],
      not_null  => [],
    },

    &FEATURE_2_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, FEATURE_TYPE_ID_COL ],
      vals      => [],
      not_null  => [],
    },

    &FEATURE_2_PUBMED_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ FEATURE_ID_COL, PUBMED_ID_COL ],
      vals      => [],
      not_null  => [],
    },

    &MHC_LOCUS_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ LOCUS_ID_COL, ],
      vals =>
        [ MHC_LOCUS_NAME_COL, ENTREZ_GENE_ID_COL, TAXONOMY_ID_COL, CLASS_COL, ],
      not_null => [ MHC_LOCUS_NAME_COL, TAXONOMY_ID_COL, CLASS_COL, ],
    },

    &MOLECULE_SEQ_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, SEQ_TYPE_ID_COL, ],
      vals      => [ MOL_LENGTH_COL, MOL_SEQ_COL, ],
      not_null  => [ MOL_LENGTH_COL, MOL_SEQ_COL, ],
    },

    &ALIGNMENT_SEQ_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, SEQ_TYPE_ID_COL, ],
      vals      => [ ALIGN_LENGTH_COL, ALIGN_SEQ_COL, ],
      not_null  => [ ALIGN_LENGTH_COL, ALIGN_SEQ_COL, ],
    },

    &VARIANT_SEQ_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, SEQ_TYPE_ID_COL, ],
      vals      => [ VAR_LENGTH_COL, VAR_SEQ_COL, ],
      not_null  => [ VAR_LENGTH_COL, VAR_SEQ_COL, ],
    },

    &VARIANT_SEQ_STRUCTURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ LOCUS_ID_COL, SEQ_TYPE_ID_COL, ],
      vals      => [ VSS_START_POS_COL, ],
      not_null  => [ VSS_START_POS_COL, ],
    },

    &PUBMED_REFERENCE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, PUBMED_ID_COL, ],
      vals      => [ PUBMED_TITLE_COL, ],
      not_null  => [ PUBMED_TITLE_COL, ],
    },

    &REFERENCE_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, LOCUS_ID_COL, SEQ_TYPE_ID_COL, ],
      vals      => [],
      not_null  => [],
    },

    &FEATURE_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, LOCUS_ID_COL, PDB_ID_COL, ],
      vals     => [ PDB_POSITIONS_COL, PDB_MAP_COL, ],
      not_null => [],
    },

    &PDB_STRUCTURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ PDB_ID_COL, ],
      vals      => [
        DESCRIPTION_COL,     MHC_PROTEIN_COL,
        PEPTIDE_COL,         CHAIN_SUBMENU_COL,
        SELECTED_CHAINS_COL, UNSELECTED_CHAINS_COL,
        MOVE_COMMAND_COL,
      ],
      not_null => [],
    },

    &SEQ_BIOSOURCE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, CELL_LINE_COL, ],
      vals      => [],
      not_null  => [],
    },

    &SEQ_EVIDENCE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, ACCESSION_COL, AUTHORITY_ID_COL, ],
      vals      => [ ACC_VERSION_COL, ],
      not_null  => [],
    },

    &GENE_SEQ_STRUCTURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, GSS_START_POS_COL, ],
      vals      => [ GSS_END_POS_COL, GENE_STRUCT_ID_COL, ORDER_NUM_COL, ],
      not_null => [ GSS_END_POS_COL, GENE_STRUCT_ID_COL, ],
    },

    &SEQ_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [SEQ_TYPE_ID_COL],
      vals      => [ SEQ_NAME_COL, SEQ_DESCR_COL, ],
      not_null  => [ SEQ_NAME_COL, SEQ_DESCR_COL, ],
    },

    &TAXONOMY_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ TAXONOMY_ID_COL, ],
      vals      => [ SCIENTIFIC_NAME_COL, ],
      not_null  => [ SCIENTIFIC_NAME_COL, ],
    },

    &PDB_PROTEIN_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key => [ PDB_ID_COL, CHAIN_ID_COL, PROTEIN_ACC_COL, PROTEIN_START_COL, ],
      vals => [ PROTEIN_END_COL, PDB_START_COL, PDB_END_COL, MOLECULE_COL, ],
      not_null =>
        [ PROTEIN_END_COL, PDB_START_COL, PDB_END_COL, MOLECULE_COL, ],
    },

    &PDB_MAPPING_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ PDB_ID_COL, FEATURE_ID_COL, ],
      vals      => [ LOCUS_ID_COL, PDB_POSITIONS_COL, ],
      not_null  => [ LOCUS_ID_COL, PDB_POSITIONS_COL, ],
    },

    &VARIANT_MAP_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, VARIANT_ID_COL, ],
      vals      => [],
      not_null  => [],
    },

    &VARIANT_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ VARIANT_ID_COL, ],
      vals      => [
        FEATURE_ID_COL, VARIANT_TYPE_NAME_COL,
        MOTIF_COL,      POS_MOTIF_COL,
        VAR_MOTIF_COL,
      ],
      not_null => [ FEATURE_ID_COL, VARIANT_TYPE_NAME_COL, ],
    },

    &VARIANT_2_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ VARIANT_ID_COL, ALLELE_NAME_COL, ],
      vals      => [],
      not_null  => [],
    },

    &VARIANT_REFERENCE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, FEATURE_ID_COL, ],
      vals      => [
        VARIANT_ID_COL, VARIANT_TYPE_NAME_COL,
        MOTIF_COL,      POS_MOTIF_COL,
        VAR_MOTIF_COL,
      ],
      not_null => [
        VARIANT_ID_COL, VARIANT_TYPE_NAME_COL,
        MOTIF_COL,      POS_MOTIF_COL,
        VAR_MOTIF_COL,
      ],
    },

    &CDS_STRUCTURE_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ CDS_STRUCT_ID_COL, ],
      vals      => [ CDS_STRUCT_NAME_COL, ],
      not_null  => [ CDS_STRUCT_NAME_COL, ],
    },

    &CDS_SEQ_STRUCTURE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, CSS_START_POS_COL, ],
      vals      => [ CSS_END_POS_COL, CDS_STRUCT_ID_COL ],
      not_null  => [ CSS_END_POS_COL, CDS_STRUCT_ID_COL, ],
    },
    ###
    ### Lookup Tables
    ###
    &LK_CANO_CWD_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ LOCUS_NAME_COL, ALLELE_NAME_COL, ],
      vals      => [ HLA_PROTEIN_NAME_COL, ],
      not_null  => [],
    },

    &LK_CHANGE_NAME_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [OLD_ALLELE_NAME_COL],
      vals      => [
        NEW_ALLELE_NAME_COL, DATE_CREATED_COL,
        CREATED_BY_COL,      DATE_LAST_UPDATED_COL,
        LAST_UPDATED_BY_COL,
      ],
      not_null => [NEW_ALLELE_NAME_COL],
    },

    &LK_CWD_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ALLELE_NAME_COL],
      vals      => [
        LOCUS_NAME_COL,        IMGT_ACCESSION_COL,
        CWD_CATEGORY_COL,      HLA_PROTEIN_NAME_COL,
        DATE_CREATED_COL,      CREATED_BY_COL,
        DATE_LAST_UPDATED_COL, LAST_UPDATED_BY_COL,
      ],
      not_null => [ LOCUS_NAME_COL, IMGT_ACCESSION_COL, ],
    },

    &LK_DELETE_NAME_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [DELETED_ALLELE_NAME_COL],
      vals      => [
        DATE_OF_DELETION_COL, REASON_COL,
        IDENTICAL_TO_COL,     DATE_CREATED_COL,
        CREATED_BY_COL,       DATE_LAST_UPDATED_COL,
        LAST_UPDATED_BY_COL,
      ],
      not_null => [REASON_COL],
    },

    &LK_NMDP_CODE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ NMDP_CODE_COL, IMGT_HLA_VERSION_COL ],
      vals      => [
        SUBTYPE_COL,    DATE_CREATED_COL,
        CREATED_BY_COL, DATE_LAST_UPDATED_COL,
        LAST_UPDATED_BY_COL,
      ],
      not_null => [SUBTYPE_COL],
    },

    &LK_ALLELE_DATA_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [DATA_TYPE_ID_COL],
      vals      => [
        DATA_NAME_COL,         DATA_DESCR_COL,
        DATE_CREATED_COL,      CREATED_BY_COL,
        DATE_LAST_UPDATED_COL, LAST_UPDATED_BY_COL,
      ],
      not_null => [ DATA_NAME_COL, DATA_DESCR_COL, ],
    },

    &MHC_HLA_ALLELE_FREQ_MAP_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ ALLELE_ID_COL, ALLELE_NAME_COL ],
      vals      => [
        DATE_CREATED_COL,      CREATED_BY_COL,
        DATE_LAST_UPDATED_COL, LAST_UPDATED_BY_COL,
      ],
      not_null => [],
    },

    &MHC_HLA_ALLELE_FREQ_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ LOCUS_ID_COL, ALLELE_NAME_COL, POP_AREA_ID_COL ],
      vals      => [
        DATA_TYPE_ID_COL,      ALLELE_FREQ_COL,
        ALLELE_COUNT_COL,      ALLELE_TOTAL_COL,
        DATE_CREATED_COL,      CREATED_BY_COL,
        DATE_LAST_UPDATED_COL, LAST_UPDATED_BY_COL,
      ],
      not_null => [
        DATA_TYPE_ID_COL, ALLELE_FREQ_COL,
        ALLELE_COUNT_COL, ALLELE_TOTAL_COL,
      ],
    },

    &MHC_HLA_FREQ_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [SUBJECT_COL],
      vals      => [
        SOURCE_COL,     POPULATION_COL, POP_AREA_COL,   METHOD_COL,
        ETHNIC_COL,     COLLECT_COL,    LATITUDE_COL,   LONGITUDE_COL,
        COMPLEX_COL,    HLA_A_1_COL,    HLA_A_2_COL,    MISMATCH1_COL,
        HLA_B_1_COL,    HLA_B_2_COL,    MISMATCH2_COL,  HLA_C_1_COL,
        HLA_C_2_COL,    MISMATCH3_COL,  HLA_DRB1_1_COL, HLA_DRB1_2_COL,
        MISMATCH4_COL,  HLA_DQA1_1_COL, HLA_DQA1_2_COL, MISMATCH5_COL,
        HLA_DQB1_1_COL, HLA_DQB1_2_COL, MISMATCH6_COL,  HLA_DPA1_1_COL,
        HLA_DPA1_2_COL, MISMATCH7_COL,  HLA_DPB1_1_COL, HLA_DPB1_2_COL,
        MISMATCH8_COL,  REPORT_COL,     AUTHORS_COL,
      ],
      not_null => [],
    },

    &LK_POP_AREA_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [POP_AREA_ID_COL],
      vals      => [
        POP_AREA_NAME_COL,  POP_AREA_ABBRV_COL,
        POP_AREA_DESCR_COL, DATE_CREATED_COL,
        CREATED_BY_COL,     DATE_LAST_UPDATED_COL,
        LAST_UPDATED_BY_COL,
      ],
      not_null =>
        [ POP_AREA_NAME_COL, POP_AREA_ABBRV_COL, POP_AREA_DESCR_COL, ],
    },

    &LK_REGION_CWD_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ POP_AREA_NAME_COL, ALLELE_NAME_COL, ],
      vals      => [
        LOCUS_NAME_COL,       CWD_ALLELE_COL,
        REGION_FREQUENCY_COL, DATE_CREATED_COL,
        CREATED_BY_COL,       DATE_LAST_UPDATED_COL,
        LAST_UPDATED_BY_COL,
      ],
      not_null => [ LOCUS_NAME_COL, CWD_ALLELE_COL, REGION_FREQUENCY_COL, ],
    },

    &REPLACEMENT_TYPE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [ REPLACEMENT_ID_COL, ],
      vals      => [ REPLACEMENT_NAME_COL, ],
      not_null  => [ REPLACEMENT_NAME_COL, ],
    },

    &REPLACEMENT_ALLELE_TABLE => {
      type      => db::Types::TAB_TYPE,
      order_ord => undef,
      key       => [
        OLD_ALLELE_NAME_COL, LOCUS_ID_COL,
        ALLELE_ID_COL,       REPLACEMENT_ID_COL,
      ],
      vals     => [],
      not_null => [],
    },

  };
}
###
### Taxonomy Constants
###
sub HOMO_SAPIENS_TAXON { return 9606; }
###
### Population Area Optional Column
### for HLA Files
###
sub POPULATION_AREA_COL          { return 'Population Area'; }
sub NONE_OF_THE_ABOVE_POPULATION { return 'None of the Above'; }

sub IS_POPULATION_AREA_COL {
  my ($pop_col) = @_;
  return util::Constants::TRUE
    if ( lc($pop_col) eq lc(POPULATION_AREA_COL)
    || lc($pop_col) eq lc( POPULATION_AREA_COL . util::Constants::ASTERISK ) );
  return util::Constants::FALSE;
}
###
### Standard Ambiguous Allele Separator
###
sub STANDARD_AMBIGUOUS_ALLELE_SEPARATOR { return util::Constants::SLASH; }
###
### IMGT/HLA Versions
###
sub IMGT_HLA_V2 { return 2; }
sub IMGT_HLA_V3 { return 3; }

sub DEFINED_IMGT_HLA_VERSION {
  my ($imgt_hla_version) = @_;
  return ( $imgt_hla_version == IMGT_HLA_V2
      || $imgt_hla_version == IMGT_HLA_V3 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}
###
### Seq Type Names
###
sub AA_SEQ   { return 'AA'; }
sub DNA_SEQ  { return 'DNA'; }
sub MRNA_SEQ { return 'mRNA'; }
sub CDS_SEQ  { return 'CDS'; }
###
### Gene Structure Type Names
###
sub INTRON          { return 'intron'; }
sub EXON            { return 'exon'; }
sub PARTIAL_EXON    { return 'partial exon'; }
sub FIVE_PRIME_UTR  { return '5 prime utr'; }
sub THREE_PRIME_UTR { return '3 prime utr'; }
sub INSERT          { return 'insert'; }
sub CODON           { return 'codon'; }
sub PROTEIN         { return 'protein'; }
sub MATURE_PROTEIN  { return 'mature protein'; }
sub UNSEQUENCED     { return 'unsequenced'; }
sub PSEUDO_GENE     { return 'pseudo gene'; }
###
### HLA Pseudo Gene
###
sub HLA_PSEUDO_GENE { return 'HLA-P'; }
###
### CDS Structure Type Names
###
sub EXACT_INTERVAL               { return 'exact'; }
sub OPEN_LEFT_INTERVAL           { return 'open left'; }
sub OPEN_RIGHT_INTERVAL          { return 'open right'; }
sub OPEN_LEFT_AND_RIGHT_INTERVAL { return 'open left and right'; }
###
### ALIGNMENT TYPES
###
sub ALIGNMENT_SEQ_TYPE { return 'alignment_seq'; }
sub VARIANT_SEQ_TYPE   { return 'variant_seq'; }
###
### ALIGNMENT VIEW TYPES
###
sub EXON_VIEW            { return 'exon'; }
sub CODON_EXON_VIEW      { return 'codon, exon'; }
sub UTR_EXON_INTRON_VIEW { return 'utr, exon, intron'; }
###
### Allele Data Types
###
sub ALLELE_GROUP_DATA_TYPE { return 'allele group'; }
sub HLA_PROTEIN_DATA_TYPE  { return 'HLA protein'; }
###
### Replacement Types
###
sub CHANGED_ALLELE_TYPE { return 'changed allele name'; }
sub DELETED_ALLELE_TYPE { return 'deleted allele name'; }
###
### Nomenclature Component Order
###
sub NOMENCLATURE_ORDER {
  return [
    ALLELE_GROUP_COL,  HLA_PROTEIN_COL,
    CODING_REGION_COL, NON_CODING_REGION_COL,
  ];
}
###
### Standard Oracle Date Format
###
sub ORACLE_DATE_FORMAT { return OracleDateFormat; }
###
### Oracle Date Format Columns
###
sub ORACLE_DATES {
  return ( ANNOT_UPDATE_DATE_COL, SEQ_CREATE_DATE_COL, SEQ_UPDATE_DATE_COL );
}

sub ORACLE_DATES_LIST {
  my %oracle_dates = ORACLE_DATES;
  return sort keys %oracle_dates;
}

################################################################################
#
#			       Private Constants
#
################################################################################
###
### Mapping Types
###
sub _ID_TO_NAME_MAP_ { return 'id_to_name'; }
sub _NAME_TO_ID_MAP_ { return 'name_to_id'; }
###
### Initialize Controlled Vocabularies
###
sub CONTROLLED_VOCABULARIES {
  return (
    ALIGNMENT_TYPE_TABLE,      ALIGNMENT_VIEW_TYPE_TABLE,
    CDS_STRUCTURE_TYPE_TABLE,  EVIDENCE_AUTHORITY_TABLE,
    FEATURE_TYPE_TABLE,        GENE_STRUCTURE_TYPE_TABLE,
    MHC_LOCUS_TABLE,           SEQ_TYPE_TABLE,
    TAXONOMY_TABLE,            LK_POP_AREA_TYPE_TABLE,
    LK_ALLELE_DATA_TYPE_TABLE, REPLACEMENT_TYPE_TABLE,
    PDB_PROTEIN_TABLE,         PDB_STRUCTURE_TABLE
  );
}

###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!###
###                                                        ###
### Note:  LK_POP_AREA_TYPE_TABLE is used elsewhere so     ###
###        it cannot be deleted in Oracle.  Must manually  ###
###        update this table on Oracle                     ###
###        This is the list to use in initializing the     ###
###        Oracle database.                                ###
###                                                        ###
###!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!###

sub ORACLE_CONTROLLED_VOCABULARIES {
  return (
    ALIGNMENT_TYPE_TABLE,     ALIGNMENT_VIEW_TYPE_TABLE,
    CDS_STRUCTURE_TYPE_TABLE, EVIDENCE_AUTHORITY_TABLE,
    FEATURE_TYPE_TABLE,       GENE_STRUCTURE_TYPE_TABLE,
    MHC_LOCUS_TABLE,          SEQ_TYPE_TABLE,
    TAXONOMY_TABLE,           LK_ALLELE_DATA_TYPE_TABLE,
    REPLACEMENT_TYPE_TABLE,   PDB_PROTEIN_TABLE,
    PDB_STRUCTURE_TABLE
  );
}

sub _INITIALIZE_MAPPING_TYPES_ {
  my @mapping_types = CONTROLLED_VOCABULARIES;
  my $mappings      = {};
  foreach my $type (@mapping_types) {
    $mappings->{$type} = {
      &_ID_TO_NAME_MAP_ => {},
      &_NAME_TO_ID_MAP_ => {},
    };
  }
  return $mappings;
}
###
### Controlled Vocabulary Queries
###
sub _QUERY_DATA_ {
  return {
    &EVIDENCE_AUTHORITY_TABLE => {
      ord => [ AUTHORITY_ID_COL, AUTHORITY_COL, ],
      id  => AUTHORITY_ID_COL,
      key => [AUTHORITY_COL],
    },

    &FEATURE_TYPE_TABLE => {
      ord => [ FEATURE_TYPE_ID_COL, FT_NAME_COL, ],
      id  => FEATURE_TYPE_ID_COL,
      key => [FT_NAME_COL],
    },

    &GENE_STRUCTURE_TYPE_TABLE => {
      ord => [ GENE_STRUCT_ID_COL, GENE_STRUCT_NAME_COL, ],
      id  => GENE_STRUCT_ID_COL,
      key => [GENE_STRUCT_NAME_COL],
    },

    &ALIGNMENT_VIEW_TYPE_TABLE => {
      ord => [ VIEW_TYPE_ID_COL, VIEW_TYPE_NAME_COL, ],
      id  => VIEW_TYPE_ID_COL,
      key => [VIEW_TYPE_NAME_COL],
    },

    &ALIGNMENT_TYPE_TABLE => {
      ord => [ ALIGNMENT_TYPE_ID_COL, ALIGNMENT_TYPE_NAME_COL, ],
      id  => ALIGNMENT_TYPE_ID_COL,
      key => [ALIGNMENT_TYPE_NAME_COL],
    },

    &MHC_LOCUS_TABLE => {
      ord => [ LOCUS_ID_COL, MHC_LOCUS_NAME_COL, TAXONOMY_ID_COL, ],
      id  => LOCUS_ID_COL,
      key => [ MHC_LOCUS_NAME_COL, TAXONOMY_ID_COL ],
    },

    &SEQ_TYPE_TABLE => {
      ord => [ SEQ_TYPE_ID_COL, SEQ_NAME_COL, ],
      id  => SEQ_TYPE_ID_COL,
      key => [SEQ_NAME_COL],
    },

    &TAXONOMY_TABLE => {
      ord => [ TAXONOMY_ID_COL, SCIENTIFIC_NAME_COL, ],
      id  => TAXONOMY_ID_COL,
      key => [SCIENTIFIC_NAME_COL],
    },

    &CDS_STRUCTURE_TYPE_TABLE => {
      ord => [ CDS_STRUCT_ID_COL, CDS_STRUCT_NAME_COL, ],
      id  => CDS_STRUCT_ID_COL,
      key => [ CDS_STRUCT_NAME_COL, ],
    },

    &LK_ALLELE_DATA_TYPE_TABLE => {
      ord => [ DATA_TYPE_ID_COL, DATA_NAME_COL, ],
      id  => DATA_TYPE_ID_COL,
      key => [ DATA_NAME_COL, ],
    },

    &LK_POP_AREA_TYPE_TABLE => {
      ord => [ POP_AREA_ID_COL, POP_AREA_NAME_COL, ],
      id  => POP_AREA_ID_COL,
      key => [ POP_AREA_NAME_COL, ],
    },

    &REPLACEMENT_TYPE_TABLE => {
      ord => [ REPLACEMENT_ID_COL, REPLACEMENT_NAME_COL, ],
      id  => REPLACEMENT_ID_COL,
      key => [ REPLACEMENT_NAME_COL, ],
    },

  };
}
###
### Initialize Globals
###
$_GLOBALS_->{mappings} = _INITIALIZE_MAPPING_TYPES_;
$_GLOBALS_->{queries}  = _QUERY_DATA_;

################################################################################
#
#			     Private Static Method
#
################################################################################

sub _getKey {
  my (@ids) = @_;
  return join( util::Constants::DOT, @ids );
}

################################################################################
#
#			Public Static Controlled Vocabulary Method
#
################################################################################

sub initializeControlledVocabularies($$) {
  my ( $db, $error_mgr ) = @_;
  ###
  ### Process Controlled Vocabulary Queries
  ###
  my $queries = new util::DbQuery($db);
  while ( my ( $table, $struct ) = each %{ $_GLOBALS_->{queries} } ) {
    my $ord = $struct->{ord};
    my $cmd = "
select " . join( util::Constants::COMMA_SEPARATOR, @{$ord} ) . "
from   $table
";
    $queries->doQuery( $table, $cmd, "$table query" );
    my $map = $_GLOBALS_->{mappings}->{$table};
    while ( my $row_ref = $queries->fetchRowRef($table) ) {
      my $result = {};
      foreach my $index ( 0 .. $#{$ord} ) {
        $result->{ $ord->[$index] } = $row_ref->[$index];
      }
      my @key_array = ();
      my $name      = $struct->{key}->[0];
      foreach my $col ( @{ $struct->{key} } ) {
        push( @key_array, $result->{$col} );
      }
      $map->{&_NAME_TO_ID_MAP_}->{ &_getKey(@key_array) } =
        $result->{ $struct->{id} };
      $map->{&_ID_TO_NAME_MAP_}->{ $result->{ $struct->{id} } } =
        $result->{$name};
    }
    $queries->finishQuery($table);
  }
  ###
  ### Get the reference allele mapping locus_id -> allele_name
  ### on a per taxon basis.
  ###
  my $reference_alleles = {};
  $_GLOBALS_->{reference_alleles} = $reference_alleles;
  my $reference_allele_query = 'reference allele';
  my $reference_allele_cmd   = "
select refa.locus_id,
       alle.allele_name,
       mhcl.taxonomy_id,
       refa.seq_type_id
from   mhc_locus        mhcl,
       allele           alle,
       reference_allele refa
where  refa.locus_id  = mhcl.locus_id
and    refa.allele_id = alle.allele_id
";
  $queries->doQuery( $reference_allele_query, $reference_allele_cmd,
    "reference allele query" );
  while ( my $row_ref = $queries->fetchRowRef($reference_allele_query) ) {
    my ( $locus_id, $allele_name, $taxonomy_id, $seq_type_id ) = @{$row_ref};
    if ( !defined( $reference_alleles->{$taxonomy_id} ) ) {
      $reference_alleles->{$taxonomy_id} = {};
    }
    my $taxon_loci = $reference_alleles->{$taxonomy_id};
    if ( !defined( $taxon_loci->{$locus_id} ) ) {
      $taxon_loci->{$locus_id} = {};
    }
    $taxon_loci->{$locus_id}->{$seq_type_id} = $allele_name;
  }
  $queries->finishQuery($reference_allele_query);
  ###
  ### Get the variant_seq_structure data
  ###
  my $variant_seq_structs = {};
  $_GLOBALS_->{variant_seq_structs} = $variant_seq_structs;
  my $variant_seq_structs_query = 'variant seq structs';
  my $variant_seq_structs_cmd   = "
select vss.locus_id,
       vss.vss_start_pos,
       mhcl.taxonomy_id,
       vss.seq_type_id
from   mhc_locus             mhcl,
       variant_seq_structure vss
where  vss.locus_id = mhcl.locus_id
";
  $queries->doQuery( $variant_seq_structs_query, $variant_seq_structs_cmd,
    "reference allele query" );
  while ( my $row_ref = $queries->fetchRowRef($variant_seq_structs_query) ) {
    my ( $locus_id, $vss_start_pos, $taxonomy_id, $seq_type_id ) = @{$row_ref};
    if ( !defined( $variant_seq_structs->{$taxonomy_id} ) ) {
      $variant_seq_structs->{$taxonomy_id} = {};
    }
    my $taxon_loci = $variant_seq_structs->{$taxonomy_id};
    if ( !defined( $taxon_loci->{$locus_id} ) ) {
      $taxon_loci->{$locus_id} = {};
    }
    $taxon_loci->{$locus_id}->{$seq_type_id} = $vss_start_pos;
  }
  $queries->finishQuery($variant_seq_structs_query);
  ###
  ### Get the mapping of allele_name to locus_id and allele_id
  ### on a per taxon basis.
  ###
  my $allele_names = {};
  $_GLOBALS_->{allele_names} = $allele_names;
  my $allele_names_query = 'allele names';
  my $allele_names_cmd   = "
select alle.allele_name,
       alle.allele_id,
       alle.locus_id,
       mhcl.taxonomy_id
from   allele    alle,
       mhc_locus mhcl
where  mhcl.locus_id = alle.locus_id
";
  $queries->doQuery( $allele_names_query, $allele_names_cmd,
    "allele names query" );
  while ( my $row_ref = $queries->fetchRowRef($allele_names_query) ) {
    my ( $allele_name, $allele_id, $locus_id, $taxonomy_id ) = @{$row_ref};
    if ( !defined( $allele_names->{$taxonomy_id} ) ) {
      $allele_names->{$taxonomy_id} = {};
    }
    $allele_names->{$taxonomy_id}->{$allele_name} = {
      locus_id  => $locus_id,
      allele_id => $allele_id,
    };
  }
  $queries->finishQuery($allele_names_query);
  ###
  ### Get the locus ids for a given taxon
  ###
  my $mhc_loci = {};
  $_GLOBALS_->{mhc_loci} = $mhc_loci;
  my $mhc_loci_query = 'mhc loci';
  my $mhc_loci_cmd   = "
select locus_id,
       taxonomy_id
from   mhc_locus
";
  $queries->doQuery( $mhc_loci_query, $mhc_loci_cmd, "mhc loci query" );
  while ( my $row_ref = $queries->fetchRowRef($mhc_loci_query) ) {
    my ( $locus_id, $taxonomy_id ) = @{$row_ref};
    if ( !defined( $mhc_loci->{$taxonomy_id} ) ) {
      $mhc_loci->{$taxonomy_id} = [];
    }
    push( @{ $mhc_loci->{$taxonomy_id} }, $locus_id );
  }
  $queries->finishQuery($mhc_loci_query);
}

################################################################################
#
#			     Public Static Getter Methods
#
################################################################################

sub infiniteTime { return $_GLOBALS_->{infinite_time}; }

sub oracleDate {
  my ($date) = @_;
  my %oracle_dates = ORACLE_DATES;
  return (
    ( defined( $oracle_dates{$date} ) )
    ? util::Constants::TRUE
    : util::Constants::FALSE
  );
}

sub getId {
  my ( $table, $name, $taxonomy_id ) = @_;
  my $map = $_GLOBALS_->{mappings}->{$table};
  return undef if ( !defined($map) );
  my $query     = $_GLOBALS_->{queries}->{$table};
  my @key_array = ($name);
  push( @key_array, $taxonomy_id ) if ( @{ $query->{key} } > 1 );
  return $map->{&_NAME_TO_ID_MAP_}->{ &_getKey(@key_array) };
}

sub maxId {
  my ($table) = @_;
  my $map = $_GLOBALS_->{mappings}->{$table};
  return undef if ( !defined($map) );
  my @ids    = keys %{ $map->{&_ID_TO_NAME_MAP_} };
  my $max_id = 0;
  foreach my $id (@ids) {
    $max_id = ( $max_id < int($id) ) ? int($id) : $max_id;
  }
  return $max_id;
}

sub getName {
  my ( $table, $id ) = @_;
  my $map = $_GLOBALS_->{mappings}->{$table};
  return undef if ( !defined($map) );
  return $map->{&_ID_TO_NAME_MAP_}->{$id};
}

sub getIds {
  my ($table) = @_;
  my $map = $_GLOBALS_->{mappings}->{$table};
  return () if ( !defined($map) );
  return keys %{ $map->{&_ID_TO_NAME_MAP_} };
}

sub referenceAlleles {
  my ($taxonomy_id) = @_;
  my $reference_alleles = $_GLOBALS_->{reference_alleles}->{$taxonomy_id};
  return {} if ( !defined($reference_alleles) );
  return { %{$reference_alleles} };
}

sub variantSeqStructs {
  my ($taxonomy_id) = @_;
  my $variant_seq_structs = $_GLOBALS_->{variant_seq_structs}->{$taxonomy_id};
  return {} if ( !defined($variant_seq_structs) );
  return { %{$variant_seq_structs} };
}

sub getLocusIds {
  my ($taxonomy_id) = @_;
  my $mhc_loci      = $_GLOBALS_->{mhc_loci}->{$taxonomy_id};
  my @loci          = ();
  return @loci if ( !defined($mhc_loci) );
  return @{$mhc_loci};
}

sub alleleNames {
  my ($taxonomy_id) = @_;
  my $allele_names = $_GLOBALS_->{allele_names}->{$taxonomy_id};
  return {} if ( !defined($allele_names) );
  return { %{$allele_names} };
}

################################################################################

1;

__END__

=head1 NAME

MhcTypes.pm

=head1 DESCRIPTION

The static class defines columns and tables for loading an
mhc sequence variation schema.  It also initializes controlled vocabulary
data from the database for use by programs, as necessary.

=head1 STATIC CONSTANTS

The following static constants are exported by this class.

The following table names are export:

   db::MhcTypes::ALIGNMENT_SEQ_TABLE         -- ALIGNMENT_SEQ
   db::MhcTypes::ALIGNMENT_TYPE_TABLE        -- ALIGNMENT_TYPE
   db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE   -- ALIGNMENT_VIEW_TYPE
   db::MhcTypes::ALLELE_ALIGNMENT_TABLE      -- ALLELE_ALIGNMENT
   db::MhcTypes::ALLELE_NOMENCLATURE_TABLE   -- ALLELE_NOMENCLATURE
   db::MhcTypes::ALLELE_TABLE                -- ALLELE
   db::MhcTypes::CDS_SEQ_STRUCTURE_TABLE     -- CDS_SEQ_STRUCTURE
   db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE    -- CDS_STRUCTURE_TYPE
   db::MhcTypes::EVIDENCE_AUTHORITY_TABLE    -- EVIDENCE_AUTHORITY
   db::MhcTypes::FEATURE_2_NAME_TABLE        -- FEATURE_2_NAME
   db::MhcTypes::FEATURE_2_PUBMED_TABLE      -- FEATURE_2_PUBMED
   db::MhcTypes::FEATURE_2_TYPE_TABLE        -- FEATURE_2_TYPE
   db::MhcTypes::FEATURE_ALLELE_TABLE        -- FEATURE_ALLELE
   db::MhcTypes::FEATURE_MAP_BASE1_TABLE     -- FEATURE_MAP_BASE1
   db::MhcTypes::FEATURE_MAP_TABLE           -- FEATURE_MAP
   db::MhcTypes::FEATURE_TABLE               -- FEATURE
   db::MhcTypes::FEATURE_TYPE_TABLE          -- FEATURE_TYPE
   db::MhcTypes::GENE_SEQ_STRUCTURE_TABLE    -- GENE_SEQ_STRUCTURE
   db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE   -- GENE_STRUCTURE_TYPE
   db::MhcTypes::MHC_LOCUS_TABLE             -- MHC_LOCUS
   db::MhcTypes::MOLECULE_SEQ_TABLE          -- MOLECULE_SEQ
   db::MhcTypes::PDB_MAPPING_TABLE           -- PDB_MAPPING
   db::MhcTypes::PDB_PROTEIN_TABLE           -- PDB_PROTEIN
   db::MhcTypes::PDB_STRUCTURE_TABLE         -- PDB_STRUCTURE
   db::MhcTypes::PUBMED_REFERENCE_TABLE      -- PUBMED_REFERENCE
   db::MhcTypes::REFERENCE_ALLELE_TABLE      -- REFERENCE_ALLELE
   db::MhcTypes::REPLACEMENT_ALLELE_TABLE    -- REPLACEMENT_ALLELE
   db::MhcTypes::REPLACEMENT_TYPE_TABLE      -- REPLACEMENT_TYPE
   db::MhcTypes::SEQ_BIOSOURCE_TABLE         -- SEQ_BIOSOURCE
   db::MhcTypes::SEQ_EVIDENCE_TABLE          -- SEQ_EVIDENCE
   db::MhcTypes::SEQ_TYPE_TABLE              -- SEQ_TYPE
   db::MhcTypes::TAXONOMY_TABLE              -- TAXONOMY
   db::MhcTypes::VARIANT_2_ALLELE_TABLE      -- VARIANT_2_ALLELE
   db::MhcTypes::VARIANT_MAP_TABLE           -- VARIANT_MAP
   db::MhcTypes::VARIANT_REFERENCE_TABLE     -- VARIANT_REFERENCE
   db::MhcTypes::VARIANT_SEQ_STRUCTURE_TABLE -- VARIANT_SEQ_STRUCTURE
   db::MhcTypes::VARIANT_SEQ_TABLE           -- VARIANT_SEQ
   db::MhcTypes::VARIANT_TYPE_TABLE          -- VARIANT_TYPE

The following column names are exported:

   db::MhcTypes::ACCESSION_COL           -- accession
   db::MhcTypes::ACC_VERSION_COL         -- acc_version
   db::MhcTypes::ALIGNMENT_TYPE_ID_COL   -- alignment_type_id
   db::MhcTypes::ALIGNMENT_TYPE_NAME_COL -- alignment_type_name
   db::MhcTypes::ALIGN_LENGTH_COL        -- align_length
   db::MhcTypes::ALIGN_SEQ_COL           -- align_seq
   db::MhcTypes::ALLELE_GROUP_COL        -- allele_group
   db::MhcTypes::ALLELE_ID_COL           -- allele_id
   db::MhcTypes::ALLELE_NAME_COL         -- allele_name
   db::MhcTypes::AMONG_CWD_COL           -- among_cwd
   db::MhcTypes::ANNOT_UPDATE_DATE_COL   -- annot_update_date
   db::MhcTypes::ANNOT_VERSION_COL       -- annot_version
   db::MhcTypes::AUTHORITY_COL           -- authority
   db::MhcTypes::AUTHORITY_ID_COL        -- authority_id
   db::MhcTypes::AUTH_DESCR_COL          -- auth_descr
   db::MhcTypes::CDS_POSITIONS_COL       -- cds_positions
   db::MhcTypes::CDS_STRUCT_ID_COL       -- cds_struct_id
   db::MhcTypes::CDS_STRUCT_NAME_COL     -- cds_struct_name
   db::MhcTypes::CELL_LINE_COL           -- cell_line
   db::MhcTypes::CHAIN_ID_COL            -- chain_id
   db::MhcTypes::CHAIN_SUBMENU_COL       -- chain_submenu
   db::MhcTypes::CLASS_COL               -- class
   db::MhcTypes::CODON_START_COL         -- codon_start
   db::MhcTypes::CODING_REGION_COL       -- coding_region
   db::MhcTypes::COMMENTS_COL            -- comments
   db::MhcTypes::COMMON_IN_US_COL        -- common_in_us
   db::MhcTypes::CSS_END_POS_COL         -- css_end_pos
   db::MhcTypes::CSS_START_POS_COL       -- css_start_pos
   db::MhcTypes::CWD_ALLELE_COL          -- cwd_allele
   db::MhcTypes::DESCRIPTION_COL         -- description
   db::MhcTypes::ENTREZ_GENE_ID_COL      -- entrez_gene_id
   db::MhcTypes::FEATURE_ID_COL          -- feature_id
   db::MhcTypes::FEATURE_NAMES_COL       -- feature_names
   db::MhcTypes::FEATURE_NAME_COL        -- feature_name
   db::MhcTypes::FEATURE_NUMBER_COL      -- feature_number
   db::MhcTypes::FEATURE_TYPES_COL       -- feature_types
   db::MhcTypes::FEATURE_TYPE_ID_COL     -- feature_type_id
   db::MhcTypes::FM_END_POS_COL          -- fm_end_pos
   db::MhcTypes::FM_START_POS_COL        -- fm_start_pos
   db::MhcTypes::FT_NAME_COL             -- ft_name
   db::MhcTypes::GAPPED_END_POS_COL      -- gapped_end_pos
   db::MhcTypes::GAPPED_START_POS_COL    -- gapped_start_pos
   db::MhcTypes::GCODE_NAME_COL          -- gcode_name
   db::MhcTypes::GENE_STRUCT_ID_COL      -- gene_struct_id
   db::MhcTypes::GENE_STRUCT_NAME_COL    -- gene_struct_name
   db::MhcTypes::GSS_END_POS_COL         -- gss_end_pos
   db::MhcTypes::GSS_START_POS_COL       -- gss_start_pos
   db::MhcTypes::G_CODE_COL              -- g_code
   db::MhcTypes::HLA_PROTEIN_COL         -- hla_protein
   db::MhcTypes::IMGT_ACCESSION_COL      -- imgt_accession
   db::MhcTypes::IMGT_HLA_G_CODE_COL     -- imgt_hla_g_code
   db::MhcTypes::IMGT_HLA_P_CODE_COL     -- imgt_hla_p_code
   db::MhcTypes::INTERVAL_NAME_COL       -- interval_name
   db::MhcTypes::LOCUS_ID_COL            -- locus_id
   db::MhcTypes::LOCUS_NAME_COL          -- locus_name
   db::MhcTypes::MHC_LOCUS_NAME_COL      -- mhc_locus_name
   db::MhcTypes::MHC_PROTEIN_COL         -- mhc_protein
   db::MhcTypes::MOLECULE_COL            -- molecule
   db::MhcTypes::MOL_LENGTH_COL          -- mol_length
   db::MhcTypes::MOL_SEQ_COL             -- mol_seq
   db::MhcTypes::MOTIF_COL               -- motif
   db::MhcTypes::MOVE_COMMAND_COL        -- move_command
   db::MhcTypes::NON_CODING_REGION_COL   -- non_coding_region
   db::MhcTypes::NUM_POSITIONS_COL       -- num_positions
   db::MhcTypes::OLD_ALLELE_NAME_COL     -- old_allele_name
   db::MhcTypes::ORDER_ALLELE_NAME_COL   -- order_allele_name
   db::MhcTypes::ORDER_NUM_COL           -- order_num
   db::MhcTypes::PARTIAL_SEQ_COL         -- partial_seq
   db::MhcTypes::PDB_END_COL             -- pdb_end
   db::MhcTypes::PDB_ID_COL              -- pdb_id
   db::MhcTypes::PDB_MAP_COL             -- pdb_map
   db::MhcTypes::PDB_POSITIONS_COL       -- pdb_positions
   db::MhcTypes::PDB_START_COL           -- pdb_start
   db::MhcTypes::PEPTIDE_COL             -- peptide
   db::MhcTypes::POSITIONS_COL           -- positions
   db::MhcTypes::POS_MOTIF_COL           -- pos_motif
   db::MhcTypes::PROTEIN_ACC_COL         -- protein_acc
   db::MhcTypes::PROTEIN_END_COL         -- protein_end
   db::MhcTypes::PROTEIN_START_COL       -- protein_start
   db::MhcTypes::PSEUDO_GENE_COL         -- pseudo_gene
   db::MhcTypes::PUBMED_ID_COL           -- pubmed_id
   db::MhcTypes::PUBMED_TITLE_COL        -- pubmed_title
   db::MhcTypes::RELATED_PUBS_COL        -- related_pubs
   db::MhcTypes::RELEASE_VERSION_COL     -- release_version
   db::MhcTypes::REPLACEMENT_ID_COL      -- replacement_id
   db::MhcTypes::REPLACEMENT_NAME_COL    -- replacement_name
   db::MhcTypes::SCIENTIFIC_NAME_COL     -- scientific_name
   db::MhcTypes::SELECTED_CHAINS_COL     -- selected_chains
   db::MhcTypes::SEQ_CREATE_DATE_COL     -- seq_create_date
   db::MhcTypes::SEQ_DESCR_COL           -- seq_descr
   db::MhcTypes::SEQ_NAME_COL            -- seq_name
   db::MhcTypes::SEQ_TYPE_ID_COL         -- seq_type_id
   db::MhcTypes::SEQ_UPDATE_DATE_COL     -- seq_update_date
   db::MhcTypes::SEQ_VERSION_COL         -- seq_version
   db::MhcTypes::SUFFIX_COL              -- suffix
   db::MhcTypes::TAXONOMY_ID_COL         -- taxonomy_id
   db::MhcTypes::TRANS_START_COL         -- trans_start
   db::MhcTypes::TRANS_STOP_COL          -- trans_stop
   db::MhcTypes::UNGAPPED_END_POS_COL    -- ungapped_end_pos
   db::MhcTypes::UNGAPPED_START_POS_COL  -- ungapped_start_pos
   db::MhcTypes::UNSELECTED_CHAINS_COL   -- unselected_chains
   db::MhcTypes::VARIANT_ID_COL          -- variant_id
   db::MhcTypes::VARIANT_TYPE_NAME_COL   -- variant_type_name
   db::MhcTypes::VAR_LENGTH_COL          -- var_length
   db::MhcTypes::VAR_MOTIF_COL           -- var_motif
   db::MhcTypes::VAR_SEQ_COL             -- var_seq
   db::MhcTypes::VIEW_TYPE_ID_COL        -- view_type_id
   db::MhcTypes::VIEW_TYPE_NAME_COL      -- view_type_name
   db::MhcTypes::VSS_START_POS_COL       -- vss_start_pos

The following are the Allele Name Validation Lookup Processing Tables

   db::MhcTypes::LK_CANO_CWD_TABLE      -- LK_CANO_CWD
   db::MhcTypes::LK_CHANGE_NAME_TABLE   -- LK_CHANGE_NAME
   db::MhcTypes::LK_CWD_ALLELE_TABLE    -- LK_CWD_ALLELE
   db::MhcTypes::LK_DELETE_NAME_TABLE   -- LK_DELETE_NAME
   db::MhcTypes::LK_NMDP_CODE_TABLE     -- LK_NMDP_CODE

The following Allele Name Validation Processing Columns

   db::MhcTypes::ALLELE_NAME_COL         -- allele_name
   db::MhcTypes::CREATED_BY_COL          -- created_by
   db::MhcTypes::DATE_CREATED_COL        -- date_created
   db::MhcTypes::DATE_LAST_UPDATED_COL   -- date_last_updated
   db::MhcTypes::DATE_OF_DELETION_COL    -- date_of_deletion
   db::MhcTypes::DELETED_ALLELE_NAME_COL -- deleted_allele_name
   db::MhcTypes::GROUP_CODE_COL          -- group_code
   db::MhcTypes::G_CODE_COL              -- g_code
   db::MhcTypes::HLA_PROTEIN_NAME_COL    -- hla_protein_name
   db::MhcTypes::IDENTICAL_TO_COL        -- identical_to
   db::MhcTypes::IMGT_HLA_VERSION_COL    -- imgt_hla_version
   db::MhcTypes::LAST_UPDATED_BY_COL     -- last_updated_by
   db::MhcTypes::NEW_ALLELE_NAME_COL     -- new_allele_name
   db::MhcTypes::NMDP_CODE_COL           -- nmdp_code
   db::MhcTypes::OLD_ALLELE_NAME_COL     -- old_allele_name
   db::MhcTypes::REASON_COL              -- reason
   db::MhcTypes::SUBTYPE_COL             -- subtype
   db::MhcTypes::SUGGESTED_NAME_COL      -- suggested_name

The Allele population data tables:

   db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE       -- LK_ALLELE_DATA_TYPE
   db::MhcTypes::LK_POP_AREA_TYPE_TABLE          -- LK_POP_AREA_TYPE
   db::MhcTypes::LK_REGION_CWD_ALLELE_TABLE      -- LK_REGION_CWD_ALLELE
   db::MhcTypes::MHC_HLA_ALLELE_FREQ_MAP_TABLE   -- MHC_HLA_ALLELE_FREQ_MAP
   db::MhcTypes::MHC_HLA_ALLELE_FREQ_TABLE       -- MHC_HLA_ALLELE_FREQ
   db::MhcTypes::MHC_HLA_FREQ_TABLE              -- MHC_HLA_FREQ

The Alele population data columns:

   db::MhcTypes::ALLELE_COUNT_COL     -- allele_count
   db::MhcTypes::ALLELE_FREQ_COL      -- allele_freq
   db::MhcTypes::ALLELE_ID_COL        -- allele_id
   db::MhcTypes::ALLELE_NAME_COL      -- allele_name
   db::MhcTypes::ALLELE_TOTAL_COL     -- allele_total
   db::MhcTypes::AUTHORS_COL          -- authors
   db::MhcTypes::COLLECT_COL          -- collect
   db::MhcTypes::COMPLEX_COL          -- complex
   db::MhcTypes::CWD_ALLELE_COL       -- cwd_allele
   db::MhcTypes::DATA_DESCR_COL       -- data_descr
   db::MhcTypes::DATA_NAME_COL        -- data_name
   db::MhcTypes::DATA_TYPE_ID_COL     -- data_type_id
   db::MhcTypes::ETHNIC_COL           -- ethnic
   db::MhcTypes::HLA_A_1_COL          -- hla_a_1
   db::MhcTypes::HLA_A_2_COL          -- hla_a_2
   db::MhcTypes::HLA_B_1_COL          -- hla_b_1
   db::MhcTypes::HLA_B_2_COL          -- hla_b_2
   db::MhcTypes::HLA_C_1_COL          -- hla_c_1
   db::MhcTypes::HLA_C_2_COL          -- hla_c_2
   db::MhcTypes::HLA_DPA1_1_COL       -- hla_dpa1_1
   db::MhcTypes::HLA_DPA1_2_COL       -- hla_dpa1_2
   db::MhcTypes::HLA_DPB1_1_COL       -- hla_dpb1_1
   db::MhcTypes::HLA_DPB1_2_COL       -- hla_dpb1_2
   db::MhcTypes::HLA_DQA1_1_COL       -- hla_dqa1_1
   db::MhcTypes::HLA_DQA1_2_COL       -- hla_dqa1_2
   db::MhcTypes::HLA_DQB1_1_COL       -- hla_dqb1_1
   db::MhcTypes::HLA_DQB1_2_COL       -- hla_dqb1_2
   db::MhcTypes::HLA_DRB1_1_COL       -- hla_drb1_1
   db::MhcTypes::HLA_DRB1_2_COL       -- hla_drb1_2
   db::MhcTypes::LATITUDE_COL         -- latitude
   db::MhcTypes::LOCUS_ID_COL         -- locus_id
   db::MhcTypes::LOCUS_NAME_COL       -- locus_name
   db::MhcTypes::LONGITUDE_COL        -- longitude
   db::MhcTypes::METHOD_COL           -- method
   db::MhcTypes::MISMATCH1_COL        -- mismatch1
   db::MhcTypes::MISMATCH2_COL        -- mismatch2
   db::MhcTypes::MISMATCH3_COL        -- mismatch3
   db::MhcTypes::MISMATCH4_COL        -- mismatch4
   db::MhcTypes::MISMATCH5_COL        -- mismatch5
   db::MhcTypes::MISMATCH6_COL        -- mismatch6
   db::MhcTypes::MISMATCH7_COL        -- mismatch7
   db::MhcTypes::MISMATCH8_COL        -- mismatch8
   db::MhcTypes::MRWAF_FREQUENCY_COL  -- mrwaf_frequency
   db::MhcTypes::POPULATION_COL       -- population
   db::MhcTypes::POP_AREA_ABBRV_COL   -- pop_area_abbrv
   db::MhcTypes::POP_AREA_COL         -- pop_area
   db::MhcTypes::POP_AREA_DESCR_COL   -- pop_area_descr
   db::MhcTypes::POP_AREA_ID_COL      -- pop_area_id
   db::MhcTypes::POP_AREA_NAME_COL    -- pop_area_name
   db::MhcTypes::REGION_FREQUENCY_COL -- region_frequency
   db::MhcTypes::REPORT_COL           -- report
   db::MhcTypes::SOURCE_COL           -- source
   db::MhcTypes::SUBJECT_COL          -- subject

The homo sapiens taxonomy id:

   db::MhcTypes::HOMO_SAPIENS_TAXON -- 9606

The Population Area column for ambiguity reduction:

   db::MhcTypes::POPULATION_AREA_COL          -- Population Area
   db::MhcTypes::NONE_OF_THE_ABOVE_POPULATION -- None of the Above

and the static method:

   db::MhcTypes::IS_POPULATION_AREA_COL
   -- Boolean method that determine the correctness of the population
      area column

The standard ambiguous allele separator:

   db::MhcTypes::STANDARD_AMBIGUOUS_ALLELE_SEPARATOR -- '/'

The controlled IMGT/HLA versions:

   db::MhcTypes::IMGT_HLA_V2 -- 2
   db::MhcTypes::IMGT_HLA_V3 -- 3

The static method DEFINED_IMGT_HLA_VERSION($version) returns a boolean
value based on whether the IMGT/HLA version is a controlled version
(TRUE) or not (FALSE).

The following controlled vocabulary names are exported:

   Seq Type
   db::MhcTypes::AA_SEQ   -- AA
   db::MhcTypes::DNA_SEQ  -- DNA
   db::MhcTypes::MRNA_SEQ -- mRNA
   db::MhcTypes::CDS_SEQ  -- CDS

   Gene Structure Type Names
   db::MhcTypes::INTRON          -- intron
   db::MhcTypes::EXON            -- exon
   db::MhcTypes::PARTIAL_EXON    -- partial exon
   db::MhcTypes::FIVE_PRIME_UTR  -- 5 prime utr
   db::MhcTypes::THREE_PRIME_UTR -- 3 prime utr
   db::MhcTypes::INSERT          -- insert
   db::MhcTypes::CODON           -- codon
   db::MhcTypes::PROTEIN         -- protein
   db::MhcTypes::MATURE_PROTEIN  -- mature protein
   db::MhcTypes::UNSEQUENCED     -- unsequenced
   db::MhcTypes::PSEUDO_GENE     -- pseudo gene

   HLA Pseudo Gene
   db::MhcTypes::HLA_PSEUDO_GENE -- HLA-P

   CDS Structure Type Names
   db::MhcTypes:::EXACT_INTERVAL               -- exact
   db::MhcTypes:::OPEN_LEFT_INTERVAL           -- open left
   db::MhcTypes:::OPEN_RIGHT_INTERVAL          -- open right
   db::MhcTypes:::OPEN_LEFT_AND_RIGHT_INTERVAL -- open left and right

   Alignment Types
   db::MhcTypes::ALIGNMENT_SEQ_TYPE -- alignment_seq
   db::MhcTypes::VARIANT_SEQ_TYPE   -- variant_seq

   Alignment View Types
   db::MhcTypes::EXON_VIEW            -- exon
   db::MhcTypes::CODON_EXON_VIEW      -- codon, exon
   db::MhcTypes::UTR_EXON_INTRON_VIEW -- utr, exon, intron

   Allele Data Types
   db::MhcTypes::ALLELE_GROUP_DATA_TYPE -- allele group
   db::MhcTypes::HLA_PROTEIN_DATA_TYPE  -- HLA protein

   Replacement Types
   db::MhcTypes::CHANGED_ALLELE_TYPE    -- changed allele name
   db::MhcTypes::DELETED_ALLELE_TYPE    -- deleted allele name

The following method returns the standard order (referenced array)
of categories of an allele name:

   db::MhcTypes::NOMENCLATURE_ORDER
   - db::MhcTypes::ALLELE_GROUP_COL
   - db::MhcTypes::HLA_PROTEIN_COL,
   - db::MhcTypes::CODING_REGION_COL
   - db::MhcTypes::NON_CODING_REGION_COL

The following Oracle date specific constants are exported:

   Standard Oracle Date Format
   db::MhcTypes:::ORACLE_DATE_FORMAT -- DD-Mon-yyyy:hh24:mi:ss

   Oracle Date Format Columns
   db::MhcTypes::ORACLE_DATES
   -- list
      - db::MhcTypes::ANNOT_UPDATE_DATE_COL
      - db::MhcTypes::SEQ_CREATE_DATE_COL
      - db::MhcTypes::SEQ_UPDATE_DATE_COL

The tables as controlled vocabulary and others:

   db::MhcTypes::CONTROLLED_VOCABULARIES
   -- list of controlled vocabulary tables
      - db::MhcTypes::ALIGNMENT_TYPE_TABLE
      - db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE
      - db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE
      - db::MhcTypes::EVIDENCE_AUTHORITY_TABLE
      - db::MhcTypes::FEATURE_TYPE_TABLE
      - db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE
      - db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE
      - db::MhcTypes::LK_POP_AREA_TYPE_TABLE
      - db::MhcTypes::MHC_LOCUS_TABLE
      - db::MhcTypes::PDB_PROTEIN_TABLE
      - db::MhcTypes::PDB_STRUCTURE_TABLE
      - db::MhcTypes::REPLACEMENT_TYPE_TABLE
      - db::MhcTypes::SEQ_TYPE_TABLE
      - db::MhcTypes::TAXONOMY_TABLE

   db::MhcTypes::ORACLE_CONTROLLED_VOCABULARIES
   -- list of controlled vocabulary tables
      - db::MhcTypes::ALIGNMENT_TYPE_TABLE
      - db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE
      - db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE
      - db::MhcTypes::EVIDENCE_AUTHORITY_TABLE
      - db::MhcTypes::FEATURE_TYPE_TABLE
      - db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE
      - db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE
      - db::MhcTypes::MHC_LOCUS_TABLE
      - db::MhcTypes::PDB_PROTEIN_TABLE
      - db::MhcTypes::PDB_STRUCTURE_TABLE
      - db::MhcTypes::REPLACEMENT_TYPE_TABLE
      - db::MhcTypes::SEQ_TYPE_TABLE
      - db::MhcTypes::TAXONOMY_TABLE


=head1 STATIC METHODS

The following static methods are exported by this class.

=head2 B<my $table_info = sequenceVariationTableInfo>

This static method returns the table specification (referenced hash) information
for the mhc sequence variation schema.

=head2 B<db::MhcTypes::initializeControlledVocabularies(db, error_mgr)>

This static method loads all the controlled vocabulary data for the schema
from the database.  The current controlled vocabulary tables include the
following tables:

   db::MhcTypes::ALIGNMENT_TYPE_TABLE
   db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE
   db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE
   db::MhcTypes::EVIDENCE_AUTHORITY_TABLE
   db::MhcTypes::FEATURE_TYPE_TABLE
   db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE
   db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE
   db::MhcTypes::LK_POP_AREA_TYPE_TABLE
   db::MhcTypes::MHC_LOCUS_TABLE
   db::MhcTypes::REPLACEMENT_TYPE_TABLE
   db::MhcTypes::SEQ_TYPE_TABLE
   db::MhcTypes::TAXONOMY_TABLE

Also, it generates data maps for the following data:

   - reference allele mapping locus_id -> allele_name by taxon
   - variant_seq_structure data
   - feature allele mapping locus_id -> allele_name by taxon
   - mapping of allele_name to locus_id and allele_id

If any of the controlled vocabularies or mapping data is missing, the
method that return this information will return undef.

=head2 B<my $infinite_time = infiniteTime>

This method returns the infinite time B<99999999999>.

=head2 B<oracleDate(col)>

This method returns TRUE (1) is the B<col> is an oracle date.

=head2 B<my $id = getId(table, name[, taxonomy_id])>

This method returns the id for the B<name> in the B<table>.  This
method assumes that B<initializeControlledVocabularies> has been
executed. If the key includes B<taxonomy_id>, then it is required.
Currently, the B<taxonomy_id> is required for the following tables:

   db::MhcTypes::MHC_LOCUS_TABLE

The name column for the tables is specified below:

   db::MhcTypes::ALIGNMENT_TYPE_TABLE
   db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE
   db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE
   db::MhcTypes::EVIDENCE_AUTHORITY_TABLE
   db::MhcTypes::FEATURE_TYPE_TABLE
   db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE
   db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE
   db::MhcTypes::LK_POP_AREA_TYPE_TABLE
   db::MhcTypes::REPLACEMENT_TYPE_TABLE
   db::MhcTypes::SEQ_TYPE_TABLE
   db::MhcTypes::TAXONOMY_TABLE

=head2 B<my $name = getName(table, id)>

This method returns the value (name/id) associated with the B<id> in
the B<table>. This method assumes that
B<initializeControlledVocabularies> has been executed. The id column
for the tables is specified below:

   db::MhcTypes::ALIGNMENT_TYPE_TABLE
   db::MhcTypes::ALIGNMENT_VIEW_TYPE_TABLE
   db::MhcTypes::CDS_STRUCTURE_TYPE_TABLE
   db::MhcTypes::EVIDENCE_AUTHORITY_TABLE
   db::MhcTypes::FEATURE_TYPE_TABLE
   db::MhcTypes::GENE_STRUCTURE_TYPE_TABLE
   db::MhcTypes::LK_ALLELE_DATA_TYPE_TABLE
   db::MhcTypes::LK_POP_AREA_TYPE_TABLE
   db::MhcTypes::MHC_LOCUS_TABLE
   db::MhcTypes::REPLACEMENT_TYPE_TABLE
   db::MhcTypes::SEQ_TYPE_TABLE
   db::MhcTypes::TAXONOMY_TABLE

=head2 B<my $max_id = maxId(table)>

This method returns the current maximum B<id> value as an integer
for the given table.

=head2 B<my @ids = getIds(table)>

This method returns the set of ids assigned to a controlled vocabulary
table.

=head2 B<my $reference_alleles = referenceAlleles(taxonomy_id)>

This method returns a (referenced) hash containing the (key, value)
pairs where the key is a locus_id and the value is a referenced
hash containing the keys, seq_type_id, and values, allele_name for
the given B<taxonomy_id>.

=head2 B<my $variant_seq_structs = variantSeqStructs(taxonomy_id)>

This method returns a (referenced) hash containing the (key, value)
pairs where the key is a locus_id and the value is a referenced
hash containing the keys, seq_type_id, and values, vss_start_pos for
the given B<taxonomy_id>.

=head2 B<my @mhc_loci = getLocusIds(taxonomy_id)>

This method returns the list of locus ids for the the given taxon.  If
there are none, then the list is empty.

=head2 B<my $allele_names = alleleNames(taxonomy_id)>

This method returns a (referenced) hash containing the (key, value)
pairs where the key is an allele_name and the value is a 
(referenced) hash with keys locus_id and allele_id for the given B<taxonomy_id>.

=cut
