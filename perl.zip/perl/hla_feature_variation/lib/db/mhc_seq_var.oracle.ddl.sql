alter table allele
add   (imgt_hla_g_code VARCHAR2(60),
       imgt_hla_p_code VARCHAR2(60));


alter table feature_allele
add   (pdb_positions VARCHAR2(1000),
       pdb_map VARCHAR2(4000));


alter table pdb_protein
add   (molecule VARCHAR2(1000));


alter table allele_nomenclature rename column allele_family to allele_group;

alter table allele_nomenclature 
change column allele_family allele_group      VARCHAR(5) NOT NULL,
change column amino_acid    hla_protein       VARCHAR(5)     NULL,
change column non_coding    coding_region     VARCHAR(5)     NULL,
change column intron        non_coding_region VARCHAR(5)     NULL;

alter table lk_pop_area_type
add   (pop_area_abbrv VARCHAR2(3));

