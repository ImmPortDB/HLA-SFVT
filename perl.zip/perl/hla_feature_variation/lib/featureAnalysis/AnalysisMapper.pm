package featureAnalysis::AnalysisMapper;

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

################################################################################
#
#			Public Static Constants
#
################################################################################

sub ANALYSIS_FILES_MODULUS         { return 25; }
sub FIRST_GENERATED_FILE_OUTPUT_ID { return 1; }

sub analysisFile                { return 'analysisFile'; }
sub analysisSequenceFeatureFile { return 'analysisSequenceFeatureFile'; }
sub analysisSummary             { return 'analysisSummary'; }
sub analysisVariantTypeFile     { return 'analysisVariantTypeFile'; }

sub ANALYSIS_LOG_OUTPUT_OFFSET              { return 0; }
sub ANALYSIS_FILE_OUTPUT_OFFSET             { return 1; }
sub ANALYSIS_SEQUENCE_FEATURE_OUTPUT_OFFSET { return 2; }
sub ANALYSIS_VARIANT_TYPE_OUTPUT_OFFSET     { return 3; }

my $sfvtAnalysisResultIdMap = {
  &analysisFile                => ANALYSIS_FILE_OUTPUT_OFFSET,
  &analysisSequenceFeatureFile => ANALYSIS_SEQUENCE_FEATURE_OUTPUT_OFFSET,
  &analysisSummary             => ANALYSIS_LOG_OUTPUT_OFFSET,
  &analysisVariantTypeFile     => ANALYSIS_VARIANT_TYPE_OUTPUT_OFFSET,
};

my $sfvtAnalysisResultNameMap = {};
while ( my ( $fileType, $offset ) = each %{$sfvtAnalysisResultIdMap} ) {
  $sfvtAnalysisResultNameMap->{$offset} = $fileType;
}

my $mhcLociIdMap = {
  'HLA-A'    => 1,
  'HLA-B'    => 2,
  'HLA-C'    => 3,
  'HLA-DMA'  => 4,
  'HLA-DMB'  => 5,
  'HLA-DOA'  => 6,
  'HLA-DOB'  => 7,
  'HLA-DPA1' => 8,
  'HLA-DPB1' => 9,
  'HLA-DQA1' => 10,
  'HLA-DQB1' => 11,
  'HLA-DRA'  => 12,
  'HLA-DRB1' => 13,
  'HLA-DRB2' => 14,
  'HLA-DRB3' => 15,
  'HLA-DRB4' => 16,
  'HLA-DRB5' => 17,
  'HLA-DRB6' => 18,
  'HLA-DRB7' => 19,
  'HLA-DRB8' => 20,
  'HLA-DRB9' => 21,
  'HLA-E'    => 22,
  'HLA-F'    => 23,
  'HLA-G'    => 24,
  'HLA-H'    => 25,
  'HLA-J'    => 26,
  'HLA-K'    => 27,
  'HLA-L'    => 28,
  'HLA-P'    => 29,
  'HLA-V'    => 30,
  'MICA'     => 31,
  'MICB'     => 32,
  'TAP1'     => 33,
  'TAP2'     => 34,
};

my $mhcLociNameMap = {};
while ( my ( $locusName, $locusId ) = each %{$mhcLociIdMap} ) {
  $mhcLociNameMap->{$locusId} = $locusName;
}

################################################################################
#
#			Public Static Methods
#
################################################################################

sub getOutputId {
  my ( $locusId, $resultName ) = @_;
  return undef
    if ( util::Constants::EMPTY_LINE($locusId)
    || util::Constants::EMPTY_LINE($resultName)
    || $locusId < 1
    || !defined( $sfvtAnalysisResultIdMap->{$resultName} ) );
  my $offset = $sfvtAnalysisResultIdMap->{$resultName};
  my $outputId =
    &FIRST_GENERATED_FILE_OUTPUT_ID +
    ( $locusId - 1 ) * &ANALYSIS_FILES_MODULUS +
    $offset;
  return $outputId;
}

sub getResultName {
  my ($outputId) = @_;
  return undef
    if ( util::Constants::EMPTY_LINE($outputId)
    || $outputId < FIRST_GENERATED_FILE_OUTPUT_ID );
  $outputId += -1;
  my $offset = $outputId % &ANALYSIS_FILES_MODULUS;
  return $sfvtAnalysisResultNameMap->{$offset};
}

sub getLocusId {
  my ($outputId) = @_;
  return undef
    if ( util::Constants::EMPTY_LINE($outputId)
    || $outputId < FIRST_GENERATED_FILE_OUTPUT_ID );
  $outputId += -1;
  my $offset  = $outputId % &ANALYSIS_FILES_MODULUS;
  my $locusId = &FIRST_GENERATED_FILE_OUTPUT_ID +
    int( ( $outputId - $offset ) / &ANALYSIS_FILES_MODULUS );
  return $locusId;
}

sub getLocusName {
  my ($filename) = @_;
  my $locusName = undef;
  return undef if ( util::Constants::EMPTY_LINE($filename) );
  my @comps = split( /\./, $filename );
  return undef if ( $#comps < 1 );
  $locusName = $comps[1];
  return $locusName;
}

sub getLocusIdFromName {
  my ($locusName) = @_;
  return undef if ( util::Constants::EMPTY_LINE($locusName) );
  $locusName = uc($locusName);
  return $mhcLociIdMap->{"$locusName"};
}

sub getLocusNameFromId {
  my ($locusId) = @_;
  return undef if ( util::Constants::EMPTY_LINE($locusId) );
  $locusId = int($locusId);
  return $mhcLociNameMap->{$locusId};
}

################################################################################

1;

__END__

=head1 NAME

AnalysisMapper.pm

=head1 DESCRIPTION

The static class defines the special static constants and method for
converting SFVT analysis HLAVT_ANALYSIS_OUTPUT_ID to MHC_SEQ_VAR locus
ID and full locus names and vice versa.

=head1 STATIC CONSTANTS

The following static constants are exported from this class

The modulus for the SFVT analysis results file sets

   featureAnalysis::AnalysisMapper::ANALYSIS_FILES_MODULUS -- 25

The beginning of the positive HLAVT_OUTPUT_ID values:

   featureAnalysis::AnalysisMapper::FIRST_GENERATED_FILE_OUTPUT_ID -- 1

The result names defined for the SFVT analysis outputs:

   featureAnalysis::AnalysisMapper::analysisFile                -- analysisFile
   featureAnalysis::AnalysisMapper::analysisSequenceFeatureFile -- analysisSequenceFeatureFile
   featureAnalysis::AnalysisMapper::analysisSummary             -- analysisSummary
   featureAnalysis::AnalysisMapper::analysisVariantTypeFile     -- analysisVariantTypeFile

The offsets for the result name data:

   featureAnalysis::AnalysisMapper::ANALYSIS_LOG_OUTPUT_OFFSET              -- 0
   featureAnalysis::AnalysisMapper::ANALYSIS_FILE_OUTPUT_OFFSET             -- 1
   featureAnalysis::AnalysisMapper::ANALYSIS_SEQUENCE_FEATURE_OUTPUT_OFFSET -- 2
   featureAnalysis::AnalysisMapper::ANALYSIS_VARIANT_TYPE_OUTPUT_OFFSET     -- 3

The result name to offset map and the offset to result name maps,
respectively:

   $featureAnalysis::AnalysisMapper::sfvtAnalysisResultIdMap
   $featureAnalysis::AnalysisMapper::sfvtAnalysisResultNameMap

The MHC full locus name to MHC_SEQ_VAR locus ID map and the
MHC_SEQ_VAR locus ID map to MHC full locus name, respectively:

   $featureAnalysis::AnalysisMapper::mhcLociIdMap
   $featureAnalysis::AnalysisMapper::mhcLociNameMap

=head1 STATIC METHODS

The following static methods are exported by this class.

=head2 B<my $outputId = getOutputIdlocusId, resultName)>

This method determines the HLAVT_OUTPUT_ID for the given locus ID and
resultName for SFVT analysis outputs.

=head2 B<my $resultName = getResultName(outputId)>

This method determine the resultName for the given positive outputId
for an SFVT analysis HLAVT_OUTPUT_ID.

=head2 B<my $locusId = getLocusId(outputId)>

This method determine the MHC_SEQ_VAR locus ID for the given positive
outputId for an SFVT analysis HLAVT_OUTPUT_ID.

=head2 B<my $locusName = getLocusName(filename)>

This method determines the locus name embedded in the filename
assuming that the file was generated as part of an SFVT analysis.

=head2 B<my $locusId = getLocusIdFromName(locusName)>

This method returns the locus ID defined in MHC_SEQ_VAR for the given
full locus name.

=head2 B<my $locusName = getLocusNameFromId(locusId)>

This method returns the full locus name for the MHC_SEQ_VAR locus ID.

=cut
