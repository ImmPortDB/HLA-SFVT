package featureAnalysis::Variant;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;
use FileHandle;
use File::Basename;

use util::Constants;
use util::Messaging;
use util::PathSpecifics;
use util::QueryMgr;

use db::MhcTypes;

use featureAnalysis::AnalysisTypes;
use featureAnalysis::ErrMsgs;

use fields qw (
  column_separator
  error_mgr
  generated_files
  hla_map
  loci
  msgs
  out_file
  optional_columns
  query_mgr
  reader
  seq_type_id
  taxon_id
  tools
  variant_map
  writer
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Special ID's for special types
###
sub NULL_TYPE_ID    { return "-1"; }
sub NO_DATA_TYPE_ID { return "-2"; }
###
### Queries for feature types
###
sub FEATURE_QUERY { return '_featureQuery_'; }
sub VARIANT_QUERY { return '_variantQuery_'; }

sub DB_QUERIES {
  return {
    &FEATURE_QUERY => {
      key => db::MhcTypes::FEATURE_ID_COL,
      ord => [
        db::MhcTypes::FEATURE_ID_COL, db::MhcTypes::FEATURE_NUMBER_COL,
        db::MhcTypes::FEATURE_NAMES_COL,
      ],
      cmd => "
select   a.feature_id,
         b.feature_number,
         b.feature_names
from     variant_type a,
         feature      b
where    b.locus_id    = ?
and      b.seq_type_id = ?
and      a.feature_id  = b.feature_id
",
    },

    &VARIANT_QUERY => {
      key => db::MhcTypes::VARIANT_ID_COL,
      ord => [
        db::MhcTypes::VARIANT_ID_COL, db::MhcTypes::FEATURE_NUMBER_COL,
        db::MhcTypes::VARIANT_TYPE_NAME_COL,
      ],
      cmd => "
select   a.variant_id,
         c.feature_number,
         a.variant_type_name
from     variant_type     a,
         variant_2_allele b,
         feature          c
where    b.allele_name = ?
and      c.seq_type_id = ?
and      a.variant_id  = b.variant_id
and      a.feature_id  = c.feature_id
",
    },

  };
}
###
### Error Category
###
sub ERR_CAT { return featureAnalysis::ErrMsgs::VARIANT_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub entityOrd { $a <=> $b; }

sub _createWriter {
  my featureAnalysis::Variant $this = shift;

  my $query_mgr = $this->{query_mgr};
  my $reader    = $this->{reader};
  my $tools     = $this->{tools};
  ###
  ### Create writer
  ###
  $this->{writer} =
    $tools->getMhcFileReader( $tools->FeatureReader, $reader->type, undef,
    $this->{taxon_id}, $this->{seq_type_id} );
  my $writer = $this->{writer};
  $writer->setOptCols( $reader->getOptCols );
  ###
  ### First get the hla order and the mapping to the input file
  ###
  my $hla_data = {};
  my $hla_ord  = [];
  my $hla_map  = {};
  foreach my $col_name ( $reader->getEntityCols ) {
    my $locus_data = $reader->getEntityData($col_name);
    last if ( !defined($locus_data) );
    my $locus_id = $locus_data->{locus_id};
    if ( !defined( $hla_data->{$locus_id} ) ) {
      my $locus_struct = { %{$locus_data} };
      $locus_struct->{allele_1} = {};
      push( @{$hla_ord}, $locus_struct );
      $hla_data->{ $locus_data->{locus_id} } = $locus_struct;
      $hla_map->{$col_name} = $locus_struct->{allele_1};
    }
    else {
      my $locus_struct = $hla_data->{ $locus_data->{locus_id} };
      $locus_struct->{allele_2} = {};
      $hla_map->{$col_name} = $locus_struct->{allele_2};
    }
  }
  $this->{hla_map} = $hla_map;
  ###
  ### Second, generate the feature list
  ###
  my $var_cols = [];
  my $names    = {};
  foreach my $locus_struct ( @{$hla_ord} ) {
    $query_mgr->execute( FEATURE_QUERY, $locus_struct->{locus_id},
      $this->{seq_type_id} );
    foreach my $feature_id (
      sort featureAnalysis::Variant::entityOrd $query_mgr->getDataKeys(
        FEATURE_QUERY) )
    {
      my $struct = $query_mgr->getData( FEATURE_QUERY, $feature_id );
      my $allele_1_feature =
        $writer->mhcType->entityNameToColName( $struct->{feature_number}, 1 );
      my $allele_2_feature =
        $writer->mhcType->entityNameToColName( $struct->{feature_number}, 2 );
      $locus_struct->{allele_1}->{ $struct->{feature_number} } =
        $allele_1_feature;
      $locus_struct->{allele_2}->{ $struct->{feature_number} } =
        $allele_2_feature;
      push( @{$var_cols}, $allele_1_feature, $allele_2_feature );
      $names->{$allele_1_feature} = $struct->{feature_names};
    }
    $query_mgr->resetResult(FEATURE_QUERY);
  }
  $writer->setVarCols( $tools->versionInfo, $names, $var_cols );
  ###
  ### Now set the column structure for the variant file
  ###
  foreach my $entity ( $reader->getData ) {
    my $vEntity = { $writer->ROW_ID_COL => $entity->{ $reader->ROW_ID_COL }, };
    foreach my $col_name ( $writer->getInitialCols ) {
      $vEntity->{$col_name} = $entity->{$col_name};
    }
    $writer->addEntity($vEntity);
  }
}

sub _getAlleleVariants {
  my featureAnalysis::Variant $this = shift;
  my ( $allele, $variants, $col_name ) = @_;

  my $query_mgr = $this->{query_mgr};
  my $msgs      = $this->{msgs};
  ###
  ### First, get the variants for the the allele,
  ### if not already defined and store them for
  ### future use.
  ###
  if ( $allele !~ /N$/ && !defined( $this->{variant_map}->{$allele} ) ) {
    my $allele_variants = {};
    my $found_data      = util::Constants::FALSE;
    $query_mgr->execute( VARIANT_QUERY, $allele, $this->{seq_type_id} );
    foreach my $variant_id ( $query_mgr->getDataKeys(VARIANT_QUERY) ) {
      $found_data = util::Constants::TRUE;
      my $struct       = $query_mgr->getData( VARIANT_QUERY, $variant_id );
      my $fn           = $struct->{feature_number};
      my $variant_type = $struct->{variant_type_name};
      if ( !defined( $allele_variants->{$fn} ) ) {
        $allele_variants->{$fn} = {};
      }
      $allele_variants->{$fn}->{$variant_id} = $variant_type;
    }
    $query_mgr->resetResult(VARIANT_QUERY);
    if ($found_data) {
      $this->{variant_map}->{$allele} = $allele_variants;
    }
    else {
      ###
      ### Allele is not assigned variants
      ###
      $this->{variant_map}->{$allele} = util::Constants::EMPTY_STR;
    }
  }
  ###
  ### Second, add the variants for the
  ### allele to the current variants
  ###
  ### There are three cases:
  ### 1.  Null for Null alleles
  ### 2.  For defined alleles (these may be unknown type)
  ### 3.  No Data for alleles with no type
  ###
  my $allele_variants = $this->{variant_map}->{$allele};
  if ( $allele =~ /N$/ ) {
    ###
    ### Null alleles are handled as Null
    ###
    my $featureColumns = $this->{hla_map}->{$col_name};
    foreach my $feature_name ( keys %{$featureColumns} ) {
      if ( !defined( $variants->{$feature_name} ) ) {
        $variants->{$feature_name} = {};
      }
      $variants->{$feature_name}->{&NULL_TYPE_ID} =
        featureAnalysis::AnalysisTypes::NULL_TYPE;
    }
  }
  elsif ( !util::Constants::EMPTY_LINE($allele_variants) ) {
    ###
    ### Variants exist for the allele, so add them
    ###
    while ( my ( $feature_name, $variant_struct ) = each %{$allele_variants} ) {
      if ( !defined( $variants->{$feature_name} ) ) {
        $variants->{$feature_name} = {};
      }
      foreach my $variant_id ( keys %{$variant_struct} ) {
        $variants->{$feature_name}->{$variant_id} =
          $variant_struct->{$variant_id};
      }
    }
  }
  else {
    ###
    ### Variants for the allele do not exist, so assign empty
    ### variants for all features if not already defined.
    ### Also, count the missing feature allele
    ###
    my $featureColumns = $this->{hla_map}->{$col_name};
    foreach my $feature_name ( keys %{$featureColumns} ) {
      if ( !defined( $variants->{$feature_name} ) ) {
        $variants->{$feature_name} = {};
      }
      $variants->{$feature_name}->{&NO_DATA_TYPE_ID} =
        featureAnalysis::AnalysisTypes::NO_DATA_TYPE;
    }
    $msgs->incStatistic( $msgs->dataTypeCounter, $msgs->locusNameTag,
      $msgs->getLocusName, $msgs->dataTypeTag,
      $msgs->missingFeatureDataTagValue );
  }
}

sub _generateVariant {
  my featureAnalysis::Variant $this = shift;
  my ( $entity, $col_name, @comps ) = @_;

  my $reader = $this->{reader};
  my $msgs   = $this->{msgs};
  ###
  ### Compute the Variant Mapping
  ###
  my $variants  = {};
  my $alleles   = {};
  my $locusData = $reader->getEntityData($col_name);
  foreach my $allele (@comps) {
    $msgs->incStatistic(
      $msgs->dataTypeCounter, $msgs->locusNameTag,
      $msgs->getLocusName,    $msgs->dataTypeTag,
      $msgs->alleleGroupTagValue
    ) if ( $allele =~ /^[0-9]+$/ );
    $msgs->incStatistic(
      $msgs->dataTypeCounter, $msgs->locusNameTag,
      $msgs->getLocusName,    $msgs->dataTypeTag,
      $msgs->nullAlleleTagValue
    ) if ( $allele =~ /^[0-9:]+N$/ );
    $msgs->incStatistic(
      $msgs->dataTypeCounter,
      $msgs->locusNameTag,
      $msgs->getLocusName,
      $msgs->dataTypeTag,
      $allele =~ /G$/ ? $msgs->gCodeTagValue : $msgs->pCodeTagValue
    ) if ( $allele =~ /(G|P)$/ );
    my $orig_allele = $allele;
    ###
    ### Only proceed with alleles that have a protein
    ###
    next if ( $allele !~ /^([0-9]+:[0-9]+)/ );
    $allele = $1;
    ###
    ### If the allele is a null allele, then use the original allele
    ###
    if ( $orig_allele =~ /N$/ ) { $allele = $orig_allele; }
    ###
    ### If already a defined protein for this cell, go to next
    ###
    next if ( defined( $alleles->{$allele} ) );
    ###
    ### Now generate variant types
    ###
    $alleles->{$allele} = util::Constants::EMPTY_STR;
    $allele =
      $locusData->{short_locus_name} . util::Constants::ASTERISK . $allele;
    $this->_getAlleleVariants( $allele, $variants, $col_name );
  }
  ###
  ### Update the Entity
  ###
  my $featureColumns = $this->{hla_map}->{$col_name};
  while ( my ( $feature_name, $variant_struct ) = each %{$variants} ) {
    my $col           = $featureColumns->{$feature_name};
    my @variant_types = ();
    foreach my $variant_id (
      sort featureAnalysis::Variant::entityOrd keys %{$variant_struct} )
    {
      push( @variant_types, $variant_struct->{$variant_id} );
    }
    my $tag_value = undef;
    if ( @variant_types == 1 ) {
      my $variant_type = $variant_types[0];
      if ( $variant_type eq featureAnalysis::AnalysisTypes::NO_DATA_TYPE ) {
        $tag_value = $msgs->noDataVariantTagValue;
      }
      elsif ( $variant_type eq featureAnalysis::AnalysisTypes::UNKOWN_TYPE ) {
        $tag_value = $msgs->unknownVariantTagValue;
      }
      elsif ( $variant_type eq featureAnalysis::AnalysisTypes::NULL_TYPE ) {
        $tag_value = $msgs->nullVariantTagValue;
      }
      else {
        $tag_value = $msgs->definedVariantTagValue;
      }
      $entity->{$col} = $variant_type;
    }
    elsif ( @variant_types > 1 ) {
      $tag_value = $msgs->ambiguousVariantTagValue;
      $entity->{$col} = featureAnalysis::AnalysisTypes::AMBIGUOUS_TYPE;
    }
    else {
      ###
      ### This alternative should not occur
      ###
      $msgs->registerError(
        ERR_CAT, 2,
        [
          $feature_name, $entity->{ $reader->ROW_ID_COL },
          $col_name, join( util::Constants::COMMA_SEPARATOR, @comps )
        ],
        util::Constants::TRUE
      );
      $tag_value = $msgs->noDataVariantTagValue;
      $entity->{$col} = featureAnalysis::AnalysisTypes::NO_DATA_TYPE;
    }
    $msgs->incStatistic( $msgs->variantFeatureCounter,
      $msgs->locusNameTag, $msgs->getLocusName, $msgs->dataTypeTag,
      $tag_value );
  }
}

sub _determineNonEmptyLoci {
  my featureAnalysis::Variant $this = shift;

  my $reader = $this->{reader};
  $this->{loci} = {};
  foreach my $r_entity ( $reader->getData ) {
    foreach my $col_name ( $reader->getEntityCols ) {
      next if ( $reader->emptyCell( $r_entity->{$col_name} ) );
      my $locus_data = $reader->getEntityData($col_name);
      my $locus_name = $locus_data->{full_entity_name};
      $this->{loci}->{$locus_name} = util::Constants::EMPTY_STR;
    }
  }
}

sub _emptyLocus {
  my featureAnalysis::Variant $this = shift;
  my ($locus_col) = @_;

  my $reader     = $this->{reader};
  my $loci       = $this->{loci};
  my $locus_data = $reader->getEntityData($locus_col);
  my $locus_name = $locus_data->{full_entity_name};
  return ( !defined( $loci->{$locus_name} ) )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

sub _onlyAlleleGroup {
  my featureAnalysis::Variant $this = shift;
  my (@comps) = @_;

  foreach my $allele (@comps) {
    return util::Constants::FALSE if ( $allele !~ /^[0-9]+$/ );
  }
  ###
  ### Only allele group so now record them all as such
  ###
  my $msgs = $this->{msgs};
  foreach (@comps) {
    $msgs->incStatistic(
      $msgs->dataTypeCounter, $msgs->locusNameTag,
      $msgs->getLocusName,    $msgs->dataTypeTag,
      $msgs->alleleGroupTagValue
    );
  }
  return util::Constants::TRUE;
}

sub _writeOptionalColumns {
  my featureAnalysis::Variant $this = shift;
  my ($property_data) = @_;

  my $reader = $this->{reader};
  my $tools  = $this->{tools};
  my $cmds   = $tools->cmds;

  my $fh = new FileHandle;
  $fh->open( $this->optionalColumns, ">" );
  $fh->autoflush(util::Constants::TRUE);
  my $subject_phenotype_col =
    lc(featureAnalysis::AnalysisTypes::SUBJECT_PHENOTYPE_COL);
  foreach my $optional_column ( $reader->getOptCols ) {
    my $column_type = undef;
    $optional_column = strip_whitespace($optional_column);
    if ( lc($optional_column) eq $subject_phenotype_col ) {
      $column_type = featureAnalysis::AnalysisTypes::PHENOTYPE_TYPE;
      push(
        @{$property_data},
        {
          $tools->PROPERTY_COL => "Phenotype column",
          $tools->VALUE_COL    => $optional_column,
        }
      );
    }
    elsif ( db::MhcTypes::IS_POPULATION_AREA_COL($optional_column) ) {
      $column_type = featureAnalysis::AnalysisTypes::POPULATION_TYPE;
    }
    else {
      $column_type = featureAnalysis::AnalysisTypes::OPTIONAL_TYPE;
    }
    $fh->print(
      join( $this->{column_separator}, $optional_column, $column_type )
        . util::Constants::NEWLINE );
  }
  $fh->close;
  $cmds->executeCommand(
    { file => $this->{optional_columns} },
    $cmds->TOUCH_CMD( $this->{optional_columns} ),
    "Guarantee optionl columns exists"
  );

}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my featureAnalysis::Variant $this = shift;
  my ( $file_reader, $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{column_separator} = undef;
  $this->{error_mgr}        = $error_mgr;
  $this->{loci}             = {};
  $this->{optional_columns} = undef;
  $this->{out_file}         = undef;
  $this->{reader}           = $file_reader;
  $this->{taxon_id}         = $taxon_id;
  $this->{tools}            = $tools;
  $this->{variant_map}      = {};

  $this->{msgs} =
    new util::Messaging( $file_reader, $taxon_id,
    $tools->getProperty( $tools->WRITE_MSGS_PROP ),
    $tools, $error_mgr );

  $this->{seq_type_id} =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::AA_SEQ );
  ###
  ### Setup the local queries
  ###
  $this->{query_mgr} = new util::QueryMgr( $tools->getSession, $error_mgr );
  $this->{query_mgr}->createAll(DB_QUERIES);
  $this->{query_mgr}->prepareQueries;

  return $this;
}

sub setOutFile {
  my featureAnalysis::Variant $this = shift;
  my ($file) = @_;
  ###
  ### Check for '.txt' since the file will contain tab-separated data
  ###
  my $tools = $this->{tools};
  my $file_error =
    !( $file =~ /\.txt$/ || ( $tools->getTreatXlsAsTxt && $file =~ /\.xls$/ ) );
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$file], $file_error );
  return if ($file_error);

  $this->{out_file} = getPath($file);
}

sub outFile {
  my featureAnalysis::Variant $this = shift;
  return $this->{out_file};
}

sub setGeneratedFiles {
  my featureAnalysis::Variant $this = shift;
  my ($generatedFiles) = @_;
  $this->{generated_files} = getPath($generatedFiles);
}

sub setOptionalColumns {
  my featureAnalysis::Variant $this = shift;
  my ($optionalColumns) = @_;
  $this->{optional_columns} = getPath($optionalColumns);
}

sub optionalColumns {
  my featureAnalysis::Variant $this = shift;

  return $this->{optional_columns};
}

sub setColumnSeparator {
  my featureAnalysis::Variant $this = shift;
  my ($separator) = @_;
  $this->{column_separator} = $separator;
}

sub processFile {
  my featureAnalysis::Variant $this = shift;

  my $reader = $this->{reader};
  my $msgs   = $this->{msgs};
  my $tools  = $this->{tools};

  my $ambiguous_allele_separator =
    db::MhcTypes::STANDARD_AMBIGUOUS_ALLELE_SEPARATOR;
  ###
  ### Read HLA data
  ###
  $reader->openReader;
  ###
  ### Create Vector File Writer
  ###
  ### Creation of the vector file writer generates all
  ### the column necessary for generation vector results
  ### for the loci in the file and sets up entities
  ### by ROW_ID_COL and having the same initial columns
  ### as the input file
  ###
  $this->_createWriter;
  my $writer = $this->{writer};
  ###
  ### Determine which loci in the file
  ### have non-empty allele data
  ###
  $this->_determineNonEmptyLoci;
  ###
  ### Process HLA data
  ###
  $msgs->resetRowNum;
  foreach my $r_entity ( $reader->getData ) {
    ###
    ### Determine if the row is empty (no id and no data)
    ###
    next if ( $reader->noIdData($r_entity) );
    ###
    ### Capture subject information
    ###
    $msgs->addDataCapture( $msgs->SUBJECT_TABLE,
      $r_entity->{ $reader->getIdCol } );
    ###
    ### Now process row
    ###
    $msgs->incRowNum;
    my $id       = $r_entity->{ $reader->ROW_ID_COL };
    my $w_entity = $writer->getEntity($id);
    foreach my $col_name ( $reader->getEntityCols ) {
      ###
      ### Process only non-empty Loci
      ###
      next if ( $this->_emptyLocus($col_name) );

      $msgs->initializeMsgs( $col_name, $r_entity );
      my $cell  = $r_entity->{$col_name};
      my @comps = ();
      if ( !$reader->emptyCell($cell) ) {
        $cell = strip_whitespace($cell);
        ###
        ### Separate cell based on separator
        ###
        @comps = ($cell);
        if ( $cell =~ /$ambiguous_allele_separator/ ) {
          @comps = split( /$ambiguous_allele_separator/, $cell );
        }
      }
      ###
      ### Must supply recording of empty cells and allele group data
      ###
      if ( @comps == 0 || $this->_onlyAlleleGroup(@comps) ) {
        ###
        ### Set all features as no data and count as no data
        ###
        my $featureColumns = $this->{hla_map}->{$col_name};
        while ( my ( $feature_name, $col ) = each %{$featureColumns} ) {
          $w_entity->{$col} = featureAnalysis::AnalysisTypes::NO_DATA_TYPE;
          $msgs->incStatistic(
            $msgs->variantFeatureCounter, $msgs->locusNameTag,
            $msgs->getLocusName,          $msgs->dataTypeTag,
            $msgs->noDataVariantTagValue
          );
        }
      }
      else {
        $this->_generateVariant( $w_entity, $col_name, @comps );
      }
      $msgs->finalizeMsgs;
    }
  }

  return if ( !defined( $this->outFile ) );
  my @property_data = ();
  my $hla_infix     = $tools->HLA_INFIX;
  my $task_infix    = $tools->TASK_INFIX;
  my $task_id       = $tools->getProperty( $tools->TASK_ID_PROP );
  my $fh            = new FileHandle;
  $fh->open( $this->{generated_files}, ">" );
  $fh->autoflush(util::Constants::TRUE);

  foreach my $locus_name ( sort $msgs->getLocusNames ) {
    next
      if (
      $msgs->getCount( $msgs->cellCounter, $msgs->locusNameTag, $locus_name ) ==
      0 );
    my $out_file = $this->outFile;
    $out_file =~ s/$task_infix/$task_id/;
    $out_file =~ s/$hla_infix/$locus_name/;
    push(
      @property_data,
      {
        $tools->PROPERTY_COL => "$locus_name Variant file",
        $tools->VALUE_COL    => basename($out_file),
      }
    );
    $writer->writeFile( $out_file, $locus_name );
    $fh->print("$out_file\n");
  }
  $fh->close;
  ###
  ### Write the optional columns file
  ###
  $this->_writeOptionalColumns( \@property_data );
  ###
  ### Finally, print all the statistics
  ###
  $msgs->printVariantStatistics(@property_data);
}

################################################################################

1;

__END__

=head1 NAME

Variant.pm

=head1 DESCRIPTION

This concrete class defines the mechanism for processng an hla file
into a set of sequence feature variant vector files (one per Locus).

=head1 METHODS

The following methods are exported by this class.

=head2 B<new featureAnalysis::Variant(file_reader, taxon_id, tools, error_mgr)>

This is the constructor for the class.  The file to process is
represented by the B<file_reader> object, an instance of a subclass of
L<file::Mhc::Hla>, the tools object
(L<util::Tools::mhcSeqVar::qualityControl>), and the error logger
(L<util::ErrMgr>).  The taxon_id specifies the species that is being
processed.  Currently, it must be B<9606> (Homo sapiens).

The construct starts messaging using the class L<util::Messaging> and
sets up loading sequence feature data into object from the database,
as necessary.

=head2 B<processFile>

This method constructs the sequence feature variant vector files, one
per locus, for all non-empty allele data that appears in the input
file.  Each cell can be an allele/G-Code/P-Code or an ambiguous allele
that is a combination of allele, G-Code and P-Code.  

During vector file generation the following data types are captured
for all features alleles/codes in the cells:

   util::Messaging::alleleGroupTagValue         -- Allele Group
   util::Messaging::ambiguousVariantTagValue    -- Ambiguous Type
   util::Messaging::definedVariantTagValue      -- Defined Type
   util::Messaging::gCodeTagValue               -- G-Code
   util::Messaging::missingFeatureDataTagValue  -- Missing SFVT data
   util::Messaging::noDataVariantTagValue       -- No Data
   util::Messaging::nullAlleleTagValue          -- NULL Allele
   util::Messaging::nullVariantTagValue         -- Null
   util::Messaging::pCodeTagValue               -- P-Code
   util::Messaging::unknownVariantTagValue      -- Unknown Type

The Feature file that is generated by this method is a subclass of
L<file::Mhc::Feature> and is of the same type as the input file.
Foreach each feature type and locus column, the possible values for the
feature of the cell include:

   known feature value
   featureAnalysis::AnalysisTypes::AMBIGUOUS_TYPE -- Ambiguous Type
   featureAnalysis::AnalysisTypes::NO_DATA_TYPE   -- No Data
   featureAnalysis::AnalysisTypes::NULL_TYPE      -- Null
   featureAnalysis::AnalysisTypes::UNKOWN_TYPE    -- Type Unknown

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setOutFile(outFile)>

This method sets the output template file name.  The B<outputFile> can
contain the task ID (B<__TASK__>) and HLA Locus (B<__HLA__>)
replacement templates which will be used to replace the B<taskId>
property and the given Locus, respectively.

=head2 B<setGeneratedFiles(generatedFiles)>

This method sets the generated files file.  During processing
L<"processFile">, the particular locus vector file names that are
generated are added to this file (one per line).

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$out_file = outFile>

This method returns the output file template that has been set.

=cut
