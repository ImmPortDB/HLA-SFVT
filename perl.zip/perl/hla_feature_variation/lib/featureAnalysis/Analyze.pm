package featureAnalysis::Analyze;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;
use Pod::Usage;
use FileHandle;
use File::Basename;

use util::ChiSquare;
use util::Constants;
use util::Messaging;
use util::PathSpecifics;
use util::QueryMgr;
use util::Table;

use util::Statistics::ContingencyTable;

use db::MhcTypes;

use featureAnalysis::AnalysisTypes;
use featureAnalysis::ErrMsgs;

use fields qw (
  allele_feature
  alleles_share_sfvt
  bad_subjects
  col_names
  column_separator
  contingency_file
  contingency_table
  error_mgr
  info_file
  locus_name
  msgs
  out_file
  output_imgt_version
  phenotype_col
  phenotype_counts
  phenotype_results
  phenotype_values
  pos_motifs
  query_mgr
  reader
  seq_type_id
  sequence_feature_data
  sequence_feature_file
  sequence_feature_name
  sequence_features
  sf_data
  sf_table
  statistical_tests
  taxon_id
  test_result_tables
  test_results
  tools
  variant_type_file
  variants
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Contingency Statistic
###
sub phenotypeValueTag { return 'Phenotype'; }
sub variantNameTag    { return 'Sequence Feature Variant'; }

sub SF_NAME_COL    { return 'sequence_feature_name'; }
sub SF_NAME_HEADER { return 'Sequence Feature Name'; }
###
### Sequence Feature Table
###
sub SF_COL  { return 'sf'; }
sub VT_COL  { return 'vt'; }
sub RUN_COL { return 'run'; }

sub SF_COLS {
  return (
    &SF_COL  => 'Sequence Feature',
    &VT_COL  => 'Num Variants',
    &RUN_COL => 'Run Tests'
  );
}
sub SF_ORD { return ( SF_COL, VT_COL, RUN_COL ); }
sub SF_HEADER { return 'Sequence Features'; }

sub EMPTY_VAL { return util::Constants::HYPHEN; }
###
### Result
###
sub CT_RESULT { return 'ct'; }
sub SF_RESULT { return 'sf'; }
sub VT_RESULT { return 'vt'; }

sub SHARE_SFVT_COL    { return 'share_sfvt'; }
sub BONFERR_CORR_COL  { return 'bonferr_corr'; }
sub CHI_SQ_COL        { return 'chi_sq'; }
sub CONF_INTERV_COL   { return 'conf_interv'; }
sub DOF_COL           { return 'dof'; }
sub ODDS_RATIO_COL    { return 'odds_ration'; }
sub P_VAL_COL         { return 'p_val'; }
sub MP_VAL_COL        { return 'mp_val'; }
sub SF_NAMES_COL      { return 'sf_names'; }
sub SFVT_SF_NAMES_COL { return 'sfvt_sf_names'; }
sub SF_ADJ_P_VAL_COL  { return 'sf_adj_p_val'; }
sub SF_NO_COL         { return 'sf_no'; }
sub SF_POS_COL        { return 'sf_pos'; }
##########sub SF_COL           { return 'sf'; }
##########sub VT_COL           { return 'vt'; }
sub VT_DEF_COL { return 'vt_def'; }

sub CHI_SQ_RESULT_COLS {
  return (
    &BONFERR_CORR_COL  => "adjusted p-value",
    &SF_ADJ_P_VAL_COL  => "Sequence Feature's\nadjusted p-value",
    &CHI_SQ_COL        => "Chi-square\nvalue",
    &CONF_INTERV_COL   => "Confidence Interval\nof Odds Ratio",
    &DOF_COL           => "Degrees of\nFreedom",
    &MP_VAL_COL        => "Multiple testing\ncorrected p-\nvalue",
    &ODDS_RATIO_COL    => "Odds\nRatio",
    &P_VAL_COL         => "Chi-square\ntest p-value",
    &SFVT_SF_NAMES_COL => "SFVT's Sequence Feature Names",
    &SF_COL            => "Sequence Feature of the SFVT",
    &SF_NAMES_COL      => "Sequence Feature Names",
    &SF_NO_COL         => "Sequence Feature\nNumber",
    &SF_POS_COL        => "Feature Location -\nAmino Acid Positions",
    &SHARE_SFVT_COL    => "Alleles in the\ndataset that\nshare the SFVT",
    &VT_COL            => "Sequence Feature\nVariant Type (SFVT)",
    &VT_DEF_COL        => "Variant Type\nDefinition"
  );
}

sub SF_CHI_SQ_RESULT_ORD {
  return ( SF_NO_COL, SF_NAMES_COL, SF_POS_COL, DOF_COL, CHI_SQ_COL, P_VAL_COL,
    BONFERR_CORR_COL );
}
###
### Queries for feature types
###
sub VARIANT_QUERY { return '_variantQuery_'; }

sub DB_QUERIES {
  return {
    &VARIANT_QUERY => {
      key => db::MhcTypes::VARIANT_TYPE_NAME_COL,
      ord =>
        [ db::MhcTypes::VARIANT_TYPE_NAME_COL, db::MhcTypes::POS_MOTIF_COL, ],
      cmd => "
select   a.variant_type_name,
         a.pos_motif
from     variant_type     a,
         feature          b,
         mhc_locus        c
where    b.feature_id     = a.feature_id
and      b.seq_type_id    = ?
and      b.locus_id       = c.locus_id
and      c.mhc_locus_name = ?
",
    },

  };
}
###
### Error Category
###
sub ERR_CAT { return featureAnalysis::ErrMsgs::ANALYZE_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _phenotypeChecks {
  my featureAnalysis::Analyze $this = shift;

  my $msgs          = $this->{msgs};
  my $phenotype_col = $this->{phenotype_col};
  my $reader        = $this->{reader};

  $this->{phenotype_counts}  = {};
  $this->{phenotype_results} = {};
  $this->{phenotype_values}  = [];
  my %phenotypes = ();
  foreach my $entity ( $reader->getData ) {
    my $phenotype_value = $entity->{$phenotype_col};
    next if ( $reader->emptyCell($phenotype_value) );
    $phenotypes{$phenotype_value} = util::Constants::EMPTY_STR;
  }
  ###
  ### test phenotype values
  ###
  my @phenotype_values = sort keys %phenotypes;
  my $phenotype_checks =
    ( scalar @phenotype_values == 2 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  $msgs->directRegisterError(
    ERR_CAT, 5,
    [
      $phenotype_col,
      join( util::Constants::COMMA_SEPARATOR, @phenotype_values )
    ],
    !$phenotype_checks
  );
  return $phenotype_checks if ( !$phenotype_checks );

  push( @{ $this->{phenotype_values} }, @phenotype_values );
  $this->{phenotype_results}->{locus} = $this->{locus_name};
  foreach my $phenotype_value (@phenotype_values) {
    $this->{phenotype_counts}->{$phenotype_value}  = 0;
    $this->{phenotype_results}->{$phenotype_value} = 0;
  }
  return $phenotype_checks;
}

sub _statisticalTestsChecks {
  my featureAnalysis::Analyze $this = shift;

  my $msgs = $this->{msgs};

  my $statistics_check =
    ( scalar @{ $this->{statistical_tests} } == 0 )
    ? util::Constants::FALSE
    : util::Constants::TRUE;
  $msgs->directRegisterError( ERR_CAT, 2, [], !$statistics_check );
  return $statistics_check if ( !$statistics_check );

  my $statistical_tests = [];
  foreach my $statistical_test ( @{ $this->{statistical_tests} } ) {
    my $good_test =
      featureAnalysis::AnalysisTypes::currentStatisticalTest($statistical_test);
    $msgs->directRegisterError( ERR_CAT, 3, [$statistical_test], !$good_test );
    next if ( !$good_test );
    push( @{$statistical_tests}, $statistical_test );
  }
  $statistics_check =
    ( scalar @{$statistical_tests} == 0 )
    ? util::Constants::FALSE
    : util::Constants::TRUE;
  $msgs->directRegisterError(
    ERR_CAT, 7,
    [
      join( util::Constants::COMMA_SEPARATOR, @{ $this->{statistical_tests} } )
    ],
    !$statistics_check
  );
  return $statistics_check if ( !$statistics_check );

  $this->{statistical_tests} = $statistical_tests;
  return $statistics_check;
}

sub _createTestResultTables {
  my featureAnalysis::Analyze $this = shift;

  $this->{test_result_tables} = {};
  foreach my $statistical_test ( @{ $this->{statistical_tests} } ) {
    my $table_data = {};
    if ( $statistical_test eq featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST )
    {
      my %cols = CHI_SQ_RESULT_COLS;
      my $sf_table = new util::Table( $this->{error_mgr}, %cols );
      $sf_table->setColumnOrder(SF_CHI_SQ_RESULT_ORD);
      $sf_table->setColumnJustification( SF_NO_COL, $sf_table->LEFT_JUSTIFY );
      $sf_table->setColumnJustification( SF_NAMES_COL,
        $sf_table->LEFT_JUSTIFY );
      $sf_table->setColumnJustification( SF_POS_COL, $sf_table->LEFT_JUSTIFY );
      $sf_table->setColumnJustification( DOF_COL,    $sf_table->RIGHT_JUSTIFY );
      $sf_table->setColumnJustification( CHI_SQ_COL, $sf_table->RIGHT_JUSTIFY );
      $sf_table->setColumnJustification( P_VAL_COL,  $sf_table->RIGHT_JUSTIFY );
      $sf_table->setColumnWidth( SF_NAMES_COL, 40 );
      $sf_table->setColumnWidth( SF_POS_COL,   20 );
      $sf_table->setEmptyField(EMPTY_VAL);
      $table_data->{&SF_RESULT} = {
        table  => $sf_table,
        data   => [],
        header => "Sequence Feature Chi-Square Results",
        result => SF_RESULT,
      };

      my @ord = ( VT_COL, VT_DEF_COL );
      foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
        push( @ord, $phenotypeValue );
        $cols{$phenotypeValue} = "$phenotypeValue\nFrequency";
      }
      push( @ord,
        SHARE_SFVT_COL,  DOF_COL,    CHI_SQ_COL,
        P_VAL_COL,       MP_VAL_COL, ODDS_RATIO_COL,
        CONF_INTERV_COL, SF_COL,     SFVT_SF_NAMES_COL,
        SF_ADJ_P_VAL_COL );
      my $vt_table = new util::Table( $this->{error_mgr}, %cols );
      $vt_table->setColumnOrder(@ord);
      $vt_table->setContinuation(util::Constants::EMPTY_STR);
      foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
        $vt_table->setColumnJustification( $phenotypeValue,
          $vt_table->RIGHT_JUSTIFY );
      }
      $vt_table->setColumnJustification( VT_COL,     $vt_table->LEFT_JUSTIFY );
      $vt_table->setColumnJustification( VT_DEF_COL, $vt_table->LEFT_JUSTIFY );
      $vt_table->setColumnJustification( DOF_COL,    $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnJustification( CHI_SQ_COL, $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnJustification( P_VAL_COL,  $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnJustification( MP_VAL_COL, $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnJustification( ODDS_RATIO_COL,
        $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnJustification( SF_ADJ_P_VAL_COL,
        $vt_table->RIGHT_JUSTIFY );
      $vt_table->setColumnWidth( VT_DEF_COL, 50 );
      $vt_table->setEmptyField(EMPTY_VAL);
      $table_data->{&VT_RESULT} = {
        table  => $vt_table,
        data   => [],
        header => "Sequence Feature Variant Chi-Square Results",
        result => VT_RESULT,
      };
    }
    $this->{test_result_tables}->{$statistical_test} = $table_data;
  }
}

sub _determineBadSubjects {
  my featureAnalysis::Analyze $this = shift;

  my $msgs              = $this->{msgs};
  my $reader            = $this->{reader};
  my $phenotype_col     = $this->{phenotype_col};
  my $sf_data           = $this->{sequence_feature_data};
  my $allele_cols       = $sf_data->{ $this->{allele_feature} }->{col_names};
  my $phenotype_counts  = $this->{phenotype_counts};
  my $phenotype_results = $this->{phenotype_results};

  my %subjects    = ();
  my %phenotypes  = ();
  my %allele_data = ();
  foreach my $entity ( $reader->getData ) {
    my $subject_id      = $entity->{ $reader->getIdCol };
    my $phenotype_value = $entity->{$phenotype_col};
    if ( !defined( $subjects{$subject_id} ) ) { $subjects{$subject_id} = 0; }
    $subjects{$subject_id}++;
    $phenotypes{$subject_id} =
      $reader->emptyCell($phenotype_value)
      ? undef
      : $phenotype_value;
    $allele_data{$subject_id} = util::Constants::FALSE;
    foreach my $colName ( @{$allele_cols} ) {
      my $allele = $entity->{$colName};
      if ( featureAnalysis::AnalysisTypes::sequenceFeatureVariant($allele) ) {
        $allele_data{$subject_id} = util::Constants::TRUE;
      }
    }
  }

  $this->{bad_subjects} = {};
  foreach my $subject_id ( sort keys %subjects ) {
    if ( $subjects{$subject_id} == 1 ) {
      my $phenotype_value = $phenotypes{$subject_id};
      my $allele          = $allele_data{$subject_id};
      $phenotype_counts->{$phenotype_value}++ if ( defined($phenotype_value) );
      $phenotype_results->{$phenotype_value}++
        if ( defined($phenotype_value) && $allele );
      next;
    }
    $msgs->directRegisterError( ERR_CAT, 6,
      [ $subject_id, $subjects{$subject_id} ],
      util::Constants::TRUE );
    $this->{bad_subjects}->{$subject_id} = util::Constants::EMPTY_STR;
  }
  my @bad_subjects = sort keys %{ $this->{bad_subjects} };
  $this->{error_mgr}->printHeader( "Bad Subjects\n"
      . "  subjects = "
      . join( util::Constants::NEWLINE . "             ", @bad_subjects ) )
    if ( scalar @bad_subjects != 0 );
}

sub _sortSF { $a->{ord} <=> $b->{ord}; }

sub _determineSequenceFeatures {
  my featureAnalysis::Analyze $this = shift;

  my $reader    = $this->{reader};
  my $query_mgr = $this->{query_mgr};

  my $allele_feature_pattern =
    featureAnalysis::AnalysisTypes::ALLELE_FEATURE_PATTERN;
  my %sequence_features = ();
  $this->{sequence_feature_data} = {};
  foreach my $sequence_feature_id ( $reader->getSequenceFeatures ) {
    my $sequence_feature_name =
      $reader->getSequenceFeatureName($sequence_feature_id);
    if ( $sequence_feature_name =~ /$allele_feature_pattern/ ) {
      $this->{allele_feature} = $sequence_feature_name;
    }
    $sequence_feature_name =~ /SF(\d+)$/;
    $sequence_features{$sequence_feature_name} = {
      ord  => $1,
      name => $sequence_feature_name,
    };
    my $names     = $reader->getSequenceFeatureNames($sequence_feature_id);
    my $positions = $reader->getSequenceFeaturePositions($sequence_feature_id);
    $this->{sequence_feature_data}->{$sequence_feature_name} = {
      names     => [ split( /; /, $names ) ],
      positions => [ split( /, /, $positions ) ],
      col_names =>
        [ $reader->getSequenceFeatureColNames($sequence_feature_id) ],
      file_col_names =>
        [ $reader->getSequenceFeatureFileColNames($sequence_feature_id) ],
    };
  }
  ###
  ### The sequence features
  ###
  my @sequence_features =
    sort featureAnalysis::Analyze::_sortSF values %sequence_features;
  $this->{sequence_features} = [];
  foreach my $sequence_feature (@sequence_features) {
    my $sequence_feature_name = $sequence_feature->{name};
    push( @{ $this->{sequence_features} }, $sequence_feature_name );
  }

  my $sf_table = new util::Table( $this->{error_mgr}, SF_COLS );
  $sf_table->setColumnOrder(SF_ORD);
  $sf_table->setColumnJustification( SF_COL,  $sf_table->LEFT_JUSTIFY );
  $sf_table->setColumnJustification( VT_COL,  $sf_table->RIGHT_JUSTIFY );
  $sf_table->setColumnJustification( RUN_COL, $sf_table->RIGHT_JUSTIFY );
  $sf_table->setEmptyField(EMPTY_VAL);
  $sf_table->setInHeader(util::Constants::TRUE);
  $this->{sf_table} = $sf_table;
  $this->{sf_data}  = [];
  ###
  ### Variant Pos Motifs
  ###
  $this->{pos_motifs} = {};
  $query_mgr->execute( VARIANT_QUERY, $this->{seq_type_id},
    $this->{locus_name} );
  foreach my $variant ( $query_mgr->getDataKeys(VARIANT_QUERY) ) {
    my $struct = $query_mgr->getData( VARIANT_QUERY, $variant );
    $this->{pos_motifs}->{$variant} = $struct->{pos_motif};
  }
}

sub _sortVT {
  if ( $a->{ord_type} eq 'char' ) {
    $a->{ord} cmp $b->{ord};
  }
  else {
    $a->{ord} <=> $b->{ord};
  }
}

sub _determineVariants {
  my featureAnalysis::Analyze $this = shift;

  my $bad_subjects = $this->{bad_subjects};
  my $reader       = $this->{reader};

  my %variants = ();
  my $ord_type = undef;
  foreach my $entity ( $reader->getData ) {
    my $subject_id = $entity->{ $reader->getIdCol };
    next if ( defined( $bad_subjects->{$subject_id} ) );
    foreach my $colName ( @{ $this->{col_names} } ) {
      my $variant = $entity->{$colName};
      next
        if (
        !featureAnalysis::AnalysisTypes::sequenceFeatureVariant($variant) );
      my $ord = $variant;
      if ( $variant =~ /VT(\d+)$/ ) {
        if ( !defined($ord_type) ) { $ord_type = 'num'; }
        $ord = $1;
      }
      elsif ( $this->{output_imgt_version} == db::MhcTypes::IMGT_HLA_V3 ) {
        if ( !defined($ord_type) ) { $ord_type = 'char'; }
        $variant =~ /\*([0-9:]+)[A-Z]?$/;
        my $digits    = $1;
        my @comps     = split( /:/, $digits );
        my @new_comps = ();
        foreach my $comp (@comps) {
          my $len = length($comp);
          if    ( $len == 2 ) { $comp = '00' . $comp; }
          elsif ( $len == 3 ) { $comp = '0' . $comp; }
          push( @new_comps, $comp );
        }
        $ord = join( util::Constants::COLON, @new_comps );
      }
      elsif ( $this->{output_imgt_version} == db::MhcTypes::IMGT_HLA_V2 ) {
        if ( !defined($ord_type) ) { $ord_type = 'char'; }
        $ord = $variant;
      }
      $variants{$variant} = {
        ord_type => $ord_type,
        ord      => $ord,
        name     => $variant,
      };
    }
  }
  my @variants =
    sort featureAnalysis::Analyze::_sortVT values %variants;
  $this->{variants} = [];
  foreach my $variant (@variants) {
    push( @{ $this->{variants} }, $variant->{name} );
  }
}

sub _variantsChecks {
  my featureAnalysis::Analyze $this = shift;

  my $msgs = $this->{msgs};

  my $variantsCheck =
    ( scalar @{ $this->{variants} } > 1 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  $msgs->addNote(
"Will not run statistical tests for sequence feature since only one variant\n"
      . "  sequence feature = "
      . $this->{sequence_feature_name} . "\n"
      . "  variant          = "
      . $this->{variants}->[0] )
    if ( !$variantsCheck );
  push(
    @{ $this->{sf_data} },
    {
      &SF_COL  => $this->{sequence_feature_name},
      &VT_COL  => scalar @{ $this->{variants} },
      &RUN_COL => $variantsCheck ? 'Yes' : 'No',
    }
  );
  return $variantsCheck;
}

sub _generateContingencyTable {
  my featureAnalysis::Analyze $this = shift;

  $this->{alleles_share_sfvt} = {};

  my $bad_subjects = $this->{bad_subjects};
  my $reader       = $this->{reader};
  my $share_sfvt   = $this->{alleles_share_sfvt};
  my $sf_data      = $this->{sequence_feature_data};
  my $allele_cols  = $sf_data->{ $this->{allele_feature} }->{col_names};
  ###
  ### Generate the contingency table statistics
  ###
  my $contigencyStatistic = new util::Statistics::ContingencyTable(
    "sequence feature contingency table\n"
      . "  sequence feature = "
      . $this->{sequence_feature_name},
    variantNameTag,
    $this->{variants},
    phenotypeValueTag,
    $this->{phenotype_values},
    $this->{error_mgr}
  );
  $this->{contingency_table} = $contigencyStatistic;
  foreach my $entity ( $reader->getData ) {
    my $subject_id = $entity->{ $reader->getIdCol };
    next if ( defined( $bad_subjects->{$subject_id} ) );
    my $phenotypeValue = $entity->{ $this->{phenotype_col} };
    next if ( $reader->emptyCell($phenotypeValue) );
    foreach my $index ( 0 .. $#{ $this->{col_names} } ) {
      my $colName = $this->{col_names}->[$index];
      my $variant = $entity->{$colName};
      my $allele  = $entity->{ $allele_cols->[$index] };
      next
        if (
        !featureAnalysis::AnalysisTypes::sequenceFeatureVariant($variant) );
      $this->{contingency_table}
        ->increment( variantNameTag, $variant, phenotypeValueTag,
        $phenotypeValue );
      if ( !defined( $share_sfvt->{$variant} ) ) {
        $share_sfvt->{$variant} = {};
      }
      $share_sfvt->{$variant}->{$allele} = util::Constants::EMPTY_STR;
    }
  }
  $this->{contingency_table}->setMarginals;
}

sub _phenotypeValuesChecks {
  my featureAnalysis::Analyze $this = shift;

  my $msgs = $this->{msgs};

  my $phenotype_value = undef;
  my $conting         = $this->{contingency_table};
  my $num_nonzero     = 0;
  foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
    $num_nonzero++ if ( $conting->colMarginal($phenotypeValue) != 0 );
    if ( !defined($phenotype_value)
      && $conting->colMarginal($phenotypeValue) != 0 )
    {
      $phenotype_value = $phenotypeValue;
    }
  }
  my $phenotypeChecks =
    ( $num_nonzero > 1 ) ? util::Constants::TRUE : util::Constants::FALSE;
  return $phenotypeChecks if ($phenotypeChecks);

  $msgs->addNote( "Will not run statistical tests for sequence feature\n"
      . "only one phenotype value has data\n"
      . "  sequence feature = "
      . $this->{sequence_feature_name} . "\n"
      . "  phenotype value  = $phenotype_value" );
  my $sf_datum = $this->{sf_data}->[ $#{ $this->{sf_data} } ];
  $sf_datum->{&RUN_COL} = 'No';
  return $phenotypeChecks;
}

sub _addContingencyData {
  my featureAnalysis::Analyze $this = shift;

  my $table_data = $this->{test_result_tables}->{&CT_RESULT};
  if ( !defined($table_data) ) {
    my %cols = $this->{contingency_table}->tableCols;
    $cols{&SF_NAME_COL} = SF_NAME_HEADER;
    my @ord = $this->{contingency_table}->tableOrd;
    unshift( @ord, SF_NAME_COL );
    my $table = new util::Table( $this->{error_mgr}, %cols );
    $table->setColumnOrder(@ord);
    $table->setEmptyField(EMPTY_VAL);
    $this->{test_result_tables}->{&CT_RESULT} = {
      table  => $table,
      data   => [],
      header => "Contingency Table Data",
      result => CT_RESULT,
    };
    $table_data = $this->{test_result_tables}->{&CT_RESULT};
  }
  my $data = $table_data->{data};
  foreach my $datum ( $this->{contingency_table}->tableData ) {
    my $new_datum = { %{$datum} };
    $new_datum->{sequence_feature_name} = $this->{sequence_feature_name};
    push( @{$data}, $new_datum );
  }
}

sub _runChiSquareSfTest {
  my featureAnalysis::Analyze $this = shift;

  my $chiSqTest = featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST;
  my $chiSquare =
    new util::ChiSquare( $this->{contingency_table}, $this->{error_mgr} );
  $chiSquare->runStatistic;
  $this->{test_results}->{$chiSqTest} = $chiSquare;

  my $table_data = $this->{test_result_tables}->{$chiSqTest};
  my $data       = $table_data->{&SF_RESULT}->{data};
  my $sf_name    = $this->{sequence_feature_name};
  my $sf_data    = $this->{sequence_feature_data}->{$sf_name};
  my $result     = {
    &SF_NO_COL => $sf_name,
    &SF_NAMES_COL =>
      join( util::Constants::SEMI_COLON_SEPARATOR, @{ $sf_data->{names} } ),
    &SF_POS_COL =>
      join( util::Constants::COMMA_SEPARATOR, @{ $sf_data->{positions} } ),
    &DOF_COL          => $chiSquare->dof,
    &CHI_SQ_COL       => $chiSquare->chiSquare,
    &P_VAL_COL        => $chiSquare->pVal,
    &BONFERR_CORR_COL => $chiSquare->bonferroniCorrection,
  };
  push( @{$data}, $result );
  return $result;
}

sub _runChiSquareVtTest {
  my featureAnalysis::Analyze $this = shift;
  my ( $sf_dof, $sf_adjusted_p_val ) = @_;

  my $chiSqTest  = featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST;
  my $conting    = $this->{contingency_table};
  my $share_sfvt = $this->{alleles_share_sfvt};
  my $sf_name    = $this->{sequence_feature_name};
  my $sf_data    = $this->{sequence_feature_data}->{$sf_name};
  my $sf_names =
    join( util::Constants::SEMI_COLON_SEPARATOR, @{ $sf_data->{names} } );

  foreach my $variant ( @{ $this->{variants} } ) {
    my $not_variant = "Not $variant";
    my $variants    = [ $variant, $not_variant ];
    my $lvConting   = new util::Statistics::ContingencyTable(
      "variant type contingency table\n" . "  variant type = $variant",
      variantNameTag,
      $variants,
      phenotypeValueTag,
      $this->{phenotype_values},
      $this->{error_mgr}
    );
    foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
      my $count = $conting->frequency( $variant, $phenotypeValue );
      foreach ( 1 .. $count ) {
        $lvConting->increment( variantNameTag, $variant, phenotypeValueTag,
          $phenotypeValue );
      }
      my $marginal  = $conting->colMarginal($phenotypeValue);
      my $not_count = $marginal - $count;
      foreach ( 1 .. $not_count ) {
        $lvConting->increment( variantNameTag, $not_variant, phenotypeValueTag,
          $phenotypeValue );
      }
    }
    $lvConting->setMarginals;
    my $chiSquare = new util::ChiSquare( $lvConting, $this->{error_mgr} );
    $chiSquare->setMultipleDof($sf_dof);
    $chiSquare->runStatistic;
    my $table_data = $this->{test_result_tables}->{$chiSqTest};
    my $data       = $table_data->{&VT_RESULT}->{data};
    my $sf_name    = $this->{sequence_feature_name};
    my $sf_data    = $this->{sequence_feature_data}->{$sf_name};
    my $result     = {
      &SHARE_SFVT_COL => join( util::Constants::COMMA_SEPARATOR,
        sort keys %{ $share_sfvt->{$variant} } ),
      &CHI_SQ_COL        => $chiSquare->chiSquare,
      &CONF_INTERV_COL   => $chiSquare->confidenceInterval,
      &DOF_COL           => $chiSquare->dof,
      &MP_VAL_COL        => $chiSquare->mpVal,
      &ODDS_RATIO_COL    => $chiSquare->oddsRatio,
      &P_VAL_COL         => $chiSquare->pVal,
      &SFVT_SF_NAMES_COL => $sf_names,
      &SF_ADJ_P_VAL_COL  => $sf_adjusted_p_val,
      &SF_COL            => $sf_name,
      &VT_COL            => $variant,
      &VT_DEF_COL        => $this->{pos_motifs}->{$variant},
    };

    foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
      $result->{$phenotypeValue} =
        $lvConting->frequency( $variant, $phenotypeValue );
    }
    push( @{$data}, $result );
  }
}

sub _computeSfStatisticalTest {
  my featureAnalysis::Analyze $this = shift;
  my ($statistical_test) = @_;

  my $result = $this->_runChiSquareSfTest
    if ( $statistical_test eq featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST );
  $this->_runChiSquareVtTest( $result->{&DOF_COL},
    $result->{&BONFERR_CORR_COL} )
    if ( $statistical_test eq featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST );
}

sub _printContingencyTable {
  my featureAnalysis::Analyze $this = shift;
  ###
  ### Generate contingency table header
  ###
  my $sf_data =
    $this->{sequence_feature_data}->{ $this->{sequence_feature_name} };
  my @position_data = ();
  my $index         = 0;
  my $positions     = util::Constants::EMPTY_STR;
  foreach my $position ( @{ $sf_data->{positions} } ) {
    if ( $positions ne util::Constants::EMPTY_STR ) {
      $positions .= util::Constants::COMMA_SEPARATOR;
    }
    if ( $index > 0 && $index % 8 == 0 ) {
      push( @position_data, $positions );
      $positions = util::Constants::EMPTY_STR;
    }
    $positions .= $position;
    $index++;
  }
  if ( $positions ne util::Constants::EMPTY_STR ) {
    push( @position_data, $positions );
  }
  my $header =
      "Contingency Table\n"
    . "  sequence feature = "
    . $this->{sequence_feature_name} . "\n"
    . "  names            = "
    . join(
    util::Constants::COMMA . util::Constants::NEWLINE . "                     ",
    @{ $sf_data->{names} }
    )
    . "\n"
    . "  positions        = "
    . join( util::Constants::NEWLINE . "                     ", @position_data )
    . "\n";
  foreach my $statistical_test ( @{ $this->{statistical_tests} } ) {
    if ( $statistical_test eq featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST )
    {
      my $chiSquare = $this->{test_results}->{$statistical_test};
      $chiSquare->printResult($header);
    }
  }
}

sub _fileName {
  my featureAnalysis::Analyze $this = shift;
  my ( $statistical_test, $result ) = @_;

  my $file     = undef;
  my $property = undef;
  if ( $result eq CT_RESULT ) {
    $file     = $this->contingencyAnalysisFile;
    $property = "Contingency Table Results";
  }
  elsif ( $statistical_test eq featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST )
  {
    if ( $result eq SF_RESULT ) {
      $file     = $this->sequenceFeatureAnalysisFile;
      $property = "Sequence Feature Analysis Results";
    }
    elsif ( $result eq VT_RESULT ) {
      $file     = $this->variantTypeAnalysisFile;
      $property = "Variant Type Analysis Results";
    }
  }
  return ( $file, $property );
}

sub _writeFile {
  my featureAnalysis::Analyze $this = shift;
  my ( $table_data, $statistical_test ) = @_;

  my $tools      = $this->{tools};
  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  my $hla_infix  = $tools->HLA_INFIX;
  my $locus_name = $this->{locus_name};

  my $table  = $table_data->{table};
  my $data   = $table_data->{data};
  my $header = $table_data->{header};
  my $result = $table_data->{result};
  $table->setData( @{$data} );
  my ( $file, $property ) = $this->_fileName( $statistical_test, $result );
  $file =~ s/$task_infix/$task_id/;
  $file =~ s/$hla_infix/$locus_name/;
  $table->generateTabFile($file);
  my $property_data =

    {
    $tools->PROPERTY_COL => $property,
    $tools->VALUE_COL    => basename($file),
    };
  return $property_data;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my featureAnalysis::Analyze $this = shift;
  my ( $file_reader, $taxon_id, $locus, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{allele_feature}        = undef;
  $this->{alleles_share_sfvt}    = undef;
  $this->{bad_subjects}          = undef;
  $this->{col_names}             = undef;
  $this->{column_separator}      = undef;
  $this->{contingency_file}      = undef;
  $this->{contingency_table}     = undef;
  $this->{error_mgr}             = $error_mgr;
  $this->{info_file}             = undef;
  $this->{locus_name}            = $locus;
  $this->{msgs}                  = undef;
  $this->{out_file}              = undef;
  $this->{phenotype_counts}      = undef;
  $this->{phenotype_results}     = undef;
  $this->{phenotype_values}      = undef;
  $this->{pos_motifs}            = undef;
  $this->{reader}                = $file_reader;
  $this->{sequence_feature_data} = undef;
  $this->{sequence_feature_file} = undef;
  $this->{sequence_feature_name} = undef;
  $this->{sequence_features}     = undef;
  $this->{taxon_id}              = $taxon_id;
  $this->{test_result_tables}    = undef;
  $this->{test_results}          = undef;
  $this->{tools}                 = $tools;
  $this->{variant_type_file}     = undef;
  $this->{variants}              = undef;

  $this->{seq_type_id} =
    db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::AA_SEQ );
  ###
  ### Determine attributes from properties
  ###
  $this->{output_imgt_version} =
    $tools->getProperty( $tools->OUTPUT_IMGT_VERSION_PROP );

  $this->{phenotype_col} = $tools->getProperty( $tools->PHENOTYPE_COLUMN_PROP );

  $this->{statistical_tests} =
    $tools->deserializeDataStructure( $tools->STATISTICAL_TESTS_PROP,
    $tools->serializer->ARRAY_TYPE );
  ###
  ### Start messaging
  ###
  $this->{msgs} =
    new util::Messaging( $this->{reader}, $taxon_id,
    $tools->getProperty( $tools->WRITE_MSGS_PROP ),
    $tools, $error_mgr );
  ###
  ### Setup the local queries
  ###
  $this->{query_mgr} = new util::QueryMgr( $tools->getSession, $error_mgr );
  $this->{query_mgr}->createAll(DB_QUERIES);
  $this->{query_mgr}->prepareQueries;

  return $this;
}

sub setOutFile {
  my featureAnalysis::Analyze $this = shift;
  my ($file) = @_;
  ###
  ### Check for '.txt' or '.xls' since the file
  ### will contain tab-separated data
  ###
  my $tools = $this->{tools};
  my $file_error =
    !( $file =~ /\.txt$/ || ( $tools->getTreatXlsAsTxt && $file =~ /\.xls$/ ) );
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$file], $file_error );
  return if ($file_error);

  $this->{out_file} = getPath($file);
}

sub outFile {
  my featureAnalysis::Analyze $this = shift;
  return $this->{out_file};
}

sub setSequenceFeatureAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  my ($file) = @_;
  ###
  ### Check for '.xls' since the file will
  ### contain tab-separated text data
  ###
  my $file_error = $file !~ /\.xls$/;
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$file], $file_error );
  return if ($file_error);

  $this->{sequence_feature_file} = getPath($file);
}

sub sequenceFeatureAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  return $this->{sequence_feature_file};
}

sub setVariantTypeAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  my ($file) = @_;
  ###
  ### Check for '.xls' since the file will
  ### contain tab-separated text data
  ###
  my $file_error = $file !~ /\.xls$/;
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$file], $file_error );
  return if ($file_error);

  $this->{variant_type_file} = getPath($file);
}

sub variantTypeAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  return $this->{variant_type_file};
}

sub setContingencyAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  my ($file) = @_;
  ###
  ### Check for '.xls' since the file will
  ### contain tab-separated text data
  ###
  my $file_error = $file !~ /\.xls$/;
  $this->{error_mgr}->registerError( ERR_CAT, 1, [$file], $file_error );
  return if ($file_error);

  $this->{contingency_file} = getPath($file);
}

sub contingencyAnalysisFile {
  my featureAnalysis::Analyze $this = shift;
  return $this->{contingency_file};
}

sub setAnalysisResultsInfoFile {
  my featureAnalysis::Analyze $this = shift;
  my ($file) = @_;

  $this->{info_file} = getPath($file);
}

sub analysisResultsInfoFile {
  my featureAnalysis::Analyze $this = shift;
  return $this->{info_file};
}

sub setColumnSeparator {
  my featureAnalysis::Analyze $this = shift;
  my ($separator) = @_;
  $this->{column_separator} = $separator;
}

sub processFile {
  my featureAnalysis::Analyze $this = shift;

  my $msgs   = $this->{msgs};
  my $reader = $this->{reader};
  my $tools  = $this->{tools};
  ###
  ### Open the reader
  ###
  $reader->openReader;
  ###
  ### Write the merged file
  ###
  my @property_data = ();
  my $hla_infix     = $tools->HLA_INFIX;
  my $locus_name    = $this->{locus_name};

  my $task_infix = $tools->TASK_INFIX;
  my $task_id    = $tools->getProperty( $tools->TASK_ID_PROP );
  ###
  ### Variant File Name
  ###
  my $out_file = $this->outFile;
  $out_file =~ s/$task_infix/$task_id/;
  $out_file =~ s/$hla_infix/$locus_name/;
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Variant file",
      $tools->VALUE_COL    => basename($out_file),
    }
  );
  ###
  ### Check Locus
  ###
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Locus",
      $tools->VALUE_COL    => $this->{locus_name},
    }
  );
  ###
  ### Check Phenotype Column
  ###
  return if ( !$this->_phenotypeChecks );
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Phenotype Column",
      $tools->VALUE_COL    => $this->{phenotype_col}
    }
  );
  ###
  ### Check Statistical Tests
  ###
  return if ( !$this->_statisticalTestsChecks );
  push(
    @property_data,
    {
      $tools->PROPERTY_COL => "Statistical Tests",
      $tools->VALUE_COL    => join( util::Constants::COMMA_SEPARATOR,
        sort @{ $this->{statistical_tests} } )
    }
  );
  ###
  ### Write the input for the analysis results
  ###
  $reader->writeFile($out_file);
  ###
  ### Set of subjects
  ###
  foreach my $entity ( $reader->getData ) {
    my $subject_id = $entity->{ $reader->getIdCol };
    $msgs->addDataCapture( $msgs->SUBJECT_TABLE, $subject_id );
  }
  ###
  ### Determine sequence features
  ###
  $this->_determineSequenceFeatures;
  my $sf_data = $this->{sequence_feature_data};
  ###
  ### Determine bad subjects
  ### -- ones that appear more than once in the file
  ###    and will not be used in the analysis
  ###
  $this->_determineBadSubjects;
  ###
  ### Create result tables for processing statistical results
  ###
  $this->_createTestResultTables;
  ###
  ### Process Sequence Features
  ###
  $msgs->resetRowNum;
  foreach my $sequence_feature ( @{ $this->{sequence_features} } ) {
    ###
    ### 1.  Setup for sequence feature
    ###
    $msgs->incRowNum;
    $this->{sequence_feature_name} = $sequence_feature;
    $this->{col_names}             = $sf_data->{$sequence_feature}->{col_names};
    $msgs->initializeAnalysisMsgs( $this->{locus_name}, $sequence_feature,
      $sf_data->{$sequence_feature}->{file_col_names} );
    ###
    ### 2.  Determine the set of defined variants
    ###
    $this->_determineVariants;
    ###
    ### 3.  If there is only one variant, then skip
    ###
    if ( !$this->_variantsChecks ) {
      $msgs->finalizeMsgs;
      next;
    }
    ###
    ### 4.  Calculate contingency table
    ###
    $this->_generateContingencyTable;
    ###
    ### 5.  If there is only one phenotype value with data, then skip
    ###
    if ( !$this->_phenotypeValuesChecks ) {
      $msgs->finalizeMsgs;
      next;
    }
    ###
    ### 6.  Add the contingency data
    ###
    ##########$this->_addContingencyData;
    ###
    ### 7.  Run each statistical test and record results
    ###
    $this->{test_results} = {};
    foreach my $statistical_test ( @{ $this->{statistical_tests} } ) {
      $this->_computeSfStatisticalTest($statistical_test);
    }
    ###
    ### 8.  finalize sequence feature messaging
    ###
    $msgs->finalizeMsgs;
  }
  ###
  ### Generate summary of sequence feature results
  ###
  $this->{sf_table}->setData( @{ $this->{sf_data} } );
  $this->{sf_table}->generateTable(SF_HEADER);
  ###
  ### Write contingency table data
  ###
  ##########push( @property_data,
  ##########  $this->_writeFile( $this->{test_result_tables}->{&CT_RESULT} ) );
  ###
  ### Write results of statistical tests
  ###
  foreach my $statistical_test ( @{ $this->{statistical_tests} } ) {
    my $table_data = $this->{test_result_tables}->{$statistical_test};
    foreach my $result ( keys %{$table_data} ) {
      push( @property_data,
        $this->_writeFile( $table_data->{$result}, $statistical_test ) );
    }
  }
  ###
  ### Finally, print all the statistics
  ###
  $msgs->printVariantStatistics(@property_data);
}

sub getPhenotypeResultsInfo {
  my featureAnalysis::Analyze $this = shift;

  my $results = { %{ $this->{phenotype_results} } };
  return $results;
}

sub writeAnalysisResultsInfo {
  my featureAnalysis::Analyze $this = shift;
  my ( $loci, $phenotypeResults ) = @_;

  my $fh = new FileHandle;
  $fh->open( $this->analysisResultsInfoFile, ">" );
  $fh->autoflush(util::Constants::TRUE);
  $fh->print(
    join(
      $this->{column_separator},
      'statisticalTests',
      join( util::Constants::COMMA_SEPARATOR,
        sort @{ $this->{statistical_tests} } )
      )
      . util::Constants::NEWLINE
  );
  $fh->print(
    join( $this->{column_separator},
      'lociAnalyzed', join( util::Constants::COMMA_SEPARATOR, @{$loci} ) )
      . util::Constants::NEWLINE
  );
  $fh->print(
    join( $this->{column_separator}, 'phenotypeCol', $this->{phenotype_col} )
      . util::Constants::NEWLINE );
  $fh->print(
    join( $this->{column_separator},
      'numPhenoTypes', scalar @{ $this->{phenotype_values} } )
      . util::Constants::NEWLINE
  );

  my $phenotypeMap = {};
  foreach my $index ( 0 .. $#{ $this->{phenotype_values} } ) {
    my $phenotypeValue = $this->{phenotype_values}->[$index];
    my $phenotypeNum   = $index + 1;
    $phenotypeMap->{$phenotypeValue} = $phenotypeNum;
    $fh->print(
      join(
        $this->{column_separator},
        'phenotypeVal' . $phenotypeNum,
        $phenotypeValue
        )
        . util::Constants::NEWLINE
    );
    $fh->print(
      join(
        $this->{column_separator},
        'phenotypeValSubjects' . $phenotypeNum,
        $this->{phenotype_counts}->{$phenotypeValue}
        )
        . util::Constants::NEWLINE
    );
  }
  foreach my $phenotypeResult ( @{$phenotypeResults} ) {
    my $locus = $phenotypeResult->{locus};
    foreach my $phenotypeValue ( @{ $this->{phenotype_values} } ) {
      $fh->print(
        join(
          $this->{column_separator},
          $locus . 'phenotypeValSubjects' . $phenotypeMap->{$phenotypeValue},
          $phenotypeResult->{$phenotypeValue}
          )
          . util::Constants::NEWLINE
      );

    }
  }
  $fh->close;
}

################################################################################

1;

__END__

=head1 NAME

Analyze.pm

=head1 DESCRIPTION

This class defines the SFVT analysis using a sequence feature vector
file.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new featureAnalysis::Analyze(file_reader, taxon_id, locus, tools, error_mgr)>

This is the constructor for the class.  The file_reader is the reader
for the sequence feature vector file that is to be processed for the
locus.  The file type of the input file(s).  This class assumes that
following properties have values:

   taskId
   outputImgtVersion
   phenotypeColumn
   statisticalTests
   writeMsgs

=head2 B<processFile>

This method performs the SFVT statistical tests on the input file and
reports the results.

=head2 B<writeAnalysisResultsInfo(loci, $phenotypeResults)>

This takes a (referenced) Perl array of locus names (loci) and the
(referenced) Perl array of phenotype result information referenced
hash structures (getPhenotypeResultsInfo) and generates the analysis
results information file (analysisResultsInfoFile).

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setOutFile(outFile)>

This method sets the output template file file.  The B<outputFile> can
contain the task ID (__TASK__) and HLA Loci (__HLA__) templates which
will be replaced by the taskId property and the given Locus,
respectively.

=head2 B<setsequenceFeatureAnalysisFile(outFile)>

This method sets the sequence feature statistical statistical tests
results file.  The B<outFile> can contain the task ID (__TASK__) and
HLA Locus (__HLA__) templates which will be replaced by the taskId
property and the given Locus, respectively.

=head2 B<setvariantTypeAnalysisFile(outFile)>

This method sets the sequence feature variant statistical test results
file.  The B<outFile> can contain the task ID (__TASK__) and HLA
Locus (__HLA__) templates which will be replaced by the taskId
property and the given Locus, respectively.

=head2 B<setContingencyAnalysisFile(outFile)>

This method sets the contingency table test results file.  The
B<outFile> can contain the task ID (__TASK__) and HLA Locus (__HLA__)
templates which will be replaced by the taskId property and the given
Locus, respectively.

=head2 B<setAnalysisResultsInfoFile(file)>

This method sets the analysis result information file name.

=head2 B<setColumnSeparator(separator)>

This method sets the column separator for the content in the analysis
result information file.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$out_file = outFile>

This method returns the output file template that has been set.

=head2 B<$sf_out_file = sequenceFeatureAnalysisFile>

This method returns the sequence feature analysis result file that has
been set.

=head2 B<$vt_out_file = variantTypeAnalysisFile>

This method returns the variant type analysis result file that has
been set.

=head2 B<$ct_out_file = contingencyAnalysisFile>

This method returns the contingency table result file that has been
set.

=head2 B<$analysis_result_info_file = analysisResultsInfoFile>

This method returns the filename for the analysis results information
file that is used to store the phenotype results information for a
run.

=head2 B<$phenotypeResultsInfo = getPhenotypeResultsInfo>

This method returns the phenotype results information after
processFile has been executed.

=cut
