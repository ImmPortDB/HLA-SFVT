package featureAnalysis::AnalysisTypes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use db::MhcTypes;

use util::Constants;

################################################################################
#
#			Public Static Methods
#
################################################################################
###
### Types for undefined, unknown, and ambiguous types
###
sub AMBIGUOUS_TYPE { return 'Ambiguous Type'; }
sub NO_DATA_TYPE   { return 'No Data'; }
sub NULL_TYPE      { return 'Null'; }
sub UNKOWN_TYPE    { return 'Type Unknown'; }
###
### Optional Column Specifics
###
### Column Types
###
sub OPTIONAL_TYPE   { return 'optional'; }
sub PHENOTYPE_TYPE  { return 'phenotype'; }
sub POPULATION_TYPE { return 'population'; }
###
### Allele Feature Pattern
###
sub ALLELE_FEATURE_PATTERN { return '_SF1$'; }
###
### Phenotype Columns
###
sub SUBJECT_PHENOTYPE_COL { return 'Subject Phenotype'; }
###
### Statistical Tests
###
sub CHI_SQUARE_TEST { return 'Chi-Square Test'; }

################################################################################
#
#			Public Static Methods
#
################################################################################

sub currentStatisticalTest($) {
  my ($test) = @_;

  return util::Constants::TRUE if ( $test eq CHI_SQUARE_TEST );
  return util::Constants::FALSE;
}

sub sequenceFeatureVariant($) {
  my ($variant) = @_;

  return util::Constants::FALSE if ( $variant eq AMBIGUOUS_TYPE );
  return util::Constants::FALSE if ( $variant eq NO_DATA_TYPE );
  return util::Constants::FALSE if ( $variant eq NULL_TYPE );
  return util::Constants::FALSE if ( $variant eq UNKOWN_TYPE );
  return util::Constants::FALSE if ( $variant =~ / unknown$/i );
  return util::Constants::TRUE;
}

################################################################################

1;

__END__

=head1 NAME

AnalysisTypes.pm

=head1 DESCRIPTION

The static class defines the special static types that define the
feature analysis library.

=head1 STATIC CONSTANTS

The following static constants define the unknown, undefined, and
ambiguous variant type names:

   featureAnalysis::AnalysisTypes::AMBIGUOUS_TYPE -- Ambiguous Type
   featureAnalysis::AnalysisTypes::NO_DATA_TYPE   -- No Data
   featureAnalysis::AnalysisTypes::NULL_TYPE      -- Null
   featureAnalysis::AnalysisTypes::UNKOWN_TYPE    -- Type Unknown

The following static constants define optional column types for a
file:

   featureAnalysis::AnalysisTypes::OPTIONAL_TYPE   -- optional
   featureAnalysis::AnalysisTypes::PHENOTYPE_TYPE  -- phenotype
   featureAnalysis::AnalysisTypes::POPULATION_TYPE -- population

This following static constant defines the subject phenotype column
name:

   featureAnalysis::AnalysisTypes::SUBJECT_PHENOTYPE_COL -- Subject Phenotype

The following statistical tests are currently supported:

   featureAnalysis::AnalysisTypes::CHI_SQUARE_TEST -- Chi-Square Test

=head1 STATIC METHODS

The following static methods are exported by this class.

=head2 B<currentStatisticalTest(test)>

This method returns TRUE (1) if the statistical test is currently
supported, otherwise it returns FALSE (0).

=head2 B<sequenceFeatureVariant(variant)>

This method returns TRUE (1) if the variant is a defined variant type,
otherwise it returns FALSE (0).

=cut
