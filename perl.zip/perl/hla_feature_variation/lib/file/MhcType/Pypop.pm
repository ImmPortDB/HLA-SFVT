package file::MhcType::Pypop;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base 'file::MhcType';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Pypop File Columns
###
sub POPULATION_COL { return 'populat'; }
sub ID_COL         { return 'id'; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $reader, $tools, $error_mgr ) = @_;
  my file::MhcType::Pypop $this =
    $that->SUPER::new( $tools->PypopType, $reader, $tools, $error_mgr );

  $reader->setInitColDefs( POPULATION_COL, ID_COL );
  $reader->setEmptyVals('****');
  $reader->setTypeValue( $tools->getFileTypeHeader( $tools->PypopType ) );
  $reader->setFillerRow( $tools->getFileTypeFillerRow( $tools->PypopType ) ); 
  $reader->setDataHeaderValue(POPULATION_COL);
  $reader->setIdCol(ID_COL);

  return $this;
}

sub colNameToEntityName {
  my file::MhcType::Pypop $this = shift;
  my ($col_value) = @_;

  my $locusName = undef;
  return $locusName if ( $col_value !~ /_(1|2)$/ );
  $col_value =~ /^(\S+)_(1|2)$/;
  $locusName = $1;

  return $locusName;
}

sub entityNameToColName {
  my file::MhcType::Pypop $this = shift;
  my ( $locus_name, $pos_num ) = @_;

  return if ( $pos_num != 1 && $pos_num != 2 );

  $locus_name =~ s/^HLA-//;
  return join( util::Constants::UNDERSCORE, $locus_name, $pos_num );
}

################################################################################

1;

__END__

=head1 NAME

Pypop.pm

=head1 DESCRIPTION

This concrete class defines the HLA file type for Pypop
files. It is a subclass of L<file::MhcType>.
The initial B<data row header> columns are:

   populat
   id

The assumed undefined allele cells are:

   ****

The first column value for the file type row is B<'labcode'>.
The first column value for the B<data row header> row is
B<'populat'>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::MhType:::Pypop(reader, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$locusName = colNameToEntityName(col_name, col_value)>

This method takes a B<data row header> column value for the Pypop
file, converts it into a locus name and return it.  If there is no
locus name, then it return B<undef>.

=head2 B<$colName = entityNameToColName(locus_name, pos_num)>

This method takes a B<locus_name> and a B<pos_num> and generates the
column name for that locus and position number in a pypop file.  If
the B<pos_num> is neither B<1 or 2>, undef returned.  The initial
'HLA-' is removed it present in the locus_name.

=cut
