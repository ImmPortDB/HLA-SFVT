package file::MhcType::Custom;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base "file::MhcType";

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Custom File Columns
###
sub ID_COL { return 'ID'; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$) {
  my ( $that, $reader, $tools, $error_mgr ) = @_;
  my file::MhcType::Custom $this =
    $that->SUPER::new( $tools->CustomType, $reader, $tools, $error_mgr );

  $reader->setInitColDefs(ID_COL);
  $reader->setEmptyVals( '-', util::Constants::EMPTY_STR, '""', '"-"', 'XXXX',
    '.' );
  $reader->setTypeValue( $tools->getFileTypeHeader( $tools->CustomType ) );
  $reader->setDataHeaderValue(ID_COL);
  $reader->setIdCol(ID_COL);

  $tools->setAllelesLookup( $tools->getProperty( $tools->TAXON_ID_PROP ) );

  return $this;
}

sub colNameToEntityName {
  my file::MhcType::Custom $this = shift;
  my ($col_value) = @_;

  my $locusName = undef;
  return $locusName if ( $col_value !~ /^(\S+)(a|b)$/ );
  $locusName = $1;
  ###
  ### sequence feature types
  ###
  return $locusName if ( $locusName =~ /^hsa_.+_sf\d+$/i );
  ###
  ### HLA typing data
  ###
  my $allelesLookup = $this->{tools}->getAllelesLookup;
  my $locusData     = $allelesLookup->getLocusData($locusName);
  return $locusName if ( defined($locusData) );
  return undef;
}

sub entityNameToColName {
  my file::MhcType::Custom $this = shift;
  my ( $locus_name, $pos_num ) = @_;

  return if ( $pos_num != 1 && $pos_num != 2 );

  return join( util::Constants::EMPTY_STR,
    $locus_name, ( $pos_num == 1 ) ? 'a' : 'b' );
}

################################################################################

1;

__END__

=head1 NAME

Typing.pm

=head1 DESCRIPTION

This concrete class defines the HLA file type for HLA-Typing
files. It is a subclass of L<file::MhcType>.
The initial B<data row header> columns are:

   ID

The assumed undefined allele cells are the empty string and the following

   ""
   -
   "-"
   XXXX
   .

The first column value for the file type row is
B<'Custom HLA typing file with phenotypes'>.  The first column value
for the B<data row header> row is B<'ID'>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::MhcType::Custom(reader, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$locusName = colNameToEntityName(col_value)>

This method takes a B<data row header> column value for the Custom
file , converts it into a locus name and return it.  If there is no
locus name, then it return B<undef>.

=head2 B<$colName = entityNameToColName(locus_name, pos_num)>

This B<locus_name> and a B<pos_num> and generates the locus column
name as follows B<'uc(locus_name)(a|b)'>, where B<pos_num> must be
either 1 (a) or 2 (b), otherwise an undef is returned.

=cut
