package file::MhcType::Raw;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base 'file::MhcType';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### HLA Raw Typing File Columns
###
sub SAMPLE_ID_COL { return 'Sample ID'; }
sub WELL_ID_COL   { return 'Well ID'; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $reader, $tools, $error_mgr ) = @_;
  my file::MhcType::Raw $this =
    $that->SUPER::new( $tools->HlaRawType, $reader, $tools, $error_mgr );

  $reader->setInitColDefs( WELL_ID_COL, SAMPLE_ID_COL );
  $reader->setEmptyVals( util::Constants::EMPTY_STR, 'NA' );
  $reader->setTypeValue($tools->getFileTypeHeader($tools->HlaRawType));
  $reader->setDataHeaderValue(WELL_ID_COL);
  $reader->setIdCol(SAMPLE_ID_COL);

  return $this;
}

sub colNameToEntityName {
  my file::MhcType::Raw $this = shift;
  my ($col_value) = @_;

  my $locusName = undef;
  return $locusName if ( $col_value !~ /allele/i );
  $col_value =~ /^(\S+)allele/i;
  $locusName = uc($1);

  return $locusName;
}

################################################################################

1;

__END__

=head1 NAME

Raw.pm

=head1 DESCRIPTION

This concrete class defines the HLA Raw data file type for HLA Raw
type data files.  It is a subclass of L<file::Mhc::Hla>.  The
initial B<data row header> columns are:

   Well ID
   Sample ID

The assumed undefined allele cells are the empty string and the following:

   NA

The first column value for the file type row is B<'Well ID'>.  The
first column value for the B<data row header> row is B<'Well ID'>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::MhcType::Raw(reader, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$locusName = colNameToEntityName(col_value)>

This method takes a B<data row header> column value for the HLA Raw
data file, converts it into a locus name and return it.  If there is
no locus name, then it return B<undef>.

=head2 B<$colName = entityNameToColName(locus_name, pos_num)>

This method is not implemented.

=head2 B<prepareFile>

This method implements the file preparation for the HLA Raw file.
The following file preparation actions are performed:

=over 4

=item B<Set Missing ID>

The id for each row without an ID (column B<'Sample ID'>) is set using the row
using the most recent previously defined ID and a sequnce number 
(starting at 1) and reset every time a defined ID is found.

=item B<Replace (homozygote)>

The column value B<(homozygote)> in data row is replaced by the immediately
preceding column value.

=item B<Remove double-quotes>

Remove all the double-quotes B<('"')> from a data column value.

=back

=head2 B<determineTypeAndHeader>

This method determines the type and header for the HLA Raw file.  It
is assumed that the first two non-empty lines compose the both the the
B<type_data> and the B<header_data> by catenating these lines 
together in a column-wise manner and removing the last 
redundant column: B<'Sample ID'>.  The B<data_index> is set to two (2).

=cut
