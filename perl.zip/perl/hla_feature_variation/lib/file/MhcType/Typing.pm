package file::MhcType::Typing;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base 'file::MhcType';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### HLA Typing File Columns
###
sub COLUMN_NAME_COL   { return 'Column Name'; }
sub EXP_SAMPLE_ID_COL { return 'Experiment Sample User-Defined ID*'; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $reader, $tools, $error_mgr ) = @_;
  my file::MhcType::Typing $this =
    $that->SUPER::new( $tools->HlaTypingType, $reader, $tools, $error_mgr );

  $reader->setInitColDefs( COLUMN_NAME_COL, EXP_SAMPLE_ID_COL );
  $reader->setEmptyVals( '-', util::Constants::EMPTY_STR, '""', '"-"', 'XXXX',
    '.', '****', 'None' );
  $reader->setTypeValue( $tools->getFileTypeHeader( $tools->HlaTypingType ) );
  $reader->setFillerRow($tools->getFileTypeFillerRow( $tools->HlaTypingType ) );
  $reader->setDataHeaderValue(COLUMN_NAME_COL);
  $reader->setIdCol(EXP_SAMPLE_ID_COL);

  return $this;
}

sub colNameToEntityName {
  my file::MhcType::Typing $this = shift;
  my ($col_value) = @_;

  my $locusName = undef;
  return $locusName if ( $col_value !~ / allele (1|2)/i );
  $col_value =~ /^(\S+)/;
  $locusName = $1;

  return $locusName;
}

sub entityNameToColName {
  my file::MhcType::Typing $this = shift;
  my ( $locus_name, $pos_num ) = @_;

  return if ( $pos_num != 1 && $pos_num != 2 );

  return join( util::Constants::SPACE, $locus_name, 'Allele', $pos_num );
}

################################################################################

1;

__END__

=head1 NAME

Typing.pm

=head1 DESCRIPTION

This concrete class defines the HLA file type for HLA-Typing
files. It is a subclass of L<file::Mhc::Hla>.
The initial B<data row header> columns are:

   Column Name
   Experiment Sample User-Defined ID*

The assumed undefined allele cells are the empty string and the
following strings:

   ""
   -
   "-"
   XXXX
   .
   ****
   None

The first column value for the file type row is B<'HLA Typing Results'>.
The first column value for the B<data row header> row is
B<'Column Name'>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::MhcType::Typing(reader, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$locusName = colNameToEntityName(col_value)>

This method takes a B<data row header> column value for the HLA-Typing
file, converts it into a locus name and return it.  If there is no
locus name, then it return B<undef>.

=head2 B<$colName = entityNameToColName(locus_name, pos_num)>

This B<locus_name> and a B<pos_num> and generates the locus column
name as follows B<'uc(locus_name) Allele pos_num'>.  The B<pos_num>
must be either 1 or 2, otherwise an undef is returned.

=cut
