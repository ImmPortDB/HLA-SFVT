package file::HlaConverter;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;

use file::ErrMsgs;

use fields
  qw (
  dest_reader
  dest_type
  error_mgr
  header_row
  locus_cols
  replace_str
  search_pattern
  source_reader
  tools
  type_data
  type_row
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Error Category
###
sub ERR_CAT { return file::ErrMsgs::HLACONVERTER_CAT; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my file::HlaConverter $this = shift;
  my ( $source_reader, $dest_type, $tools, $taxon_id, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{dest_type}      = $dest_type;
  $this->{error_mgr}      = $error_mgr;
  $this->{header_row}     = [];
  $this->{locus_cols}     = [];
  $this->{replace_str}    = undef;
  $this->{search_pattern} = undef;
  $this->{source_reader}  = $source_reader;
  $this->{tools}          = $tools;
  $this->{type_data}      = [];
  $this->{type_row}       = [];

  my $source_ref = ref($source_reader);
  $this->{error_mgr}->exitProgram( ERR_CAT, 1, [$source_ref],
    !defined($source_ref) || $source_ref !~ /^file::Mhc::Hla::/ );

  $this->{error_mgr}->exitProgram(
    ERR_CAT, 2,
    [$dest_type],
    !$tools->definedFileType($dest_type)
      || ( $dest_type ne $tools->HlaTypingType
      && $dest_type ne $tools->PypopType )
  );

  $this->{dest_reader} =
    $this->{tools}
    ->getMhcFileReader( $tools->HlaReader, $this->{dest_type}, undef,
    $taxon_id );

  return $this;
}

sub getDestReader {
  my file::HlaConverter $this = shift;
  return $this->{dest_reader};
}

sub getHeaderRow {
  my file::HlaConverter $this = shift;
  return @{ $this->{header_row} };
}

sub getTypeRow {
  my file::HlaConverter $this = shift;
  return @{ $this->{type_row} };
}

sub setFileConversion {
  my file::HlaConverter $this = shift;

  my $dest_reader   = $this->getDestReader;
  my $source_reader = $this->{source_reader};
  ###
  ### Initialize the Attributes
  ###
  $this->{header_row} = [];
  $this->{locus_cols} = [];
  $this->{type_data}  = [];
  $this->{type_row}   = [];

  push( @{ $this->{type_data} }, $dest_reader->getFillerRow );
  ###
  ### Set the header row and type row if the dest_type is the
  ### same as the source type
  ###
  if ( $source_reader->type eq $dest_reader->type ) {
    push( @{ $this->{header_row} }, $source_reader->getHeaderData );
    if ( $source_reader->type eq $this->{tools}->PypopType ) {
      push( @{ $this->{type_row} }, $dest_reader->getTypeValue );
    }
    else {
      push( @{ $this->{type_row} }, $source_reader->getTypeData );
    }
    return;
  }
  ###
  ### Now compute the header and type rows and the locus columns
  ###
  push( @{ $this->{header_row} }, $dest_reader->getInitColDefs );
  push( @{ $this->{type_row} },   $dest_reader->getTypeValue );
  ###
  ###  Get the allele pair columns
  ###
  my @non_init_cols = $source_reader->getCols;
  foreach my $col ( $source_reader->getInitialCols ) {
    shift(@non_init_cols);
  }
  foreach my $index ( 1 .. $source_reader->numEntities ) {
    my $col_index = 2 * $index - 1;
    my $locus_1   =
      $source_reader->getEntityData( $non_init_cols[ $col_index - 1 ] );
    my $locus_2 = $source_reader->getEntityData( $non_init_cols[$col_index] );
    last if ( !defined($locus_1) );
    my $locus_error =
      $locus_1->{full_entity_name} ne $locus_2->{full_entity_name};
    $this->{error_mgr}->registerError(
      ERR_CAT, 5,
      [
        $locus_1->{col_name}, $locus_1->{full_entity_name},
        $locus_2->{col_name}, $locus_2->{full_entity_name},
      ],
      $locus_error
    );
    next if ($locus_error);

    push(
      @{ $this->{locus_cols} },
      $non_init_cols[ $col_index - 1 ],
      $non_init_cols[$col_index]
    );

    my $locus_prefix = $locus_1->{full_entity_name};
    push(
      @{ $this->{header_row} },
      $dest_reader->mhcType->entityNameToColName( $locus_prefix, 1 ),
      $dest_reader->mhcType->entityNameToColName( $locus_prefix, 2 ),
    );
  }
}

sub setEntityConversion {
  my file::HlaConverter $this = shift;
  my ( $search_pattern, $replace_str ) = @_;
  $this->{search_pattern} = $search_pattern;
  $this->{replace_str}    = $replace_str;
}

sub writeFile {
  my file::HlaConverter $this = shift;
  my ($file) = @_;

  my $dest_reader    = $this->getDestReader;
  my $source_reader  = $this->{source_reader};
  my $search_pattern = $this->{search_pattern};
  my $replace_str    = $this->{replace_str};
  ###
  ### Only write a txt file so suffix must be 'txt'
  ###
  my $file_error = $file !~ /\.txt$/;
  $this->{error_mgr}
    ->registerError( ERR_CAT, 3, [ $source_reader->getFile, $file ],
    $file_error );
  return if ($file_error);
  ###
  ### Open file for writing
  ###
  unlink($file);
  my $fh = new FileHandle;
  my $open_error = !$fh->open( $file, '>' );
  $this->{error_mgr}
    ->registerError( ERR_CAT, 4, [ $source_reader->getFile, $file ],
    $open_error );
  return if ($open_error);
  ###
  ### Print the initial rows (type and header).
  ###
  $fh->print(
    join( util::Constants::TAB, $this->getTypeRow )
      . util::Constants::NEWLINE );
  $fh->print(
    join( util::Constants::TAB, @{ $this->{type_data} } )
      . util::Constants::NEWLINE );
  $fh->print(
    join( util::Constants::TAB, $this->getHeaderRow )
      . util::Constants::NEWLINE );
  ###
  ### Write the file data (only data columns!)
  ###
  my $emptyCell = $dest_reader->getEmptyVal;
  my $first_col = $source_reader->getFirstCol;
  my $id_col    = $source_reader->getIdCol;
  foreach my $entity ( $source_reader->getData ) {
    my @row = ();
    if ( $source_reader->type eq $dest_reader->type ) {
      ###
      ### source and destination are the same type
      ### just write out 'as-is'
      ### except for the requested replacement
      ###
      foreach my $col ( $source_reader->getInitialCols ) {
        push( @row, $entity->{$col} );
      }
      foreach my $col ( $source_reader->getEntityColsByOrder ) {
        my $datum = $entity->{$col};
        if ( $source_reader->emptyCell($datum) ) { $datum = $emptyCell; }
        elsif ( !util::Constants::EMPTY_LINE($search_pattern) ) {
          $datum =~ s/$search_pattern/$replace_str/g;
        }
        push( @row, $datum );
      }
    }
    else {
      ###
      ### source and destination differ.
      ###
      ### Account for fact whether first column is id or not
      ###
      if ( $dest_reader->getFirstCol eq $dest_reader->getIdCol ) {
        push( @row, $entity->{$id_col} );
      }
      elsif ( $first_col eq $id_col ) {
        push( @row, $emptyCell, $entity->{$id_col} );
      }
      else {
        push( @row, $entity->{$first_col}, $entity->{$id_col} );
      }
      ###
      ### Now the HLA Locus columns
      ###
      foreach my $col ( @{ $this->{locus_cols} } ) {
        my $datum = $entity->{$col};
        if ( $source_reader->emptyCell($datum) ) { $datum = $emptyCell; }
        ###
        ### Fix for pypop because it does not like new format
        ###
        elsif ( !util::Constants::EMPTY_LINE($search_pattern) ) {
          $datum =~ s/$search_pattern/$replace_str/g;
        }
        push( @row, $datum );
      }
    }
    my $row = join( util::Constants::TAB, @row );
    $row =~ s/\t+$//;
    $fh->print("$row\n");
  }
  ###
  ### Finally, close the file
  ###
  $fh->close;
}

################################################################################

1;

__END__

=head1 NAME

HlaConverter.pm

=head1 DESCRIPTION

This concrete class write an hla file (B<source_reader>) out via a
destination reader type (B<dest_type>).  Currently, the destination
types include are HLA Typing Template and pypop files.  The source
reader can be any subclass object of L<file::Mhc::Hla>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new file::HlaConverter(source_reader, dest_type, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=head2 B<writeFile(file)>

This method writes a tab-separated file to the file using the file
data content of the B<source_reader> object and the format of the the
B<dest_type>.  An an error is registerd if the B<file> does not have a
B<'.txt'> suffix or is not be writable.  This method can only be called
if the setter method L<"setFileConversion"> has been called.

=head1 SETTER METHODS

The following settter methods are exported by this class.

=head2 <setEntityConversion(search_pattern, replace_str)>

This method allows a particular regular expression B<search_pattern>
in the entity column cell to be replaced as many as times possible
by a replacement string (B<replace_str>) when the file is written out.

=head2 <setFileConversion>

This method determines the necessary attributes for file conversion
from the source reader to the destination type.  These attributes
include the B<header_row> and B<type_row>.  Also, this method
determines the set of source locus columns in the correct order.

=head1 GETTER METHODS

The following settter methods are exported by this class.

=head2 B<$dest_reader = getDestReader>

This method returns the destination HLA file reader object.

=head2 B<@header_row = getHeaderRow>

This method returns the B<header_row> column list for the header row
of destination file type.

=head2 B<@type_row = getTypeRow>

This method returns the B<type_row> column list for the type row of
the destination file type.

=cut
