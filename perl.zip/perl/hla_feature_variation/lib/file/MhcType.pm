package file::MhcType;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use file::ErrMsgs;

use fields
  qw (
  error_mgr
  reader
  tools
  type
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Error Category
###
sub ERR_CAT { return file::ErrMsgs::HLA_CAT; }

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my file::MhcType $this = shift;
  my ( $type, $reader, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{error_mgr} = $error_mgr;
  $this->{reader}    = $reader;
  $this->{tools}     = $tools;
  $this->{type}      = $type;

  $this->{error_mgr}->exitProgram( ERR_CAT, 5, [$type],
    !$this->{tools}->definedFileType($type) );

  return $this;
}

sub colNameToEntityName {
  my file::MhcType $this = shift;
  my ($col_value) = @_;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}
    ->printDebug("Abstract Method:  file::MhcType::colNameToEntityName");
  return undef;
}

sub entityNameToColName {
  my file::MhcType $this = shift;
  my ( $entity_name, $pos_num ) = @_;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}
    ->printDebug("Abstract Method:  file::MhcType::entityNameToColName");
  return undef;
}

sub type {
  my file::MhcType $this = shift;
  return $this->{type};
}

################################################################################

1;

__END__

=head1 NAME

MhcType.pm

=head1 DESCRIPTION

This abstract class defines the standard file type class.  It defines how 
column names are represented in each file file.  It also defines how to configure
the file type for the given reader.
The abstract methods include:
B<colNameToEntityName> and B<entityNameToColName>.
Subclasses define how to configure the reader and implement the abstract methods.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new file::MhcType(type, reader, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$enityName = colNameToEntityName(col_value)>

This abstract method takes a column value from the
B<data row header>
and returns the entity name for the value.  If the column does
not have an entity name, then it B<undef> is returned.

=head2 B<$colName = entityNameToColName(entity_name, pos_num)>

This abstract method takes a B<entity_name> and a B<pos_num> and
generates the column name for that entity and position number. It
does not upper-case the entity_name.

=head1 GETTER METHODS

The following settter methods are exported by this class.

=head2 B<$file_type = type>

This method returns the file type of the file represented by the object.

=cut
