package file::Mhc;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::PathSpecifics;

use file::ErrMsgs;

use fields qw (
  cols
  data
  data_index
  data_map
  empty_vals
  error_mgr
  file
  filler_row
  first_col
  header_data
  header_map
  header_val
  id_col
  id_cols
  init_col_defs
  entity_cols
  last_col
  mhc_type
  num_cols
  num_entities
  opt_cols
  reader
  reader_entities
  second_col
  taxon_id
  tools
  type
  type_data
  type_val
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### All Columns Definitions
###
sub COL_NAME { my ($num) = @_; return ( 'COL_' . $num ); }
###
### row id column
###
sub ROW_ID_COL { return '__row__col__id__'; }
###
### Error Category
###
sub ERR_CAT { return file::ErrMsgs::HLA_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _determineTypeAndHeader {
  my file::Mhc $this = shift;
  my (@entities) = @_;

  my $data_index  = 0;
  my $header_data = [];
  my $type_data   = [];
  foreach my $entity (@entities) {
    $data_index++;
    ###
    ### Must have the correct file type
    ###
    if ( @{$type_data} == 0
      && $entity->{ $this->{first_col} } eq $this->{type_val} )
    {
      $type_data = $this->getDataRow($entity);
    }
    ###
    ### Must process the entities names for the data row header
    ###
    if ( @{$header_data} == 0
      && lc($entity->{ $this->{first_col} }) eq lc($this->{header_val}) )
    {
      $header_data = $this->getDataRow($entity);
    }
    last if ( @{$header_data} > 0 );
  }
  return ( $type_data, $header_data, $data_index );
}
###
### _determineContent:
###
### This method determines the content of file (Perl
### referenced array attribute reader_entities).  if it
### not an Excel file, then it is all the reader entities,
### If it is an Excel file, the business rule is defined
### as follows:
###   Each worksheet with the type and header rows will
###   included with its non-empty data rows.  Only one
###   set of header rows is kept with all the data found.
###   All other worksheets will be discarded.
###
sub _determineContent {
  my file::Mhc $this = shift;
  ###
  ### Set all reader entities if the file is
  ### not an Excel file
  ###
  my $reader = $this->{reader};
  return if ( !defined($reader) );
  if ( ref($reader) ne 'file::Chunk::Excel' ) {
    $this->{reader_entities} = $this->{reader}->getEntities;
    return;
  }
  ###
  ### Now must work through the worksheets
  ###
  my @worksheet_nums       = $this->{reader}->getWorksheetNums;
  my $first_data_worksheet = util::Constants::TRUE;
  $this->{reader_entities} = [];
  foreach my $worksheet_num (@worksheet_nums) {
    my @worksheet_entities = $reader->getWorksheet($worksheet_num);
    my ( $type_data, $header_data, $data_index ) =
      $this->_determineTypeAndHeader( $reader->getWorksheet($worksheet_num) );
    next
      if ( scalar @{$type_data} == 0
      || scalar @{$header_data} == 0
      || $data_index == 0 );
    if ($first_data_worksheet) {
      $first_data_worksheet = util::Constants::FALSE;
      foreach my $index ( 0 .. ( $data_index - 1 ) ) {
        push( @{ $this->{reader_entities} }, $worksheet_entities[$index] );
      }
    }
    foreach my $index ( $data_index .. $#worksheet_entities ) {
      my $entity = $worksheet_entities[$index];
      next if ( util::Constants::EMPTY_LINE( $entity->{ $this->getIdCol } ) );
      push( @{ $this->{reader_entities} }, $entity );
    }
  }
}

sub _entityNames {
  my file::Mhc $this = shift;
  my ($entity_num)   = @_;
  my $entity_name    = 'EN_' . $entity_num;
  return ( $entity_name . '_1', $entity_name . '_2' );
}

sub _getData {
  my file::Mhc $this = shift;

  return $this->{data}
    if ( !defined( $this->{reader} ) || @{ $this->{data} } > 0 );
  return $this->{reader_entities};
}

sub _determineOptCols {
  my file::Mhc $this = shift;
  ###
  ### Initialize Reader Attributes
  ###
  $this->{type_data}   = [];
  $this->{header_data} = [];
  $this->{data_index}  = 0;
  ###
  ### Do not known whethe there are any optional columns before HLA columns
  ###
  $this->{cols} = [ @{ $this->{init_col_defs} } ];
  foreach my $col_num ( 1 .. $this->{num_cols} ) {
    push( @{ $this->{cols} }, COL_NAME($col_num) );
  }
  ###
  ### Open the reader
  ###
  $this->{reader} = $this->{tools}->getReader( $this->{file}, $this->{cols} );
  $this->_determineContent;
  ###
  ### Pre-Process File and then Determine Type and Header
  ### (re-implementable portion of opening reader)
  ###
  $this->prepareFile;
  $this->determineTypeAndHeader;
  ###
  ### Check for conformance.
  ###
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 2,
    [
      $this->{type_val},
      ( ( @{ $this->{type_data} } > 0 ) ? 'TRUE' : 'FALSE' ),
      $this->{header_val},
      ( ( @{ $this->{header_data} } > 0 ) ? 'TRUE' : 'FALSE' )
    ],
    @{ $this->{type_data} } == 0 || @{ $this->{header_data} } == 0
  );
  ###
  ### Get the header data and the set of the
  ### columns to determine the optional columns
  ###
  my @header_data   = @{ $this->{header_data} };
  my @init_col_defs = @{ $this->{init_col_defs} };
  foreach (@init_col_defs) { shift(@header_data); }
  ###
  ### Now determine optional columns
  ###
  $this->{opt_cols} = [];
  foreach my $index ( 0 .. $#header_data ) {
    my $col_val = $header_data[$index];
    ###
    ### The first column header value that is empty
    ### indicates the last data column
    ###
    last if ( util::Constants::EMPTY_LINE($col_val) );
    ###
    ### Process column heading to determine
    ### the entity name.  If it is an entity name,
    ### then it is the last column
    ###
    my $entityName = $this->{mhc_type}->colNameToEntityName($col_val);
    if ( defined($entityName) ) {
      my $entityData = $this->getEntityDataStruct($entityName);
      last if ( defined($entityData) );
    }
    ###
    ### This is an optional column
    ###
    push( @{ $this->{opt_cols} }, $col_val );
  }
  $this->{reader}->closeSourceFile;
  $this->{reader} = undef;
}
###
### _determineEntityNames:
###   This method takes the header_data array row from
###   the file attribute that represents the data row
###   header and determines the specific entities assigned
###   to each of the allele data columns.
###
sub _determineEntityNames {
  my file::Mhc $this = shift;
  ###
  ### Initialize entity columns
  ###
  $this->{entity_cols} = {};
  ###
  ### Get the header data and the set of the
  ### columns to determine the entity columns
  ###
  my @cols         = @{ $this->{cols} };
  my @header_data  = @{ $this->{header_data} };
  my @initial_cols = $this->getInitialCols;
  ###
  ### First, initialize the last_col attribute and prepare the
  ### cols and header_data list by removing the initial columns
  ###
  $this->{last_col} = $#initial_cols;
  foreach (@initial_cols) { shift(@cols); shift(@header_data); }
  ###
  ### Now process the columns that can contain entities
  ### Stop when there are no more headings...
  ###
  foreach my $index ( 0 .. $#header_data ) {
    my $col_name = $cols[$index];
    my $col_val  = $header_data[$index];
    ###
    ### The first column header value that is empty
    ### indicates the last data column
    ###
    last if ( util::Constants::EMPTY_LINE($col_val) );
    ###
    ### Increment the last_col
    ###
    $this->{last_col}++;
    ###
    ### Process column heading to determine
    ### the entity name.  If it is not a entity
    ### name, then it is the last column
    ###
    my $entityName = $this->{mhc_type}->colNameToEntityName($col_val);
    next if ( !defined($entityName) );
    ###
    ### Prepare entity name
    ###
    my $entityData = $this->getEntityDataStruct($entityName);
    $this->{error_mgr}
      ->exitProgram( ERR_CAT, 1, [ $entityName, $this->{taxon_id} ],
      !defined($entityData) );
    ###
    ### Set entity data structure for column
    ###
    $entityData->{col_name}           = $col_val;
    $entityData->{reader_col_name}    = $col_name;
    $this->{entity_cols}->{$col_name} = $entityData;
    $this->{header_map}->{$col_val}   = $entityData;
  }
}

sub _setSecondCol {
  my file::Mhc $this = shift;
  $this->{second_col} = $this->{cols}->[1];
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my file::Mhc $this = shift;
  my ( $file, $type, $taxon_id, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{cols}            = [];
  $this->{data}            = [];
  $this->{data_index}      = 0;
  $this->{data_map}        = {};
  $this->{empty_vals}      = [];
  $this->{error_mgr}       = $error_mgr;
  $this->{file}            = undef;
  $this->{filler_row}      = [];
  $this->{first_col}       = undef;
  $this->{header_data}     = [];
  $this->{header_map}      = {};
  $this->{header_val}      = undef;
  $this->{id_col}          = undef;
  $this->{id_cols}         = undef;
  $this->{init_col_defs}   = [];
  $this->{entity_cols}     = {};
  $this->{last_col}        = 0;
  $this->{num_cols}        = 0;
  $this->{num_entities}    = 0;
  $this->{opt_cols}        = [];
  $this->{reader}          = undef;
  $this->{reader_entities} = undef;
  $this->{second_col}      = undef;
  $this->{taxon_id}        = $taxon_id;
  $this->{tools}           = $tools;
  $this->{type}            = $type;
  $this->{type_data}       = [];
  $this->{type_val}        = undef;
  ###
  ### Set the reading file only if needed
  ###
  if ( !util::Constants::EMPTY_LINE($file) ) {
    $this->{file} = getPath($file);
  }

  $this->{mhc_type} = $tools->getMhcFileType($this);

  return $this;
}

sub getEntityDataStruct {
  my file::Mhc $this = shift;
  my ($entity_name) = @_;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}
    ->printDebug("Abstract Method:  file::Mhc::getEntityDataStruct");
  return undef;
}

sub prepareFile {
  my file::Mhc $this = shift;
  ###############################
  ### Re-Implementable Method ###
  ###############################
  ###
  ### Default:  NO-OP
  ###
}

sub determineTypeAndHeader {
  my file::Mhc $this = shift;
  ###############################
  ### Re-Implementable Method ###
  ###############################
  ###
  ### Default:  Determine conformance to file type and determine columns
  ###           assuming single line for file type and header row
  ###
  ( $this->{type_data}, $this->{header_data}, $this->{data_index} ) =
    $this->_determineTypeAndHeader( @{ $this->{reader_entities} } );
}

sub openReader {
  my file::Mhc $this = shift;
  ###
  ### Determine whether there are optional columns and what they are
  ###
  $this->_determineOptCols;
  ###
  ### Initialize Reader Attributes
  ###
  $this->{type_data}   = [];
  $this->{header_data} = [];
  $this->{data_index}  = 0;
  ###
  ### Assume that there are an initial set of columns (initial columns
  ### followed by optional columns) by an entity pair--assume as
  ### many as $this->{num_entities}
  ###
  $this->{cols} = [ @{ $this->{init_col_defs} }, @{ $this->{opt_cols} } ];
  foreach my $entity_num ( 1 .. $this->{num_entities} ) {
    push( @{ $this->{cols} }, $this->_entityNames($entity_num) );
  }
  ###
  ### Open the reader
  ###
  $this->{reader} = $this->{tools}->getReader( $this->{file}, $this->{cols} );
  $this->_determineContent;
  ###
  ### Pre-Process File and then Determine Type and Header
  ### (re-implementable portion of opening reader)
  ###
  $this->prepareFile;
  $this->determineTypeAndHeader;
  ###
  ### Check for conformance.
  ###
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 2,
    [
      $this->{type_val},
      ( ( @{ $this->{type_data} } > 0 ) ? 'TRUE' : 'FALSE' ),
      $this->{header_val},
      ( ( @{ $this->{header_data} } > 0 ) ? 'TRUE' : 'FALSE' )
    ],
    @{ $this->{type_data} } == 0 || @{ $this->{header_data} } == 0
  );
  ###
  ### Finally, Determine entity names
  ###
  $this->_determineEntityNames;
  ###
  ### Create the Entity Map
  ###
  my $row_id = 0;
  foreach my $entity ( $this->getData ) {
    $row_id++;
    $entity->{&ROW_ID_COL} = $row_id;
    $this->{data_map}->{$row_id} = $entity;
  }
}

sub writeFile {
  my file::Mhc $this = shift;
  my ( $file, $locus_name ) = @_;
  ###
  ### is there no locus name
  ###
  my $no_locus_name = util::Constants::EMPTY_LINE($locus_name);
  $locus_name = uc($locus_name);
  ###
  ### Only write a txt file so suffix must be 'txt'
  ###
  my $tools = $this->{tools};
  my $file_error =
    !( $file =~ /\.txt$/ || ( $tools->getTreatXlsAsTxt && $file =~ /\.xls$/ ) );
  $this->{error_mgr}
    ->registerError( ERR_CAT, 3, [ $this->getFile, $file ], $file_error );
  return if ($file_error);
  ###
  ### Open file for writing
  ###
  unlink($file);
  my $fh = new FileHandle;
  my $open_error = !$fh->open( $file, '>' );
  $this->{error_mgr}
    ->registerError( ERR_CAT, 4, [ $this->getFile, $file ], $open_error );
  return if ($open_error);
  ###
  ### Now write the file header (remove empty fields on the right)
  ###
  my @initial_cols = @{ $this->{init_col_defs} };
  push( @initial_cols, @{ $this->{opt_cols} } );
  my $last_initial_index = $#initial_cols;
  foreach my $entity ( $this->getHeader ) {
    my @row = ();
    foreach my $col_index ( 0 .. $this->{last_col} ) {
      my $col_name  = $this->{cols}->[$col_index];
      my $ucol_name = uc($col_name);
      if ( $no_locus_name
        || $col_index <= $last_initial_index
        || $ucol_name =~ /$locus_name/ )
      {
        my $col_val = $entity->{$col_name};
        push( @row, $col_val );
      }
    }
    my $row = join( util::Constants::TAB, @row );
    $row =~ s/\t+$//;
    $fh->print("$row\n");
  }
  ###
  ### Now write the file data (only data columns!)
  ###
  foreach my $entity ( $this->getData ) {
    my @row = ();
    foreach my $col_index ( 0 .. $this->{last_col} ) {
      my $col_name  = $this->{cols}->[$col_index];
      my $ucol_name = uc($col_name);
      if ( $no_locus_name
        || $col_index <= $last_initial_index
        || $ucol_name =~ /$locus_name/ )
      {
        my $col_val = $entity->{$col_name};
        push( @row, $col_val );
      }
    }
    my $row = join( util::Constants::TAB, @row );
    $fh->print("$row\n");
  }
  ###
  ### Finally, close the file
  ###
  $fh->close;
}

sub emptyCell {
  my file::Mhc $this = shift;
  my ($cell) = @_;
  $cell = strip_whitespace($cell);
  return util::Constants::TRUE if ( util::Constants::EMPTY_LINE($cell) );
  foreach my $empty_val ( @{ $this->{empty_vals} } ) {
    return util::Constants::TRUE if ( $cell eq $empty_val );
  }
  return util::Constants::FALSE;
}

################################################################################
#
#				 Setter Methods
#
################################################################################

sub setInitColDefs {
  my file::Mhc $this = shift;
  my (@init_col_names) = @_;
  $this->{init_col_defs} = [@init_col_names];
  $this->{first_col}     = $init_col_names[0];
  if ( $#init_col_names >= 1 ) {
    $this->{second_col} = $init_col_names[1];
  }
}

sub setEmptyVals {
  my file::Mhc $this = shift;
  my (@empty_vals) = @_;
  $this->{empty_vals} = [@empty_vals];
}

sub setTypeValue {
  my file::Mhc $this = shift;
  my ($col_value) = @_;
  $this->{type_val} = $col_value;
}

sub setFillerRow {
  my file::Mhc $this = shift;
  my (@filler_row) = @_;
  $this->{filler_row} = [@filler_row];
}

sub setDataHeaderValue {
  my file::Mhc $this = shift;
  my ($col_value) = @_;
  $this->{header_val} = $col_value;
}

sub setIdCol {
  my file::Mhc $this = shift;
  my ($col_name) = @_;
  $this->{id_col} = $col_name;
}

sub addHeaderInfo {
  my file::Mhc $this = shift;
  my (@info) = @_;
  return if ( @info == 0 );
  ###
  ### Find the type header and then add the info columns
  ###
  foreach my $entity ( $this->getHeader ) {
    next if ( $entity->{ $this->{first_col} } ne $this->{type_val} );
    ###
    ### Now add information after the defined columns
    ###
    my $info_index = 0;
    foreach my $col_name ( $this->getCols ) {
      my $col_val = $entity->{$col_name};
      next if ( !util::Constants::EMPTY_LINE($col_val) );
      last if ( $info_index > $#info );
      $entity->{$col_name} = $info[$info_index];
      $info_index++;
    }
    last;
  }
}

sub setOptCols {
  my file::Mhc $this = shift;
  my (@opt_col_names) = @_;
  $this->{opt_cols} = [@opt_col_names];
}

sub addEntity {
  my file::Mhc $this = shift;
  my ($entity) = @_;
  push( @{ $this->{data} }, $entity );
  $this->{data_map}->{ $entity->{&ROW_ID_COL} } = $entity;
}

################################################################################
#
#				 Getter Methods
#
################################################################################

sub type {
  my file::Mhc $this = shift;
  return $this->{type};
}

sub mhcType {
  my file::Mhc $this = shift;
  return $this->{mhc_type};
}

sub getCols {
  my file::Mhc $this = shift;
  return @{ $this->{cols} };
}

sub numEntities {
  my file::Mhc $this = shift;
  return $this->{num_entities};
}

sub getEntityColsByOrder {
  my file::Mhc $this = shift;
  my @initial_cols   = $this->getInitialCols;
  my @cols           = ();
  foreach my $index ( $#initial_cols + 1 .. $this->{last_col} ) {
    push( @cols, $this->{cols}->[$index] );
  }
  return @cols;
}

sub getEntityCols {
  my file::Mhc $this = shift;
  return sort keys %{ $this->{entity_cols} };
}

sub getEntityData {
  my file::Mhc $this = shift;
  my ($col_name) = @_;
  return $this->{entity_cols}->{$col_name};
}

sub getInitColDefs {
  my file::Mhc $this = shift;
  return @{ $this->{init_col_defs} };
}

sub getOptCols {
  my file::Mhc $this = shift;
  return @{ $this->{opt_cols} };
}

sub getInitialCols {
  my file::Mhc $this = shift;
  my @initial_cols = $this->getInitColDefs;
  push( @initial_cols, $this->getOptCols );
  return @initial_cols;
}

sub getFirstCol {
  my file::Mhc $this = shift;
  return $this->{first_col};
}

sub getSecondCol {
  my file::Mhc $this = shift;
  $this->_setSecondCol if ( !defined( $this->{second_col} ) );
  return $this->{second_col};
}

sub getEmptyVals {
  my file::Mhc $this = shift;
  return @{ $this->{empty_vals} };
}

sub getEmptyVal {
  my file::Mhc $this = shift;
  return undef if ( @{ $this->{empty_vals} } == 0 );
  return $this->{empty_vals}->[0];
}

sub getTypeValue {
  my file::Mhc $this = shift;
  my ($col_value) = @_;
  return $this->{type_val};
}

sub getFillerRow {
  my file::Mhc $this = shift;
  return @{ $this->{filler_row} };
}

sub getFillerRowName {
  my file::Mhc $this = shift;
  my @fillerRow = $this->getFillerRow;
  return undef if ( @fillerRow == 0 );
  return $fillerRow[0];
}

sub getDataHeaderValue {
  my file::Mhc $this = shift;
  my ($col_value) = @_;
  return $this->{header_val};
}

sub getFile {
  my file::Mhc $this = shift;
  return $this->{file};
}

sub getIdCol {
  my file::Mhc $this = shift;
  return $this->{id_col};
}

sub getData {
  my file::Mhc $this = shift;
  my $data = $this->_getData;
  return @{$data}[ $this->{data_index} .. $#{$data} ];
}

sub getDataRow {
  my file::Mhc $this = shift;
  my ($entity)       = @_;
  my $data           = [];
  foreach my $col_name ( @{ $this->{cols} } ) {
    my $col_val = $entity->{$col_name};
    last if ( util::Constants::EMPTY_LINE($col_val) );
    push( @{$data}, $col_val );
  }
  return $data;
}

sub getHeader {
  my file::Mhc $this = shift;
  my $data = $this->_getData;
  return @{$data}[ 0 .. ( $this->{data_index} - 1 ) ];
}

sub getTypeData {
  my file::Mhc $this = shift;
  return @{ $this->{type_data} };
}

sub getHeaderData {
  my file::Mhc $this = shift;
  return @{ $this->{header_data} };
}

sub getEntityFileCols {
  my file::Mhc $this = shift;
  return sort keys %{ $this->{header_map} };
}

sub getEntityDataByFileCol {
  my file::Mhc $this = shift;
  my ($file_col_name) = @_;
  return $this->{header_map}->{$file_col_name};
}

sub getEntity {
  my file::Mhc $this = shift;
  my ($row_col_id) = @_;
  return $this->{data_map}->{$row_col_id};
}

sub replaceData {
  my file::Mhc $this = shift;
  my (@entities) = @_;

  my @header = $this->getHeader;
  $this->{data} = [@header];
  push( @{ $this->{data} }, @entities );
}

sub getIdCols {
  my file::Mhc $this = shift;
  ###
  ### If the id_col is not defined, then return the trivial array
  ### otherwise if the id_cols is already defined, return it.
  ###
  my @id_cols = ();
  return @id_cols if ( !defined( $this->getIdCol ) );
  return @{ $this->{id_cols} } if ( defined( $this->{id_cols} ) );
  ###
  ### Must compute id_cols once
  ###
  my %id_cols = ();
  foreach my $rowId ( keys %{ $this->{data_map} } ) {
    my $entity = $this->{data_map}->{$rowId};
    $id_cols{ $entity->{ $this->getIdCol } } = util::Constants::EMPTY_STR;
  }
  $this->{id_cols} = [ sort keys %id_cols ];
  return @{ $this->{id_cols} };
}

sub getEntitiesById {
  my file::Mhc $this = shift;
  my ($id) = @_;

  my @entities = ();
  foreach my $rowId ( keys %{ $this->{data_map} } ) {
    my $entity = $this->{data_map}->{$rowId};
    push( @entities, $entity ) if ( $entity->{ $this->getIdCol } eq $id );
  }
  return @entities;
}

sub getEntityByRowNum {
  my file::Mhc $this = shift;
  my ($row_num) = @_;

  foreach my $entity ( $this->getData ) {
    return $entity if ( $row_num == $entity->{&ROW_ID_COL} );
  }
  return undef;
}

sub noIdData {
  my file::Mhc $this = shift;
  my ($entity) = @_;
  ###
  ### There is data if the ID column is defined
  ### and has content (return FALSE)
  ###
  my $id = $entity->{ $this->getIdCol };
  return util::Constants::FALSE if ( !util::Constants::EMPTY_LINE($id) );
  ###
  ### If any one of the entity columns contains data,
  ### then the entity is defined (return FALSE)
  ###
  foreach my $col_name ( $this->getEntityCols ) {
    my $cell = $entity->{$col_name};
    return util::Constants::FALSE if ( !$this->emptyCell($cell) );
  }
  ###
  ### There is no ID and no entity data.
  ###
  return util::Constants::TRUE;

}

################################################################################

1;

__END__

=head1 NAME

Mhc.pm

=head1 DESCRIPTION

This abstract class defines the standard MHC file for reading and
writing MHC files (e.g., HLA typing results and sequence features,
etc.)  The abstract method for this class is B<getEntityDataStruct>.
Subclasses will process specific file formats and need to implement
these method.  Also, all files have an initial set of file type
specific rows, then a B<data row header>, and finally the data rows.
The B<data row header> has a type specific set of initial columns
(B<setInitColDefs>), optional columns, and then entity pair columns.
Also, each file type has a definition of empty cell B<setEmptyVals>.
Each subclass needs to set the initial columns and the empty values.
Besides that, a subclass needs to specify what the value of the first
column of the line that defines the file type (B<setTypeValue>) and
the value of the first column of the line that defined the data column
headers (B<setDataHeaderValue>).  Finally, a subclass can define the
id column of a data row by specifying the column name of the id in the
heading line (B<setIdCol>).

=head1 METHODS

The following methods are exported by this class.

=head2 B<new file::Mhc(file, type, taxon_id, tools, error_mgr)>

This is the constructor for the class.  This class will instantiate
the file type of the class based on the B<type> and a subclass of the
base class L<file::MhcType>.

=head2 B<$entity_data = getEntityDataStruct(entity_name)>

This abstract method returns Perl Hash data structure from some lookup
that contains at least the following components for the entity:

   full_entity_name -- the full entity name as defined by IMGT
   entity_id        -- id from the database for the entity
   locus_id         -- id of the locus associated with the entity
   entity_names     -- the name(s) of the the entity

=head2 B<prepareFile>

This re-implementable method implements file preparation before the
type and header are determined.  The default action is a NO-OP.  The
preparation allows the data content to be useable by the Pypop HLA QC
pipeline.

=head2 B<determineTypeAndHeader>

This re-implementable method determines the type and header for the
file and sets the following attributes:

=over 4

=item B<data_index>

The data index is the index of the entities of the file where data row
begin.

=item B<type_data>

This (referenced) array defines the row containing the file type
definition, where there are no trailing empty columns.

=item B<header_data>

this (referenced) array defines the row containing the header
definition, where there are no trailing empty columns.

=back

=head2 B<openReader>

This method open the HLA file and determines that it is conformant to
its subtype specification, determine the column map and sets where
data begins.  This method calls two re-implementable methods in order:
L<"prepareFile"> and L<"determineTypeAndHeader"> before it determines
conformance of type and header and computes the entity names.

=head2 B<writeFile(file[, locus_name])>

This method writes a tab-separated file to the file using the file
content of the object.  A an error is registerd if the B<file> does
not have a B<'.txt'> suffix or is not be writable.

=head2 B<emptyCell(cell)>

This method returns a TRUE (1) if the cell is empty as defined the file
type, otherwise it returns FALSE (0).

=head1 SETTER METHODS

The following settter methods are exported by this class.

=head2 B<setInitColDefs(@init_col_names>

This method sets the list of initial column names that occur in data
columns before the entity data.

=head2 B<setEmptyVals(@empty_vals)>

This method sets the list of values that are considered empty allele
cell values, other than undefined or empty string.

=head2 B<setTypeValue(col_value)>

This method sets the column value of the first column of the row that
defines the type of the HLA file.

=head2 B<setDataHeaderValue(col_value)>

This method sets the column value of the first column of the row that
defines the B<data row header>.

=head2 B<setIdCol(col_name)>

This method sets name of the B<data row header> column that contains
the id for each data row.  This is needed in reporting results.

=head2 B<addHeaderInfo(@info>

These information columns columns will be added to the type line after
any other defined information.

=head2 B<setOptCols(@opt_col_names>

These method set the column names in order for the optional columns that
come after the intitial columns and before the entity columns.

=head2 B<addEntity(entity)>

These method adds and entity to the data and sets the data map by it row id.

=head1 GETTER METHODS

The following settter methods are exported by this class.

=head2 B<$file_type = type>

This method returns the file type of the file represented by the object.

=head2 B<$mhc_type = mhcType>

This method returns the MhcType object for the reader.

=head2 B<@cols = getCols>

This method returns the list of columns that are use for this file.

=head2 B<@init_col_names = getInitColDefs>

This method returns the list of initial column names that occur in data
columns before the entity data.

=head2 B<@opt_col_names = getOptCols>

This method returns the list of optional columns that occur between
the initial columns and the entity columns.

=head2 B<@init_col_names = getInitialCols>

This method returns the list of all columns that occur before entity
columns (initial columns and optional columns).

=head2 B<$first_col = getFirstCol>

This method returns the name of the first column in the header.

=head2 B<$second_col = getSecondCol>

This method returns the name of the second column in the header.

=head2 B<@empty_vals = getEmptyVals>

This method returns the list of values that are considered empty allele
cell values, other than undefined or empty string.

=head2 B<$empty_val = getEmptyVal>

This method returns an empty cell value.  If the empty values have
been set by B<setEmptyVals>, then this method returns the first empty
value that was set.

=head2 B<$filepath = getFile>

This method the file path to the file.

=head2 B<@entity_cols = getEntityColsByOrder>

This method returns the hla column names defined by the reader in the
order that they appear in the file.

=head2 B<$type_col_val = getTypeValue(col_value)>

This method returns the column value of the first column of the row that
defines the type of the HLA file.

=head2 B<$header_col_val = getDataHeaderValue(col_value)>

This method returns the column value of the first column of the row that
defines the B<data row header>.

=head2 B<$id_col_name = getIdCol>

This method returns the column name the B<data row header> that contains
the id for each data row.  This is needed in reporting results.

=head2 B<@data_rows = getData>

This method returns the data rows read from the file.

=head2 B<$data_row = getDataRow(entity)>

For a given (referenced) hash entity row from the reader, this special
method returns the data row (referenced) array after removing any
empty columns at the end.  That is, this method assumes that the first
empty column (in column order) in the entity is the end of defined
columns.

=head2 B<@header_rows = getHeader>

This method returns the header rows read from the file.

=head2 B<@cols = getTypeData>

This method return a list of the column names for the
file type line in the hla file.

=head2 B<@cols = getHeaderData>

This method return a list of the column names for the
B<data row header> line.

=head2 B<@entity_cols = getEntityCols>

This method returns the list of entity columns as defined by the given file.

=head2 B<$entity_data = getEntityData(reader_col_name)>

For a given entity column name, return its data as a referenced Perl
Hash with at least the following components appropriate for the the
entity:

   col_name         -- the entity column name as defined by the file
   reader_col_name  -- column name for entity assigned by the reader
                       (needed to access column data from an entity)
   full_entity_name -- the full entity name as defined by IMGT
   entity_id        -- id from the database for the entity
   locus_id         -- id of the locus associated with the entity

=head2 B<$entity_data = getEntityDataByFileCol(col_name)>

For a given feature file column name, return its data as a referenced
Perl Hash with the following components:

   col_name         -- the entity column name as defined by the file
   reader_col_name  -- column name for entity assigned by the reader
                       (needed to access column data from an entity)
   full_entity_name -- the full entity name as defined by IMGT
   entity_id        -- id from the database for the entity
   locus_id         -- id of the locus associated with the entity


=head2 B<@col_names = getEntityFileCols>

This method returns the list entity columns in the file in sort order.

=head2 B<$num_entities = numEntities>

This method returns the maximum number of unique entities that the
object can expect.

=head2 B<$entity = getEntity(row_col_id)>

This method returns the entity by assigned row column id.

=head2 B<replaceData(@entities)>

This method replaces the data (non-header) portion of the data with
the @entities.

=head2 B<@col_ids = getIdCols>

This method returns the array of unique id_col values.

=head2 B<@entities = getEntitiesById(id)>

This method returns the array of entities that have been assigned the
id in the id_col.

=head2 B<$entity = getEntityByRowNum(row_num)>

This method returns the entity with the row number B<row_num>.  If
there is no entity at the row number, then B<undef> is returned.

=head2 B<noIdData(entity)>

This method returns TRUE if there is no value for the ID column and
there are no values for all the entity columns, otherwise it returns
FALSE.

=cut
