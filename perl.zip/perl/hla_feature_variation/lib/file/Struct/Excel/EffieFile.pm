package file::Struct::Excel::EffieFile;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PathSpecifics;

use db::MhcTypes;

use base 'file::Struct::Excel';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ACC_NUM        { return 'acc_num'; }

sub LIST_TYPES {
  return { &ACC_NUM => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Excel::EffieFile $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Excel::EffieFile $this = shift;
  $this->{file_order} = [ 'acc_num', 'include', ];
}

sub computeLists {
  my file::Struct::Excel::EffieFile $this = shift;

  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $acc_num = $entity->{acc_num};
    my $include = $entity->{include};

    next if ( util::Constants::EMPTY_LINE($acc_num) );
    $acc_num = &strip_whitespace($acc_num);
    $include = uc( &strip_whitespace($include) );
    next if ( util::Constants::EMPTY_LINE($acc_num) );

    if ( $include eq 'YES' ) { $include = util::Constants::TRUE; }
    else { $include = util::Constants::FALSE; }
    $entity->{include} = $include;

    $this->addToList( ACC_NUM, $entity, $acc_num );
    $this->setEntityId( ACC_NUM, $acc_num );
  }
}

################################################################################

1;

__END__

=head1 NAME

EffieFile.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Excel> and
implements the reading of user defined accessions for the data
that Effie Pertersdorf (aka Mari Malkki) wants kept.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Spaces::ChangedNames(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   acc_num => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   'acc_num', 'include'

However, during processing in L<"computeLists">, a given row is
converted into several entities and the column names are changed
to:

   acc_num
   include

=head2 B<computeLists>

This method computes the component lists for the Excel spreadsheet containing
the user defined accessions to be kept.  Only rows with defined and
non-trivial accessions will be processed.  If the include column is
the string 'YES', then include will be set to TRUE (1), otherwise
it will be set to FALSE (0).

=cut
