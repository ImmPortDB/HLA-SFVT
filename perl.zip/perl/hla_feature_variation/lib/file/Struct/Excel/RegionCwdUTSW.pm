package file::Struct::Excel::RegionCwdUTSW;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base 'file::Struct::Excel';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###

sub POPULATION_ACCESSION_TYPE { return 'population_accession_type'; }
sub POPULATION_ALLELE_NAME    { return 'population_allele'; }

sub LIST_TYPES {
  return { &POPULATION_ALLELE_NAME => POPULATION_ACCESSION_TYPE };
}

sub ALLELE_COL            { return 'allele'; }
sub GLOBAL_FREQUENCY_COL  { return 'global frequency'; }
sub REGION_COL            { return 'region'; }
sub REGION_CWD_STATUS_COL { return 'region CWD status'; }
sub REGION_FREQUENCY_COL  { return 'region frequency'; }

sub ID_COLS { return ( REGION_COL, ALLELE_COL ); }

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Excel::RegionCwdUTSW $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Excel::RegionCwdUTSW $this = shift;
  $this->{file_order} = [
    REGION_COL,
    ALLELE_COL,
    'region allele count',
    'region number gametes',
    REGION_FREQUENCY_COL,
    REGION_CWD_STATUS_COL,
    'global allele count',
    'global number gametes',
    GLOBAL_FREQUENCY_COL,
    'populations observed',
    'number of regions obs',
  ];

}

sub computeLists {
  my file::Struct::Excel::RegionCwdUTSW $this = shift;

  my $entities = $this->{chunker}->getEntities;
  my @id_cols  = ID_COLS;
  foreach my $entity ( @{$entities} ) {
    next
      if ( util::Constants::EMPTY_LINE( $entity->{&REGION_COL} )
      || $entity->{&REGION_COL} eq 'Region' );
    my $id = undef;
    foreach my $col (@id_cols) {
      if ( defined($id) ) { $id .= '::'; }
      $id .= $entity->{$col};
    }
    $this->addToList( POPULATION_ALLELE_NAME, $entity, $id );
    $this->setEntityId( POPULATION_ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

RegionCwdUTSW.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Excel> and
implements the abstract methods B<setFileOrder> and B<computeLists>
for UTSW Region Data.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Spaces::ChangedNames(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   population_allele => population_accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

    region
    allele
    region allele count
    region number gametes
    region frequency
    region CWD status
    global allele count
    global number gametes
    global frequency
    global CWD status
    populations observed

=head2 B<computeLists>

This method computes the component lists for the Excel spreadsheet
containing the region data.

=cut
