package file::Struct::Bcp::Tab::Cwd;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Tab';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Other Columns
###
sub COL_1 { return 'col_1'; }
sub COL_2 { return 'col_2'; }
sub COL_3 { return 'col_3'; }
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ALLELE_NAME    { return 'allele'; }

sub LIST_TYPES {
  return { &ALLELE_NAME => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Tab::Cwd $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Tab::Cwd $this = shift;
  $this->{file_order} = [
    db::MhcTypes::LOCUS_NAME_COL,  db::MhcTypes::IMGT_ACCESSION_COL,
    db::MhcTypes::ALLELE_NAME_COL, COL_1,
    COL_2,                         db::MhcTypes::CWD_CATEGORY_COL,
    COL_3,
  ];

}

sub computeLists {
  my file::Struct::Bcp::Tab::Cwd $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    next
      if ( $entity->{&db::MhcTypes::LOCUS_NAME_COL} =~ /Alleles/
      || $entity->{&db::MhcTypes::LOCUS_NAME_COL} =~ /Locus/ );
    my $id = $entity->{&db::MhcTypes::ALLELE_NAME_COL};
    ###
    ### Determine the Protein Designator
    ###
    $id =~ /^(.+)\*(.+)$/;
    my $allele = $2;
    my @row = split( /:/, $allele );
    if ( scalar @row > 2 ) {
      $entity->{&db::MhcTypes::HLA_PROTEIN_NAME_COL} =
        join( util::Constants::COLON, $row[0], $row[1] );
    }
    ###
    ### Add to list and set id
    ###
    $this->addToList( ALLELE_NAME, $entity, $id );
    $this->setEntityId( ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

Cwd.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Tab> and
implements the abstract methods B<setFileOrder> and B<computeLists> for
the new CWD file format.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Tab::Cwd(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   allele => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::LOCUS_NAME_COL
   db::MhcTypes::IMGT_ACCESSION_COL
   db::MhcTypes::ALLELE_NAME_COL
   COL_1,
   COL_2,
   db::MhcTypes::CWD_CATEGORY_COL
   COL3

If the ALLELE_NAME has more than protein designator, HLA_PROTEIN_NAME
will be the protein designator of the ALLELE_NAME.

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
