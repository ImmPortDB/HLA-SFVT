package file::Struct::Bcp::Tab::DeletedNames;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Tab';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ALLELE_NAME    { return 'allele'; }

sub LIST_TYPES {
  return { &ALLELE_NAME => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Tab::DeletedNames $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Tab::DeletedNames $this = shift;
  $this->{file_order} = [
    db::MhcTypes::IMGT_ACCESSION_COL, db::MhcTypes::DELETED_ALLELE_NAME_COL,
    db::MhcTypes::REASON_COL,
  ];

}

sub computeLists {
  my file::Struct::Bcp::Tab::DeletedNames $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $imgt_id = $entity->{&db::MhcTypes::IMGT_ACCESSION_COL};
    my $id      = $entity->{&db::MhcTypes::DELETED_ALLELE_NAME_COL};
    ###
    ### Not an deleted allele name
    ###
    next if ( $imgt_id !~ /^HLA\d+$/ );
    ###
    ### Now fix the comments field to contain other columns
    ###
    my $reason = $entity->{&db::MhcTypes::REASON_COL};
    if ( $reason =~ / (\w+\*[0-9:]+[A-Z]?)/ ) {
      $entity->{&db::MhcTypes::IDENTICAL_TO_COL} = $1;
    }
    if ( $reason =~ / \((\w+) (\d+)\)/ ) {
      my $mon  = $1;
      my $year = $2;
      if ( $year =~ /^0/ ) { $year = '20' . $year; }
      elsif ( $year =~ /^2/ ) {}    ### NO-OP--as is ###
      else { $year = '19' . $year; }
      $entity->{&db::MhcTypes::DATE_OF_DELETION_COL} =
        join( util::Constants::HYPHEN, '01', $mon, $year );
    }

    $this->addToList( ALLELE_NAME, $entity, $id );
    $this->setEntityId( ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

DeletedNames.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Tab> and
implements the abstract methods B<setFileOrder> and B<computeLists> for
allele deleted names.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Tab::DeletedNames(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   allele => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::IMGT_ACCESSION_COL
   db::MhcTypes::DELETED_ALLELE_NAME_COL
   db::MhcTypes::REASON_COL

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
