package file::Struct::Bcp::Tab::NmdpCodes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Tab';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub NMDP_CODE      { return 'nmdp'; }

sub LIST_TYPES {
  return { &NMDP_CODE => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Tab::NmdpCodes $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Tab::NmdpCodes $this = shift;
  $this->{file_order} =
    [ db::MhcTypes::NMDP_CODE_COL, db::MhcTypes::SUBTYPE_COL ];

}

sub computeLists {
  my file::Struct::Bcp::Tab::NmdpCodes $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $id      = $entity->{&db::MhcTypes::NMDP_CODE_COL};
    my $subtype = $entity->{&db::MhcTypes::SUBTYPE_COL};
    ###
    ### Not an NMDP codes
    ###
    next if ( $subtype !~ /^[0-9:]+/ );

    $this->addToList( NMDP_CODE, $entity, $id );
    $this->setEntityId( NMDP_CODE, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

NmdpCodes.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Tab> and
implements the abstract methods B<setFileOrder> and B<computeLists>
for allele NMDP codes.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Tab::NmdpCodes(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   nmdp_code => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::NMDP_CODE_COL
   db::MhcTypes::SUBTYPE_COL

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
