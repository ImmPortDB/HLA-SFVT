package file::Struct::Bcp::Tab::CwdAlleles;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Tab';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Other columns
###
sub FOUR_DIGIT_CODE_COL {return 'four_digit_code';}
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ALLELE_NAME    { return 'allele'; }

sub LIST_TYPES {
  return { &ALLELE_NAME => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Tab::CwdAlleles $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Tab::CwdAlleles $this = shift;
  $this->{file_order} = [
    db::MhcTypes::LOCUS_NAME_COL, db::MhcTypes::ALLELE_NAME_COL,
    FOUR_DIGIT_CODE_COL,
  ];

}

sub computeLists {
  my file::Struct::Bcp::Tab::CwdAlleles $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    next if ( $entity->{&db::MhcTypes::LOCUS_NAME_COL} eq 'Locus' );
    my $id = join( util::Constants::ASTERISK,
      $entity->{&db::MhcTypes::LOCUS_NAME_COL},
      $entity->{&db::MhcTypes::ALLELE_NAME_COL}
    );
    $entity->{&db::MhcTypes::ALLELE_NAME_COL} = $id;
    ###
    ### Add to list and set id
    ###
    $this->addToList( ALLELE_NAME, $entity, $id );
    $this->setEntityId( ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

CwdAlleles.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Tab> and
implements the abstract methods B<setFileOrder> and B<computeLists> for
allele nomenclature changed names.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Tab::CwdAlleles(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   allele => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::LOCUS_NAME_COL
   db::MhcTypes::ALLELE_NAME_COL
   db::MhcTypes::FOUR_DIGIT_CODE_COL

The B<ALLELE_NAME> column will be composed of the the B<LOCUS_NAME>
and B<ALLELE_NAME> values separated by an asterisk ('*').

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
