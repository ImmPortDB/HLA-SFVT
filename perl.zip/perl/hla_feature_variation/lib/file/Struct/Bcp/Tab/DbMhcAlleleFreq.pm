package file::Struct::Bcp::Tab::DbMhcAlleleFreq;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Tab';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for id type
###
sub ID_TYPE    { return 'id_type'; }
sub SUBJECT_ID { return 'subject'; }

sub LIST_TYPES {
  return { &SUBJECT_ID => ID_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Tab::DbMhcAlleleFreq $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Tab::DbMhcAlleleFreq $this = shift;
  $this->{file_order} = [
    db::MhcTypes::SOURCE_COL,     db::MhcTypes::SUBJECT_COL,
    db::MhcTypes::POPULATION_COL, db::MhcTypes::POP_AREA_COL,
    db::MhcTypes::METHOD_COL,     db::MhcTypes::ETHNIC_COL,
    db::MhcTypes::COLLECT_COL,    db::MhcTypes::LATITUDE_COL,
    db::MhcTypes::LONGITUDE_COL,  db::MhcTypes::COMPLEX_COL,
    db::MhcTypes::HLA_A_1_COL,    db::MhcTypes::HLA_A_2_COL,
    db::MhcTypes::MISMATCH1_COL,  db::MhcTypes::HLA_B_1_COL,
    db::MhcTypes::HLA_B_2_COL,    db::MhcTypes::MISMATCH2_COL,
    db::MhcTypes::HLA_C_1_COL,    db::MhcTypes::HLA_C_2_COL,
    db::MhcTypes::MISMATCH3_COL,  db::MhcTypes::HLA_DRB1_1_COL,
    db::MhcTypes::HLA_DRB1_2_COL, db::MhcTypes::MISMATCH4_COL,
    db::MhcTypes::HLA_DQA1_1_COL, db::MhcTypes::HLA_DQA1_2_COL,
    db::MhcTypes::MISMATCH5_COL,  db::MhcTypes::HLA_DQB1_1_COL,
    db::MhcTypes::HLA_DQB1_2_COL, db::MhcTypes::MISMATCH6_COL,
    db::MhcTypes::HLA_DPA1_1_COL, db::MhcTypes::HLA_DPA1_2_COL,
    db::MhcTypes::MISMATCH7_COL,  db::MhcTypes::HLA_DPB1_1_COL,
    db::MhcTypes::HLA_DPB1_2_COL, db::MhcTypes::MISMATCH8_COL,
    db::MhcTypes::REPORT_COL,     db::MhcTypes::AUTHORS_COL,
  ];

}

sub computeLists {
  my file::Struct::Bcp::Tab::DbMhcAlleleFreq $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $id = $entity->{&db::MhcTypes::SUBJECT_COL};
    ###
    ### Not an deleted allele name
    ###
    next if ( $id eq 'Subject' );
    ###
    ### Now add row
    ###
    $this->addToList( SUBJECT_ID, $entity, $id );
    $this->setEntityId( SUBJECT_ID, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

DbMhcAlleleFreq.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Tab> and
implements the abstract methods B<setFileOrder> and B<computeLists>
for the dbMhc allele population file.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Tab::DbMhcAlleleFreq(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   subject => id_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::SOURCE_COL
   db::MhcTypes::SUBJECT_COL
   db::MhcTypes::POPULATION_COL
   db::MhcTypes::POP_AREA_COL
   db::MhcTypes::METHOD_COL
   db::MhcTypes::ETHNIC_COL
   db::MhcTypes::COLLECT_COL
   db::MhcTypes::LATITUDE_COL
   db::MhcTypes::LONGITUDE_COL
   db::MhcTypes::COMPLEX_COL
   db::MhcTypes::HLA_A_1_COL
   db::MhcTypes::HLA_A_2_COL
   db::MhcTypes::MISMATCH1_COL
   db::MhcTypes::HLA_B_1_COL
   db::MhcTypes::HLA_B_2_COL
   db::MhcTypes::MISMATCH2_COL
   db::MhcTypes::HLA_C_1_COL
   db::MhcTypes::HLA_C_2_COL
   db::MhcTypes::MISMATCH3_COL
   db::MhcTypes::HLA_DRB1_1_COL
   db::MhcTypes::HLA_DRB1_2_COL
   db::MhcTypes::MISMATCH4_COL
   db::MhcTypes::HLA_DQA1_1_COL
   db::MhcTypes::HLA_DQA1_2_COL
   db::MhcTypes::MISMATCH5_COL
   db::MhcTypes::HLA_DQB1_1_COL
   db::MhcTypes::HLA_DQB1_2_COL
   db::MhcTypes::MISMATCH6_COL
   db::MhcTypes::HLA_DPA1_1_COL
   db::MhcTypes::HLA_DPA1_2_COL
   db::MhcTypes::MISMATCH7_COL
   db::MhcTypes::HLA_DPB1_1_COL
   db::MhcTypes::HLA_DPB1_2_COL
   db::MhcTypes::MISMATCH8_COL
   db::MhcTypes::REPORT_COL
   db::MhcTypes::AUTHORS_COL

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
