package file::Struct::Bcp::Spaces::AlleleList;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Spaces';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ALLELE_NAME    { return 'allele'; }

sub LIST_TYPES {
  return { &ALLELE_NAME => ACCESSION_TYPE, };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Spaces::AlleleList $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Spaces::AlleleList $this = shift;
  $this->{file_order} =
    [ db::MhcTypes::IMGT_ACCESSION_COL, db::MhcTypes::ALLELE_NAME_COL, ];
}

sub computeLists {
  my file::Struct::Bcp::Spaces::AlleleList $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $id = $entity->{&db::MhcTypes::ALLELE_NAME_COL};

    $this->addToList( ALLELE_NAME, $entity, $id );
    $this->setEntityId( ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

AlleleList.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Spaces> and
implements the abstract methods B<setFileOrder> and B<computeLists> for
allele list for the current IMGT release

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Spaces::AlleleList(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   allele => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::IMGT_ACCESSION_COL
   db::MhcTypes::ALLELE_NAME_COL

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
