package file::Struct::Bcp::Spaces::ChangedNames;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use db::MhcTypes;

use base 'file::Struct::Bcp::Spaces';

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### The following component lists are supported
### for accession type
###
sub ACCESSION_TYPE { return 'accession_type'; }
sub ALLELE_NAME    { return 'allele'; }

sub LIST_TYPES {
  return { &ALLELE_NAME => ACCESSION_TYPE, };
}
###
### repeats the delete data in the change name file (must skip)
###
sub NONE { return 'None'; }

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $file, $error_mgr ) = @_;
  my file::Struct::Bcp::Spaces::ChangedNames $this =
    $that->SUPER::new( $file, LIST_TYPES, $error_mgr );

  return $this;
}

sub setFileOrder {
  my file::Struct::Bcp::Spaces::ChangedNames $this = shift;
  $this->{file_order} =
    [ db::MhcTypes::OLD_ALLELE_NAME_COL, db::MhcTypes::NEW_ALLELE_NAME_COL ];

}

sub computeLists {
  my file::Struct::Bcp::Spaces::ChangedNames $this = shift;
  my $entities = $this->{chunker}->getEntities;
  foreach my $entity ( @{$entities} ) {
    my $id = $entity->{&db::MhcTypes::OLD_ALLELE_NAME_COL};
    my $new_allele = $entity->{&db::MhcTypes::NEW_ALLELE_NAME_COL};
    ###
    ### Not an allele name
    ###
    next if ( $id !~ /\*/ || $new_allele eq NONE);

    $this->addToList( ALLELE_NAME, $entity, $id );
    $this->setEntityId( ALLELE_NAME, $id );
  }
}

################################################################################

1;

__END__

=head1 NAME

ChangedNames.pm

=head1 DESCRIPTION

This concrete class is a subclass of L<file::Struct::Bcp::Spaces> and
implements the abstract methods B<setFileOrder> and B<computeLists> for
allele nomenclature changed names.

=head1 METHODS

This class exports the followng methods.

=head2 B<new file::Struct::Bcp::Spaces::ChangedNames(file, error_mgr)>

This method is the constructor for this class.  The file is read using
the specific read method for the subclass which implements this
superclass.  The result of reading the file is a Perl object
describing the file and a set of lists described in
L<file::Struct>.  The specific component lists are defined as
follows:

   allele => accession_type

The error_mgr is an instance of the L<util::ErrMgr> class and is
required for registering errors.

=head1 SETTER METHODS

The following setter methods are defined for this class.

=head2 B<setFileOrder>

This class defines the column name order for the bcp file:

   db::MhcTypes::OLD_ALLELE_NAME_COL
   db::MhcTypes::NEW_ALLELE_NAME_COL

=head2 B<computeLists>

This method computes the component lists for the bcp-file

=cut
