package file::Mhc::Hla::Typing;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'file::Mhc::Hla';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $taxon_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Hla::Typing $this =
    $that->SUPER::new( $file, $tools->HlaTypingType, $taxon_id, $tools,
    $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Typing.pm

=head1 DESCRIPTION

This concrete class defines the HLA file type for HLA-Typing
files. It is a subclass of L<file::Mhc::Hla>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::Mhc::Hla::Typing(file, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=cut
