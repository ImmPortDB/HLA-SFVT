package file::Mhc::Hla::Raw;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

use base 'file::Mhc::Hla';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $taxon_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Hla::Raw $this =
    $that->SUPER::new( $file, $tools->HlaRawType, $taxon_id, $tools,
    $error_mgr );

  return $this;
}

sub prepareFile {
  my file::Mhc::Hla::Raw $this = shift;
  ###
  ### Pre process the entity rows
  ###
  my $entities     = $this->{reader}->getEntities;
  my @entities     = ( $entities->[0], $entities->[1] );
  my $curr_id      = undef;
  my $instance_num = 0;
  foreach my $index ( 2 .. $#{$entities} ) {
    my $entity = $entities->[$index];
    ###
    ### Get my current id and check
    ### to see if at the last row
    ###
    my $id = $entity->{ $this->getIdCol };
    if ( !util::Constants::EMPTY_LINE($id) ) {
      $curr_id      = $id;
      $instance_num = 0;
    }
    else {
      $instance_num++;
      $id = join( util::Constants::DOT, $curr_id, $instance_num );
    }
    last if ( $curr_id eq '-ve' );
    ###
    ### Now set the id appropriately
    ###
    $entity->{ $this->getIdCol } = $id;
    ###
    ### pre-process row, replacing homozygote
    ### and getting rid of double-quotes
    ###
    my $curr_col_val = undef;
    foreach my $col_name ( @{ $this->{cols} } ) {
      my $col_val = $entity->{$col_name};
      if ( $col_val eq '(homozygote)' ) {
        $col_val = $curr_col_val;
      }
      elsif ( $col_val eq 'repeat' ) {
        $col_val = $this->getEmptyVal;
      }
      else {
        $col_val =~ s/"//g;
      }
      $entity->{$col_name} = $col_val;
      my $curr_col_val = $col_val;
    }
    ###
    ### Add the entity to the entities
    ###
    push( @entities, $entity );
  }
  ###
  ### Finally set the entity rows in the reader.
  ###
  @{$entities} = @entities;
}

sub determineTypeAndHeader {
  my file::Mhc::Hla::Raw $this = shift;
  ###
  ### The first two non-empty rows are
  ### the potential (catenated) header
  ###
  my $entities        = $this->{reader}->getEntities;
  my $header_1        = $entities->[0];
  my $header_2        = $entities->[1];
  my $entity          = {};
  my $curr_col_1_val  = undef;
  my $found_sample_id = util::Constants::FALSE;
  foreach my $index ( 0 .. $#{ $this->{cols} } ) {
    my $col_name  = $this->{cols}->[$index];
    my $col_1_val = $header_1->{$col_name};
    my $col_2_val = $header_2->{$col_name};
    ###
    ### Stop when column value is undefined or
    ### find SAMPLE_ID_COL a second time
    ###
    next
      if (
      util::Constants::EMPTY_LINE($col_2_val)
      || ( $col_2_val eq $this->mhcType->SAMPLE_ID_COL
        && $found_sample_id )
      );
    $found_sample_id =
      ( $col_2_val eq $this->mhcType->SAMPLE_ID_COL )
      ? util::Constants::TRUE
      : $found_sample_id;
    if ( util::Constants::EMPTY_LINE($col_1_val)
      && $col_2_val =~ /allele/i )
    {
      $col_1_val = $curr_col_1_val;
    }
    elsif ( util::Constants::EMPTY_LINE($col_1_val) ) {
      $col_1_val = util::Constants::EMPTY_STR;
    }
    else {
      $curr_col_1_val = $col_1_val;
    }
    $entity->{$col_name} = $col_1_val . $col_2_val;
  }
  my $entity_row = $this->getDataRow($entity);

  $this->{data_index} = 2;
  if ( $entity->{ $this->{first_col} } eq $this->{type_val} ) {
    $this->{type_data} = $entity_row;
  }
  if ( lc($entity->{ $this->{first_col} }) eq lc($this->{header_val}) ) {
    $this->{header_data} = $entity_row;
  }
}

################################################################################

1;

__END__

=head1 NAME

Raw.pm

=head1 DESCRIPTION

This concrete class defines the HLA Raw data file type for HLA Raw
type data files.  It is a subclass of L<file::Mhc::Hla>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::Mhc::Hla::Raw(file, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=head2 B<prepareFile>

This method implements the file preparation for the HLA Raw file.
The following file preparation actions are performed:

=over 4

=item B<Set Missing ID>

The id for each row without an ID (column B<'Sample ID'>) is set using the row
using the most recent previously defined ID and a sequnce number 
(starting at 1) and reset every time a defined ID is found.

=item B<Replace (homozygote)>

The column value B<(homozygote)> in data row is replaced by the immediately
preceding column value.

=item B<Remove double-quotes>

Remove all the double-quotes B<('"')> from a data column value.

=back

=head2 B<determineTypeAndHeader>

This method determines the type and header for the HLA Raw file.  It
is assumed that the first two non-empty lines compose the both the the
B<type_data> and the B<header_data> by catenating these lines 
together in a column-wise manner and removing the last 
redundant column: B<'Sample ID'>.  The B<data_index> is set to two (2).

=cut
