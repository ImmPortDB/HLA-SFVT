package file::Mhc::Hla::Pypop;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'file::Mhc::Hla';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $taxon_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Hla::Pypop $this =
    $that->SUPER::new( $file, $tools->PypopType, $taxon_id, $tools,
    $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Pypop.pm

=head1 DESCRIPTION

This concrete class defines the HLA file type for Pypop
files. It is a subclass of L<file::Mhc::Hla>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::Mhc::Hla::Pypop(file, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=cut
