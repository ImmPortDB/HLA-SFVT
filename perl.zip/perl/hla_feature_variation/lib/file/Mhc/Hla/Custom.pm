package file::Mhc::Hla::Custom;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'file::Mhc::Hla';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $taxon_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Hla::Custom $this =
    $that->SUPER::new( $file, $tools->CustomType, $taxon_id, $tools,
    $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Typing.pm

=head1 DESCRIPTION

This concrete class defines the HLA Custom result type for HLA-Typing
files. It is a subclass of L<file::Mhc::Hla>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::Mhc::Hla::Custom(file, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=cut
