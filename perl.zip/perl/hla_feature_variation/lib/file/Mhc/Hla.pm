package file::Mhc::Hla;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'file::Mhc';

use fields qw (
  loci
);

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $type, $taxon_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Hla $this =
    $that->SUPER::new( $file, $type, $taxon_id, $tools, $error_mgr );

  $this->{num_cols}     = 256;
  $this->{num_entities} = 34;
  $this->{loci}         = undef;

  $tools->setAllelesLookup($taxon_id);

  return $this;
}

sub getEntityDataStruct {
  my file::Mhc::Hla $this = shift;
  my ($entity_name) = @_;

  my $tools         = $this->{tools};
  my $allelesLookup = $tools->getAllelesLookup;
  my $locusData     = $allelesLookup->getLocusData($entity_name);
  my $entity_struct = {
    full_entity_name => $locusData->{full_locus_name},
    entity_id        => $locusData->{locus_id},
    locus_id         => $locusData->{locus_id},
    entity_names     => $locusData->{full_locus_name},
    ###
    ### Specific to locus data
    ###
    short_locus_name => $locusData->{short_locus_name},
    alt_locus_name   => $locusData->{alt_locus_name},
  };

  return $entity_struct;
}
sub _sortLoci { $a <=> $b; }

sub getLoci {
  my file::Mhc::Hla $this = shift;

  return sort file::Mhc::Hla::_sortLoci keys %{ $this->{loci} }
    if ( defined( $this->{loci} ) );
  ###
  ### Compute the loci once
  ###
  $this->{loci} = {};
  foreach my $col_name ( sort $this->getEntityCols ) {
    my $entityData = $this->getEntityData($col_name);
    my $locusId    = $entityData->{locus_id};
    if ( !defined( $this->{loci}->{$locusId} ) ) {
      $this->{loci}->{$locusId} = [];
    }
    push( @{ $this->{loci}->{$locusId} }, $col_name );
  }
  return sort file::Mhc::Hla::_sortLoci keys %{ $this->{loci} };
}

sub getLocusColNames {
  my file::Mhc::Hla $this = shift;
  my ($locus_id) = @_;

  my @cols = ();
  my $loci = $this->{loci};
  return @cols if ( !defined($loci) || !defined( $loci->{$locus_id} ) );
  return @{ $loci->{$locus_id} };
}

################################################################################

1;

__END__

=head1 NAME

Hla.pm

=head1 DESCRIPTION

This concrete is the HLA locus file reader/writer. It is a
subclass of L<file::Mhc>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new file::Mhc::Hla(file, type, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=head2 B<$entity_data = getEntityDataStruct(entity_name)>

For a given locus entity_name, this method returns Perl Hash with
the locus data as defined by the allele lookup with the following
following components:

   full_entity_name -- the full locus name as defined by IMGT (eg, 'HLA-A', 'HLA-Cw')
   entity_id        -- locus_id from the database for the locus
   locus_id         -- locus_id from the database for the locus
   short_locus_name -- the short locus name that is often used (eg, 'A', 'Cw')
   alt_locus_name   -- the alternate locus name this is often used (eg, 'A', 'C')

=head2 B<@loci = getLoci>

This method returns the array of locus_ids for the loci that appear in
the file.

=head2 B<@col_names = getLocusColNames(locus_id)>

This method returns the array of col_names that appear in the for the
given locus_id.

=cut
