package file::Mhc::Feature;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::PerlObject;

use lookup::LookupTable::Features;

use base 'file::Mhc';

use fields qw (
  feature_lookup
  sequence_features
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
##
### Variant Sequence Type Column Definitions
###
sub TYPE_ROW_INDEX   { return 0; }
sub FILLER_ROW_INDEX { return 1; }
sub HEADER_ROW_INDEX { return 2; }
###
### Error Category
###
sub ERR_CAT { return file::ErrMsgs::HLA_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _getSequenceFeatureAttribute {
  my file::Mhc::Feature $this = shift;
  my ( $sequence_feature_id, $attrib ) = @_;

  my @cols              = ();
  my $sequence_features = $this->{sequence_features};
  return @cols
    if ( !defined($sequence_features)
    || !defined( $sequence_features->{$sequence_feature_id} ) );
  my $attrib_value = $sequence_features->{$sequence_feature_id}->{$attrib};
  return @{$attrib_value}
    if ( ref($attrib_value) eq util::PerlObject::ARRAY_TYPE );
  return $attrib_value;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $type, $taxon_id, $seq_type_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Feature $this =
    $that->SUPER::new( $file, $type, $taxon_id, $tools, $error_mgr );

  $this->{num_cols}     = 3256;
  $this->{num_entities} = 3000;

  $this->setEmptyVals( '-', util::Constants::EMPTY_STR );
  $this->setTypeValue( $tools->getFileTypeHeader( $tools->VariantType ) );
  $this->setFillerRow( $tools->getFileTypeFillerRow( $tools->VariantType ) );

  $this->{feature_lookup} =
    new lookup::LookupTable::Features( $taxon_id, $seq_type_id, $tools,
    $error_mgr );

  $this->{sequence_features} = undef;

  return $this;
}

sub merge {
  my file::Mhc::Feature $this = shift;
  my ($file) = @_;
  ###
  ### file must be a feature type
  ###
  my $fileRef = ref($file);
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 6,
    [ ref($this), $fileRef ],
    $fileRef !~ /^file::Mhc::Feature/
  );
  ###
  ### file must be of the same type
  ###
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 9,
    [ $this->type, $file->type ],
    $this->type ne $file->type
  );
  ###
  ### Now perform the merge
  ###
  my @fileNoOptColOrd = $file->getEntityColsByOrder;
  my @objCols         = $this->getCols;

  my $index = 0;
  foreach my $entity ( @{ $this->_getData } ) {
    ###
    ### These are type row and the filler row
    ###
    my $fileEntity = undef;
    if ( $index == TYPE_ROW_INDEX ) {
      $index++;
      next;
    }
    elsif ( $index == FILLER_ROW_INDEX || $index == HEADER_ROW_INDEX ) {
      my $fileData = $file->_getData;
      $fileEntity = $fileData->[$index];
    }
    else {
      ###
      ### Data row
      ###
      my $rowId    = $entity->{ $this->ROW_ID_COL };
      my $entityId = $entity->{ $this->getIdCol };
      ###
      ### Now get the file entity
      ###
      $fileEntity = $file->getEntity($rowId);
      $this->{error_mgr}
        ->exitProgram( ERR_CAT, 7, [$rowId], !defined($fileEntity) );
      ###
      ### Check entity IDs
      ###
      my $fileEntityId = $fileEntity->{ $file->getIdCol };
      $this->{error_mgr}->exitProgram(
        ERR_CAT, 8,
        [ $rowId, $entityId, $fileEntityId ],
        $entityId ne $fileEntityId
      );
    }
    ###
    ### Now copy columns
    ###
    my $curr_col = $this->{last_col};
    foreach my $col (@fileNoOptColOrd) {
      $curr_col++;
      my $col_name = $objCols[$curr_col];
      my $col_val  = $fileEntity->{$col};
      $entity->{$col_name} = $col_val;
      if ( $index == HEADER_ROW_INDEX ) {
        ###
        ### Correction for header data
        ###
        my $entityName = $file->mhcType->colNameToEntityName($col_val);
        my $entityData = $file->getEntityDataStruct($entityName);
        $entityData->{col_name}           = $col_val;
        $entityData->{reader_col_name}    = $col_name;
        $this->{entity_cols}->{$col_name} = $entityData;
        $this->{header_map}->{$col_val}   = $entityData;
      }
    }
    $index++;
  }
  ###
  ### Lastly, reset last column
  ###
  $this->{last_col} += scalar @fileNoOptColOrd;
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setVarCols {
  my file::Mhc::Feature $this = shift;
  my ( $version_info, $names, $var_cols ) = @_;

  my $tools = $this->{tools};
  ###
  ### Columns Defined
  ###
  $this->{cols} = [ $this->getInitialCols, @{$var_cols} ];
  $this->{last_col} = $#{ $this->{cols} };
  ###
  ### Add the Initial Rows
  ###
  my $type = {
    $this->getFirstCol  => $this->getTypeValue,
    $this->getSecondCol => $version_info,
  };
  my $names_header = { %{$names} };
  $names_header->{ $this->getFirstCol } = $this->getFillerRowName;
  my $header = {};
  foreach my $col_name ( @{ $this->{cols} } ) {
    $header->{$col_name} = $col_name;
  }
  $this->{data} = [];
  push( @{ $this->{data} }, $type, $names_header, $header );
  ###
  ### Set the beginning of the data
  ###
  $this->{data_index} = $#{ $this->{data} } + 1;
  ###
  ### Compute the header and type data
  ###
  $this->{header_data} = $this->getDataRow($header);
  $this->{type_data}   = $this->getDataRow($type);
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub getEntityDataStruct {
  my file::Mhc::Feature $this = shift;
  my ($entity_name) = @_;

  my $featureData   = $this->{feature_lookup}->getValue($entity_name);
  my $entity_struct = {
    full_entity_name => $featureData->{feature_number},
    entity_id        => $featureData->{feature_id},
    locus_id         => $featureData->{locus_id},
    entity_names     => $featureData->{feature_names},
    positions        => $featureData->{positions},
  };

  return $entity_struct;
}

sub _sortSequenceFeatures { $a <=> $b; }

sub getSequenceFeatures {
  my file::Mhc::Feature $this = shift;

  return
    sort file::Mhc::Feature::_sortSequenceFeatures
    keys %{ $this->{sequence_features} }
    if ( defined( $this->{sequence_features} ) );
  ###
  ### Compute the sequence features once
  ###
  $this->{sequence_features} = {};
  foreach my $col_name ( sort $this->getEntityCols ) {
    my $entityData        = $this->getEntityData($col_name);
    my $sequenceFeatureId = $entityData->{entity_id};
    my $fileColName       = $entityData->{col_name};
    if ( !defined( $this->{sequence_features}->{$sequenceFeatureId} ) ) {
      $this->{sequence_features}->{$sequenceFeatureId} = {
        name           => $entityData->{full_entity_name},
        entity_names   => $entityData->{entity_names},
        positions      => $entityData->{positions},
        col_names      => [],
        file_col_names => [],
      };
    }
    push(
      @{ $this->{sequence_features}->{$sequenceFeatureId}->{col_names} },
      $col_name
    );
    push(
      @{ $this->{sequence_features}->{$sequenceFeatureId}->{file_col_names} },
      $fileColName
    );
  }
  return
    sort file::Mhc::Feature::_sortSequenceFeatures
    keys %{ $this->{sequence_features} };
}

sub getSequenceFeatureColNames {
  my file::Mhc::Feature $this = shift;
  my ($sequence_feature_id) = @_;

  return $this->_getSequenceFeatureAttribute( $sequence_feature_id,
    'col_names' );
}

sub getSequenceFeatureFileColNames {
  my file::Mhc::Feature $this = shift;
  my ($sequence_feature_id) = @_;

  return $this->_getSequenceFeatureAttribute( $sequence_feature_id,
    'file_col_names' );
}

sub getSequenceFeatureName {
  my file::Mhc::Feature $this = shift;
  my ($sequence_feature_id) = @_;

  return $this->_getSequenceFeatureAttribute( $sequence_feature_id, 'name' );
}

sub getSequenceFeatureNames {
  my file::Mhc::Feature $this = shift;
  my ($sequence_feature_id) = @_;

  return $this->_getSequenceFeatureAttribute( $sequence_feature_id,
    'entity_names' );
}

sub getSequenceFeaturePositions {
  my file::Mhc::Feature $this = shift;
  my ($sequence_feature_id) = @_;

  return $this->_getSequenceFeatureAttribute( $sequence_feature_id,
    'positions' );
}

################################################################################

1;

__END__

=head1 NAME

Feature.pm

=head1 DESCRIPTION

This concrete is the sequence feature file reader/writer. It is a
subclass of L<file::Mhc>.
The assumed undefined allele cells are the empty string and the following

   -

The first column value for the file type row is
B<'HLA Sequence Feature Variant Type Results'> and this is assumed to
be the first row in the file.  The first column value for the B<data
row header> is determined by the source type of the allele file from
which the vector file has been generated.  This row is assumed to be
the third row in the file.  The second row in the file is a filler row
and contains the sequence feature names for each sequence feature and
contains the name B<'Sequence feature names are listed in this row'>
in the first column.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new file::Mhc::Feature(file, type, taxon_id, tools, error_mgr)>

This is the constructor for the class.

=head2 B<merge(file)>

This method takes the content of the hla file (B<file::Mhc::Feature>)
of the same file type and merges it with the content of the object.
The process assumes each file contains a type row, names (filler) row ,
and header row, and that each corresponding data row by row ID is for the
same entity ID.  This method merges the names row, header row and data
rows of the hla file for the variant data to the object.  The optional
columns of the hla file are ignored, while those of the object are
maintained.

=head1 SETTER METHODS

The following setter methods are exported by this class

=head2 B<setVarCols($version_info, $name_cols, $var_cols)>

This method resets the data in the file, adds the type row,
the names row, and  variant columns to the initial columns and
defines the type and the header data rows.

=head1 GETTER METHODS

The following getter methods are exported by this class

=head2 B<$entity_data = getEntityDataStruct(entity_name)>

This method returns Perl Hash data structure from feature lookup
that contains the following components for the entity:

   full_entity_name -- the full feature number as defined by IMGT
   entity_id        -- id from the database for the feature number
   locus_id         -- id of the locus associated with the feature number
   entity_names     -- the string containing all feature names
   positions        -- the string containing all amino-acid positions

=head2 B<@sequence_features = getSequenceFeatures>

This method returns the ordered list of sequence features IDs that
occur in the file.

=head2 B<@col_names = getSequenceFeatureColNames(sequence_feature_id)>

This method returns the list of column names for the given sequence
feature ID.

=head2 B<@file_col_names = getSequenceFeatureFileColNames(sequence_feature_id)>

The method returns the list of file column names for the given
sequence feature ID.

=head2 B<$sequence_feature_name = getSequenceFeatureName(sequence_feature_id)>

This method returns the sequence feature name for the given sequence
feature ID.

=head2 B<$feature_names = getSequenceFeatureNames(sequence_feature_id)>

This method returns the string (comma-separted) of feature names for
the given sequence feature ID.

=head2 B<$sequence_positions = getSequenceFeaturePositions(sequence_feature_id)>

This method returns the string (comma-separted) of amino-acid
positions for the given sequence feature ID.

=cut
