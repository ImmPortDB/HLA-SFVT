package file::Mhc::Feature::Pypop;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'file::Mhc::Feature';

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$) {
  my ( $that, $file, $taxon_id, $seq_type_id, $tools, $error_mgr ) = @_;
  my file::Mhc::Feature::Pypop $this =
    $that->SUPER::new( $file, $tools->PypopType, $taxon_id, $seq_type_id,
    $tools, $error_mgr );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

Typing.pm

=head1 DESCRIPTION

This concrete class defines the HLA sequence featur type for the HLA
typing result.  It is a subclass of L<file::Mhc::Feature>.

=head1 METHODS

The following static methods are exported by this class.

=head2 B<new file::Mhc::Feature::Pypop(file, taxon_id, seq_type_id, tools, error_mgr)>

This is the constructor for the class.

=cut
