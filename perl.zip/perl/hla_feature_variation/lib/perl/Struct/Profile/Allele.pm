package perl::Struct::Profile::Allele;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PerlObject;

use base 'perl::Struct::Profile';

use fields
  qw(
  alignment_seqs
  allele_alignments
  cds_seq_structures
  gene_seq_structures
  molecule_seqs
  pubmed_references
  seq_biosources
  seq_evidences
  variant_seqs
);

###############################################################################
#
#				   Constants
#
################################################################################

sub SUB_STRUCTURES {
  return {
    pubmed_references => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'pubmed_reference',
    },

    seq_evidences => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'seq_evidence',
    },

    seq_biosources => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'seq_biosource',
    },

    gene_seq_structures => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'gene_seq_structure',
    },

    molecule_seqs => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'molecule_seq',
    },

    alignment_seqs => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'alignment_seq',
    },

    variant_seqs => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'variant_seq',
    },

    allele_alignments => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'allele_alignment',
    },

    variant_maps => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'variant_map',
    },

    cds_seq_structures => {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'cds_seq_structure',
    },

    allele => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        ###
        ### Allele specific
        ###
        allele_id         => undef,
        allele_name       => undef,
        order_allele_name => undef,
        old_allele_name   => undef,
        locus_id          => undef,
        imgt_accession    => undef,
        release_version   => undef,
        seq_version       => undef,
        annot_version     => undef,
        codon_start       => undef,
        seq_create_date   => undef,
        seq_update_date   => undef,
        annot_update_date => undef,
        cds_positions     => undef,
        trans_start       => undef,
        trans_stop        => undef,
        partial_seq       => undef,
        comments          => undef,
        cwd_allele        => undef,
        g_code            => undef,
        pseudo_gene       => undef,
        order_allele_name => undef,
        imgt_hla_g_code   => undef,
        imgt_hla_p_code   => undef,
        ###
        ### Substructures (Arrays)
        ###
        alignment_seqs      => undef,
        pubmed_references   => undef,
        seq_evidences       => undef,
        seq_biosources      => undef,
        gene_seq_structures => undef,
        molecule_seqs       => undef,
        allele_alignments   => undef,
        variant_maps        => undef,
        cds_seq_structures  => undef,
        variant_seqs        => undef,
        ###
        ### Substructures (Hash)
        ###
        allele_nomenclature => undef,
      }
    },

    allele_nomenclature => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id         => undef,
        locus_id          => undef,
        allele_name       => undef,
        locus_name        => undef,
        allele_group      => undef,
        hla_protein       => undef,
        coding_region     => undef,
        non_coding_region => undef,
        suffix            => undef,
      }
    },

    pubmed_reference => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id    => undef,
        pubmed_id    => undef,
        pubmed_title => undef,
      }
    },

    seq_evidence => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        seq_evidence_key => undef,

        allele_id    => undef,
        accession    => undef,
        authority_id => undef,
        acc_version  => undef,
      }
    },

    seq_biosource => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id => undef,
        cell_line => undef,
      }
    },

    gene_seq_structure => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id      => undef,
        gss_start_pos  => undef,
        gss_end_pos    => undef,
        gene_struct_id => undef,
        order_num      => undef,
      }
    },

    cds_seq_structure => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id     => undef,
        css_start_pos => undef,
        css_end_pos   => undef,
        cds_struct_id => undef,
      }
    },

    molecule_seq => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id   => undef,
        seq_type_id => undef,
        mol_length  => undef,
        mol_seq     => undef,
      }
    },

    alignment_seq => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id    => undef,
        seq_type_id  => undef,
        align_length => undef,
        align_seq    => undef,
      }
    },

    variant_seq => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id   => undef,
        seq_type_id => undef,
        var_length  => undef,
        var_seq     => undef,
      }
    },

    allele_alignment => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_alignment_key => undef,

        allele_id          => undef,
        ungapped_start_pos => undef,
        ungapped_end_pos   => undef,
        view_type_id       => undef,
        seq_type_id        => undef,
        alignment_type_id  => undef,
        gene_struct_id     => undef,
        gapped_start_pos   => undef,
        gapped_end_pos     => undef,
        interval_name      => undef,
      }
    },

    variant_map => {
      kind => util::PerlObject::HASH_TYPE,
      type => {
        allele_id  => undef,
        variant_id => undef,
      }
    },

  };
}

################################################################################
#
#				 Class Methods
#
################################################################################
###
###  Lists
###
sub ALIGNMENT_SEQS_LIST      { return 'alignment_seqs'; }
sub PUBMED_REFERENCES_LIST   { return 'pubmed_references'; }
sub SEQ_EVIDENCES_LIST       { return 'seq_evidences'; }
sub SEQ_BIOSOURCES_LIST      { return 'seq_biosources'; }
sub GENE_SEQ_STRUCTURES_LIST { return 'gene_seq_structures'; }
sub MOLECULE_SEQS_LIST       { return 'molecule_seqs'; }
sub ALLELE_ALIGNMENTS_LIST   { return 'allele_alignments'; }
sub VARIANT_MAPS_LIST        { return 'variant_maps'; }
sub CDS_SEQ_STRUCTURES_LIST  { return 'cds_seq_structures'; }
sub VARIANT_SEQS_LIST        { return 'variant_seqs'; }
###
### Mapping Types
###
sub ACCESSION_MAP { return 'accession_map'; }
###
### Entity Component Path Names
###
sub ALLELE_NOMENCLATURE_PATH { return 'allele_nomenclature'; }
sub ALLELE_PATH              { return 'allele'; }
sub ALLELE_NAME_PATH         { return 'allele_name'; }
sub ALLELE_ID_PATH           { return 'allele_id'; }
sub IMGT_ACCESSION_PATH      { return 'imgt_accession'; }
###
### Component Key Definitions
###
sub PATH_TO_KEYS {
  return {
    &PUBMED_REFERENCES_LIST => {
      key  => 'pubmed_id',
      cmps => [],
    },

    &SEQ_EVIDENCES_LIST => {
      key  => 'seq_evidence_key',
      cmps => [ 'authority_id', 'accession', ],
    },

    &SEQ_BIOSOURCES_LIST => {
      key  => 'cell_line',
      cmps => [],
    },

    &GENE_SEQ_STRUCTURES_LIST => {
      key  => 'gss_start_pos',
      cmps => [],
    },

    &CDS_SEQ_STRUCTURES_LIST => {
      key  => 'css_start_pos',
      cmps => [],
    },

    &MOLECULE_SEQS_LIST => {
      key  => 'seq_type_id',
      cmps => [],
    },

    &ALIGNMENT_SEQS_LIST => {
      key  => 'seq_type_id',
      cmps => [],
    },

    &VARIANT_SEQS_LIST => {
      key  => 'seq_type_id',
      cmps => [],
    },

    &ALLELE_ALIGNMENTS_LIST => {
      key  => 'allele_alignment_key',
      cmps => [
        'seq_type_id',       'ungapped_start_pos',
        'ungapped_end_pos',  'view_type_id',
        'alignment_type_id', 'gene_struct_id',
      ],
    },

    &VARIANT_MAPS_LIST => {
      key  => 'variant_id',
      cmps => [],
    },

  };
}
###
### Search Paths
###
sub SEARCH_PATHS {
  return {
    &ALLELE_PATH => [ ALLELE_NAME_PATH, IMGT_ACCESSION_PATH, ALLELE_ID_PATH, ],
  };
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my ( $that, $generator, $product, $db, $release_ts, $error_mgr ) = @_;
  my perl::Struct::Profile::Allele $this = $that->SUPER::new(
    $generator,  $product,         $db,            $release_ts,
    ALLELE_PATH, ALLELE_NAME_PATH, SUB_STRUCTURES, SEARCH_PATHS,
    undef,       PATH_TO_KEYS,     $error_mgr
  );

  $this->{alignment_seqs}      = {};
  $this->{allele_alignments}   = {};
  $this->{cds_seq_structures}  = {};
  $this->{gene_seq_structures} = {};
  $this->{molecule_seqs}       = {};
  $this->{pubmed_references}   = {};
  $this->{seq_biosources}      = {};
  $this->{seq_evidences}       = {};
  $this->{variant_seqs}        = {};
  ###
  ### Return the object
  ###
  return $this;
}

################################################################################
#
#			   Public Population Methods
#
################################################################################

sub initAllele($;$) {
  my perl::Struct::Profile::Allele $this = shift;
  my ($not_initialize_profile) = @_;
  $not_initialize_profile =
    ( defined($not_initialize_profile) && $not_initialize_profile )
    ? util::Constants::TRUE
    : util::Constants::FALSE;

  ###
  ### Create Gene Profile
  ###
  $this->initializeObject if ( !$not_initialize_profile );
  $this->setEntity;
  $this->{alignment_seqs}      = {};
  $this->{allele_alignments}   = {};
  $this->{cds_seq_structures}  = {};
  $this->{gene_seq_structures} = {};
  $this->{molecule_seqs}       = {};
  $this->{pubmed_references}   = {};
  $this->{seq_biosources}      = {};
  $this->{seq_evidences}       = {};
  $this->{variant_seqs}        = {};

  return $this->entity;
}

sub addPmid {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $pmid, $title ) = @_;
  return if ( util::Constants::EMPTY_LINE($pmid) );
  my $allele           = $this->entity;
  my $pubmed_reference =
    $this->initializeSubstructByComponent( $this->PUBMED_REFERENCES_LIST );
  $this->{pubmed_references}->{$pmid} = $pubmed_reference;
  $pubmed_reference->{allele_id}      = $allele->{allele_id};
  $pubmed_reference->{pubmed_id}      = $pmid;
  $pubmed_reference->{pubmed_title}   = $title;
}

sub setPmids {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele                             = $this->entity;
  my $pubmed_references                  =
    $this->getCValue( $allele, $this->PUBMED_REFERENCES_LIST );
  push( @{$pubmed_references}, values %{ $this->{pubmed_references} } );
}

sub addEvidence {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $accession, $authority_id, $acc_version ) = @_;
  return if ( util::Constants::EMPTY_LINE($accession) );
  my $allele       = $this->entity;
  my $seq_evidence =
    $this->initializeSubstructByComponent( $this->SEQ_EVIDENCES_LIST );
  my $key = join( util::Constants::DOT, $authority_id, $accession );
  $this->{seq_evidences}->{$key} = $seq_evidence;
  $seq_evidence->{allele_id}     = $allele->{allele_id};
  $seq_evidence->{accession}     = $accession;
  $seq_evidence->{authority_id}  = $authority_id;
  $seq_evidence->{acc_version}   = $acc_version;
}

sub setEvidences {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele = $this->entity;
  my $seq_evidences = $this->getCValue( $allele, $this->SEQ_EVIDENCES_LIST );
  push( @{$seq_evidences}, values %{ $this->{seq_evidences} } );
}

sub addBiosource {
  my perl::Struct::Profile::Allele $this = shift;
  my ($cell_line) = @_;
  return if ( util::Constants::EMPTY_LINE($cell_line) );
  my $allele        = $this->entity;
  my $seq_biosource =
    $this->initializeSubstructByComponent( $this->SEQ_BIOSOURCES_LIST );
  $this->{seq_biosources}->{$cell_line} = $seq_biosource;
  $seq_biosource->{allele_id}           = $allele->{allele_id};
  $seq_biosource->{cell_line}           = $cell_line;
}

sub setBiosources {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele = $this->entity;
  my $seq_biosources = $this->getCValue( $allele, $this->SEQ_BIOSOURCES_LIST );
  push( @{$seq_biosources}, values %{ $this->{seq_biosources} } );
}

sub addGeneSeqStruct {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $gss_start_pos, $gss_end_pos, $gene_struct_id, $order_num ) = @_;
  my $allele = $this->entity;
  return if ( util::Constants::EMPTY_LINE($gss_start_pos) );
  my $gene_seq_structure =
    $this->initializeSubstructByComponent( $this->GENE_SEQ_STRUCTURES_LIST );
  $this->{gene_seq_structures}->{$gss_start_pos} = $gene_seq_structure;
  $gene_seq_structure->{allele_id}               = $allele->{allele_id};
  $gene_seq_structure->{gss_start_pos}           = $gss_start_pos;
  $gene_seq_structure->{gss_end_pos}             = $gss_end_pos;
  $gene_seq_structure->{gene_struct_id}          = $gene_struct_id;
  $gene_seq_structure->{order_num}               = $order_num;
}

sub setGeneSeqStruct {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele                             = $this->entity;
  my $gene_seq_structures                =
    $this->getCValue( $allele, $this->GENE_SEQ_STRUCTURES_LIST );
  push( @{$gene_seq_structures}, values %{ $this->{gene_seq_structures} } );
}

sub addMolSeq {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $seq, $seq_type_id ) = @_;
  return if ( util::Constants::EMPTY_LINE($seq_type_id) );
  my $allele       = $this->entity;
  my $molecule_seq =
    $this->initializeSubstructByComponent( $this->MOLECULE_SEQS_LIST );
  $this->{molecule_seqs}->{$seq_type_id} = $molecule_seq;
  $molecule_seq->{allele_id}             = $allele->{allele_id};
  $molecule_seq->{seq_type_id}           = $seq_type_id;
  $molecule_seq->{mol_length}            = length($seq);
  $molecule_seq->{mol_seq}               = $seq;
}

sub setMolSeqs {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele = $this->entity;
  my $molecule_seqs = $this->getCValue( $allele, $this->MOLECULE_SEQS_LIST );
  push( @{$molecule_seqs}, values %{ $this->{molecule_seqs} } );
}

sub addAlignSeq {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $seq, $seq_type_id ) = @_;
  return if ( util::Constants::EMPTY_LINE($seq_type_id) );
  my $allele        = $this->entity;
  my $alignment_seq =
    $this->initializeSubstructByComponent( $this->ALIGNMENT_SEQS_LIST );
  $this->{alignment_seqs}->{$seq_type_id} = $alignment_seq;
  $alignment_seq->{allele_id}             = $allele->{allele_id};
  $alignment_seq->{seq_type_id}           = $seq_type_id;
  $alignment_seq->{align_length}          = length($seq);
  $alignment_seq->{align_seq}             = $seq;
}

sub setAlignSeqs {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele = $this->entity;
  my $alignment_seqs = $this->getCValue( $allele, $this->ALIGNMENT_SEQS_LIST );
  push( @{$alignment_seqs}, values %{ $this->{alignment_seqs} } );
}

sub addVarSeq {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $seq, $seq_type_id ) = @_;
  return if ( util::Constants::EMPTY_LINE($seq_type_id) );
  my $allele      = $this->entity;
  my $variant_seq =
    $this->initializeSubstructByComponent( $this->VARIANT_SEQS_LIST );
  $this->{variant_seqs}->{$seq_type_id} = $variant_seq;
  $variant_seq->{allele_id}             = $allele->{allele_id};
  $variant_seq->{seq_type_id}           = $seq_type_id;
  $variant_seq->{var_length}            = length($seq);
  $variant_seq->{var_seq}               = $seq;
}

sub setVarSeqs {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele = $this->entity;
  my $variant_seqs = $this->getCValue( $allele, $this->VARIANT_SEQS_LIST );
  push( @{$variant_seqs}, values %{ $this->{variant_seqs} } );
}

sub addCdsSeqStruct {
  my perl::Struct::Profile::Allele $this = shift;
  my ( $css_start_pos, $css_end_pos, $cds_struct_id ) = @_;
  return if ( util::Constants::EMPTY_LINE($css_start_pos) );
  my $allele         = $this->entity;
  my $cds_seq_struct =
    $this->initializeSubstructByComponent( $this->CDS_SEQ_STRUCTURES_LIST );
  $this->{cds_seq_structures}->{$css_start_pos} = $cds_seq_struct;
  $cds_seq_struct->{allele_id}                  = $allele->{allele_id};
  $cds_seq_struct->{css_start_pos}              = $css_start_pos;
  $cds_seq_struct->{css_end_pos}                = $css_end_pos;
  $cds_seq_struct->{cds_struct_id}              = $cds_struct_id;
}

sub setCdsSeqStruct {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele                             = $this->entity;
  my $cds_seq_structures                 =
    $this->getCValue( $allele, $this->CDS_SEQ_STRUCTURES_LIST );
  push( @{$cds_seq_structures}, values %{ $this->{cds_seq_structures} } );
}

sub addAlignment {
  my perl::Struct::Profile::Allele $this = shift;
  my (
    $seq_type_id,      $view_type_id,       $alignment_type_id,
    $gene_struct_id,   $ungapped_start_pos, $ungapped_end_pos,
    $gapped_start_pos, $gapped_end_pos,     $interval_name
    )
    = @_;
  return if ( util::Constants::EMPTY_LINE($ungapped_start_pos) );
  my $allele           = $this->entity;
  my $allele_alignment =
    $this->initializeSubstructByComponent( $this->ALLELE_ALIGNMENTS_LIST );
  my $key = join( util::Constants::COLON,
    $seq_type_id,        $view_type_id, $gene_struct_id,
    $ungapped_start_pos, $ungapped_end_pos
  );
  $this->{allele_alignments}->{$key}      = $allele_alignment;
  $allele_alignment->{allele_id}          = $allele->{allele_id};
  $allele_alignment->{seq_type_id}        = $seq_type_id;
  $allele_alignment->{view_type_id}       = $view_type_id;
  $allele_alignment->{alignment_type_id}  = $alignment_type_id;
  $allele_alignment->{gene_struct_id}     = $gene_struct_id;
  $allele_alignment->{ungapped_start_pos} = $ungapped_start_pos;
  $allele_alignment->{ungapped_end_pos}   = $ungapped_end_pos;
  $allele_alignment->{gapped_start_pos}   = $gapped_start_pos;
  $allele_alignment->{gapped_end_pos}     = $gapped_end_pos;
  $allele_alignment->{interval_name}      = $interval_name;
}

sub setAlignments {
  my perl::Struct::Profile::Allele $this = shift;
  my $allele                             = $this->entity;
  my $allele_alignments                  =
    $this->getCValue( $allele, $this->ALLELE_ALIGNMENTS_LIST );
  push( @{$allele_alignments}, values %{ $this->{allele_alignments} } );
}

################################################################################

1;

__END__

=head1 NAME

Allele.pm

=head1 DESCRIPTION

This concrete class defines the class for generating annotation
profiles (B<generateProfile>) and writing annotation profile
(B<writeProfile>) for Hla Allele variants from Anthony Nolan.

The data-structure supported by this class is defined below.  The
attributes that are Perl referenced hashes and array are indicated

    allele
        allele_id
        allele_name
        order_allele_name
        old_allele_name
        locus_id
        imgt_accession
        release_version
        seq_version
        annot_version
        codon_start
        seq_create_date
        seq_update_date
        annot_update_date
        cds_positions
        trans_start
        trans_stop
        partial_seq
        comments
        cwd_allele
        g_code
        pseudo_gene
        order_allele_name
        imgt_hla_g_code
        imgt_hla_p_code
        ###
        ### Substructures (Arrays)
        ###
        alignment_seqs      list of alignment_seq
        pubmed_references   list of pubmed_reference
        seq_evidences       list of seq_evidence
        seq_biosources      list of seq_biosource
        gene_seq_structures list of gene_seq_structure
        molecule_seqs       list of molecule_seq
        allele_alignments   list of allele_alignment
        variant_maps        list of variant_map
        cds_seq_structures  list of cds_seq_structure
        variant_seqs        list of variant_seq
        ###
        ### Substructures (Hash)
        ###
        allele_nomenclature

    allele_nomenclature
        allele_id
        locus_id
        allele_name
        locus_name
        allele_group
        hla_protein
        coding_region
        non_coding_region
        suffix

    pubmed_reference
        allele_id
        pubmed_id
        pubmed_title

    seq_evidence
        seq_evidence_key
        allele_id
        accession
        authority_id
        acc_version

    seq_biosource
        allele_id
        cell_line

    gene_seq_structure
        allele_id
        gss_start_pos
        gss_end_pos
        gene_struct_id
        order_num

    cds_seq_structure
        allele_id
        css_start_pos
        css_end_pos
        cds_struct_id

    molecule_seq
        allele_id
        seq_type_id
        mol_length
        mol_seq

    alignment_seq
        allele_id
        seq_type_id
        align_length
        align_seq

    variant_seq
        allele_id
        seq_type_id
        var_length
        var_seq

    allele_alignment
        allele_alignment_key
        allele_id
        ungapped_start_pos
        ungapped_end_pos
        view_type_id
        seq_type_id
        alignment_type_id
        gene_struct_id
        gapped_start_pos
        gapped_end_pos
        interval_name

    variant_map
        allele_id
        variant_id


=head1 CONSTANTS

The following list constants are defined by this class:

   perl::Struct::Profile::Allele::ALIGNMENT_SEQS_LIST      -- alignment_seqs
   perl::Struct::Profile::Allele::PUBMED_REFERENCES_LIST   -- pubmed_references
   perl::Struct::Profile::Allele::SEQ_EVIDENCES_LIST       -- seq_evidences
   perl::Struct::Profile::Allele::SEQ_BIOSOURCES_LIST      -- seq_biosources
   perl::Struct::Profile::Allele::GENE_SEQ_STRUCTURES_LIST -- gene_seq_structures
   perl::Struct::Profile::Allele::MOLECULE_SEQS_LIST       -- molecule_seqs
   perl::Struct::Profile::Allele::ALLELE_ALIGNMENTS_LIST   -- allele_alignments
   perl::Struct::Profile::Allele::VARIANT_MAPS_LIST        -- variant_maps
   perl::Struct::Profile::Allele::CDS_SEQ_STRUCTURES_LIST  -- cds_seq_structures
   perl::Struct::Profile::Allele::VARIANT_SEQS_LIST        -- variant_seqs

The following constant (class method) defines the type of B<maps> that
can be generated during the generation of a profile:

   perl::Struct::Profile::Allele::ACCESSION_MAP

The following entity component path names are defined by this class

   perl::Struct::Profile::Allele::ALLELE_NOMENCLATURE_PATH -- allele_nomenclature
   perl::Struct::Profile::Allele::ALLELE_PATH              -- allele
   perl::Struct::Profile::Allele::ALLELE_NAME_PATH         -- allele_name
   perl::Struct::Profile::Allele::ALLELE_ID_PATH           -- allele_id
   perl::Struct::Profile::Allele::IMGT_ACCESSION_PATH      -- imgt_accession

The following search paths are defined by this class

   perl::Struct::Profile::Allele::SEARCH_PATHS
   -- returns the referenced Perl hash containing the following (key, value)-pairs
      ALLELE_PATH => referenced Perl array of 
                     - ALLELE_NAME_PATH
                     - IMGT_ACCESSION_PATH
                     - ALLELE_ID_PATH

The path to keys mapping is defined by this class

   perl::Struct::Profile::Allele::PATH_TO_KEYS
   -- returns the referenced Perl hash containing the following (key, value)-pairs
      PUBMED_REFERENCES_LIST => referenced Perl hash
        key  => pubmed_id
        cmps => []

      SEQ_EVIDENCES_LIST => referenced Perl hash
        key  => seq_evidence_key
        cmps => reference Perl array of 'authority_id', 'accession'

      SEQ_BIOSOURCES_LIST => referenced Perl hash
        key  => cell_line
        cmps => []

      GENE_SEQ_STRUCTURES_LIST => referenced Perl hash
        key  => gss_start_pos
        cmps => []

      CDS_SEQ_STRUCTURES_LIST => referenced Perl hash
        key  => css_start_pos
        cmps => []

      MOLECULE_SEQS_LIST => referenced Perl hash
        key  => seq_type_id
        cmps => []

      ALIGNMENT_SEQS_LIST => referenced Perl hash
        key  => seq_type_id
        cmps => []

      VARIANT_SEQS_LIST => referenced Perl hash
        key  => seq_type_id
        cmps => []

      ALLELE_ALIGNMENTS_LIST => referenced Perl hash
        key  => allele_alignment_key
        cmps => reference Perl array of 
                  'seq_type_id',       'ungapped_start_pos',
                  'ungapped_end_pos',  'view_type_id',
                  'alignment_type_id', 'gene_struct_id'

      VARIANT_MAPS_LIST => referenced Perl hash
        key  => variant_id
        cmps => []

=head1 METHODS

These methods are used for creating and populating a gene profile.

=head2 B<new perl::Struct::Profile::Allele(generator, product, db, release_ts, error_mgr)>

This method is the constructor for this module.  It creates an empty
profile.  Normally, this method is only used as part of the
instantiation of a subclass of this class that implements the
re-implementable methods (generatProfile and writeProfile).  All
parameters are required.  The B<generator> parameter specifies whether
the class generates rss (TRUE) or does not generate rss (FALSE).  The
B<error_mgr> is an instance of the class L<util::ErrMgr>. The database
session (base class L<util::Db>) is required if database access is
required of the profile, otherwise it must be set to undef.

=head2 B<$gene = initAllele([not_initialize_profile])>

This method initialize the profile by resetting the entity, attrs,
num_proteins, num_transcripts, and relships and returns the entity.
Further if B<not_initialize_profile> is defined and TRUE (1), then the
list of entities is not reset, otherwise it is is also reset.  The
adder/setter hashes are also initialized.

   alignment_seqs
   allele_alignments
   cds_seq_structures
   gene_seq_structures
   molecule_seqs
   pubmed_references
   seq_biosources
   seq_evidences
   variant_seqs

=head1 ADDER METHODS

The following adder methods are exported from this class.

=head2 B<addPmid(pmid, title)>

This method adds the PubMed id and title to the pubmed_references Perl
hash.

=head2 B<addEvidence(accession, authority_id, acc_version)>

This method adds the evidence to the seq_evidences Perl
hash.

=head2 B<addBiosource(cell_line)>

This method adds the bio-source to the seq_biosources Perl
hash.

=head2 B<addGeneSeqStruct(gss_start_pos, gss_end_pos, gene_struct_id, order_num)>

This method adds gene sequence structure to the gene_seq_structures Perl
hash.

=head2 B<addMolSeq(seq, seq_type_id)>

This method adds the molecular sequence to the molecule_seqs Perl
hash.

=head2 B<addAlignSeq(seq, seq_type_id)>

This method adds the alignment sequence to the alignment_seqs Perl
hash.

=head2 B<addVarSeq(seq, seq_type_id)>

This method adds variant sequence to the variant_seqs Perl
hash.

=head2 B<addCdsSeqStruct(css_start_pos, css_end_pos, cds_struct_id)>


This method adds CDS sequence structure to the cds_seq_structures Perl
hash.

=head2 B<addAlignment(seq_type_id, view_type_id, alignment_type_id, gene_struct_id, ungapped_start_pos, ungapped_end_pos, gapped_start_pos, gapped_end_pos, interval_name)>

This method adds the feature alignment to the allele_alignments Perl
hash.

=head1 SETTER METHODS

The following setter methods are exported from this class.

=head2 B<setPmid>

This method add the values in the pubmed_references Perl hash to
pub_references list.

=head2 B<setEvidence>

This method add the values in the seq_evidences Perl hash to the
seq_evidences list.

=head2 B<setBiosource>

This method add the values in the seq_biosources Perl hash to the
seq_biosources list.

=head2 B<setGeneSeqStruct>

This method add the values in the gene_seq_structures Perl hash to the
gene_seq_structures list.

=head2 B<setMolSeq>

This method add the values in the molecule_seq Perl hash to the
molecule_seqs list.

=head2 B<setAlignSeq>

This method add the values in the alignment_seqs Perl hash to the
alignment_seqs list.

=head2 B<setVarSeq>

This method add the values in the variant_seqs Perl hash to the
variant_seqs list.

=head2 B<setCdsSeqStruct>


This method add the values in the cds_seq_structures Perl hash to the
cds_seq_structures list.

=head2 B<setAlignment>

This method add the values in the allele_alignments Perl hash to the
allele_alignments list.

=cut
