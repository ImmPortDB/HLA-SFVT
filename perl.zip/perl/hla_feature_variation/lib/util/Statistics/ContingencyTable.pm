package util::Statistics::ContingencyTable;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;
use Pod::Usage;

use util::Constants;
use util::ErrMsgs;
use util::Table;

use base 'util::Statistics';

use fields qw (
  col_name
  col_vals
  contingency_table
  col_marginals
  data
  row_marginals
  row_name
  row_vals
  table_cols
  table_ord
  total
);

################################################################################
#
#			     Static Class Constants
#
################################################################################
###
### Contingency Statistic
###
sub FREQ_COL { return 'Freq'; }
###
### Contingency Table
###
sub TOTAL_COL { return 'total'; }
sub TOTAL_VAL { return 'Total'; }
sub EMPTY_VAL { return util::Constants::HYPHEN; }
###
### Error Category
###
sub ERR_CAT { return util::ErrMsgs::STATS_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _createContingencyTable {
  my util::Statistics::ContingencyTable $this = shift;

  $this->{data}       = [];
  $this->{table_cols} = {
    &TOTAL_COL        => TOTAL_VAL,
    $this->{row_name} => $this->{row_name},
  };

  $this->{table_ord} = [ $this->{row_name} ];
  foreach my $col_val ( @{ $this->{col_vals} } ) {
    $this->{table_cols}->{$col_val} = "$col_val Freq";
    push( @{ $this->{table_ord} }, $col_val );
  }
  push( @{ $this->{table_ord} }, TOTAL_COL );
  my $table = new util::Table( $this->{error_mgr}, %{ $this->{table_cols} } );
  $table->setColumnOrder( @{ $this->{table_ord} } );
  $table->setColumnJustification( $this->{row_name}, $table->LEFT_JUSTIFY );
  $table->setEmptyField(EMPTY_VAL);
  $table->setInHeader(util::Constants::TRUE);
  $this->{contingency_table} = $table;
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$$) {
  my ( $that, $header, $row_name, $row_vals, $col_name, $col_vals, $error_mgr )
    = @_;
  my util::Statistics::ContingencyTable $this =
    $that->SUPER::new( $header, undef, $error_mgr, $row_name, $row_vals,
    $col_name, $col_vals );
  $this->setShowTotal(util::Constants::TRUE);
  $this->setCountsToZero(util::Constants::TRUE);
  $this->setCountColName(FREQ_COL);

  $this->{col_name} = $col_name;
  $this->{col_vals} = [ @{$col_vals} ];
  $this->{row_name} = $row_name;
  $this->{row_vals} = [ @{$row_vals} ];
  ###
  ### total and marginals
  ###
  $this->{total}         = 0;
  $this->{row_marginals} = {};
  foreach my $row_val ( @{ $this->{row_vals} } ) {
    $this->{row_marginals}->{$row_val} = 0;
  }
  $this->{col_marginals} = {};
  foreach my $col_val ( @{ $this->{col_vals} } ) {
    $this->{col_marginals}->{$col_val} = 0;
  }
  ###
  ### Create Contingency Table
  ###
  $this->_createContingencyTable;

  return $this;
}

sub printContingencyTable {
  my util::Statistics::ContingencyTable $this = shift;
  my ($header) = @_;
  $this->{contingency_table}->generateTable($header);
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setMarginals {
  my util::Statistics::ContingencyTable $this = shift;

  $this->{data} = [];
  foreach my $row_val ( @{ $this->{row_vals} } ) {
    my $data = { $this->{row_name} => $row_val };
    $this->{row_marginals}->{$row_val} =
      $this->count( $this->{row_name}, $row_val );
    $data->{&TOTAL_COL} = $this->{row_marginals}->{$row_val};
    foreach my $col_val ( @{ $this->{col_vals} } ) {
      $data->{$col_val} =
        $this->count( $this->{col_name}, $col_val, $this->{row_name},
        $row_val );
    }
    push( @{ $this->{data} }, $data );
  }
  my $data = { $this->{row_name} => TOTAL_VAL };
  foreach my $col_val ( @{ $this->{col_vals} } ) {
    $this->{col_marginals}->{$col_val} =
      $this->count( $this->{col_name}, $col_val );
    $data->{$col_val} = $this->{col_marginals}->{$col_val};
    $this->{total} += $this->{col_marginals}->{$col_val};
  }
  $data->{&TOTAL_COL} = $this->{total};
  push( @{ $this->{data} }, $data );
  $this->{contingency_table}->setData( @{ $this->{data} } );
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub rowName {
  my util::Statistics::ContingencyTable $this = shift;

  return $this->{row_name};
}

sub colName {
  my util::Statistics::ContingencyTable $this = shift;

  return $this->{col_name};
}

sub rowVals {
  my util::Statistics::ContingencyTable $this = shift;

  return @{ $this->{row_vals} };
}

sub colVals {
  my util::Statistics::ContingencyTable $this = shift;

  return @{ $this->{col_vals} };
}

sub frequency {
  my util::Statistics::ContingencyTable $this = shift;
  my ( $row_val, $col_val ) = @_;

  return $this->count( $this->{row_name}, $row_val, $this->{col_name},
    $col_val );
}

sub rowMarginal {
  my util::Statistics::ContingencyTable $this = shift;
  my ($row_val) = @_;

  return $this->{row_marginals}->{$row_val};
}

sub colMarginal {
  my util::Statistics::ContingencyTable $this = shift;
  my ($col_val) = @_;

  return $this->{col_marginals}->{$col_val};
}

sub tableCols {
  my util::Statistics::ContingencyTable $this = shift;

  return %{ $this->{table_cols} };
}

sub tableData {
  my util::Statistics::ContingencyTable $this = shift;

  return @{ $this->{data} };
}

sub tableOrd {
  my util::Statistics::ContingencyTable $this = shift;

  return @{ $this->{table_ord} };
}

sub total {
  my util::Statistics::ContingencyTable $this = shift;

  return $this->{total};
}

################################################################################

1;

__END__

=head1 NAME

ContingencyTable.pm

=head1 DESCRIPTION

This class defines the contingency table data structure using
the base class L<util::Statistics>

=head1 METHODS

The following methods are exported by this class.

=head2 B<new util::Statistics::ContingencyTable(header, row_name, row_vals, col_name, col_vals, error_mgr)>

This method is the constructor of the class.  The B<header> is used
for generating tables to the log.  The B<row_name> and Perl referenced
array B<row_vals> define the rows of the contingency table.  The
B<col_name> and Perl referenced array B<col_vals> define the columns
of the contingency table.  The B<error_mgr> is the standard logging
output manager L<util::ErrMgr>.

=head2 B<printContingencyTable>

This method generates the contingency table to the log.

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setMarginals>

This method completes the contingency table by computing the marginal
row and column totals.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$row_name = rowName>

The method returns the row name of the contingency table.

=head2 B<$col_name = colName>

This method returns the column name of the contingency table.

=head2 B<@row_vals = rowVals>

This method returns the array of row values.

=head2 B<@col_vals = colVals>

This method returns the array of column values.

=head2 B<$freq = frequency(row_val, col_val)>

This method returns the frequency for the row and column values.

=head2 B<$row_total = rowMarginal(row_val)>

This method returns the total for the given row value.  This value
will be defined only after the method L<"setMarginals"> has been
executed.

=head2 B<$col_val = colMarginal(col_val)>

This method returns the total for the given column value.  This value
will be defined only after the method L<"setMarginals"> has been
executed.

=head2 B<%cols = tableCols>

This method retruns the Perl hash that defines the column names (key)
and headers (value) in the contingency table.

=head2 B<@data = tableData>

This method returns the data for the contingency table including the
row and column marginals.  The data is an array containing referenced
Perl hashes that have keys defined by B<tableCols> Perl hash.  This
value will be defined only after the method L<"setMarginals"> has been
executed.

=head2 B<@ord = tableOrd>

This method returns the Perl array defining the column order for the
contingency table.

=head2 B<$total = total>

This method defines grand total for the contingency tables.

=cut
