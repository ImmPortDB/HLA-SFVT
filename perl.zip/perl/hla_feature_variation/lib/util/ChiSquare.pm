package util::ChiSquare;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;
use Pod::Usage;

use util::Constants;
use util::ErrMsgs;
use util::Math;
use util::PathSpecifics;

use fields qw (
  bonferroni
  chi_square
  confid_interv
  contingency_table
  dof
  error_mgr
  mp_val
  multiple_dof
  odds_ratio
  p_val
  std_err
);

################################################################################
#
#				Private Methods
#
################################################################################

sub _calculateOddsRatio {
  my util::ChiSquare $this = shift;

  $this->{odds_ratio} = undef;
  my $conting = $this->{contingency_table};
  my @rows    = $conting->rowVals;
  my @cols    = $conting->colVals;
  return if ( scalar @rows != 2 || scalar @cols != 2 );
  my $a = $conting->frequency( $rows[0], $cols[0] );
  my $b = $conting->frequency( $rows[0], $cols[1] );
  my $num = ( $a != 0 && $b != 0 ) ? ( $a / $b ) : 0.0;
  my $c = $conting->frequency( $rows[1], $cols[0] );
  my $d = $conting->frequency( $rows[1], $cols[1] );
  my $dem = ( $c != 0 && $d != 0 ) ? ( $c / $d ) : 0.0;

  return if ( !( $num > 0.0 && $dem > 0.0 ) );

  $this->{odds_ratio} = $num / $dem;
  $this->{std_err}    = sqrt( 1 / $a + 1 / $b + 1 / $c + 1 / $d );

  my @confidence_interval =
    util::Math::confidenceInterval( $this->{odds_ratio}, $this->{std_err} );
  $this->{confid_interv} = [@confidence_interval];
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$) {
  my util::ChiSquare $this = shift;
  my ( $contingency_table, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{contingency_table} = $contingency_table;
  $this->{error_mgr}         = $error_mgr;

  my @colVals = $contingency_table->colVals;
  my @rowVals = $contingency_table->rowVals;

  $this->{bonferroni}    = undef;
  $this->{chi_square}    = undef;
  $this->{confid_interv} = undef;
  $this->{dof}           = ( scalar @colVals - 1 ) * ( scalar @rowVals - 1 );
  $this->{mp_val}        = undef;
  $this->{multiple_dof}  = undef;
  $this->{odds_ratio}    = undef;
  $this->{p_val}         = undef;
  $this->{std_err}       = undef;

  util::Math::setErrorMgr($error_mgr);

  return $this;
}

sub runStatistic {
  my util::ChiSquare $this = shift;

  my $conting = $this->{contingency_table};
  ###
  ### 1.  Compute chi-square statistics
  ###
  $this->{chi_square} = 0.0;
  foreach my $row_val ( $conting->rowVals ) {
    foreach my $col_val ( $conting->colVals ) {
      my $obsFreq = $conting->frequency( $row_val, $col_val );
      my $expFreq =
        ( $conting->rowMarginal($row_val) * $conting->colMarginal($col_val) ) /
        $conting->total;
      $this->{chi_square} += ( $obsFreq - $expFreq )**2 / $expFreq;
    }
  }
  ###
  ### 2.  Determine p-value
  ###
  $this->{p_val} =
    util::Math::chiSquarePVal( $this->{chi_square}, $this->{dof} );
  ###
  ### 3.  Compute Bonferroni Correction
  ###
  $this->{bonferroni} =
    ( $this->{p_val} * $this->{dof} * ( $this->{dof} + 1 ) ) / 2;
  ###
  ### 4. calculate the odds ratio, if possible
  ###
  $this->_calculateOddsRatio;
  ###
  ### 5.  calculate multiple testing p-val
  ###
  if ( defined( $this->{multiple_dof} ) ) {
    $this->{mp_val} = $this->{multiple_dof} * $this->{p_val};
    if ( $this->{mp_val} > 1 ) { $this->{mp_val} = 1.0; }
  }
}

sub printResult {
  my util::ChiSquare $this = shift;
  my ($header) = @_;

  $header .=
      "  chi-square test:\n"
    . "    chi-square = "
    . $this->chiSquare . "\n"
    . "    DoF        = "
    . $this->dof . "\n"
    . "    p-val      = "
    . $this->pVal;
  $this->{contingency_table}->printContingencyTable($header);
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub setMultipleDof {
  my util::ChiSquare $this = shift;
  my ($multiple_dof) = @_;

  return if ( util::Constants::EMPTY_LINE($multiple_dof) );
  $multiple_dof = int($multiple_dof);
  return if ( $multiple_dof < 1 );
  $this->{multiple_dof} = $multiple_dof;
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub dof {
  my util::ChiSquare $this = shift;

  return $this->{dof};
}

sub chiSquare {
  my util::ChiSquare $this = shift;

  return $this->{chi_square} if ( !defined( $this->{chi_square} ) );
  return strip_whitespace( sprintf( '%10.5f', $this->{chi_square} ) );
}

sub pVal {
  my util::ChiSquare $this = shift;

  return $this->{p_val} if ( !defined( $this->{p_val} ) );
  return strip_whitespace( sprintf( '%13.5e', $this->{p_val} ) );
}

sub mpVal {
  my util::ChiSquare $this = shift;

  return $this->{mp_val}
    if ( !defined( $this->{mp_val} )
    || $this->{mp_val} == 1.0 );
  return strip_whitespace( sprintf( '%13.5e', $this->{mp_val} ) );
}

sub bonferroniCorrection {
  my util::ChiSquare $this = shift;

  return $this->{bonferroni} if ( !defined( $this->{bonferroni} ) );
  return strip_whitespace( sprintf( '%13.5e', $this->{bonferroni} ) );
}

sub oddsRatio {
  my util::ChiSquare $this = shift;

  return $this->{odds_ratio} if ( !defined( $this->{odds_ratio} ) );
  return strip_whitespace( sprintf( '%6.2f', $this->{odds_ratio} ) );
}

sub confidenceInterval {
  my util::ChiSquare $this = shift;

  return undef if ( !defined( $this->{confid_interv} ) );
  return
    strip_whitespace( sprintf( '%6.2f', $this->{confid_interv}->[0] ) ) . ' - '
    . strip_whitespace( sprintf( '%6.2f', $this->{confid_interv}->[1] ) );
}

################################################################################

1;

__END__

=head1 NAME

ChiSquare.pm

=head1 DESCRIPTION

This class defines the Chi-Square statistic using contingency
tables, L<util::Statistics::ContingencyTable>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new util::ChiSquare(contingency_table, error_mgr)>

This is the constructor of the class.  It requires a contingency table
(B<contingency_table>) which is an instance of the class
L<util::Statistics::ContingencyTable> and the error messaging manager
(B<error_mgr>) which is an instance of L<util::ErrMgr>.  The
constructor determines the degrees of freed for the contingency table.

=head2 B<runStatistic>

This method takes the contingency table and computes the Chi-Square
and its associated p-value and the Bonferroni correction.  Also, the
method calculates the odds ratio and confidence interval, if possible.

=head2 B<printResult>

The method prints the contingency table to the the log file using the
header provided.  This method also includes the Chi-square data
(degrees of freedom, chi-square, and p-vvalue) in the header.

=head1 GETTER METHODS

The following getter methods are exported by this class.  They depend
on the method L<"runStatistics"> being executed, otherwise undefined
values are returns.

=head2 B<$dof = dof>

This method returns the degrees of freedom for this chi-square.

=head2 B<$chiSquare = chiSquare>

The method returns the Chi-Square value appropriately formated
B<%10.5f>.

=head2 B<$bonferroniCorrection = bonferroniCorrection>

The method returns the Bonderroni correction value appropriately
formated B<%10.5f>.

=head2 B<$pVal = pVal>

This method returns the Chi-Square probabiltiy value (p-val)
appropriately formated B<%13.5e>.

=head2 B<$oddsRatio = oddsRatio>

This method returns the odds ration appropriately formated B<%6.2f>.

=head2 B<$confidenceInterval = confidenceInterval>

This method returns the confidence interval as a string 
B<lower_bound - upper_bound> appropriately formated B<%6.2f>.

=cut
