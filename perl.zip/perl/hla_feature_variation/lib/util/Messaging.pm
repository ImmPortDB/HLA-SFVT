package util::Messaging;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PathSpecifics;
use util::Table;
use util::Statistics;

use db::MhcTypes;

use fields qw (
  all_msgs
  ambiguous_cell
  cell_info
  cell_state
  cell_statistics
  current_locus
  data_capture
  empty_cell
  error_info
  error_ord
  error_mgr
  info_cols
  locus_names
  msgs
  note_info
  note_ord
  reader
  row_num
  row_nums
  statistics
  taxon_id
  tools
  write_msgs
);

################################################################################
#
#				Constants
#
################################################################################
###
### Message Types
###
sub ERROR_MSG  { return 'err'; }
sub HEADER_MSG { return 'header'; }
sub MSG_MSG    { return 'msg'; }
sub NOTE_MSG   { return 'note'; }
###
### Col Headers
###
sub _INFO_COLS {
  return [
    {
      col    => 'num',
      header => 'Row Num',
      loc    => util::Table::RIGHT_JUSTIFY,
    },

    {
      col    => 'id',
      header => 'Row Id',
      loc    => util::Table::LEFT_JUSTIFY,
    },

    {
      col    => 'col',
      header => 'Col Name',
      loc    => util::Table::LEFT_JUSTIFY,
    },

    {
      col    => 'data',
      header => 'Cell Data',
      loc    => util::Table::LEFT_JUSTIFY,
    },

    {
      col    => 'err',
      header => 'Err Num',
      loc    => util::Table::RIGHT_JUSTIFY,
    },

    {
      col    => 'err_msg',
      header => 'Error Message',
      loc    => util::Table::LEFT_JUSTIFY,
    },

    {
      col    => 'note_msg',
      header => 'Note Message',
      loc    => util::Table::LEFT_JUSTIFY,
    },

  ];
}
###
### Error Info Types
###
sub LIST_OF_ERRORS { return 'List of Errors'; }
sub LIST_OF_INFO   { return 'Validation Notes for entries'; }
###
### Row Header Information
###
sub GENO_ROWS_PER_ROW { return 10; }
sub GENO_ROWS_SPACER  { return "                  "; }

sub MSG_ROWS_PER_ROW { return 8; }
sub MSG_ROWS_SPACER  { return "           "; }

################################################################################
#
#			      Statistics Constants
#
################################################################################
###
### Count column name
###
sub NUMBER_OF_ALLELESETS       { return 'Number of Allele Sets'; }
sub NUMBER_OF_MAPPED_ALLELES   { return 'Number of Mapped Allele Names'; }
sub NUMBER_OF_SFVTS_ANNOTATED  { return 'Number of SFVTs Annotated'; }
sub NUMBER_OF_TYPED_ALLELES    { return 'Number of Typed Alleles'; }
sub NUMBER_OF_SAMPLE_ROWS      { return 'Number of Sample Rows'; }
sub NUMBER_OF_SEQUENCEFEATURES { return 'Number of SFs'; }
sub NUMBER_OF_SUBJECTS         { return 'Number of Subjects'; }
###
### Tags
###
sub ambiguityTag      { return 'Ambiguity Status'; }
sub cwdAlleleTag      { return 'CWD Allele'; }
sub cwdTag            { return 'CWD Status'; }
sub dataTypeTag       { return 'Data Type'; }
sub errorCountTag     { return 'Error Status'; }
sub locusNameTag      { return 'Locus Name'; }
sub rareAlleleTag     { return 'Rare Allele'; }
sub subjectTag        { return 'Subject ID'; }
sub variantFeatureTag { return 'Feature Variant Count'; }
###
### Tag Values
###
sub alleleGroupTagValue        { return 'Allele Group'; }
sub ambiguousTagValue          { return 'Ambiguous'; }
sub ambiguousVariantTagValue   { return 'Ambiguous Type'; }
sub correctTagValue            { return 'No Error'; }
sub cwdAlleleTagValue          { return 'CWD'; }
sub definedVariantTagValue     { return 'Defined Type'; }
sub deletedNameTagValue        { return 'Deleted Name'; }
sub errorTagValue              { return 'Error'; }
sub gCodeTagValue              { return 'G-Code'; }
sub missingFeatureDataTagValue { return 'Missing SFVT data'; }
sub nmdpCodeTagValue           { return 'NMDP Code'; }
sub noDataVariantTagValue      { return 'No Data'; }
sub notAmbiguousTagValue       { return 'Not Ambiguous'; }
sub nullAlleleTagValue         { return 'NULL Allele'; }
sub nullVariantTagValue        { return 'Null'; }
sub pCodeTagValue              { return 'P-Code'; }
sub rareAlleleTagValue         { return 'Rare Allele'; }
sub unknownVariantTagValue     { return 'Unknown Type'; }
sub zeroPrefixTagValue         { return 'Zero Prefix'; }
###
### Counters
###
sub ambiguityCounter      { return ambiguityTag; }
sub cellCounter           { return 'Cell Count'; }
sub cwdCounter            { return cwdTag; }
sub cwdAlleleCounter      { return cwdAlleleTag; }
sub dataTypeCounter       { return dataTypeTag; }
sub errorCounter          { return errorCountTag; }
sub rareAlleleCounter     { return rareAlleleTag; }
sub subjectCounter        { return subjectTag; }
sub variantFeatureCounter { return variantFeatureTag; }

sub counterOrd {
  return (
    ambiguityCounter, dataTypeCounter,   cwdCounter,
    cwdAlleleCounter, rareAlleleCounter, cellCounter
  );
}

sub variantCounterOrd {
  return ( errorCounter, variantFeatureCounter, dataTypeCounter, cellCounter );
}

sub _cellStatisticsConfig {
  return {

    &cellCounter => {
      header    => 'Summary of AlleleSets by Locus',
      tags      => [ locusNameTag, ],
      count_col => NUMBER_OF_ALLELESETS,
      epilogue  => undef,
    },

    &errorCounter => {
      header    => 'Summary of Error Counts by Locus',
      tags      => [ locusNameTag, errorCountTag, ],
      count_col => NUMBER_OF_ALLELESETS,
      epilogue  => undef,
    },

    &ambiguityCounter => {
      header    => 'Summary of Ambiguity Counts by Locus',
      tags      => [ locusNameTag, ambiguityTag, ],
      count_col => NUMBER_OF_ALLELESETS,
      epilogue  => "An ambiguous typing result is one that contains
more than one allele.  Only typing results with no
errors are counted in this table.",
    },
  };
}

sub _cellStatisticsGenotypeConfig {
  return {

    &cellCounter => {
      header    => 'Summary of Subjects by Locus',
      tags      => [ locusNameTag, ],
      count_col => NUMBER_OF_SUBJECTS,
      epilogue  => "Subject is counted only if it has a non-empty
subGenotype for a locus",
    },

    &errorCounter => {
      header    => 'Summary of Error Counts by Locus',
      tags      => [ locusNameTag, errorCountTag, ],
      count_col => NUMBER_OF_SUBJECTS,
      epilogue  => "Subject is counted only if it has a non-empty
subGenotype for a locus",
    },

  };
}

sub _cellStatisticsAnalysisConfig {
  return {

    &cellCounter => {
      header    => 'Summary of Sequence Features by Locus',
      tags      => [ locusNameTag, ],
      count_col => NUMBER_OF_SEQUENCEFEATURES,
      epilogue  => undef,
    },

    &errorCounter => {
      header    => 'Summary of Error Counts by Locus',
      tags      => [ locusNameTag, errorCountTag, ],
      count_col => NUMBER_OF_SEQUENCEFEATURES,
      epilogue  => undef,
    },
  };
}

sub _statisticsConfig {
  return {
    &cellCounter => {
      header => undef,
      tags   => [
        [ locusNameTag,  [] ],
        [ ambiguityTag,  [ ambiguousTagValue, notAmbiguousTagValue, ] ],
        [ errorCountTag, [ correctTagValue, errorTagValue ] ],
      ],
      statistic  => undef,
      show_total => util::Constants::FALSE,
      set_zero   => util::Constants::FALSE,
      count_col  => undef,
      epilogue   => undef,
    },

    &dataTypeCounter => {
      header => 'Summary of Data Types by Locus (not necessarily distinct)',
      tags   => [
        [ locusNameTag, [] ],
        [
          dataTypeTag,
          [
            gCodeTagValue,              pCodeTagValue,
            nmdpCodeTagValue,           alleleGroupTagValue,
            missingFeatureDataTagValue, nullAlleleTagValue,
            deletedNameTagValue,
          ]
        ],
      ],
      statistic  => undef,
      show_total => util::Constants::FALSE,
      set_zero   => util::Constants::FALSE,
      count_col  => NUMBER_OF_TYPED_ALLELES,
      epilogue   => undef,
    },

    &cwdCounter => {
      header => "Summary of Common and Well-Documented (CWD) Data by Locus",
      tags   => [
        [ locusNameTag, [] ],
        [ cwdTag, [ cwdAlleleTagValue, rareAlleleTagValue, ] ],
      ],
      statistic  => undef,
      show_total => util::Constants::FALSE,
      set_zero   => util::Constants::FALSE,
      count_col  => NUMBER_OF_MAPPED_ALLELES,
      epilogue   => "This table contains counts based on all the
allele names occurring within a typed allele

CWD Allele - Common and Well-Documented alleles at the HLA protein-
level as identified by the site, Common & Well-Documented Alleles,
at http://cwd.immunogenomics.org

Rare Allele - Allele not identified as a CWD Allele
at the site specified above.",
    },

    &variantFeatureCounter => {
      header =>
        "Number of Sequence Feature Variant Types (SFVTs)\ndefined per Locus",
      tags => [
        [ locusNameTag, [] ],
        [
          dataTypeTag,
          [
            definedVariantTagValue, ambiguousVariantTagValue,
            unknownVariantTagValue, noDataVariantTagValue,
            nullVariantTagValue
          ]
        ],
      ],
      statistic  => undef,
      show_total => util::Constants::FALSE,
      set_zero   => util::Constants::FALSE,
      count_col  => NUMBER_OF_SFVTS_ANNOTATED,
      epilogue   => undef,
    },

  };
}
###
### Data Capture Tables
###
sub CWD_TABLE     { return 'cwd'; }
sub RARE_TABLE    { return 'rare'; }
sub SUBJECT_TABLE { return 'subject'; }

my $NUM_OF_DATA     = '__num_of_data__';
my $NUM_OF_ENTITIES = '__num_of_entities__';

sub DATA_CAPTURE_TABLES {
  return {
    &CWD_TABLE => {
      use_locus  => util::Constants::TRUE,
      entity_tag => cwdAlleleTag,
      statistic  => cwdAlleleCounter,
      header     => 'List of CWD Alleles by Locus',
      epilogue   => undef,
      count_col  => NUMBER_OF_TYPED_ALLELES,
      extra_col  => 'Full Length CWD?',
    },
    &RARE_TABLE => {
      use_locus  => util::Constants::TRUE,
      entity_tag => rareAlleleTag,
      statistic  => rareAlleleCounter,
      header     => 'List of Rare Alleles by Locus',
      epilogue   => "Rare Allele - Allele not identified as a CWD Allele
by the site, Common & Well-Documented Alleles, at
http://cwd.immunogenomics.org",
      count_col => NUMBER_OF_TYPED_ALLELES,
      extra_col => undef,
    },
    &SUBJECT_TABLE => {
      use_locus  => util::Constants::FALSE,
      entity_tag => subjectTag,
      statistic  => subjectCounter,
      header     => "Subject Statistics\n"
        . "  Number of subjects    = $NUM_OF_ENTITIES\n"
        . "  Number of sample rows = $NUM_OF_DATA",
      epilogue  => undef,
      count_col => NUMBER_OF_SAMPLE_ROWS,
      extra_col => undef,
    },
  };
}

################################################################################
#
#				Private Methods
#
################################################################################

sub _printMsgs {
  my util::Messaging $this = shift;

  return if ( @{ $this->{all_msgs} } == 0 );

  $this->{error_mgr}->printHeader("Error and Note Details for Entries");
  foreach my $msg ( @{ $this->{all_msgs} } ) {
    if ( $msg->{type} eq HEADER_MSG ) {
      $this->{error_mgr}->printHeader( $msg->{msg} );
    }
    elsif ( $msg->{type} eq ERROR_MSG ) {
      ###
      ### At this point, must print error messages
      ###
      $this->{error_mgr}->setPrintErrorMsgs(util::Constants::TRUE);
      $this->{error_mgr}->registerError(
        $msg->{err_cat}, $msg->{err_num},
        $msg->{msgs},    util::Constants::TRUE
      );
    }
    elsif ( $msg->{type} eq NOTE_MSG ) {
      $this->{error_mgr}->printNote( $msg->{msg} );
    }
    else {
      $this->{error_mgr}->printMsg( $msg->{msg} );
    }
  }
  $this->{all_msgs} = [];
}

sub _setupStatistics {
  my util::Messaging $this = shift;
  ###
  ### Create statistics
  ###
  while ( my ( $counter, $config ) = each %{ $this->{statistics} } ) {
    my @params = ();
    foreach my $tag_data ( @{ $config->{tags} } ) {
      if ( $tag_data->[0] eq locusNameTag ) {
        $tag_data->[1] = [ @{ $this->{locus_names} } ];
      }
      push( @params, @{$tag_data} );
    }
    $config->{statistic} =
      new util::Statistics( $config->{header}, $config->{epilogue},
      $this->{error_mgr}, @params );
    $config->{statistic}->setShowTotal( $config->{show_total} );
    $config->{statistic}->setCountsToZero if ( $config->{set_zero} );
    $config->{statistic}->setCountColName( $config->{count_col} );
  }
}

sub _printInfo {
  my util::Messaging $this = shift;
  my ( $header, $infos ) = @_;

  return if ( @{$infos} == 0 );
  ###
  ### Create Table and Set Configuration
  ###
  my %cols = ();
  foreach my $col_data ( @{ $this->{info_cols} } ) {
    $cols{ $col_data->{col} } = $col_data->{header};
  }
  my $table = new util::Table( $this->{error_mgr}, %cols );
  $table->setColumnWidth( 'col',      20 );
  $table->setColumnWidth( 'data',     30, );
  $table->setColumnWidth( 'err_msg',  40 );
  $table->setColumnWidth( 'note_msg', 40 );
  foreach my $col_data ( @{ $this->{info_cols} } ) {
    $table->setColumnJustification( $col_data->{col}, $col_data->{loc} );
  }
  if ( $header eq LIST_OF_ERRORS ) {
    $table->setColumnOrder( @{ $this->{error_ord} } );
  }
  elsif ( $header eq LIST_OF_INFO ) {
    $table->setColumnOrder( @{ $this->{note_ord} } );
  }
  else {
    return;
  }
  ###
  ### Print Table
  ###
  $table->setData( @{$infos} );
  $table->generateTable($header);
}

sub _createDataCaptureStatistic {
  my util::Messaging $this = shift;
  my ($table) = @_;
  ###
  ### Check if there are any rare alleles
  ###
  my $data_table = $this->{data_capture}->{$table};
  return if ( !defined($data_table) );

  my $data = [ keys %{ $data_table->{data} } ];
  return if ( scalar @{$data} == 0 );
  ###
  ### parameters for the statistic
  ###
  my $counts = $data_table->{counts};
  my @params = ();
  if ( $data_table->{use_locus} ) {
    push( @params, locusNameTag, $this->{locus_names} );
  }
  else {
    my $num_entities = 0;
    my $num_data     = 0;
    foreach my $entity ( keys %{$counts} ) {
      $num_entities++;
      foreach ( 1 .. $counts->{$entity} ) {
        $num_data++;
      }
    }
    $data_table->{header} =~ s/$NUM_OF_ENTITIES/$num_entities/;
    $data_table->{header} =~ s/$NUM_OF_DATA/$num_data/;
  }
  push( @params, $data_table->{entity_tag}, $data );
  if ( defined( $data_table->{extra_col} ) ) {
    my $vals = [ values %{ $data_table->{data} } ];
    push( @params, $data_table->{extra_col}, $vals );
  }
  ###
  ### Create the statistic
  ###
  my $statistic =
    new util::Statistics( $data_table->{header}, $data_table->{epilogue},
    $this->{error_mgr}, @params );
  $this->{statistics}->{ $data_table->{statistic} } =
    { statistic => $statistic };
  $statistic->setCountColName( $data_table->{count_col} );
  ###
  ### Add the data
  ###
  if ( $data_table->{use_locus} ) {
    foreach my $locus_name ( keys %{$counts} ) {
      foreach my $entity ( keys %{ $counts->{$locus_name} } ) {
        foreach ( 1 .. $counts->{$locus_name}->{$entity} ) {
          my @value =
            ( locusNameTag, $locus_name, $data_table->{entity_tag}, $entity );
          push( @value,
            $data_table->{extra_col},
            $data_table->{data}->{$entity} )
            if ( defined( $data_table->{extra_col} ) );
          $this->incStatistic( $data_table->{statistic}, @value );
        }
      }
    }
  }
  else {
    foreach my $entity ( keys %{$counts} ) {
      foreach ( 1 .. $counts->{$entity} ) {
        my @value = ( $data_table->{entity_tag}, $entity );
        push( @value, $data_table->{extra_col}, $data_table->{data}->{$entity} )
          if ( defined( $data_table->{extra_col} ) );
        $this->incStatistic( $data_table->{statistic}, @value );
      }
    }
  }
}

sub _incCellCounter {
  my util::Messaging $this = shift;

  $this->incStatistic(
    cellCounter,
    locusNameTag,
    $this->getLocusName,
    ambiguityTag,
    $this->getAmbiguousCell ? ambiguousTagValue : notAmbiguousTagValue,
    errorCountTag,
    ( $this->getCellState eq ERROR_MSG ) ? errorTagValue : correctTagValue
  );
}

sub _printCellStatistic {
  my util::Messaging $this = shift;
  my ($cell_statistic) = @_;

  my $statistic_info = $this->{cell_statistics}->{$cell_statistic};
  return if ( !defined($statistic_info) );
  my $config = $this->{statistics}->{&cellCounter};
  return if ( !defined($config) );

  my $statistic = $config->{statistic};
  $statistic->setHeader( $statistic_info->{header} );
  $statistic->setEpilogue( $statistic_info->{epilogue} );
  $statistic->setCountColName( $statistic_info->{count_col} );
  $statistic->print( @{ $statistic_info->{tags} } );
}

sub _printProperties {
  my util::Messaging $this = shift;
  my (@property_data) = @_;

  my $tools  = $this->{tools};
  my $reader = $this->{reader};
  ###
  ### Add the standard property data
  ###
  unshift(
    @property_data,
    {
      $tools->PROPERTY_COL => 'Species',
      $tools->VALUE_COL =>
        db::MhcTypes::getName( db::MhcTypes::TAXONOMY_TABLE, $this->{taxon_id}
        ),
    }
  );
  unshift(
    @property_data,
    {
      $tools->PROPERTY_COL => 'HLA Allele File Type',
      $tools->VALUE_COL    => $reader->type,
    }
  );
  ###
  ### Create and print property table
  ###
  my @ord  = $tools->MSG_COLS;
  my %cols = ();
  foreach my $col (@ord) { $cols{$col} = $col; }
  my $table = new util::Table( $this->{error_mgr}, %cols );
  $table->setColumnOrder(@ord);
  $table->setInHeader(util::Constants::TRUE);
  $table->setData(@property_data);

  foreach my $col (@ord) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }
  ###
  ### Generate the property table.
  ###
  $table->generateTable('Files and species information');
}

################################################################################
#
#				Public Methods
#
################################################################################

sub new($$$$$$) {
  my util::Messaging $this = shift;
  my ( $file_reader, $taxon_id, $write_msgs, $tools, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{all_msgs}        = [];
  $this->{cell_info}       = undef;
  $this->{cell_state}      = undef;
  $this->{current_locus}   = undef;
  $this->{empty_cell}      = util::Constants::FALSE;
  $this->{ambiguous_cell}  = util::Constants::FALSE;
  $this->{error_info}      = [];
  $this->{error_mgr}       = $error_mgr;
  $this->{error_ord}       = [];
  $this->{info_cols}       = _INFO_COLS;
  $this->{msgs}            = undef;
  $this->{note_info}       = [];
  $this->{note_ord}        = [];
  $this->{reader}          = $file_reader;
  $this->{row_num}         = 0;
  $this->{statistics}      = _statisticsConfig;
  $this->{cell_statistics} = undef;
  $this->{taxon_id}        = $taxon_id;
  $this->{tools}           = $tools;
  $this->{write_msgs} =
    ( defined($write_msgs) && $write_msgs )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### per run data capture
  ###
  $this->{data_capture} = DATA_CAPTURE_TABLES;
  foreach my $table ( keys %{ $this->{data_capture} } ) {
    $this->{data_capture}->{$table}->{data}   = {};
    $this->{data_capture}->{$table}->{counts} = {};
  }
  ###
  ### Setup for table generation for errors and notes
  ###
  foreach my $col_data ( @{ $this->{info_cols} } ) {
    my $col = $col_data->{col};
    if ( $col ne 'note_msg' ) { push( @{ $this->{error_ord} }, $col ); }
    if ( $col ne 'err' && $col ne 'err_msg' ) {
      push( @{ $this->{note_ord} }, $col );
    }
  }
  ###
  ### First get the locus names
  ###
  my $allelesLookup = $tools->getAllelesLookup;
  $this->{locus_names} = [];
  foreach my $locus_id ( db::MhcTypes::getLocusIds($taxon_id) ) {
    my $locus_data = $allelesLookup->getLocusData($locus_id);
    push( @{ $this->{locus_names} }, $locus_data->{full_locus_name} );
  }
  ###
  ### Now create statistics
  ###
  $this->_setupStatistics;

  return $this;
}

sub initializeMsgs {
  my util::Messaging $this = shift;
  my ( $locus_col, $entity ) = @_;

  if ( !defined( $this->{cell_statistics} ) ) {
    $this->{cell_statistics} = _cellStatisticsConfig;
  }

  my $reader     = $this->{reader};
  my $cell       = $entity->{$locus_col};
  my $locus_data = $reader->getEntityData($locus_col);
  ###
  ### At a minimum, set locus name, cell status, and print msgs
  ### and also add statistic
  ###
  $this->{empty_cell}     = $reader->emptyCell($cell);
  $this->{current_locus}  = $locus_data->{full_entity_name};
  $this->{ambiguous_cell} = util::Constants::FALSE;

  return if ( $this->getEmptyCell );
  ###
  ### If it is a real cell, then set msgs, num errors, and header
  ###
  my @data = split( /\//, strip_whitespace($cell) );
  $this->{cell_state} = undef;
  $this->{msgs}       = [];
  $this->{cell_info}  = {
    num         => $this->{row_num},
    id          => $entity->{ $reader->getIdCol },
    col         => $locus_data->{col_name},
    data        => join( util::Constants::COMMA_SEPARATOR, @data ),
    unique_errs => {},
    errs        => [],
    err_msgs    => [],
    note_msgs   => [],
  };

  my $cell_info = $this->{cell_info};
  push(
    @{ $this->{msgs} },
    {
      msg => "Row Num  = "
        . $cell_info->{num} . "\n"
        . "Row Id   = "
        . $cell_info->{id} . "\n"
        . "Col Name = "
        . $cell_info->{col} . "\n"
        . "Cell     = "
        . $this->formatData(
        $this, '(', ')', MSG_ROWS_SPACER, MSG_ROWS_PER_ROW, @data
        ),
      type => HEADER_MSG,
    }
  );
}

sub formatData {
  my util::Messaging $this = shift;
  my ( $that, $start, $end, $spacer, $num_per_row, @data ) = @_;

  return if ( scalar @data == 0 );

  my $rows_header = $start;
  my $row_segment = util::Constants::EMPTY_STR;
  foreach my $index ( 0 .. $#data ) {
    if ( $index > 0 && $index % $num_per_row == 0 ) {
      $rows_header .= $row_segment . util::Constants::COMMA . "\n";
      $row_segment = $spacer;
    }
    if ( $index > 0 && $row_segment ne $spacer ) {
      $row_segment .= util::Constants::COMMA_SEPARATOR;
    }
    $row_segment .= $that->formatDatum( $data[$index] );
  }
  if ( $row_segment ne util::Constants::EMPTY_STR ) {
    $rows_header .= $row_segment;
  }
  $rows_header .= $end;

}

sub _sortRowNums { $a <=> $b; }

sub initializeRowNums {
  my util::Messaging $this = shift;
  my (@entities) = @_;

  my $reader = $this->{reader};
  $this->{row_nums} = [];
  foreach my $entity (@entities) {
    push( @{ $this->{row_nums} }, $entity->{ $reader->ROW_ID_COL } );
    $this->addDataCapture( SUBJECT_TABLE, $entity->{ $reader->getIdCol } );
  }
  @{ $this->{row_nums} } =
    sort util::Messaging::_sortRowNums @{ $this->{row_nums} };
}

sub formatDatum {
  my util::Messaging $this = shift;
  my ($row_num) = @_;

  return $row_num;
}

sub generateRowsHeader {
  my util::Messaging $this = shift;
  my ( $rows_spacer, $num_rows_per_row ) = @_;

  return $this->formatData( $this, '(', ')', $rows_spacer, $num_rows_per_row,
    @{ $this->{row_nums} } );
}

sub initializeGenotypeMsgs {
  my util::Messaging $this = shift;
  my ( $locus_id, @entities ) = @_;

  if ( !defined( $this->{cell_statistics} ) ) {
    $this->{cell_statistics} = _cellStatisticsGenotypeConfig;
  }
  my $reader       = $this->{reader};
  my @col_names    = $reader->getLocusColNames($locus_id);
  my $locus_data_0 = $reader->getEntityData( $col_names[0] );
  my $locus_data_1 = $reader->getEntityData( $col_names[1] );
  ###
  ### At a minimum, set locus name, cell status, and print msgs
  ### and also add statistic
  ###
  $this->{empty_cell} =
    ( @entities == 0 ) ? util::Constants::TRUE : util::Constants::FALSE;
  $this->{current_locus} = $locus_data_0->{full_entity_name};

  return if ( $this->getEmptyCell );
  ###
  ### Create Data
  ###
  my $data = util::Constants::EMPTY_STR;
  foreach my $entity (@entities) {
    if ( !util::Constants::EMPTY_LINE($data) ) {
      $data .= util::Constants::COMMA_SEPARATOR;
    }
    $data .= '('
      . $entity->{ $col_names[0] }
      . util::Constants::COMMA
      . $entity->{ $col_names[1] } . ')';
  }
  ###
  ### If it is a real group, then set msgs, num errors, and header
  ###
  $this->{cell_state} = undef;
  $this->{msgs}       = [];
  $this->{cell_info}  = {
    num => $this->{row_num},
    id  => $entities[0]->{ $reader->getIdCol },
    col => join( util::Constants::COMMA_SEPARATOR,
      $locus_data_0->{col_name},
      $locus_data_1->{col_name}
    ),
    data        => $data,
    unique_errs => {},
    errs        => [],
    err_msgs    => [],
    note_msgs   => [],
  };

  my $cell_info = $this->{cell_info};
  push(
    @{ $this->{msgs} },
    {
      msg => "Genotype Id     = "
        . $cell_info->{id} . "\n"
        . "Locus Col Names = "
        . $cell_info->{col} . "\n"
        . "Row Nums        = "
        . $this->generateRowsHeader( GENO_ROWS_SPACER, GENO_ROWS_PER_ROW ),
      type => HEADER_MSG,
    }
  );
}

sub initializeAnalysisMsgs {
  my util::Messaging $this = shift;
  my ( $locus, $sequence_feature, $col_names ) = @_;

  if ( !defined( $this->{cell_statistics} ) ) {
    $this->{cell_statistics} = _cellStatisticsAnalysisConfig;
  }
  ###
  ### At a minimum, set locus name, cell status, and print msgs
  ### and also add statistic
  ###
  $this->{empty_cell}    = util::Constants::FALSE;
  $this->{current_locus} = $locus;
  ###
  ### Create Data
  ###
  $this->{cell_state} = undef;
  $this->{msgs}       = [];
  $this->{cell_info}  = {
    num         => $this->{row_num},
    id          => $sequence_feature,
    col         => join( util::Constants::COMMA_SEPARATOR, @{$col_names} ),
    data        => util::Constants::HYPHEN,
    unique_errs => {},
    errs        => [],
    err_msgs    => [],
    note_msgs   => [],
  };

  my $cell_info = $this->{cell_info};
  push(
    @{ $this->{msgs} },
    {
      msg => "Sequence Feature = "
        . $cell_info->{id} . "\n"
        . "Col Names        = "
        . $col_names->[0] . "\n"
        . "                   "
        . $col_names->[1],
      type => HEADER_MSG,
    }
  );
}

sub addMsg {
  my util::Messaging $this = shift;
  my ($msg) = @_;

  $this->{cell_state} =
    !defined( $this->getCellState ) ? MSG_MSG : $this->getCellState;

  return if ( $this->getEmptyCell );
  push(
    @{ $this->{msgs} },
    {
      msg  => $msg,
      type => MSG_MSG,
    }
  );
}

sub addNote {
  my util::Messaging $this = shift;
  my ($msg) = @_;

  return if ( $this->getEmptyCell );
  if ( !defined( $this->getCellState ) || $this->getCellState eq MSG_MSG ) {
    $this->{cell_state} = NOTE_MSG;
  }
  ###
  ### Add a note message if it really is a note
  ###
  my $cell_info = $this->{cell_info};
  my @msg_lines = split( /\n/, $msg );
  my $msg_key   = $msg_lines[0];
  if ( !defined( $cell_info->{unique_msgs}->{$msg_key} ) ) {
    $cell_info->{unique_msgs}->{$msg_key} = util::Constants::EMPTY_STR;
    push( @{ $cell_info->{note_msgs} }, $msg_key );
  }
  push(
    @{ $this->{msgs} },
    {
      msg  => $msg,
      type => NOTE_MSG,
    }
  );
}

sub addResult {
  my util::Messaging $this = shift;
  my ( $header, $names, $vals, $print_type ) = @_;

  return if ( $this->getEmptyCell );

  my $max_length = 0;
  foreach my $name ( @{$names} ) {
    $max_length = ( length($name) > $max_length ) ? length($name) : $max_length;
  }
  my @msgs = ($header);
  foreach my $name ( @{$names} ) {
    my $msg =
        '  ' 
      . $name
      . &util::Constants::SPACE x ( $max_length - length($name) ) . " = "
      . $vals->{$name};
    push( @msgs, $msg );
  }

  my $msg = join( util::Constants::NEWLINE, @msgs );
  $this->addMsg($msg)  if ( $print_type eq MSG_MSG );
  $this->addNote($msg) if ( $print_type eq NOTE_MSG );
}

sub addDataCapture {
  my util::Messaging $this = shift;
  my ( $table, $datum, $extra_col ) = @_;

  return if ( $table ne SUBJECT_TABLE && $this->getEmptyCell );

  my $data_table = $this->{data_capture}->{$table};
  return if ( !defined($data_table) );

  my $counts = $data_table->{counts};
  my $data   = $data_table->{data};
  if ( $data_table->{use_locus} ) {
    my $locus_name = $this->getLocusName;
    if ( !defined( $counts->{$locus_name} ) ) {
      $counts->{$locus_name} = {};
    }
    my $locus = $counts->{$locus_name};
    if ( !defined( $locus->{$datum} ) ) {
      $locus->{$datum} = 0;
    }
    $locus->{$datum}++;
  }
  else {
    if ( !defined( $counts->{$datum} ) ) { $counts->{$datum} = 0; }
    $counts->{$datum}++;
  }
  my $val = util::Constants::HYPHEN;
  if ( !util::Constants::EMPTY_LINE($extra_col) ) {
    $val = $extra_col;
  }
  $data->{$datum} = $val;
}

sub registerError {
  my util::Messaging $this = shift;
  my ( $err_cat, $err_num, $params, $error ) = @_;

  return if ( !$error );
  ###
  ### Add error information if not already present
  ###
  my $cell_info = $this->{cell_info};
  my $err_key = $this->{error_mgr}->errNum( $err_cat, $err_num );
  if ( !defined( $cell_info->{unique_errs}->{$err_key} ) ) {
    $cell_info->{unique_errs}->{$err_key} = util::Constants::EMPTY_STR;
    push( @{ $cell_info->{errs} }, $err_key );
    push(
      @{ $cell_info->{err_msgs} },
      $this->{error_mgr}->firstLine( $err_cat, $err_num )
    );
  }

  $this->{cell_state} = ERROR_MSG;
  push(
    @{ $this->{msgs} },
    {
      err_cat => $err_cat,
      err_num => $err_num,
      msgs    => $params,
      type    => ERROR_MSG,
    }
  );
}

sub directRegisterError {
  my util::Messaging $this = shift;
  my ( $err_cat, $err_num, $params, $error ) = @_;

  return if ( !$error );
  $this->{error_mgr}->setPrintErrorMsgs(util::Constants::TRUE);
  $this->{error_mgr}->registerError( $err_cat, $err_num, $params, $error );
  $this->{error_mgr}->setPrintErrorMsgs(util::Constants::FALSE);
}

sub finalizeMsgs {
  my util::Messaging $this = shift;

  return if ( $this->getEmptyCell );
  ###
  ### Add cell info to info lists as necessary
  ###
  my $cell_info = $this->{cell_info};
  foreach my $index ( 0 .. $#{ $this->{cell_info}->{errs} } ) {
    my $cell = { %{$cell_info} };
    $cell->{err}     = $this->{cell_info}->{errs}->[$index];
    $cell->{err_msg} = $this->{cell_info}->{err_msgs}->[$index];
    push( @{ $this->{error_info} }, $cell );
  }
  foreach my $index ( 0 .. $#{ $this->{cell_info}->{note_msgs} } ) {
    my $cell = { %{$cell_info} };
    $cell->{note_msg} = $this->{cell_info}->{note_msgs}->[$index];
    push( @{ $this->{note_info} }, $cell );
  }
  ###
  ### Add all notes and errors to print at the end
  ###
  if ( $this->getWriteMsgs
    || $this->getCellState eq ERROR_MSG
    || $this->getCellState eq NOTE_MSG )
  {
    push( @{ $this->{all_msgs} }, @{ $this->{msgs} } );
  }
  ###
  ### Final determination num errors and print msgs
  ###
  $this->_incCellCounter;
}

sub incStatistic {
  my util::Messaging $this = shift;
  my ( $statistic_name, @tag_data ) = @_;
  my $config = $this->{statistics}->{$statistic_name};
  return if ( !defined($config) );
  $config->{statistic}->increment(@tag_data);
}

sub printStatistics {
  my util::Messaging $this = shift;
  my (@property_data) = @_;

  my $statistics     = $this->{statistics};
  my $cellStatistics = $this->{cell_statistics};
  ###
  ### First:  Print the property data
  ###
  $this->_printProperties(@property_data);
  ###
  ### Second:  Generate and print the subject statistics
  ###
  $this->_createDataCaptureStatistic(SUBJECT_TABLE);
  my $subject_table = $this->{data_capture}->{&SUBJECT_TABLE};
  $statistics->{ $subject_table->{statistic} }->{statistic}->print;
  ###
  ### Third:  Error counts per locus and list of errors
  ###
  $this->_printCellStatistic(errorCounter);
  $this->_printInfo( LIST_OF_ERRORS, $this->{error_info} );
  ###
  ### Fourth:  Validation Notes
  ###
  $this->_printInfo( LIST_OF_INFO, $this->{note_info} );
  ###
  ### Fifth:  print error and validation messages
  ###
  $this->_printMsgs;
  ###
  ### Sixth:  Category errors
  ###
  $this->{error_mgr}->printStats;
  $this->{tools}->setPrintStats(util::Constants::FALSE);
  ###
  ### Seventh:  Generate CWD/Rare allele statistics
  ###
  $this->_createDataCaptureStatistic(RARE_TABLE);
  $this->_createDataCaptureStatistic(CWD_TABLE);
  ###
  ### Eighth:  Print statistic counts
  ###
  foreach my $counter (counterOrd) {
    my $config = undef;
    if ( defined( $cellStatistics->{$counter} ) ) {
      $this->_printCellStatistic($counter);
    }
    else {
      $config = $statistics->{$counter};
      next if ( !defined($config) );
      $config->{statistic}->print;
    }
  }
}

sub printVariantStatistics {
  my util::Messaging $this = shift;
  my (@property_data) = @_;

  my $statistics     = $this->{statistics};
  my $cellStatistics = $this->{cell_statistics};
  ###
  ### First:  Print the property data
  ###
  $this->_printProperties(@property_data);
  ###
  ### Second:  Print the number of subjects
  ###
  $this->_createDataCaptureStatistic(SUBJECT_TABLE);
  my $subject_table = $this->{data_capture}->{&SUBJECT_TABLE};
  $statistics->{ $subject_table->{statistic} }->{statistic}->print;
  ###
  ### Third:  print statistics for variant
  ###
  foreach my $counter (variantCounterOrd) {
    my $config = undef;
    if ( defined( $cellStatistics->{$counter} ) ) {
      $this->_printCellStatistic($counter);
    }
    else {
      $config = $statistics->{$counter};
      next if ( !defined($config) );
      $config->{statistic}->print;
    }
  }
  ###
  ### Fourth:  List of errors
  ###
  $this->_printInfo( LIST_OF_ERRORS, $this->{error_info} );
  ###
  ### Fifth:  Validation Notes
  ###
  $this->_printInfo( LIST_OF_INFO, $this->{note_info} );
  ###
  ### Sixth:  print error and validation messages
  ###
  $this->_printMsgs;
  ###
  ### Seventh:  Category errors
  ###
  $this->{error_mgr}->printStats;
  $this->{tools}->setPrintStats(util::Constants::FALSE);
  ###
  ### The End!
  ###
}

################################################################################
#
#				Getter Methods
#
################################################################################

sub getAmbiguousCell {
  my util::Messaging $this = shift;
  return $this->{ambiguous_cell};
}

sub getCellState {
  my util::Messaging $this = shift;
  return $this->{cell_state};
}

sub getEmptyCell {
  my util::Messaging $this = shift;
  return $this->{empty_cell};
}

sub getCount {
  my util::Messaging $this = shift;
  my ( $statistic_name, @tag_data ) = @_;
  my $config = $this->{statistics}->{$statistic_name};
  return 0 if ( !defined($config) );
  $config->{statistic}->count(@tag_data);
}

sub getLocusName {
  my util::Messaging $this = shift;
  return $this->{current_locus};
}

sub getLocusNames {
  my util::Messaging $this = shift;
  return @{ $this->{locus_names} };
}

sub getRowNum {
  my util::Messaging $this = shift;
  return $this->{row_num};
}

sub getWriteMsgs {
  my util::Messaging $this = shift;
  return $this->{write_msgs};
}

################################################################################
#
#				Setter Methods
#
################################################################################

sub incRowNum {
  my util::Messaging $this = shift;
  $this->{row_num}++;
}

sub resetRowNum {
  my util::Messaging $this = shift;
  $this->{row_num} = 0;
}

sub setAmbiguousCell {
  my util::Messaging $this = shift;
  $this->{ambiguous_cell} = util::Constants::TRUE;
}

################################################################################

1;

__END__

=head1 NAME

Messaging.pm

=head1 DESCRIPTION

This class manages the generation of information for quality control
tool log output.  The information includes statistic counts using
L<util::Statistics>, error and note listings using L<util::Table>, and
detailed error information supported by L<util::ErrMgr>.

=head1 STATISTIC CONSTANTS

The following constants are defined to support counting statistic
capture.  They include tags for categories, the tag values, and the
statistic counter names.

The tags (categories) include the following:

   ambiguityTag      -- Ambiguity Status
   cwdAlleleTag      -- CWD Allele
   cwdTag            -- CWD Status
   dataTypeTag       -- Data Type
   errorCountTag     -- Error Status
   locusNameTag      -- Locus Name
   rareAlleleTag     -- Rare Allele
   subjectTag        -- Subject ID
   variantFeatureTag -- Feature Variant Count

The values of the the above tags including the following:

   alleleGroupTagValue        -- Allele Group
   ambiguousTagValue          -- Ambiguous
   ambiguousVariantTagValue   -- Ambiguous Type
   correctTagValue            -- No Error
   cwdAlleleTagValue          -- CWD
   definedVariantTagValue     -- Defined Type
   deletedNameTagValue        -- Deleted Name
   errorTagValue              -- Error
   gCodeTagValue              -- G-Code
   missingFeatureDataTagValue -- Missing SFVT data
   nmdpCodeTagValue           -- NMDP Code
   noDataVariantTagValue      -- No Data
   notAmbiguousTagValue       -- Not Ambiguous
   nullAlleleTagValue         -- NULL Allele
   nullVariantTagValue        -- Null
   pCodeTagValue              -- P-Code
   rareAlleleTagValue         -- Rare Allele
   unknownVariantTagValue     -- Unknown Type
   zeroPrefixTagValue         -- Zero Prefix

The following counting statistics (instances of L<util::Statistics>)
that use the method L<"incStatistic(statistic_name, @tag_data)"> include:

   cellCounter           -- Cell Count
   cwdCounter            -- CWD Status
   dataTypeCounter       -- Data Type
   variantFeatureCounter -- Feature Variant Count

The following counting statistics (instances of L<util::Statistics>)
are generated from data capture tables:

   cwdAlleleCounter      -- CWD Allele
   rareAlleleCounter     -- Rare Allele
   subjectCounter        -- Subject ID

The data capture tables are managed by L<"addDataCapture((table, datum)">
and include:

   CWD_TABLE     -- cwd
   RARE_TABLE    -- rare
   SUBJECT_TABLE -- subject

where the data capture table correspondence to counting statistic is
provided below:

   CWD_TABLE     -- cwdAlleleCounter
   RARE_TABLE    -- rareAlleleCounter
   SUBJECT_TABLE -- subjectCounter

=head1 COUNTING STATISTICS MANAGED BY THE CLASS

The counting statistics maintained by this class are defined as
follows:

B<cellCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   ambiguityTag  ambiguousTagValue notAmbiguousTagValue
   errorCountTag correctTagValue errorTagValue

B<cwdCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   cwdTag        cwdAlleleTagValue, rareAlleleTagValue

B<cwdAlleleCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   cwdAlleleTag  The list of alleles that have allele status CWD

B<dataTypeCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   dataTypeTag   gCodeTagValue, pCodeTagValue, nmdpCodeTagValue,
                 alleleGroupTagValue, missingFeatureDataTagValue,
                 nullAlleleTagValue, deletedNameTagValue

B<rareAlleleCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   rareAlleleTag The list of alleles that have allele status Rare

B<subjectCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   subjectTag    The unique set of subject in the given file

B<variantFeatureCounter:>

   Category      Values
   ------------- ------------------------------------------------------------
   locusNameTag  These are the locus names defined in the given file
   dataTypeTag   definedVariantTagValue, ambiguousVariantTagValue,
                 unknownVariantTagValue, noDataVariantTagValue,
                 nullVariantTagValue

=head1 CONSTRUCTOR METHOD

=head2 B<new util::Messaging(file_reader, taxon_id, write_msgs, tools, error_mgr)>

This method is the constructor for the class.  It requires the file
reader (subclass of L<file::Mhc> for the file type) used by the
quality control tool, the taxon id of the data, the Boolean write_msgs
that indicates whether messages are generated into the log, the tools
instance used by the quality control tool
(L<util::Tools::mhcSeqVar::qualityControl>), and the instance of
logging out (L<util::ErrMgr>).  This method initializes the list
attributes all_msgs, error_info, and note_info to empty.  The all_msgs
list will be generated into the log at the end of processing (see
L<"PRINTING MESSAGES AND STATISTICS METHODS">).  The error_info and
note_info lists will be generated as error and note informational
tables at the end of processing.  This method also gets the list of
locus names associated with the taxon_id and set the list to the
attribute locus_names.

=head1 INITIALIZATION/FINALIZATION METHODS

These method initialize and finalize message, note, and error
gathering for a given entity being processed by the quality control
tool.

=head2 B<initializeMsgs(locus_col, entity)>

This method initializes messaging for a given alleleSet being processed
by the quality control tool that includes:

   validateAlleleNames.pl        -- allele validation
   allelicAmbiguityReduction.pl  -- allelic ambiguity reduction
   generateVariantTypes.pl       -- sequence feature vector file generation

The B<locus_col> represents the particular column and locus being
processed.  The entity is the row containing the alleleSet for the
particular column and locus.  The alleleSet may be ambiguous. This
method manages the ambiguity for logging purposes.  This method also
sets the current_locus attribute to the full name for the locus being
processed and the ambiguous_cell attribute to FALSE (0).  This
attribute can be modified to TRUE (1) by the quality control tool by
using the method L<"setAmbiguousCell">.  If the alleleSet is empty,
this method sets the empty_cell attribute to TRUE (1) and returns
immediately.  Otherwise, the method sets the cell_state to undefined.
The possible values that the cell_state can be set include:

   ERROR_MSG  -- err
   MSG_MSG    -- msg
   NOTE_MSG   -- note

Further, the method sets the cell_info attribute for the alleleSet
with the column name, id, row number, and the data contained in the
alleleSet (appropriately formated).  It sets the error and notes for
the alleleSet to empty.  Finally, it initializes the list of messages
(msgs attribute) for the alleleSet with a header message
(B<HEADER_MSG>) for alleleSet.  These messages will be generated into
log if the alleleSet has any errors (ERROR_MSG) or notes (NOTE_MSG)
associated with it.

This method also sets the set of statistics that will be generated
from the B<cellCounter> counting statistic if it has not already been
set.  These include:

   Statistic        Header                               Tags
   -----------      ------------------------------------ -------------
   cellCounter      Summary of AlleleSets by Locus       locusNameTag,
   errorCounter     Summary of Error Counts by Locus     locusNameTag,
                                                         errorCountTag
   ambiguityCounter Summary of Ambiguity Counts by Locus locusNameTag,
                                                         ambiguityTag

The count column for these generated statistics is
B<Number of Allele Sets>.

=head2 B<initializeGenotypeMsgs(locus_id, @entities)>

This method initializes messaging for a given set of subgenotypes
being processed by the quality control tool:

   genotypeAmbiguityReduction.pl -- genotype ambiguity reduction

The B<locus_id> represents the particular locus being processed.  The
@entity is the set of sub-genotypes for the particular locus.  The set
may contain several sub-genotypes. This method manages this ambiguity
for logging purposes. This method also sets the current_locus
attribute to the full name for the locus being processed.  If the set
of sub-genotypes is empty, this method sets the empty_cell attribute
to TRUE (1) and returns immediately.  Otherwise, the method sets the
cell_state to undefined.  The possible values that the cell_state can
be set include:

   ERROR_MSG  -- err
   MSG_MSG    -- msg
   NOTE_MSG   -- note

Further, the method sets the cell_info attribute for the set of
sub-genotypes with the id, number of the the set of sub-genotypes, and
the data contained in the set (appropriately formated).  It sets the
error and notes for the alleleSet to empty.  Finally, it initializes
the set of messages (msgs attribute) for the set of sub-genotypes with
the header message (B<HEADER_MSG>) for the set.  These messages will
be generated into log if the set of sub-genotypes has any errors
(ERROR_MSG) or notes (NOTE_MSG) associated with it.

This method also sets the set of statistics that will be generated
from the B<cellCounter> counting statistic if it has not already been
set.  These include:

   Statistic        Header                               Tags
   -----------      ------------------------------------ -------------
   cellCounter      Summary of Subjects by Locus         locusNameTag,
   errorCounter     Summary of Error Counts by Locus     locusNameTag,
                                                         errorCountTag

The count column for these generated statistics is
B<Number of Subjects>.

=head2 B<initializeRowNums(@entities)>

This method initializes the set of row numbers assigned to a set of
sub-genotypes being processed by the quality control tool:

   genotypeAmbiguityReduction.pl -- genotype ambiguity reduction

This method determines the set of row numbers associated with the set
of sub-genotypes (@entities) and orders them numerically.  Also, this
method does the data capture (see L<"addDataCapture((table, datum)">)
on the subjects (B<table == subject> and B<datum == subject_ID>)
contained in the set @entities.

=head2 B<initializeAnalysisMsgs(locus, sequence_feature, col_names)>

This method initializes messaging for a given SFVT analysis of
of a locus and sequence_feature 
being processed by the quality control tool:

   analyzeVariantTypes.pl -- SFVT analysis

The B<locus> represents the particular locus name being processed for
the analysis.  The B<sequence_feature> is the current sequence feature
being process and the B<col_names> is the Perl referenced array of the
columns in the input file containing the data for the sequence
feature.  The empty_cell is set to FALSE (0) and the cell_state is set
to undef.  The possible values that the cell_state can be set include:

   ERROR_MSG  -- err
   MSG_MSG    -- msg
   NOTE_MSG   -- note

Further, the method sets the cell_info attribute for the sequence 
feature the id.  Finally, it initializes
the set of messages (msgs attribute) for the sequence feature
the header message (B<HEADER_MSG>) for the set.  These messages will
be generated into log if the sequence feature has any errors
(ERROR_MSG) or notes (NOTE_MSG) associated with it.

This method also sets the set of statistics that will be generated
from the B<cellCounter> counting statistic if it has not already been
set.  These include:

   Statistic        Header                                 Tags
   -----------      ------------------------------------   -------------
   cellCounter      Summary of Sequence Features by Locus  locusNameTag,
   errorCounter     Summary of Error Counts by Locus       locusNameTag,
                                                           errorCountTag

The count column for these generated statistics is B<Number of SFs>.

=head2 B<finalizeMsgs>

This method finalizes the processing of an entity (alleleSet of set of
sub-genotypes) for a given quality control tool:

   allelicAmbiguityReduction.pl  -- allelic ambiguity reduction
   analyzeVariantTypes.pl        -- SFVT analysis
   generateVariantTypes.pl       -- sequence feature vector file generation
   genotypeAmbiguityReduction.pl -- genotype ambiguity reduction
   validateAlleleNames.pl        -- allele validation

This method adds all unique error messages for the entity into the
error_info list attribute, and all notes for the entity into the
note_info list attribute.  Finally, if the cell_state is B<ERROR_MSG>
or B<NOTE_MSG>, then all the messages generated for the entity are
added to the all_msgs list attribute for generation into log at the
end of processing (L<"PRINTING MESSAGES AND STATISTICS METHODS">).
This method increments the counting statistic B<cellCounter>.  The
locus name is obtained from L<"$current_locus_name = getLocusName">,
the ambiguous status is obtained from L<"getAmbiguousCell">, and the
cell state is obtained from L<"$cell_state = getCellState">.

=head1 MESSAGE GATHERING METHODS

These method provide the means of adding message data that includes:
messages, notes, and errors.

=head2 B<addMsg(msg)>

The method add the msg to msgs list attribue and denotes it as a
B<MSG_MSG>.  If the cell_state is not defined, then it sets the
cell_state to B<MSG_MSG>.

=head2 B<addNote(msg)>

The method add the msg to msgs list attribue and denotes it as a
B<NOTE_MSG>.  If the cell_state is not defined or B<MSG_MSG>, then it
sets the cell_state to B<NOTE_MSG>.

=head2 B<addResult(header, names, vals, print_type)>

The method adds a result message consisting of a header and several
names (referenced Perl array) and associated values for the names
(vals-referenced Perl hash) and print_type (B<MSG_MSG> or
B<NOTE_MSG>).  This method creates a formated display of the header,
names and values and adds this to either messages or notes as
indicated by print_type.  If empty_cell is TRUE (0), then this method
returns immediately and does not generate a result.

=head2 B<registerError(err_cat, err_num, params, error)>

This method manages error messages that will used in generating error
information into the log.  The parameters are the same as those for
the similar method defined in L<util::ErrMgr>, since this class will
call that method in the logging object when processing error messages
at the end of processing (L<"PRINTING MESSAGES AND STATISTICS METHODS">).
The err_cat is a non-zero integer representing an error category,
err_num is a positive integer associated with the err_cat category,
and params is a rereferenced Perl array for the error message, and error
is Boolean indicating whether the error has occured (TRUE 1)) or not
(FALSE (0).  If the error Boolean is FALSE (0), then this method
returns immediately.  Otherwise, it will register the error message
into the msgs list attribute and denote it as B<ERROR_MSG>.  The
cell_state is set to B<ERROR_MGS>.  Also, this method adds the error
to err_msgs for the cell_info attribute if the error has not already
occurred for the current entity being processed.

=head2 B<directRegisterError(err_cat, err_num, params, error)>

This method directly writes the error message to the log using the
logging object's B<registerError> method (L<util::ErrMgr>).  The method
does not process the error message any further.

=head1 COUNTING STATISTIC METHODS

These method allow the gathering of the counting statistics data
mantained by this class.

=head2 B<addDataCapture((table, datum)>

This method gathers the datum into data capture table one of the following:

   CWD_TABLE     -- cwd
   RARE_TABLE    -- rare
   SUBJECT_TABLE -- subject

These tables will be used to generate the following counting statistics when the
data is finally written to the log.  The correspondence of table to counting
statistics is defined below:

   CWD_TABLE     -- cwdAlleleCounter
   RARE_TABLE    -- rareAlleleCounter
   SUBJECT_TABLE -- subjectCounter

The B<CWD_TABLE> and B<RARE_TABLE> data capture tables also manage the
capture of associated locus name, using 
L<"$current_locus_name = getLocusName">, for the table.

=head2 B<incStatistic(statistic_name, @tag_data)>

This method increments a count for a given counting statistic
(statistic_name) and for the list of tag value pairs, @tag_data.
The counting statistics supported by this class include:

   cellCounter           -- Cell Count
   cwdCounter            -- CWD Status
   dataTypeCounter       -- Data Type
   variantFeatureCounter -- Feature Variant Count

The tags and tag values for these counting statistics are defined in
L<"COUNTING STATISTICS MANAGED BY THE CLASS">.

=head1 PRINTING MESSAGES AND STATISTICS METHODS

These methods are executed at the end of processing of the quality
control tool to allow the counting statistics, informational tables
(errors and notes), and detailed error information to be printed to
the log.

=head2 B<printStatistics(@property_data)>

This method prints data to the log at the end of processing for the
following quality control tool that includes:

   validateAlleleNames.pl        -- allele validation
   allelicAmbiguityReduction.pl  -- allelic ambiguity reduction
   genotypeAmbiguityReduction.pl -- genotype ambiguity reduction

This method generates the following in order into the log:

=over 4

=item B<Properties Table>

The properties table takes the @property_data list that consists of
referenced Perl hash containing the keys B<Property> and B<Value>,
adds to it the (Property, Value)-pairs for B<Species> and B<HLA Allele
File Type> properties, and then generates the
B<Files and species information> table.

=item B<Subject Table>

The counting statistics B<subjectCounter> is generated from the
B<SUBJECT_TABLE> table and then written into the log as 
B<Subject Statistics>.

=item B<Error Counts>

The counting statistic B<cellCounter> is used to generate the
statistic B<errorCounter> to the log.

=item B<List of Errors>

If there were any errors registered 
(see L<"registerError(err_cat, err_num, params, error)">),
then the list of errors is generated into the log as a table with
colums: 'Row Num', 'Row Id', 'Col Name', 'Cell Data', 'Err Num', and
'Error Message'.

=item B<List of Notes>

If there were any notes registered (see L<"addNote(msg)">),
then the of list of notes is generated into the log as a table with
colums: 'Row Num', 'Row Id', 'Col Name', 'Cell Data', and
'Note Message'.

=item B<Message Details>

The message details are generated only if there were B<NOTE_MSG> or
B<ERROR_MSG> messages generated during the run.  Also, message details
will be generated is L<"getWriteMsgs"> is TRUE (1).

=item B<Error Log Statistic>

The error statistics for the error logger (L<util::ErrMgr>) is generated next if
there were any error registered using
(L<"registerError(err_cat, err_num, params, error)"> 
or L<"directRegisterError(err_cat, err_num, params, error)">).

=item B<Counting Statistics>

The countining statistics B<cwdAlleleCounter> and B<rareAlleleCounter>
are generated from the B<CWD_TABLE> and B<RARE_TABLE> tables,
respectively.  Finally, the following counting statistics are
generated into the log in order:

    Counting Statistic
    -----------------
    ambiguityCounter  (using cellCounter counting statistic)
    dataTypeCounter
    cwdCounter
    cwdAlleleCounter
    rareAlleleCounter
    cellCounter       (using cellCounter counting statistic)

If there is no data for a counting statistic, it will not be
generated.

=back

=head2 B<printVariantStatistics(@property_data)>

This method prints data to the log at the end of processing for the
following quality control tool:

   analyzeVariantTypes.pl  -- SFVT analysis
   generateVariantTypes.pl -- sequence feature vector file generation

This method generates the following in order into the log:

=over 4

=item B<Properties Table>

The properties table takes the @property_data list that consists of
referenced Perl hash containing the keys B<Property> and B<Value>,
adds to it the (Property, Value)-pairs for B<Species> and B<HLA Allele
File Type> properties, and then generates the
B<Files and species information> table.

=item B<Subject Table>

The countining statistics B<subjectCounter> is generated from the
B<SUBJECT_TABLE> table and then written into the log as 
B<Subject Statistics>.

=item B<Counting Statistics>

The following counting statistics are generated into the log in the
order:

    Counting Statistic
    ---------------------
    errorCounter          (using cellCounter counting statistic)
    variantFeatureCounter
    dataTypeCounter
    cellCounter           (using cellCounter counting statistic)

If there is no data for a counting statistic, it will not be
generated.

=item B<Error Counts>

The counting statistic B<cellCounter> is used to generate the
statistic B<errorCounter> to the log.

=item B<List of Errors>

If there were any errors registered 
(see L<"registerError(err_cat, err_num, params, error)">),
then the list of errors is generated into the log as a table with
colums: 'Row Num', 'Row Id', 'Col Name', 'Cell Data', 'Err Num', and
'Error Message'.

=item B<List of Notes>

If there were any notes registered (see L<"addNote(msg)">),
then the of list of notes is generated into the log as a table with
colums: 'Row Num', 'Row Id', 'Col Name', 'Cell Data', and
'Note Message'.

=item B<Message Details>

The message details are generated only if there were B<NOTE_MSG> or
B<ERROR_MSG> messages generated during the run.  Also, message details
will be generated is L<"getWriteMsgs"> is TRUE (1).

=item B<Error Log Statistic>

The error statistics for the error logger (L<util::ErrMgr>) is generated next if
there were any error registered using
(L<"registerError(err_cat, err_num, params, error)"> 
or L<"directRegisterError(err_cat, err_num, params, error)">).

=back

=head1 SETTER METHODS

These methods set attributes in the class.

=head2 B<incRowNum>

This method increments the row_num attribute by one (1);

=head2 B<resetRowNum>

This method sets the row_num attribute to zero (0).

=head2 B<setAmbiguousCell>

This method set the ambiguous_cell attribute to TRUE (1) for the
current alleleSet being processed.

=head1 GETTER METHODS

These method provide access to attributes of the class.

=head2 B<getAmbiguousCell>

This method returns a Boolean indicating whether the cell is ambiguous
(TRUE (1)) or not ambiguous (FALSE (0)).

=head2 B<$cell_state = getCellState>

This method returns current cell_state for the entity being proessed by a 
quality control tool.  The state can include:

   <undef>    -- <NO STATE>
   ERROR_MSG  -- err
   MSG_MSG    -- msg
   NOTE_MSG   -- note

=head2 B<getEmptyCell>

This method returns the Boolean empty_cell attribute that indicate
whether the cell is empty (TRUE (1)) or not empty (FALSE (0)).

=head2 B<$count = getCount(statistic_name, @tag_data)>

This method returns the count for counting statistic (statistic_name)
and for the list of tag value pairs, @tag_data.  The counting
statistics supported by this class include:

   cellCounter           -- Cell Count
   cwdCounter            -- CWD Status
   dataTypeCounter       -- Data Type
   variantFeatureCounter -- Feature Variant Count

The tags and tag values for these counting statistics are defined in
L<"COUNTING STATISTICS MANAGED BY THE CLASS">.

=head2 B<$current_locus_name = getLocusName>

This method returns the current_locus attribute.

=head2 B<@locus_names = getLocusNames>

This methods returns the list of full locus names associated with the
taxon_id in the constructor.

=head2 B<$row_num = getRowNum>

This method returns the current row_num attribute.

=head2 B<getWriteMsgs>

This method returns the Boolean attribute write_msgs.  The attribute
determines whether messages that are neither error nor note messages
are to be generated into log file at the end of processing 
L<"PRINTING MESSAGES AND STATISTICS METHODS">.

=head1 FORMAT DATA LIST METHODS

This methods provide a convenient mechanism for managing the formating
of lists of data.

=head2 B<$formated_data = formatData(that, start, end, spacer, num_per_row, @data)>

This method formats the data list @data using the start and end as
prefix and suffix of the format string.  Also, the method breaks apart
the @data modulo num_per_row separating each datum by a B<', '> into
segments that are separated by space.  Each datum in @datum is
formated by the method B<that-E<gt>formatDatum> in the object that.

=head2 B<$row_num = formatDatum(row_num)>

This datum formating method for this class takes a row_num and returns
it 'as-is'.

=head2 B<$header = generateRowsHeader(rows_spacer, num_rows_per_row)>

This method returns the current row_nums list attribute in a format
for writing into a header in the log.  This method uses the method
L<"$formated_data = formatData(that, start, end, spacer, num_per_row, @data)">,
where B<that> is this object, B<start> '(', B<end> '(', B<space>
rows_spacer, B<num_per_row> num_rows_per_row, and B<@data> the current
row_nums attribute.

=cut
