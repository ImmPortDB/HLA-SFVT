package util::Math;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;

################################################################################
#
#			Public Static Methods
#
################################################################################
###
### Value of pi
###
sub PI { return 3.14159265358979323846; }

################################################################################
#
#			Public Static Methods
#
################################################################################

my $_ERROR_MGR_ = undef;

sub setErrorMgr($) {
  my ($error_mgr) = @_;
  $_ERROR_MGR_ = $error_mgr;
}

sub chiSquarePVal($$) {
  my ( $chiSquare, $DoF ) = @_;
  ###
  ### Probability zero (0) case
  ###
  if ( $chiSquare > 1000 && $DoF == 1 ) {
    return 0;
  }
  ###
  ### Scale chi-square before computing probability
  ###
  if ( $chiSquare > 1000 || $DoF > 1000 ) {
    my $p_val =
      &chiSquarePVal( ( $chiSquare - $DoF )**2 / ( 2 * $DoF ), 1 ) / 2;
    if   ( $chiSquare > $DoF ) { return $p_val; }
    else                       { return 1 - $p_val; }
  }
  ###
  ### Now compute probability in all other cases
  ###
  my $p_val = exp( -0.5 * $chiSquare );
  ###
  ### Case:  The degrees of freedom are odd
  ###
  if ( $DoF % 2 == 1 ) {
    if ( $chiSquare < 0 ) {
      my $msg = "Negative chi-square value = $chiSquare";
      if   ( defined($_ERROR_MGR_) ) { $_ERROR_MGR_->printWarning($msg); }
      else                           { print "WARNING $msg\n\n"; }
    }
    elsif ( $chiSquare > 0 ) {
      $p_val *= sqrt( 2 * $chiSquare / PI );
    }
  }
  ###
  ### Final computation of probability
  ###
  ### 1.  Using degrees of freedom
  ###
  my $degreesOfFreedom = $DoF;
  while ( $degreesOfFreedom >= 2 ) {
    $p_val *= $chiSquare / $degreesOfFreedom;
    $degreesOfFreedom -= 2;
  }
  ###
  ### 2.  Using the p-value and degrees of freedom
  ###
  my $theProbability = $p_val;
  $degreesOfFreedom = $DoF;
  while ( $theProbability > ( 0.0000000001 * $p_val ) ) {
    $degreesOfFreedom += 2;
    $theProbability *= $chiSquare / $degreesOfFreedom;
    $p_val += $theProbability;
  }

  return 1 - $p_val;
}

sub confidenceInterval($$) {
  my ( $oddsRatio, $stdErr ) = @_;

  return ( 0.0, 0.0 ) if ( !defined($oddsRatio) || !defined($stdErr) );

  my $L     = log($oddsRatio);
  my $lower = exp( $L - 1.96 * $stdErr );
  my $upper = exp( $L + 1.96 * $stdErr );

  return ( $lower, $upper );
}

################################################################################

1;

__END__

=head1 NAME

Math.pm

=head1 DESCRIPTION

The static class defines basic mathematic functions

=head1 STATIC CONSTANTS

The following constants are exported:

   util::Math::PI - 3.14159265358979323846

=head1 STATIC METHODS

The following static methods are exported by this class.

=head2 B<setErrorMgr(error_mgr)>

This method sets the error_mgr object for reporting information in
this static class.  The B<error_mgr> is an instance of
L<util::ErrMgr>.

=head2 B<$pVal = chiSquarePVal(chiSquare, DoF)>

This method computes the Chi-Square probabiltiy (p-value) for the
given Chi-Square value B<chiSquare> and degrees of freedom B<DoF>.

=head2 B<($lower, $upper) = confidenceInterval(oddsRatio, stdErr)>

This method computes lower and upper bounds of the confidence interval
given the odd ration and standard error.

=cut
