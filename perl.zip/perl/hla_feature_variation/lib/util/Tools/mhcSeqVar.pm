package util::Tools::mhcSeqVar;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;

use util::Constants;
use util::ErrMsgs;
use util::PathSpecifics;
use util::Properties;

use db::MhcTypes;

use lookup::Alleles;

use base 'util::Tools';

use fields qw(
  alleles_lookup
  create_exec_dir
  file_types
  file_type_filler_rows
  file_type_headers
  reader_types
  treat_xls_as_txt
);

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Context Properties
###
sub PROPERTIES_FILE_PROP { return 'propertiesFile'; }
###
### Reader Types
###
sub HlaReader     { return 'Hla'; }
sub FeatureReader { return 'Feature'; }

sub readerTypes {
  return {
    &HlaReader     => HlaReader,
    &FeatureReader => FeatureReader,
  };
}
###
### File Types
###
sub CustomType    { return 'Custom HLA Typing'; }
sub HlaRawType    { return 'HLA Raw'; }
sub HlaTypingType { return 'HLA Typing'; }
sub PypopType     { return 'Pypop'; }
sub VariantType   { return 'Variant Sequence Type'; }

sub fileTypes {
  return {
    &CustomType    => 'Custom',
    &HlaRawType    => 'Raw',
    &HlaTypingType => 'Typing',
    &PypopType     => 'Pypop',
  };
}

sub fileTypeHeaders {
  return {
    &CustomType    => 'Custom HLA typing file with phenotypes',
    &HlaRawType    => 'Well ID',
    &HlaTypingType => 'HLA Typing Results',
    &PypopType     => 'labcode',
    &VariantType   => 'HLA Sequence Feature Variant Type Results',
  };
}

sub fileTypeFillerRows {
  return {
    &HlaTypingType => 'Please do not delete or edit this column',
    &PypopType     => 'Please do not delete or edit this column',
    &VariantType   => 'Sequence feature names are listed in this row',
  };
}
###
### All the file properties for this library
### Used to limit the basename in log files
###
sub FILE_PROPERTIES {
  return (
    'alignmentDirectory',       'allelicAmbiguityReducedFile',
    'analysisFile',             'analysisTxtOutput',
    'analysisXmlOutput',        'anttFile',
    'anttIniFile',              'anttTool',
    'anttTranslationDirectory', 'bcpDirectory',
    'dbConfigFile',             'dbMhcDirectory',
    'dbMhcFile',                'executionDirectory',
    'featureFile',              'fileTypeFile',
    'generatedFiles',           'genotypeAmbiguityReducedFile',
    'hlaAlleleFile',            'hlaFile',
    'lookupDirectory',          'monoTool',
    'mrafFrequencyData',        'msfDirectory',
    'nmdpDirectory',            'nomenclatureFile',
    'propertiesFile',           'pypopFile',
    'pypopIniFile',             'pypopTool',
    'regionData',               'statusFile',
    'validatedFile',            'variantFile',
    'variantFiles'
  );
}
###
### Max Columns
###
sub MAX_COLS { return 4000; }
###
### Error Category
###
sub ERR_CAT { return util::ErrMsgs::TOOLS_CAT; }

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $tool_order, $error_mgr, $error_categories ) = @_;
  my util::Tools::mhcSeqVar $this =
    $that->SUPER::new( $error_mgr, $error_categories );

  $this->{alleles_lookup}        = undef;
  $this->{create_exec_dir}       = util::Constants::FALSE;
  $this->{file_type_filler_rows} = fileTypeFillerRows;
  $this->{file_type_headers}     = fileTypeHeaders;
  $this->{file_types}            = fileTypes;
  $this->{reader_types}          = readerTypes;
  $this->{treat_xls_as_txt}      = util::Constants::FALSE;

  $this->setContextProperty( $this->DBCONFIG_FILE_PROP );
  $this->setContextProperty( $this->HEADER_MESSAGE_PROP );
  $this->setToolOrder($tool_order);
  $this->setTableInfo(db::MhcTypes::sequenceVariationTableInfo);

  $this->setFileProperties(FILE_PROPERTIES);

  return $this;
}

################################################################################
#
#                           Setter Methods
#
################################################################################

sub setInitializations {
  my util::Tools::mhcSeqVar $this = shift;
  db::MhcTypes::initializeControlledVocabularies( $this->{db},
    $this->{error_mgr} );
}

sub setCreateExecutionDirectory {
  my util::Tools::mhcSeqVar $this = shift;
  my ($create_dir) = @_;
  $this->{create_exec_dir} =
    ( !util::Constants::EMPTY_LINE($create_dir) && $create_dir )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
}

sub setPipelineContext {
  my util::Tools::mhcSeqVar $this = shift;
  my ($propertiesFile) = @_;
  ###
  ### Get the properties
  ###
  my $properties = new util::Properties;
  $propertiesFile = getPath($propertiesFile);
  $properties->loadFile($propertiesFile);
  ###
  ### Create logInfix Property
  ###
  $properties->setProperty( $this->LOG_INFIX_PROP,
    $this->getLogInfix($propertiesFile) );
  ###
  ### Create execution directory as necessary,
  ### removing it if necessary
  ###
  $this->setContextProperty(PROPERTIES_FILE_PROP);
  my $executionDirectory =
    $properties->getProperty( $this->EXECUTION_DIRECTORY_PROP );

  $this->setExecutionDir( $executionDirectory, $this->{create_exec_dir} )
    if ( $this->{create_exec_dir} );
  ###
  ### Create property file
  ###
  $propertiesFile = join( util::Constants::SLASH,
    $executionDirectory,
    join( util::Constants::DOT,
      $this->getPropertiesFilename($propertiesFile),
      $this->PROPERTIES
    )
  );
  $properties->setProperty( PROPERTIES_FILE_PROP, $propertiesFile );
  ###
  ### Store the properties for the pipeline
  ### into the pipeline properties file
  ###
  $properties->storeFile($propertiesFile);
  ###
  ### Now return the tool's properties file
  ###
  return $propertiesFile;
}

sub setAllelesLookup {
  my util::Tools::mhcSeqVar $this = shift;
  my ($taxon_id) = @_;
  return if ( defined( $this->{alleles_lookup} ) );
  $this->{alleles_lookup} =
    new lookup::Alleles( $taxon_id, $this, $this->{error_mgr} );
}

sub setTreatXlsAsTxt {
  my util::Tools::mhcSeqVar $this = shift;

  $this->{treat_xls_as_txt} = util::Constants::TRUE;
}

################################################################################
#
#                           Getter Methods
#
################################################################################

sub getLogInfix {
  my util::Tools::mhcSeqVar $this = shift;
  my ($propertiesFile) = @_;
  ###############################
  ### Re-Implementable Method ###
  ###############################

  return $this->getStartTime;
}

sub getPropertiesFilename {
  my util::Tools::mhcSeqVar $this = shift;
  my ($propertiesFile) = @_;
  ###############################
  ### Re-Implementable Method ###
  ###############################

  return join( util::Constants::DOT, $this->scriptPrefix, $this->getStartTime );
}

sub definedReaderType {
  my util::Tools::mhcSeqVar $this = shift;
  my ($readerType) = @_;

  my $readerTypes = $this->{reader_types};
  return (
    defined( $readerTypes->{$readerType} )
    ? util::Constants::TRUE
    : util::Constants::FALSE
  );
}

sub definedFileType {
  my util::Tools::mhcSeqVar $this = shift;
  my ($fileType) = @_;

  my $fileTypes = $this->{file_types};
  return (
    defined( $fileTypes->{$fileType} )
    ? util::Constants::TRUE
    : util::Constants::FALSE
  );
}

sub getFileTypeHeader {
  my util::Tools::mhcSeqVar $this = shift;
  my ($file_type) = @_;
  return $this->{file_type_headers}->{$file_type};
}

sub getFileTypeFillerRow {
  my util::Tools::mhcSeqVar $this = shift;
  my ($file_type) = @_;
  return $this->{file_type_filler_rows}->{$file_type};
}

sub determineMhcFileType {
  my util::Tools::mhcSeqVar $this = shift;
  my ($file) = @_;
  ###
  ### Return immediately for no file
  ###
  return undef if ( util::Constants::EMPTY_LINE($file) );
  ###
  ### Now determine the file file
  ###
  my $cols = [];
  foreach my $index ( 0 .. MAX_COLS ) {
    push( @{$cols}, 'col_' . $index );
  }
  my $first_col = $cols->[0];
  my $reader    = $this->getReader( $file, $cols );
  my $file_type = undef;
OUTTER_LOOP:
  foreach my $entity ( @{ $reader->getEntities } ) {
    my $col_val = $entity->{$first_col};
    foreach my $fileType ( keys %{ $this->{file_type_headers} } ) {
      next if ( $col_val ne $this->getFileTypeHeader($fileType) );
      $file_type = $fileType;
      last OUTTER_LOOP;
    }
  }
  $reader->closeSourceFile;
  return $file_type;
}

sub getAllelesLookup {
  my util::Tools::mhcSeqVar $this = shift;
  return $this->{alleles_lookup};
}

sub getTreatXlsAsTxt {
  my util::Tools::mhcSeqVar $this = shift;

  return $this->{treat_xls_as_txt};
}

################################################################################
#
#                           Object Instantiation Methods
#
################################################################################

sub getReader {
  my util::Tools::mhcSeqVar $this = shift;
  my ( $file, $cols ) = @_;
  ###
  ### File class type determined
  ###
  my $class = undef;
  if ( $file =~ /\.txt$/
    || ( $this->getTreatXlsAsTxt && $file =~ /\.xls$/ ) )
  {
    ###
    ### Determine if it is TAB NEWLINE (Tab) or TAB CTRLM (TabCtrlM)
    ###
    my $className = 'Tab';
    my $fh        = new FileHandle;
    $this->exitProgram(
      ERR_CAT, 108,
      [ basename($file), ],
      !$fh->open( $file, "<" )
    );
    my $prev_line_separator = $/;
    $/ = util::Constants::NEWLINE;
    while ( !$fh->eof ) {
      my $line = $fh->getline;
      if ( $line =~ // ) { $className = 'TabCtrlM'; }
      last;
    }
    $fh->close;
    $/ = $prev_line_separator;
    $this->{error_mgr}->printDebug("getReader className = $className");
    $class = 'file::Chunk::Bcp::' . $className;
  }
  elsif ( $file =~ /\.xls$/ ) {
    $class = 'file::Chunk::Excel';
  }
  $this->exitProgram( ERR_CAT, 104, [ basename($file) ], !defined($class) );
  ###
  ### Open and read file
  ###
  my $reader     = undef;
  my @eval_array = (
    'use ' . $class . ';',
    '$reader =',
    'new ' . $class,
    '  (undef,',
    '   $cols,',
    '   $this->{error_mgr});'
  );
  my $eval_str = join( util::Constants::NEWLINE, @eval_array );
  $this->{error_mgr}->printDebug("getReader:  eval_str=\n$eval_str");
  eval $eval_str;
  my $status = $@;
  $this->exitProgram(
    ERR_CAT, 9,
    [ $status, $eval_str ],
    defined($status) && $status
  );
  ###
  ### set the file and read it
  ###
  $reader->setSourceFile($file);
  if ( $file =~ /\.txt$/
    || ( $this->getTreatXlsAsTxt && $file =~ /\.xls$/ ) )
  {
    $reader->readBcpFile;
  }
  elsif ( $file =~ /\.xls$/ ) {
    $reader->readExcelFile;
  }

  return $reader;
}

sub getMhcFileReader {
  my util::Tools::mhcSeqVar $this = shift;
  my ( $readerType, $fileType, $file, $taxonId, @params ) = @_;

  my $file_types = $this->{file_types};
  $this->exitProgram( ERR_CAT, 101, [$fileType],
    !$this->definedFileType($fileType) );
  $this->exitProgram( ERR_CAT, 102, [$readerType],
    !$this->definedReaderType($readerType) );
  my $class = join( util::Constants::DOUBLE_COLON,
    'file', 'Mhc', $readerType, $file_types->{$fileType} );
  my $params_str = util::Constants::EMPTY_STR;
  if ( @params >= 1 ) {
    $params_str = join( util::Constants::COMMA_SEPARATOR, @params )
      . util::Constants::COMMA_SEPARATOR;
  }
  my $mhc_reader = undef;
  my @eval_array = (
    'use ' . $class . ';',
    '$mhc_reader =',
    'new ' . $class,
    '  ($file,', '   $taxonId,', $params_str, '   $this,',
    '   $this->{error_mgr});'
  );
  my $eval_str = join( util::Constants::NEWLINE, @eval_array );
  $this->{error_mgr}->printDebug("getMhcFileReader:  eval_str=\n$eval_str");
  eval $eval_str;
  my $status = $@;
  $this->exitProgram(
    ERR_CAT, 9,
    [ $status, $eval_str ],
    defined($status) && $status
  );

  return $mhc_reader;
}

sub getMhcFileType {
  my util::Tools::mhcSeqVar $this = shift;
  my ($reader) = @_;

  my $file_types = $this->{file_types};

  $this->exitProgram(
    ERR_CAT, 101,
    [ $reader->type ],
    !$this->definedFileType( $reader->type )
  );
  my $class = join( util::Constants::DOUBLE_COLON,
    'file', 'MhcType', $file_types->{ $reader->type } );
  my $mhc_type   = undef;
  my @eval_array = (
    'use ' . $class . ';',
    '$mhc_type =',
    'new ' . $class,
    '  ($reader,',
    '   $this,',
    '   $this->{error_mgr});'
  );
  my $eval_str = join( util::Constants::NEWLINE, @eval_array );
  $this->{error_mgr}->printDebug("getMhcFileType:  eval_str=\n$eval_str");
  eval $eval_str;
  my $status = $@;
  $this->exitProgram(
    ERR_CAT, 9,
    [ $status, $eval_str ],
    defined($status) && $status
  );

  return $mhc_type;
}

################################################################################

1;

__END__

=head1 NAME

mhcSeqVar.pm

=head1 DESCRIPTION

This class defines the basics capabilities for running loaders and
quality control tools for the B<MHC_SEQ_VAR> database.  This class is
a subclass of L<util::Tools>.

=head1 STATIC CONSTANTS

The following context properties are exported:

   util::Tools::mhcSeqVar::PROPERTIES_FILE_PROP -- propertiesFile

The classes of file readers include:

   util::Tools::mhcSeqVar::HlaReader   -- Hla
   util::Tools::mhcSeqVar::FeatureType -- Feature

The type of files recognized by this class include:

   util::Tools::mhcSeqVar::CustomType    -- Custom Type
   util::Tools::mhcSeqVar::HlaRawType    -- HLA Raw
   util::Tools::mhcSeqVar::HlaTypingType -- HLA Typing
   util::Tools::mhcSeqVar::PypopType     -- Pypop
   util::Tools::mhcSeqVar::VariantType   -- Variant Seequence Type

This class exports three referenced Perl hashes that define file type
suclass names, the headers, and the filler rows for the various file
types defined as follows:

   util::Tools::mhcSeqVar::fileTypes
     util::Tools::mhcSeqVar::CustomType    -- Custom
     util::Tools::mhcSeqVar::HlaRawType    -- Raw
     util::Tools::mhcSeqVar::HlaTypingType -- Typing
     util::Tools::mhcSeqVar::PypopType     -- Pypop

   util::Tools::mhcSeqVar::fileTypeHeaders
     util::Tools::mhcSeqVar::CustomType    -- Custom HLA typing file with phenotypes
     util::Tools::mhcSeqVar::HlaRawType    -- Well ID
     util::Tools::mhcSeqVar::HlaTypingType -- HLA Typing Results
     util::Tools::mhcSeqVar::PypopType     -- labcode
     util::Tools::mhcSeqVar::VariantType   -- HLA Sequence Feature Variant Type Results

   util::Tools::mhcSeqVar::fileTypeFillerRows
     util::Tools::mhcSeqVar::HlaTypingType -- Please do not delete or edit this column
     util::Tools::mhcSeqVar::PypopType     -- Please do not delete or edit this column
     util::Tools::mhcSeqVar::VariantType   -- Sequence feature names are listed in this row

The following properties for this class and subclasses will have only their
file base name generated into log files:

   FILE_PROPERTIES
     alignmentDirectory
     allelicAmbiguityReducedFile
     analysisFile
     analysisTxtOutput
     analysisXmlOutput
     anttFile
     anttIniFile
     anttTool
     anttTranslationDirectory
     bcpDirectory
     dbConfigFile
     dbMhcDirectory
     dbMhcFile
     executionDirectory
     featureFile
     fileTypeFile
     generatedFiles
     genotypeAmbiguityReducedFile
     hlaAlleleFile
     hlaFile
     lookupDirectory
     monoTool
     msfDirectory
     nmdpDirectory
     nomenclatureFile
     propertiesFile
     pypopFile
     pypopIniFile
     pypopTool
     statusFile
     validatedFile
     variantFile
     variantFiles

=head1 PUBLIC METHODS

The following methods are exported by this class.

=head2 B<new mhcSeqVar::new(tool_order, error_mgr[, error_categories])>

This is the constructor for the class.  The error_mgr parameter
defines the logging object (L<util::ErrMgr>).  The B<tool_order> is a
referenced Perl array containing the tools to execute in order using
the B<generate> method.  The tools in the array are the Perl tool base
names.  The bin directory containing the tools is defined by the
environment variable B<$DEVEL_BIN>.  The optional B<error_categories>
parameter is a referenced Perl array of the error reporting categories
that the class will use.  These need to be Perl library names that
contains the error message class B<library::ErrMsgs>.

The following properties are added to the basic context properties:

   util::Tools::DBCONFIG_FILE_PROP  -- dbConfigFile
   util::Tools::HEADER_MESSAGE_PROP -- headerMessage

The constructor sets the table information for the L<db::MhcTypes>
schema.  Finally, it sets the file properties whose base name will
only appear in the log files (see L"CONSTANTS">).

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<setInitializations>

This method implements the setting of the controlled vocabulary data
in the B<db::MhcTypes> static class by reading the database.

=head2 B<setCreateExecutionDirectory(create_dir)>

This method sets the flag B<create_dir> to create the execution
directory (TRUE (1)) or not (FALSE (0)).  By default, the flag is
FALSE (0).

=head2 B<$properties_file = setPipelineContext(properties_file)>

This method sets up the standard pipeline configuration for executing
a pipeline as defined by the B<tool_order> in the constructor.  The
method reads the properties file B<properties_file>.  Then it sets the
B<logInfix> property.  Further, it set the B<propertiesFile> property
to the properties file that will be used by the pipeline tools.  This
properties file will exist in the execution directory.  The method
then sets the execution directory using the B<executionDirectory>
property, creating the directory if requested (see
L<"setCreateExecutionDirectory(create_dir)">.  Then it stores all the
properties into the file B<propertiesFile> in the execution directory.
Finally, it returns the tool's properties file that can be used to set
the context using the method B<setContext>.  This method uses the two
re-implementable method:
L<"$log_infix = getLogInfix(properties_file)"> and
B<"$properties_filename = getPropertiesFilename(properties_file)">.

=head2 B<setAllelesLookup(taxon_id)>

This method instantiates the alleles lookup object for the B<taxon_id>
if it has not already been created.  The allele lookup is an instance
of L<lookup::Alleles>.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$log_infix = getLogInfix(properties_file)>

This re-implementable method creates B<log_infix> name.  By default,
this infix is the tool's start time.

=head2 B<$properties_filename = getPropertiesFilename(properties_file)>

This re-implementable method creates B<properties_filename> (without
the '.properties' suffix).  By dnefault, the properties filename is

   <tool's script prefix>.<tool's start time>

=head2 B<definedReaderType(readerType)>

This method returns TRUE (1) if the readerType is a defined reader type
for this class, otherwise it returns FALSE(0).  The currently defined
tool reader types include:

   util::Tools::mhcSeqVar::HlaReader
   util::Tools::mhcSeqVar::FeatureReader

=head2 B<definedFileType(fileType)>

This method returns TRUE (1) if the fileType is a defined file type
for this class, otherwise it returns FALSE(0).  The currently defined
tool file types include:

   util::Tools::mhcSeqVar::CustomType
   util::Tools::mhcSeqVar::HlaRawType
   util::Tools::mhcSeqVar::HlaTypingType
   util::Tools::mhcSeqVar::PypopType
   util::Tools::mhcSeqVar::VariantType

=head2 B<$file_header = getFileTypeHeader(file_type)>

This method returns the file header for the given
file_type. Currently, the file types having headers include:

   util::Tools::mhcSeqVar::CustomType
   util::Tools::mhcSeqVar::HlaRawType
   util::Tools::mhcSeqVar::HlaTypingType
   util::Tools::mhcSeqVar::PypopType
   util::Tools::mhcSeqVar::VariantType

=head2 B<$file_filler_row = getFileTypeFillerRow(file_type)>

This method returns the file filler row for the given file_type.
Currently, the file types having filler rows include:

   util::Tools::mhcSeqVar::HlaTypingType
   util::Tools::mhcSeqVar::PypopType
   util::Tools::mhcSeqVar::VariantType

=head2 B<$mhc_file_type = determineMhcFileType(file)>

This method determines the file type of the file by inspecting the
file's contents and determining the file type by the file header in
the file.  If there is no file or it cannot determine a file type,
then it return undef.  The currently defined file types include the
following:

   util::Tools::mhcSeqVar::CustomType
   util::Tools::mhcSeqVar::HlaRawType
   util::Tools::mhcSeqVar::HlaTypingType
   util::Tools::mhcSeqVar::PypopType
   util::Tools::mhcSeqVar::VariantType

=head2 B<$alleles_lookup = getAllelesLookup>

This method returns the alleles lookup object--an instance of
L<lookup::Alleles>--if it has been created by
L<"setAllelesLookup(taxon_id)">, otherwise it return B<undef>.

=head1 OBJECT INSTANTIATION METHODS

The following object instantiation methods are exported by this class.

=head2 B<$reader = getReader(file, cols)>

The method returns a file reader for the filename B<file> based on the
suffix of the file ('.txt'--text file or '.xls'--2003 Excel
spreadsheet), and for text files based on the line separator (Ctrl-M
or Ctrl-J).  Further, text files are assumed to be tab-separated file.
The B<cols> parameters defines a referenced Perl array defining the
columns (in order) that appear in the file.  The method will return
one the following class instances: L<file::Chunk::Bcp::Tab>,
L<file::Chunk::Bcp::TabCtrlM>, or L<file::Chunk::Excel> for
tab-separated text files with Ctrl-J line separator, tab-separated
text files with Ctrl-M line separator, and 2003 Excel spreadsheets,
respectively.

=head2 B<$file_reader = getMhcFileReader(reader_type, file_type, file_name, taxon_id, @params)>

This method instantiates the file reader for the B<file_name>
having the B<reader_type> and B<file_type> as defined in this class.
The B<taxon_id> is the taxon of the species.  Currently B<9606> (Homo
Sapiens) is supported.  The optional B<@params> list is supplied to
the instantiated file reader 'as-is'.  This method assumes the file
reader class being instantiated has the signature: 
B<file, taxon_id, @params, tools, error_mgr)>, 
where B<tools> is this class and B<error_mgr> is the logger defined in
this class.  The file reader class is defined to be
B<file::Mhc::E<lt>reader_typeE<gt>::E<lt>file_typeE<gt>> and is
subclass of B<file::Mhc>.  The current reader types supported include:

   Hla     -- util::Tools::mhcSeqVar::HlaReader
   Feature -- util::Tools::mhcSeqVar::FeatureType

The current file types supported include:

   Custom  -- util::Tools::mhcSeqVar::CustomType
   Raw     -- util::Tools::mhcSeqVar::HlaRawType
   Typing  -- util::Tools::mhcSeqVar::HlaTypingType
   Pypop   -- util::Tools::mhcSeqVar::PypopType

where the B<HlaRawType> is not supported in the reader type B<Feature>.

=head2 B<$file_type = getMhcFileType(reader)>

This method instantiates the subclass of L<file::MhcType> for the
reader, which is assumed to to be a subclass of L<file::Mhc>.  The
subclass of L<file::MhcType> that is instantiated is defined by the
readers file type (B<type> method).  Currently, the file types
supported by this class include:

   Custom  -- util::Tools::mhcSeqVar::CustomType
   Raw     -- util::Tools::mhcSeqVar::HlaRawType
   Typing  -- util::Tools::mhcSeqVar::HlaTypingType
   Pypop   -- util::Tools::mhcSeqVar::PypopType

=cut
