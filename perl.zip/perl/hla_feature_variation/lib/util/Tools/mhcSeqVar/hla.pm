package util::Tools::mhcSeqVar::hla;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'util::Tools::mhcSeqVar';

use fields
  qw(
  locus_name
);

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Tools External
###
sub generateHlaFeature          { return 'generateHlaFeature'; }
sub generatePdbPositions        { return 'generatePdbPositions'; }
sub generateHlaFeatureVariation { return 'generateHlaFeatureVariation'; }
###
### Tool Execution Order
###
sub toolOrder {
  return [ generateHlaFeature, generatePdbPositions, generateHlaFeatureVariation ];
}
###
### Error Category
###
sub ERROR_CATEGORIES {
  my $err_cats = [ 'db', 'hla', 'lookup', 'perl', ];
  return $err_cats;
}

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$) {
  my ( $that, $error_mgr ) = @_;
  my util::Tools::mhcSeqVar::hla $this =
    $that->SUPER::new( toolOrder, $error_mgr, ERROR_CATEGORIES );

  $this->{locus_name} = undef;

  $this->setContextProperty( $this->WORKSPACE_ROOT_PROP );

  return $this;
}

sub setLocusName {
  my util::Tools::mhcSeqVar::hla $this = shift;
  my ($locus_name) = @_;
  $this->{locus_name} = $locus_name;
}

sub scriptPrefix {
  my util::Tools::mhcSeqVar::hla $this = shift;
  my $script_prefix = $this->{script_name};
  $script_prefix =~ s/\.pl$//;
  if ( defined( $this->{locus_name} ) ) {
    $script_prefix =
      join( util::Constants::DOT, $script_prefix, $this->{locus_name} );
  }
  return $script_prefix;
}

################################################################################

1;

__END__

=head1 NAME

hla.pm

=head1 DESCRIPTION

This class defines the basics capabilities for running HLA feature
name loader and variant type generator tools.
It is a subclass of L<util::Tools::mhcSeqVar>.

=head1 CONSTANTS

The following constants are exported by this class

The following tools are known to this class

   util::Tools::mhcSeqVar::hla::generateHlaFeature          -- generateHlaFeature
   util::Tools::mhcSeqVar::hla::generatePdbPositions        -- generatePdbPositions
   util::Tools::mhcSeqVar::hla::generateHlaFeatureVariation -- generateHlaFeatureVariation

The tool order is defined as follows:

   util::Tools::mhcSeqVar::anthonyNolan::toolOrder
   -- referenced Perl array
      - util::Tools::mhcSeqVar::hla::generateHlaFeature
      - util::Tools::mhcSeqVar::hla::generatePdbPositions
      - util::Tools::mhcSeqVar::hla::generateHlaFeatureVariation

=head1 METHODS

The following methods are exported by this class.

=head2 B<new anthonyNolan::new(error_mgr)>

This method is the constructor for the class.  The error categories
include the following: db, hla, lookup, perl.

=head2 B<setLocusName(locus_name)>

This method allows the B<locus_name> to be defined for creating specific
script prefixes with respect to the locus.

=head2 B<scriptPrefix>

This is a re-implementation of the base method to allow for a locus name
if one is defined by the B<setLocusName> method.  If one has been defined,
then the script prefix has the suffix B<.locusName>.

=cut
