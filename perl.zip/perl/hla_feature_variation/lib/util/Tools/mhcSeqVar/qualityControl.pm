package util::Tools::mhcSeqVar::qualityControl;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;

use antt::Runner;

use db::MhcTypes;

use util::Constants;
use util::PathSpecifics;
use util::Properties;

use util::ErrMsgs;

use base 'util::Tools::mhcSeqVar';

use fields qw(
  failure_codes
  obj_types
  pipelines
  tool
);

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Special Infixes
###
sub HLA_INFIX  { return '__HLA__'; }
sub TASK_INFIX { return '__TASK__'; }
###
### Quality Control Tools
###
sub allelicAmbiguityReduction  { return 'allelicAmbiguityReduction'; }
sub analyzeVariantTypes        { return 'analyzeVariantTypes'; }
sub generateVariantTypes       { return 'generateVariantTypes'; }
sub genotypeAmbiguityReduction { return 'genotypeAmbiguityReduction'; }
sub pipelineController         { return 'pipelineController'; }
sub runPypop                   { return 'runPypop'; }
sub validateAlleleNames        { return 'validateAlleleNames'; }

sub isQualityControlTool {
  my ($tool) = @_;
  return util::Constants::TRUE if ( $tool eq allelicAmbiguityReduction );
  return util::Constants::TRUE if ( $tool eq analyzeVariantTypes );
  return util::Constants::TRUE if ( $tool eq generateVariantTypes );
  return util::Constants::TRUE if ( $tool eq genotypeAmbiguityReduction );
  return util::Constants::TRUE if ( $tool eq pipelineController );
  return util::Constants::TRUE if ( $tool eq runPypop );
  return util::Constants::TRUE if ( $tool eq validateAlleleNames );
  return util::Constants::FALSE;
}
###
### MHC Object Types
###
sub PY_LIB_NAME { return 'pypop'; }
sub QC_LIB_NAME { return 'qualityControl'; }
sub FA_LIB_NAME { return 'featureAnalysis'; }

sub CLASS_PATH {
  my (@comps) = @_;
  return join( util::Constants::DOUBLE_COLON, @comps );
}

sub objectTypes {
  return {
    &allelicAmbiguityReduction =>
      CLASS_PATH( QC_LIB_NAME, 'Allele', 'AllelicAmbiguityReduction' ),
    &analyzeVariantTypes => CLASS_PATH( FA_LIB_NAME, 'Analyze' ),
    &genotypeAmbiguityReduction =>
      CLASS_PATH( QC_LIB_NAME, 'Allele', 'GenotypeAmbiguityReduction' ),
    &generateVariantTypes => CLASS_PATH( FA_LIB_NAME, 'Variant' ),
    &validateAlleleNames  => CLASS_PATH( QC_LIB_NAME, 'Allele', 'Validator' ),
    &runPypop             => CLASS_PATH( PY_LIB_NAME, 'Runner' ),
  };
}
###
### Pipeline Types
###
sub HLAQC_PIPELINE { return 'hlaqc'; }
sub HLAVA_PIPELINE { return 'hlava'; }
sub HLAVD_PIPELINE { return 'hlavd'; }
sub HLAVF_PIPELINE { return 'hlavf'; }
sub HLAVT_PIPELINE { return 'hlavt'; }
###
### Tool Execution Order
###
sub QCPipelines {
  return {
    &HLAQC_PIPELINE => [ validateAlleleNames, runPypop, ],
    &HLAVA_PIPELINE => [ analyzeVariantTypes, ],
    &HLAVD_PIPELINE => [
      validateAlleleNames, allelicAmbiguityReduction,
      genotypeAmbiguityReduction,
    ],
    &HLAVF_PIPELINE => [ validateAlleleNames, ],
    &HLAVT_PIPELINE => [ validateAlleleNames, generateVariantTypes, ],
  };
}
###
### Pipeline Controller Context Properties
###
sub ANTT_TOOL_PROP            { return 'anttTool'; }
sub ANTT_TRANSLATION_DIR_PROP { return 'anttTranslationDirectory'; }
sub FILE_TYPE_FILE_PROP       { return 'fileTypeFile'; }
sub GENERATED_FILES_PROP      { return 'generatedFiles'; }
sub HLA_ALLELE_FILE_PROP      { return 'hlaAlleleFile'; }
sub HLA_ALLELE_FILE_TYPE_PROP { return 'hlaAlleleFileType'; }
sub HLA_LOCI_PROP             { return 'hlaLoci'; }
sub MONO_TOOL_PROP            { return 'monoTool'; }
sub OPTIONAL_COLUMNS_PROP     { return 'optionalColumns'; }
sub OUTPUT_IMGT_VERSION_PROP  { return 'outputImgtVersion'; }
sub PHENOTYPE_COLUMN_PROP     { return 'phenotypeColumn'; }
sub PIPELINE_TYPE_PROP        { return 'pipelineType'; }
sub STATISTICAL_TESTS_PROP    { return 'statisticalTests'; }
sub STATUS_FILE_PROP          { return 'statusFile'; }
sub TASK_ID_PROP              { return 'taskId'; }
sub TAXON_ID_PROP             { return 'taxonId'; }
sub TOOL_FILES_PROP           { return 'toolFiles'; }
sub WRITE_MSGS_PROP           { return 'writeMsgs'; }
###
### Version Properties
###
sub IMGT_RELEASE_DATE_PROP    { return 'imgtReleaseDate'; }
sub IMGT_RELEASE_VERSION_PROP { return 'imgtReleaseVersion'; }
sub TOOL_NAME_PROP            { return 'toolName'; }
sub TOOL_VERSION_PROP         { return 'toolVersion'; }
###
### Other properties
###
sub ANTT_FILE_PROP     { return 'anttFile'; }
sub ANTT_INI_FILE_PROP { return 'anttIniFile'; }
###
### Quality Control Failure Codes
###
sub FAILED_IN_ALLELE_AMBIGUITY_REDUCTION {
  return 'FAILED_IN_ALLELE_AMBIGUITY_REDUCTION';
}

sub FAILED_IN_GENOTYPE_AMBIGUITY_REDUCTION {
  return 'FAILED_IN_GENOTYPE_AMBIGUITY_REDUCTION';
}
sub FAILED_IN_ANALYSIS     { return 'FAILED_IN_ANALYSIS'; }
sub FAILED_IN_GENERATION   { return 'FAILED_IN_GENERATION'; }
sub FAILED_IN_PYPOP        { return 'FAILED_IN_PYPOP'; }
sub FAILED_IN_PYPOP_OUTPUT { return 'FAILED_IN_PYPOP_OUTPUT'; }
sub FAILED_IN_VALIDATION   { return 'FAILED_IN_VALIDATION'; }
sub UNKNOWN_FILE_TYPE      { return 'UNKNOWN_FILE_TYPE'; }

sub failureCodeMap {
  return {
    &allelicAmbiguityReduction  => FAILED_IN_ALLELE_AMBIGUITY_REDUCTION,
    &analyzeVariantTypes        => FAILED_IN_ANALYSIS,
    &genotypeAmbiguityReduction => FAILED_IN_GENOTYPE_AMBIGUITY_REDUCTION,
    &generateVariantTypes       => FAILED_IN_GENERATION,
    &runPypop                   => FAILED_IN_PYPOP,
    &validateAlleleNames        => FAILED_IN_VALIDATION,
  };
}

sub outputFiles {
  return {
    &allelicAmbiguityReduction  => 'allelicAmbiguityReducedFile',
    &genotypeAmbiguityReduction => 'genotypeAmbiguityReducedFile',
    &runPypop                   => 'pypopFile',
    &validateAlleleNames        => 'validatedFile',
    &generateVariantTypes       => GENERATED_FILES_PROP,
  };
}
###
### Error Category
###
sub ERR_CAT { return util::ErrMsgs::TOOLS_CAT; }

sub ERROR_CATEGORIES {
  my $err_cats = [
    'antt',   'db',    'featureAnalysis', 'file',
    'lookup', 'pypop', 'qualityControl',  'xml',
  ];
  return $err_cats;
}

################################################################################
#
#                           Private Methods
#
################################################################################

sub _translateFile {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;
  my ( $pipelineStep, $outputFile, $tmpFile ) = @_;

  my $ambiguous_allele_separator =
    db::MhcTypes::STANDARD_AMBIGUOUS_ALLELE_SEPARATOR;

  my $taskId     = $this->getProperty(TASK_ID_PROP);
  my $taskInfix  = TASK_INFIX;
  my $taxonId    = $this->getProperty(TAXON_ID_PROP);
  my $fileType   = $this->getProperty(HLA_ALLELE_FILE_TYPE_PROP);
  my $readerType = $this->HlaReader;
  my @params     = ();
  if ( $pipelineStep eq runPypop ) { $fileType = $this->PypopType; }
  elsif ( $pipelineStep eq generateVariantTypes ) {
    $this->{treat_xls_as_txt} = util::Constants::TRUE;
    $readerType = $this->FeatureReader;
    my $seq_type_id =
      db::MhcTypes::getId( db::MhcTypes::SEQ_TYPE_TABLE, db::MhcTypes::AA_SEQ );
    push( @params, $seq_type_id );
  }

  $outputFile =~ s/$taskInfix/$taskId/;
  $this->{error_mgr}->printHeader( "pipelineStep = $pipelineStep\n"
      . "readerType   = $readerType\n"
      . "fileType     = $fileType\n"
      . "outputFile   = $outputFile" );
  next if ( !-e $outputFile );
  $this->{error_mgr}->printMsg("Generating Version 2.* Format");
  my $reader =
    $this->getMhcFileReader( $readerType, $fileType, $outputFile, $taxonId,
    @params );
  $reader->openReader;
  my $antt =
    new antt::Runner( $reader, $ambiguous_allele_separator, $this,
    $this->{error_mgr} );
  $antt->setAnttFile( $tmpFile . '.txt' );
  $antt->setAnttIniFile( $tmpFile . '.ini' );
  $antt->setAnttTool( $this->getProperty(ANTT_TOOL_PROP) );
  $antt->setMonoTool( $this->getProperty(MONO_TOOL_PROP) );
  $antt->setAnttTranslationDirectory(
    $this->getProperty(ANTT_TRANSLATION_DIR_PROP) );
  $antt->run( $antt->REVERSE_ACTION );
  $antt->updateReader;
  $reader->writeFile($outputFile);
  if ( $pipelineStep eq generateVariantTypes ) {
    $this->{treat_xls_as_txt} = util::Constants::FALSE;
  }
}

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$) {
  my ( $that, $tool, $error_mgr ) = @_;
  my util::Tools::mhcSeqVar::qualityControl $this =
    $that->SUPER::new( [], $error_mgr, ERROR_CATEGORIES );

  $this->{failure_codes} = failureCodeMap;
  $this->{obj_types}     = objectTypes;
  $this->{pipelines}     = QCPipelines;

  $this->{statuses}->{&FAILED_IN_ALLELE_AMBIGUITY_REDUCTION} =
    util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_GENOTYPE_AMBIGUITY_REDUCTION} =
    util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_ANALYSIS}     = util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_GENERATION}   = util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_PYPOP_OUTPUT} = util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_PYPOP}        = util::Constants::FALSE;
  $this->{statuses}->{&FAILED_IN_VALIDATION}   = util::Constants::FALSE;
  $this->{statuses}->{&UNKNOWN_FILE_TYPE}      = util::Constants::FALSE;

  $this->cmds->unsetPrintMsg;
  $this->setDieOnError(util::Constants::FALSE);

  $this->{error_mgr}
    ->exitProgram( ERR_CAT, 12, [$tool], !isQualityControlTool($tool) );
  $this->{tool} = $tool;
  ###
  ### These properties are required by all tools in
  ### the quality control pipeline
  ###
  $this->setContextProperty(IMGT_RELEASE_DATE_PROP);
  $this->setContextProperty(IMGT_RELEASE_VERSION_PROP);
  $this->setContextProperty(OUTPUT_IMGT_VERSION_PROP);
  $this->setContextProperty(TASK_ID_PROP);
  $this->setContextProperty(TAXON_ID_PROP);
  $this->setContextProperty(TOOL_NAME_PROP);
  $this->setContextProperty(TOOL_VERSION_PROP);
  $this->setContextProperty(WRITE_MSGS_PROP);

  return $this;
}

sub getLogInfix {
  my util::Tools::mhcSeqVar $this = shift;
  my ($propertiesFile) = @_;
  ###
  ### Get the properties
  ###
  my $properties = new util::Properties;
  $propertiesFile = getPath($propertiesFile);
  $properties->loadFile($propertiesFile);
  ###
  ### Create logInfix Property
  ###
  my $logInfix = basename( $properties->getProperty(HLA_ALLELE_FILE_PROP) );
  $logInfix =~ s/\.\w+$//;
  return $logInfix;
}

sub getPropertiesFilename {
  my util::Tools::mhcSeqVar $this = shift;
  my ($propertiesFile) = @_;

  return $this->getLogInfix($propertiesFile);
}

sub setQualityControlPipelineContext {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;
  my ($propertiesFile) = @_;
  ###
  ### Set the general pipeline context
  ###
  $propertiesFile = $this->setPipelineContext($propertiesFile);
  ###
  ### Set the quality control file properties
  ###
  my $properties = new util::Properties;
  $propertiesFile = getPath($propertiesFile);
  $properties->loadFile($propertiesFile);
  my $toolFiles = eval $properties->getProperty(TOOL_FILES_PROP);
  my $status    = $@;
  $this->exitProgram(
    ERR_CAT, 9,
    [ $status, $properties->getProperty(TOOL_FILES_PROP) ],
    defined($status) && $status
  );

  foreach my $tool ( keys %{$toolFiles} ) {
    foreach my $property ( keys %{ $toolFiles->{$tool} } ) {
      my $file_data = $toolFiles->{$tool}->{$property};
      ###
      ### Determine filename components
      ###
      my @filename_comps = ( $file_data->{infix}, $file_data->{suffix} );
      ###
      ### Determine the prefix
      ###
      if ( exists( $file_data->{prefix} ) ) {
        ###
        ### If there is a prefix provided and it is not empty,
        ### use it, otherwise do not use a prefix
        ###
        if ( !util::Constants::EMPTY_LINE( $file_data->{prefix} ) ) {
          unshift( @filename_comps, $file_data->{prefix} );
        }
      }
      else {
        unshift( @filename_comps,
          $properties->getProperty( $this->LOG_INFIX_PROP ) );
      }
      $properties->setProperty(
        $property,
        join( util::Constants::SLASH,
          $properties->getProperty( $this->EXECUTION_DIRECTORY_PROP ),
          join( util::Constants::DOT, @filename_comps )
        )
      );
    }
  }
  ###
  ### Now determine the file type of the
  ### allele file if it is not already set
  ###
  my $fileType = $properties->getProperty(HLA_ALLELE_FILE_TYPE_PROP);
  $properties->setProperty(
    HLA_ALLELE_FILE_TYPE_PROP,
    $this->determineMhcFileType(
      $properties->getProperty(HLA_ALLELE_FILE_PROP)
    )
  ) if ( util::Constants::EMPTY_LINE($fileType) );
  ###
  ### Set the pipeline tool order
  ###
  my $pipelines    = $this->{pipelines};
  my $pipelineType = $properties->getProperty(PIPELINE_TYPE_PROP);
  $this->exitProgram( ERR_CAT, 13, [$pipelineType],
    !defined( $pipelines->{$pipelineType} ) );
  $this->setToolOrder( $pipelines->{$pipelineType} );
  ###
  ### Store the File Properties for the Pipeline
  ###
  $properties->storeFile($propertiesFile);
  ###
  ### Finally, return the standard quality control
  ### pipeline context (these properties are used
  ### by the quality control controller)
  ###
  my @contextProperties = (
    HLA_ALLELE_FILE_PROP, HLA_ALLELE_FILE_TYPE_PROP,
    STATUS_FILE_PROP,     FILE_TYPE_FILE_PROP,
    ANTT_TOOL_PROP,       ANTT_TRANSLATION_DIR_PROP,
    MONO_TOOL_PROP
  );
  my $outputFiles = outputFiles;
  push( @contextProperties, values %{$outputFiles} );

  return $this->setContext( $propertiesFile, @contextProperties );
}

sub setFileTypeFile {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;

  return if ( $this->{tool} ne pipelineController );

  my $hlaAlleleFileType = $this->getProperty(HLA_ALLELE_FILE_TYPE_PROP);
  my $fileTypeFile      = $this->getProperty(FILE_TYPE_FILE_PROP);
  my $fh                = new FileHandle;
  $this->exitProgram(
    ERR_CAT, 105,
    [ $fileTypeFile, ],
    !$fh->open( $fileTypeFile, ">" )
  );
  $fh->print("$hlaAlleleFileType\n");
  $fh->close;
}

sub setQualityControlStatusFile {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;

  return if ( $this->{tool} ne pipelineController );

  my $hlaAlleleFileType = $this->getProperty(HLA_ALLELE_FILE_TYPE_PROP);
  my $hlaAlleleFile     = $this->getProperty(HLA_ALLELE_FILE_PROP);
  my $statusFile        = $this->getProperty(STATUS_FILE_PROP);
  my $status            = undef;
  ###
  ### Is the file type defined
  ###
  if ( util::Constants::EMPTY_LINE($hlaAlleleFileType) ) {
    ###
    ### Check for file type
    ###
    $this->{error_mgr}->printErrorMsg( ERR_CAT, 106, [ $hlaAlleleFile, ],
      util::Constants::TRUE );
    $status = UNKNOWN_FILE_TYPE;
  }
  ###
  ### Was there failure in the pipeline
  ###
  if ( !defined($status) ) {
    foreach my $tool ( $this->getToolOrder ) {
      if ( $this->FAILED eq $this->getRunStatus($tool) ) {
        $status = $this->{failure_codes}->{$tool};
        last;
      }
    }
  }
  ###
  ### Finally, if there is no status then the pipeline succeeded.
  ###
  if ( !defined($status) ) {
    $status = $this->SUCCEEDED;
  }
  $this->setStatus($status);
  $this->saveStatus($statusFile);
}

sub getMhcObject {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;
  my ( $objectType, $mhcFileReader, $taxonId, @params ) = @_;

  my $obj_types = $this->{obj_types};
  $this->exitProgram( ERR_CAT, 103, [$objectType],
    !defined( $obj_types->{$objectType} ) );
  ###
  ### Create the alleles lookup class
  ###
  $this->setAllelesLookup($taxonId);
  ###
  ### Create the hla object
  ###
  my $params_str = util::Constants::EMPTY_STR;
  if ( @params >= 1 ) {
    foreach my $index ( 0 .. $#params ) {
      if ( $index > 0 ) { $params_str .= util::Constants::COMMA_SEPARATOR; }
      $params_str .= '$params[' . $index . ']';
    }
    $params_str .= util::Constants::COMMA_SEPARATOR;
  }
  my $class      = $obj_types->{$objectType};
  my $mhc_object = undef;
  my @eval_array = (
    'use ' . $class . ';',
    '$mhc_object =',
    'new ' . $class,
    '  ($mhcFileReader,',
    '   $taxonId,', 
    $params_str, 
    '   $this,', 
    '   $this->{error_mgr});'
  );
  my $eval_str = join( util::Constants::NEWLINE, @eval_array );
  $this->{error_mgr}->printDebug("getMhcObject:  eval_str=\n$eval_str");
  eval $eval_str;
  my $status = $@;
  $this->exitProgram(
    ERR_CAT, 9,
    [ $status, $eval_str ],
    defined($status) && $status
  );

  return $mhc_object;
}

sub generateVersion2Format {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;

  my $outputImgtVersion = $this->getProperty(OUTPUT_IMGT_VERSION_PROP);
  $this->{error_mgr}->printHeader(
    "generateVersion2Format\n" . " outputImgtVersion = $outputImgtVersion" );
  ###
  ### Check to see that the ouput IMGT/HLA version is 2
  ###
  return
    if ( !db::MhcTypes::DEFINED_IMGT_HLA_VERSION($outputImgtVersion)
    || $outputImgtVersion != db::MhcTypes::IMGT_HLA_V2 );

  my $tmpFile = $this->cmds->TMP_FILE(OUTPUT_IMGT_VERSION_PROP);
  $this->{error_mgr}->printMsg("tmpFile              = $tmpFile");
  $this->{error_mgr}->printMsg(
    "anttTool             = " . $this->getProperty(ANTT_TOOL_PROP) );
  $this->{error_mgr}->printMsg(
    "monoTool             = " . $this->getProperty(MONO_TOOL_PROP) );
  $this->{error_mgr}->printMsg(
    "translationDirectory = " . $this->getProperty(ANTT_TRANSLATION_DIR_PROP) );

  $this->openSession;
  my $outputFiles = outputFiles;
  foreach my $pipelineStep ( keys %{$outputFiles} ) {
    if ( $pipelineStep eq generateVariantTypes ) {
      my $generatedFile = $this->getProperty( $outputFiles->{$pipelineStep} );
      my $fh            = new FileHandle;
      next if ( !$fh->open( $generatedFile, "<" ) );
      while ( !$fh->eof ) {
        my $file = $fh->getline;
        chomp($file);
        $this->_translateFile( $pipelineStep, $file, $tmpFile );
      }
      $fh->close;
    }
    else {
      my $outputFile = $this->getProperty( $outputFiles->{$pipelineStep} );
      $this->_translateFile( $pipelineStep, $outputFile, $tmpFile );
    }
  }
  $this->closeSession;
}

sub versionInfo {
  my util::Tools::mhcSeqVar::qualityControl $this = shift;
  my $version_info =
      "Immport tool "
    . $this->getProperty(TOOL_NAME_PROP) . " ("
    . "version "
    . $this->getProperty(TOOL_VERSION_PROP) . ")"
    . " and IMGT/HLA "
    . $this->getProperty(IMGT_RELEASE_VERSION_PROP) . " ("
    . $this->getProperty(IMGT_RELEASE_DATE_PROP) . ")";
  return $version_info;
}

################################################################################

1;

__END__

=head1 NAME

qualityControl.pm

=head1 DESCRIPTION

This class defines the basics capabilities for running HLA validator.
It is a subclass of L<util::Tools::mhcSeqVar>.

=head1 STATIC CONSTANTS

The following status constants are exported from this class:

The quality control tools defined by this class include:

   util::Tools::mhcSeqVar::qualityControl::allelicAmbiguityReduction  -- allelicAmbiguityReduction.pl
   util::Tools::mhcSeqVar::qualityControl::analyzeVariantTypes        -- analyzeVariantTypes
   util::Tools::mhcSeqVar::qualityControl::generateVariantTypes       -- generateVariantTypes.pl
   util::Tools::mhcSeqVar::qualityControl::genotypeAmbiguityReduction -- genotypeAmbiguityReduction
   util::Tools::mhcSeqVar::qualityControl::pipelineController         -- pipelineController
   util::Tools::mhcSeqVar::qualityControl::runPypop                   -- runPypop.pl
   util::Tools::mhcSeqVar::qualityControl::validateAlleleNames        -- validateAlleleNames.pl

The pipeline types currently defined by this class include:

   util::Tools::mhcSeqVar::qualityControl::HLAQC_PIPELINE -- hlaqc
   util::Tools::mhcSeqVar::qualityControl::HLAVA_PIPELINE -- hlava
   util::Tools::mhcSeqVar::qualityControl::HLAVD_PIPELINE -- hlavd
   util::Tools::mhcSeqVar::qualityControl::HLAVF_PIPELINE -- hlavf
   util::Tools::mhcSeqVar::qualityControl::HLAVT_PIPELINE -- hlavt

The Tool execution order for the HLAVF_PIPELINE pipeline

   - util::Tools::mhcSeqVar::qualityControl::validateAlleleNames

The Tool execution order for the HLAQC_PIPELINE pipeline

   - util::Tools::mhcSeqVar::qualityControl::validateAlleleNames
   - util::Tools::mhcSeqVar::qualityControl::runPypop

The Tool execution order for the HLAVD_PIPELINE pipeline

   - util::Tools::mhcSeqVar::qualityControl::validateAlleleNames
   - util::Tools::mhcSeqVar::qualityControl::allelicAmbiguityReduction
   - util::Tools::mhcSeqVar::qualityControl::genotypeAmbiguityReduction

The Tool execution order for the HLAVT_PIPELINE pipeline

   - util::Tools::mhcSeqVar::qualityControl::validateAlleleNames
   - util::Tools::mhcSeqVar::qualityControl::generateVariantTypes

The Tool execution order for the HLAVA_PIPELINE pipeline

   - util::Tools::mhcSeqVar::qualityControl::analyzeVariantTypes

The following context properties are exported for a pipeline controller:

   Pipeline Controller Context Properties

   util::Tools::mhcSeqVar::ANTT_TOOL_PROP            -- anttTool
   util::Tools::mhcSeqVar::ANTT_TRANSLATION_DIR_PROP -- anttTranslationDirectory
   util::Tools::mhcSeqVar::FILE_TYPE_FILE_PROP       -- fileTypeFile
   util::Tools::mhcSeqVar::GENERATED_FILES_PROP      -- generatedFiles
   util::Tools::mhcSeqVar::HLA_ALLELE_FILE_PROP      -- hlaAlleleFile
   util::Tools::mhcSeqVar::HLA_ALLELE_FILE_TYPE_PROP -- hlaAlleleFileType
   util::Tools::mhcSeqVar::HLA_LOCI_PROP             -- hlaLoci
   util::Tools::mhcSeqVar::MONO_TOOL_PROP            -- monoTool
   util::Tools::mhcSeqVar::OPTIONAL_COLUMNS_PROP     -- optionalColumns
   util::Tools::mhcSeqVar::OUTPUT_IMGT_VERSION_PROP  -- outputImgtVersion
   util::Tools::mhcSeqVar::PHENOTYPE_COLUMN_PROP     -- phenotypeColumn
   util::Tools::mhcSeqVar::PIPELINE_TYPE_PROP        -- pipelineType
   util::Tools::mhcSeqVar::STATISTICAL_TESTS_PROP    -- statisticalTests
   util::Tools::mhcSeqVar::STATUS_FILE_PROP          -- statusFile
   util::Tools::mhcSeqVar::TASK_ID_PROP              -- taskId
   util::Tools::mhcSeqVar::TAXON_ID_PROP             -- taxonId
   util::Tools::mhcSeqVar::TOOL_FILES_PROP           -- toolFiles
   util::Tools::mhcSeqVar::WRITE_MSGS_PROP           -- writeMsgs

   Version Properties

   util::Tools::mhcSeqVar::IMGT_RELEASE_DATE_PROP    -- imgtReleaseDate
   util::Tools::mhcSeqVar::IMGT_RELEASE_VERSION_PROP -- imgtReleaseVersion
   util::Tools::mhcSeqVar::TOOL_NAME_PROP            -- toolName
   util::Tools::mhcSeqVar::TOOL_VERSION_PROP         -- toolVersion

   Other properties

   util::Tools::mhcSeqVar::ANTT_FILE_PROP     -- anttFile
   util::Tools::mhcSeqVar::ANTT_INI_FILE_PROP -- anttIniFile

The special infix templates are defined by this class

   util::Tools::mhcSeqVar::HLA_INFIX  --__HLA__
   util::Tools::mhcSeqVar::TASK_INFIX --__TASK__

=head1 METHODS

The following methods are exported by this class.

=head2 B<new anthonyNolan::new(error_mgr)>

This method is the constructor for the class.  The error categories
include the following: antt, db, featureAnalysis, file, lookup, pypop,
qualityControl, xml.

=head2 B<$log_infix = getLogInfix(propertiesFile)>

This re-implementable method is implemented to return the following
infix.  This method acquires the B<hlaAlleleFile> property from the
B<propertiesFile> and determines the basename of the file represented
by this property.  Finally, it truncates the '.*' suffix from the
basename.  This method is used in the B<setPipelineContext> method.

=head2 B<$properties_filename = getPropertiesFilename(propertiesFile)>

This re-implementable method is implemented to return the B<log_infix>
(see B<getLogInfix>) as the properties filename.  This method is used
in the B<setPipelineContext> method.

=head2 B<$properties_file = setQualityControlPipelineContext(propertiesFile)>

This method sets up the standard pipeline configuration for executing
quality control tools.  This method first sets the standard pipeline
context B<setPipelineContext>.  This method sets up all the file
properties for the quality control pipeline.  and store them into the
B<propertiesFile>.  Finally, it sets the context for a quality
control pipeline.

=head2 B<setFileTypeFile>

If the tool is a pipeline controller, then the method sets the HLA
file type of the HLA allele file int the file type file.

=head2 B<setQualityControlStatusFile>

If the tool is a pipeline controller, then the method sets pipeline
status in the status file.

=head2 B<$mhc_obj = getMhcObject(objectType, mhcFileReader, taxonId[, @params])>

This method sets the alleles lookup object (set by
B<setAllelesLookup>, an instance of L<lookup::Alleles>, and accessed
by B<getAllelesLookup>), instantiates the MHC object type for the
given object type and the mhc file reader, and finally returns the MHC
object.

=head2 B<generateVersion2Format>

This method determines the set of generated files for the given
pipeline and converts the output from IMGT/HLA version 3 format to
IMGT/HLA version 2 format if the run has requested this conversion.
The property outputImgtVersion determines the output version (2 or 3).
If the output version is 2, then the file conversion is processed.
The file conversion is effected by the ANTT tool.

=head2 B<$version_info = versionInfo>

This method generates the version information string by using the
following properties:

   util::Tools::mhcSeqVar::TOOL_NAME_PROP
   util::Tools::mhcSeqVar::TOOL_VERSION_PROP
   util::Tools::mhcSeqVar::IMGT_RELEASE_VERSION_PROP
   util::Tools::mhcSeqVar::IMGT_RELEASE_DATE_PROP

=cut
