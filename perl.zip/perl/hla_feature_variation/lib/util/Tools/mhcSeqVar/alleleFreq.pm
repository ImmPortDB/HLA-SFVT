package util::Tools::mhcSeqVar::alleleFreq;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'util::Tools::mhcSeqVar';

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Error Category
###
sub ERROR_CATEGORIES {
  my $err_cats = [ 'db', 'file', 'lookup' ];
  return $err_cats;
}

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$) {
  my ( $that, $error_mgr ) = @_;
  my util::Tools::mhcSeqVar::alleleFreq $this =
    $that->SUPER::new( [], $error_mgr, ERROR_CATEGORIES );

  $this->setContextProperty( $this->WORKSPACE_ROOT_PROP );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

alleleFreq.pm

=head1 DESCRIPTION

This class defines the basics capabilities for loading allele
frequency tables. It is a subclass of L<util::Tools::mhcSeqVar>.

=head1 METHODS

The following methods are exported by this class.

=head2 B<new util::Tools::mhcSeqVar::alleleFreq(error_mgr)>

This method is the constructor for the class.  The error categories
include the following: db, file, and lookup.

=cut
