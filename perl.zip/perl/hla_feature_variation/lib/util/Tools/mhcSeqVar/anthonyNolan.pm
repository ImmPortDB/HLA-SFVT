package util::Tools::mhcSeqVar::anthonyNolan;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use base 'util::Tools::mhcSeqVar';

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Tools External
###
sub generateAntAlignData           { return 'generateAntAlignData'; }
sub generateAntAlleleAlignmentData { return 'generateAntAlleleAlignmentData'; }
sub generateAntHlaData             { return 'generateAntHlaData'; }
sub generateAntMsfData             { return 'generateAntMsfData'; }
sub initializeDatabase             { return 'initializeDatabase' }
###
### Tool Execution Order
###
sub toolOrder {
  return [
    initializeDatabase,   generateAntHlaData,
    generateAntAlignData, generateAntMsfData,
    generateAntAlleleAlignmentData
  ];
}
###
### Error Category
###
sub ERROR_CATEGORIES {
  my $err_cats = [ 'anthonyNolan', 'db', 'file', 'lookup', 'perl' ];
  return $err_cats;
}

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$) {
  my ( $that, $error_mgr ) = @_;
  my util::Tools::mhcSeqVar::anthonyNolan $this =
    $that->SUPER::new( toolOrder, $error_mgr, ERROR_CATEGORIES );

  $this->setContextProperty( $this->WORKSPACE_ROOT_PROP );

  return $this;
}

################################################################################

1;

__END__

=head1 NAME

anthonyNolan.pm

=head1 DESCRIPTION

This class defines the basics capabilities for running Anthony Nolan data
loader tools.  It is a subclass of L<util::Tools::mhcSeqVar>.

=head1 CONSTANTS

The following constants are exported by this class

The following tools are known to this class

   util::Tools::mhcSeqVar::anthonyNolan::generateAntAlignData           -- generateAntAlignData
   util::Tools::mhcSeqVar::anthonyNolan::generateAntAlleleAlignmentData -- generateAntAlleleAlignmentData
   util::Tools::mhcSeqVar::anthonyNolan::generateAntHlaData             -- generateAntHlaData
   util::Tools::mhcSeqVar::anthonyNolan::generateAntMsfData             -- generateAntMsfData
   util::Tools::mhcSeqVar::anthonyNolan::initializeDatabase             -- initializeDatabase

The tool order is defined as follows:

   util::Tools::mhcSeqVar::anthonyNolan::toolOrder
   -- referenced Perl array
      - util::Tools::mhcSeqVar::anthonyNolan::initializeDatabase
      - util::Tools::mhcSeqVar::anthonyNolan::generateAntHlaData
      - util::Tools::mhcSeqVar::anthonyNolan::generateAntAlignData
      - util::Tools::mhcSeqVar::anthonyNolan::generateAntMsfData
      - util::Tools::mhcSeqVar::anthonyNolan::generateAntAlleleAlignmentData

=head1 METHODS

The following methods are exported by this class.

=head2 B<new anthonyNolan::new(error_mgr)>

This method is the constructor for the class.  The error categories
include the following: anthonyNolan, db, file, lookup, perl.

=cut
