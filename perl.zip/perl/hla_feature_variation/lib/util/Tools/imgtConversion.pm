package util::Tools::imgtConversion;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use FileHandle;
use Pod::Usage;

use util::Constants;
use util::ErrMsgs;
use util::PathSpecifics;

use base 'util::Tools';

use fields qw(
  coding_region_map
  hla_protein_map
  change_map
  deleted_names_list
  deleted_names_map
  loci
  allele_group_map
);

################################################################################
#
#			            Static Class Constants
#
################################################################################
###
### Special Properties
###
sub NOMENCLATURE_FILE_PROP { return 'nomenclatureFile'; }
sub DELETED_NAME_FILE_PROP { return 'deletedNamesFile'; }
###
### Error Category
###
sub ERROR_CATEGORIES { my $err_cats = [ 'hla', 'file', ]; return $err_cats; }
sub ERR_CAT { return util::ErrMsgs::TOOLS_CAT; }

################################################################################
#
#                           Public Methods
#
################################################################################

sub new($$$$) {
  my ( $that, $error_mgr ) = @_;
  my util::Tools::imgtConversion $this = 
    $that->SUPER::new( $error_mgr, ERROR_CATEGORIES );

  $this->{coding_region_map}  = {};
  $this->{hla_protein_map}    = {};
  $this->{change_map}         = {};
  $this->{deleted_names_list} = [];
  $this->{deleted_names_map}  = {};
  $this->{loci}               = [];
  $this->{allele_group_map}   = {};

  $this->setContextProperty(NOMENCLATURE_FILE_PROP);
  $this->setContextProperty( $this->WORKSPACE_ROOT_PROP );

  return $this;
}

sub generateMaps {
  my util::Tools::imgtConversion $this = shift;
  my ($keep_none) = @_;
  ###
  ### Determine keep_none
  ###
  $keep_none =
    ( !util::Constants::EMPTY_LINE($keep_none) && $keep_none )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### Initialize the maps
  ###
  $this->{coding_region_map} = {};
  $this->{hla_protein_map}   = {};
  $this->{change_map}        = {};
  $this->{allele_group_map}  = {};

  my $coding_region_map = $this->{coding_region_map};
  my $hla_protein_map   = $this->{hla_protein_map};
  my $change_map        = $this->{change_map};
  my $loci              = {};
  my $allele_group_map  = $this->{allele_group_map};
  ###
  ### Get the Nomenclature File
  ###
  my $nomenclature_file =
    getPath( $this->{properties}->{&NOMENCLATURE_FILE_PROP} );
  ###
  ### Open the file
  ###
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 2,
    [ 'file', 'open', 'text', $nomenclature_file ],
    !$fh->open( $nomenclature_file, "<" )
  );
  ###
  ### Process the file
  ###
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);

    next if ( $line =~ /^(Current|=)/
      || ( $line =~ /None/ && !$keep_none ) );
    my ( $current_name, $new_name ) = split( /\t| +/, $line );

    my $new_locus           = util::Constants::EMPTY_STR;
    my $new_digits          = util::Constants::EMPTY_STR;
    my $new_suffix          = undef;
    my $new_digits_no_colon = util::Constants::EMPTY_STR;
    if ( $new_name ne 'None' ) {
      $new_name =~ /^(\w+)\*([0-9:]+)[A-Z]?$/;
      $new_locus  = $1;
      $new_digits = $2;
      if ( $new_name =~ /([A-Z])$/ ) { $new_suffix = $1; }
      $new_digits_no_colon = $new_digits;
      $new_digits_no_colon =~ s/://g;
    }

    $current_name =~ /^(\w+)\*([0-9]+)[A-Z]?$/;
    my $current_locus  = $1;
    my $current_digits = $2;

    $loci->{$current_locus} = util::Constants::EMPTY_STR;

    my $current_locus_compare = $current_locus;
    if ( $current_locus eq 'Cw' ) { $current_locus_compare = 'C'; }

    my $current_suffix = undef;
    if ( $current_name =~ /([A-Z])$/ ) {
      $current_suffix = $1;
    }
    my $current_len = length($current_digits);

    my $current_allele_group         = undef;
    my $current_allele_group_wsuffix = undef;

    my $current_coding_region         = undef;
    my $current_coding_region_wsuffix = undef;

    my $current_hla_protein         = undef;
    my $current_hla_protein_wsuffix = undef;

    if ( $current_len % 2 == 0 ) {
      $current_digits =~ /^(\d\d)/;
      $current_allele_group = $1;

      if ( $current_digits =~ /^(\d\d\d\d)/ ) {
        my $hla_protein = $1;
        $current_hla_protein = $current_locus . '*' . $hla_protein;
      }
      if ( $current_name =~ /^\w+\*\d\d\d\d[A-Z]$/ ) {
        $current_hla_protein_wsuffix = $current_name;
      }

      if ( $current_digits =~ /^(\d\d\d\d\d\d)/ ) {
        my $coding_region = $1;
        $current_coding_region = $current_locus . '*' . $coding_region;
      }
      if ( $current_name =~ /^\w+\*\d\d\d\d\d\d[A-Z]$/ ) {
        $current_coding_region_wsuffix = $current_name;
      }
    }
    else {    ### MICA or MICB ###
      $current_digits =~ /^(\d\d\d)/;
      $current_allele_group = $1;
      if ( $current_name =~ /^\w+\*\d\d\d[A-Z]$/ ) {
        $current_allele_group_wsuffix = $current_name;
      }

      if ( $current_digits =~ /^(\d\d\d\d\d)/ ) {
        my $hla_protein = $1;
        $current_hla_protein = $current_locus . '*' . $hla_protein;
      }
      if ( $current_name =~ /^\w+\*\d\d\d\d\d[A-Z]$/ ) {
        $current_hla_protein_wsuffix = $current_name;
      }

      if ( $current_digits =~ /^(\d\d\d\d\d\d\d)/ ) {
        my $coding_region = $1;
        $current_coding_region = $current_locus . '*' . $coding_region;
      }
      if ( $current_name =~ /^\w+\*\d\d\d\d\d\d\d[A-Z]$/ ) {
        $current_coding_region_wsuffix = $current_name;
      }
    }

    my $diff_suffix = (
      (
             util::Constants::EMPTY_LINE($new_suffix)
          && util::Constants::EMPTY_LINE($current_suffix)
      )
        || ( !util::Constants::EMPTY_LINE($new_suffix)
        && !util::Constants::EMPTY_LINE($current_suffix)
        && $new_suffix eq $current_suffix )
    ) ? util::Constants::FALSE : util::Constants::TRUE;

    my $conversion =
      (    $new_locus ne $current_locus_compare
        || $diff_suffix
        || $new_digits_no_colon ne $current_digits )
      ? util::Constants::TRUE
      : util::Constants::FALSE;
    ###
    ### Generate the change map
    ###
    $change_map->{$current_name} = {
      current           => $current_name,
      digits            => [ split( /:/, $new_digits ) ],
      locus             => $new_locus,
      new_name          => $new_name,
      order             => [ 0, 0, 0, 0 ],
      suffix            => $new_suffix,
      zero_allele_group => undef,
      diff_allele_group => undef,
      diff_suffix       => $diff_suffix,
      conversion        => $conversion,
    };
    ###
    ### determine the zero_allele_group in the change map
    ###
    my $allele_group_comp = util::Constants::EMPTY_STR;
    if ( $new_name ne 'None' ) {
      $allele_group_comp = $change_map->{$current_name}->{digits}->[0];
    }
    if ( $allele_group_comp =~ /^[1-9]/ ) {
      $change_map->{$current_name}->{zero_allele_group} = 0;
    }
    elsif ( $allele_group_comp =~ /^0[1-9]/ ) {
      $change_map->{$current_name}->{zero_allele_group} = 1;
    }
    elsif ( $allele_group_comp =~ /^00[1-9]/ ) {
      $change_map->{$current_name}->{zero_allele_group} = 2;
    }
    elsif ( $allele_group_comp =~ /^000/ ) {
      $change_map->{$current_name}->{zero_allele_group} = 3;
    }
    ###
    ### determine the diff allele_group in the change map
    ###
    if ( $new_locus eq 'A' && $current_allele_group eq '92' ) {
      $change_map->{$current_name}->{diff_allele_group} =
        ( $allele_group_comp eq '02' ) ? 2 : 1;
    }
    elsif ( $new_locus eq 'B' && $current_allele_group eq '95' ) {
      $change_map->{$current_name}->{diff_allele_group} =
        ( $allele_group_comp eq '15' ) ? 2 : 1;
    }
    else {
      $change_map->{$current_name}->{diff_allele_group} =
        ( $allele_group_comp eq $current_allele_group ) ? 0 : 1;
    }
    ###
    ### Generate the order in the change map
    ###
    foreach my $index ( 0 .. $#{ $change_map->{$current_name}->{digits} } ) {
      $change_map->{$current_name}->{order}->[$index] =
        int( $change_map->{$current_name}->{digits}->[$index] );
    }
    ###
    ### Generate the allele_group map
    ###
    $current_allele_group = $current_locus . '*' . $current_allele_group;
    if ( !defined( $allele_group_map->{$current_allele_group} )
      && $#{ $change_map->{$current_name}->{digits} } > 0 )
    {
      my $digits = $change_map->{$current_name}->{digits};
      $allele_group_map->{$current_allele_group} = {
        locus            => $new_locus,
        new_allele_group => $new_locus . '*' . $digits->[0],
      };
    }
    if ( defined($current_allele_group_wsuffix) ) {
      $allele_group_map->{$current_allele_group_wsuffix} = {
        locus            => $new_locus,
        new_allele_group => $new_name,
      };
    }
    ###
    ### Generate the HLA protein map
    ###
    if ( defined($current_hla_protein) ) {
      if ( !defined( $hla_protein_map->{$current_hla_protein} )
        && $#{ $change_map->{$current_name}->{digits} } > 0 )
      {
        my $digits = $change_map->{$current_name}->{digits};
        $hla_protein_map->{$current_hla_protein} = {
          locus           => $new_locus,
          new_hla_protein => $new_locus . '*'
            . $digits->[0] . ':'
            . $digits->[1],
          alleles => {},
        };
      }
      $hla_protein_map->{$current_hla_protein}->{alleles}->{$current_name} =
        $new_name;
    }

    if ( defined($current_hla_protein_wsuffix) ) {
      $hla_protein_map->{$current_hla_protein_wsuffix} = {
        locus           => $new_locus,
        new_hla_protein => $new_name,
        alleles         => { $current_name => $new_name, },
      };
    }
    ###
    ### Generate the Coding Region Map
    ###
    if ( defined($current_coding_region) ) {
      if ( !defined( $coding_region_map->{$current_coding_region} )
        && $#{ $change_map->{$current_name}->{digits} } > 0 )
      {
        my $digits = $change_map->{$current_name}->{digits};
        $coding_region_map->{$current_coding_region} = {
          locus             => $new_locus,
          new_coding_region => $new_locus . '*'
            . $digits->[0] . ':'
            . $digits->[1] . ':'
            . $digits->[2],
          alleles => {},
        };
      }
      $coding_region_map->{$current_coding_region}->{alleles}->{$current_name} =
        $new_name;
    }

    if ( defined($current_coding_region_wsuffix) ) {
      $coding_region_map->{$current_coding_region_wsuffix} = {
        locus             => $new_locus,
        new_coding_region => $new_name,
        alleles           => { $current_name => $new_name, },
      };
    }
  }
  $fh->close;
  $this->{loci} = [ sort keys %{$loci} ];

}

sub generateDeletedNamesMap {
  my util::Tools::imgtConversion $this = shift;
  ###
  ### Initialize the maps
  ###
  $this->{deleted_names_list} = [];
  $this->{deleted_names_map}  = {};

  my $deleted_names_list = $this->{deleted_names_list};
  my $deleted_names_map  = $this->{deleted_names_map};
  ###
  ### Get hte Deleted Names File
  ###
  my $deleted_name_file =
    getPath( $this->{properties}->{&DELETED_NAME_FILE_PROP} );
  ###
  ### Open the file
  ###
  my $fh = new FileHandle;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 2,
    [ 'file', 'open', 'text', $deleted_name_file ],
    !$fh->open( $deleted_name_file, "<" )
  );
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    chomp($line);
    ###
    ### remove more than one space and replace with one space
    ###
    $line =~ s/  +/ /g;
    ###
    ### now split the line
    ###
    my @row          = split( / /, $line );
    my $hla_id       = shift @row;
    my $deleted_name = shift @row;
    my $commentary   = join( util::Constants::SPACE, @row );
    push(
      @{$deleted_names_list},
      {
        hla_id       => $hla_id,
        deleted_name => $deleted_name,
        commentary   => $commentary,
      }
    );
    if ( $deleted_name =~ /:/ ) {
      ###
      ### New IMGT/HLA 3.* format not part of this map
      ###
      next;
    }
    ###
    ### Only deleted HLA proteins
    ###
    $deleted_name =~ /^(\w+\*)([0-9]+)([A-Z]?)$/;
    my $locus  = $1;
    my $digits = $2;
    my $suffix = $3;
    next if ( length($digits) != 4 );
    ###
    ### now convert to new format
    ###
    my $pos             = 0;
    my $digits_w_colons = undef;
    if ( $locus =~ /^MIC/ ) {
      $digits_w_colons .= substr( $digits, $pos, 3 );
      $pos = 3;
    }
    while ( $pos < length($digits) ) {
      if ( defined($digits_w_colons) ) { $digits_w_colons .= ':'; }
      $digits_w_colons .= substr( $digits, $pos, 2 );
      $pos += 2;
    }
    ###
    ### Correct Cw to C
    ###
    if ( $locus =~ /^Cw/ ) { $locus = 'C*'; }
    $deleted_names_map->{$deleted_name} = $locus . $digits_w_colons . $suffix;
  }
  $fh->close;
}

sub loci {
  my util::Tools::imgtConversion $this = shift;
  return @{ $this->{loci} };
}

sub changeMap {
  my util::Tools::imgtConversion $this = shift;
  return $this->{change_map};
}

sub alleleGroupMap {
  my util::Tools::imgtConversion $this = shift;
  return $this->{allele_group_map};
}

sub codingRegionMap {
  my util::Tools::imgtConversion $this = shift;
  return $this->{coding_region_map};
}

sub hlaProteinMap {
  my util::Tools::imgtConversion $this = shift;
  return $this->{hla_protein_map};
}

sub deletedNamesMap {
  my util::Tools::imgtConversion $this = shift;
  return $this->{deleted_names_map};
}

sub deletedNames {
  my util::Tools::imgtConversion $this = shift;
  return @{ $this->{deleted_names_list} };
}

################################################################################

1;

__END__

=head1 NAME

imgtConversion.pm

=head1 DESCRIPTION

This class is a subclass of L<util::Tools> and implements those common
method used to convert current IMGT data to the new allele format.

=head1 STATIC CONSTANTS

The following constant property are defined in this class:

   util::Tools::imgtConversion::NOMENCLATURE_FILE_PROPT -- nomenclatureFile

=head1 METHODS

The following methods are exported by this class.

=head2 B<new mhcSeqVar::new(error_mgr)>

This method is the constructor for the class.  The following
property is also added to be basic context properties:

   util::Tools::imgtConversion::NOMENCLATURE_FILE_PROP -- nomenclatureFile

=head2 B<generateMaps>

This method generates the standard hash for representing the change
map, allele_group map, HLA protein map, and the list of loci.

=head2 B<generateDeletedNamesMap>

This method generates the the following map from the deletedNamesFile
file.  The key is deleted allele name and the value is the new format 
HLA protein name equivalent of the deleted name.  Also, this metho generates
the list of deleted names rows in order as defined in the file.

=head1 GETTER METHODS

The following getter methods are exported:

=head2 B<$change_map = changeMap>

The method returns the change map whose key is the
current allele name and the value is the hash with the
following compoents:

   current            => current name
   digits             => array of components of new name (':' separator)
   locus              => new locus name
   new_name           => new name
   order              => order array of digits in the new name
   suffix             => new suffix
   zero_allele_group  => number of zero's in prefix for allele_group
   diff_allele_group  => type (0--none, 1--differ, 2--95/92) of
                         allele_group difference
   diff_suffix        => (boolean) differing suffixes
   conversion         => (boolean) conversion between current and new name

=head2 B<$coding_region_map = codingRegionMap>

The method returns the coding region map. The key is a current
coding region (with and/or without suffix) and the value is
a hash containing the following components:

   locus             => new locus name
   new_coding_region => new coding region

=head2 B<$hla_protein_map = hlaProteinMap>

The method returns the HLA protein map. The key is a current
HLA protein (with and/or without suffix) and the value is
a hash containing the following components:

   locus           => new locus name
   new_hla_protein => new HLA protein name

=head2 B<$allele_group_map = alleleGroupMap>

The method returns the allele_group map. The key is a current
allele_group (with and/or without suffix) and the value is
a hash containing the following components:

   locus            => new locus name
   new_allele_group => new allele_group name

=head2 B<@loci = loci>

The method returns the list of distinct loci in order in the change
file.

=head2 B<$deleted_names_map = deletedNamesMap>

The method returns the deleted names map.

=head2 B<@deleted_names = deletedNames>

The method returns the list of deleted names where each element
is a hash with the following components:

   hla_id       => HLA id
   deleted_name => deleted name
   commentary   => commentar

=cut
