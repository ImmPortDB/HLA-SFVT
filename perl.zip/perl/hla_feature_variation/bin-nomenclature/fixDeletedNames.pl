#!/usr/bin/perl -w
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#			    Local Functions
#
################################################################################

sub _convertToVersion2 {
  my ( $locus, $digits ) = @_;

  if ( $locus !~ /^MIC/ ) {
    my @comps = split(/:/, $digits);
    foreach my $comp (@comps) {
      ###
      ### Cannot convert to version 2
      ###
      return $digits if ($comp =~ /^\d\d\d/);
    }
  }
  $digits =~ s/://g;
  return $digits;
}

sub _convertToVersion3 {
  my ( $locus, $digits ) = @_;

  my $pos             = 0;
  my $version3_digits = undef;
  if ( $locus =~ /^MIC/ ) {
    $version3_digits .= substr( $digits, $pos, 3 );
    $pos = 3;
  }
  while ( $pos < length($digits) ) {
    if ( defined($version3_digits) ) { $version3_digits .= ':'; }
    $version3_digits .= substr( $digits, $pos, 2 );
    $pos += 2;
  }
  return $version3_digits;
}

sub _convertAllele {
  my ($allele) = @_;

  $allele =~ /^(\w+\*)([0-9:]+)([A-Z]?)$/;
  my $locus  = $1;
  my $digits = $2;
  my $suffix = $3;

  my $version3 = ($allele =~ /:/) ? util::Constants::TRUE : util::Constants::FALSE;
  my $len      = length($digits);
  ###
  ### If digit length is 3 or 5 and not MICA or MICB return, 'as-is'
  ###
  return ($locus, $digits, $suffix, $version3, $len)
    if ( !$version3 && ( $len == 5 || $len == 7 ) && $locus !~ /^MIC/ );

  my $new_digits = undef;
  if ($version3) {
    $new_digits = _convertToVersion2($locus, $digits);
    if ( $locus =~ /^C\*$/ ) { $locus = 'Cw*'; }
  }
  else {
    $new_digits = _convertToVersion3( $locus, $digits );
    if ( $locus =~ /^Cw\*$/ ) { $locus = 'C*'; }
  }

  return ($locus, $new_digits, $suffix, $version3, $len);
}

sub _needTwoRows {
  my ($allele) = @_;

  my ($locus, $digits, $suffix, $version3, $len) = _convertAllele($allele);
  ###
  ### If digit length is 3 or 5 and not MICA or MICB
  ### return, 'as-is'
  ###
  if ( !$version3 && ( $len == 5 || $len == 7 ) && $locus !~ /^MIC/ ) {
    $error_mgr->printWarning(
      "_needTwoRows:  Allele not changed since 5- or 7-digits\n" . "  allele = $allele",
      util::Constants::TRUE );
    return util::Constants::FALSE;
  }
  my $new_allele = $locus . $digits . $suffix; 
  $error_mgr->printMsg("_needTwoRows:  Allele and new allele differ (allele, new_allele) = ($allele, $new_allele)")
    if ($allele ne $new_allele);

  return ( $allele eq $new_allele )
    ? util::Constants::FALSE
    : util::Constants::TRUE;
}

sub _correctAllele {
  my ($allele) = @_;

  my ($locus, $digits, $suffix, $version3, $len) = _convertAllele($allele);
  ###
  ### If digit length is 3 or 5 and not MICA or MICB
  ### return, 'as-is'
  ###
  if ( !$version3 && ( $len == 5 || $len == 7 ) && $locus !~ /^MIC/ ) {
    $error_mgr->printWarning(
      "_correctAllele:  Allele not changed since 5- or 7-digits\n" . "  allele = $allele",
      util::Constants::TRUE );
    return $allele;
  }
  my $new_allele = $locus . $digits . $suffix;
  return $new_allele;
}

sub _correctCommentary {
  my ($commentary) = @_;
  ###
  ### If the commentary contains a version 2.* allele,
  ### then correct commentary
  ###
  return $commentary if ( $commentary !~ /(\w+\*\d+[A-Z]?)/ );

  my $allele     = $1;
  my $new_allele = _correctAllele($allele);
  $allele     =~ s/\*/\\\*/;
  $commentary =~ s/$allele/$new_allele/;
  return $commentary;
}

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties = $tools->setWorkspaceProperty($tools->setContext( $opt_P, 'deletedNamesFile' ));

$tools->generateDeletedNamesMap;

################################################################################
#
#				Main Program
#
################################################################################
###
### Read the content of the nomenclature file,
###
my $fh = new FileHandle;
my $deletedNamesFile = basename( $properties{deletedNamesFile} );
$deletedNamesFile =~ s/\.txt$/.v3.txt/;
$fh->open( $deletedNamesFile, ">" );
$fh->autoflush(util::Constants::TRUE);
foreach my $line ( $tools->deletedNames ) {
  my $commentary = _correctCommentary( $line->{commentary} );
  ###
  ### Always print 'as-is'
  ###
  $fh->print(
    join( util::Constants::TAB,
      $line->{hla_id}, $line->{deleted_name}, $commentary )
      . "\n"
  );
  my $needTwoRows = _needTwoRows( $line->{deleted_name} );
  $error_mgr->printWarning(
    "Allele Needs Only One Row\n" . "  allele = " . $line->{deleted_name},
    !$needTwoRows );
  next if ( !$needTwoRows );

  ###
  ### Now print in new notation
  ###
  $fh->print(
    join( util::Constants::TAB,
      $line->{hla_id}, _correctAllele( $line->{deleted_name} ), $commentary )
      . "\n"
  );
}
$fh->close;

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

fixDeletedNames.pl

=head1 SYNOPSIS

   fixDeletedNames.pl
      -P properties_file (deletedNamesFile)

Fix the deleted names file.

=cut
