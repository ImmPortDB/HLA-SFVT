#!/usr/bin/perl
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::PathSpecifics;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#				Local Constants
#
################################################################################
###
### Standard tags
###
sub DELETED_TAG { return 'Deleted' }
sub UNKNOWN_TAG { return 'Unknown'; }
###
### Month translation
###
sub MONTH_NUM {
  my ($mon) = @_;
  return '01' if ( lc($mon) eq 'jan' );
  return '02' if ( lc($mon) eq 'feb' );
  return '03' if ( lc($mon) eq 'mar' );
  return '04' if ( lc($mon) eq 'apr' );
  return '05' if ( lc($mon) eq 'may' );
  return '06' if ( lc($mon) eq 'jun' );
  return '07' if ( lc($mon) eq 'jul' );
  return '08' if ( lc($mon) eq 'aug' );
  return '09' if ( lc($mon) eq 'sep' );
  return '10' if ( lc($mon) eq 'oct' );
  return '11' if ( lc($mon) eq 'nov' );
  return '12' if ( lc($mon) eq 'dec' );
  return util::Constants::EMPTY_STR;
}
################################################################################
#
#			    Local Functions
#
################################################################################

sub _sortableDate {
  my ($date) = @_;

  my ( $day, $month, $year ) = split( /-/, $date );
  $date = $year . MONTH_NUM($month) . $day;
  return $date;
}

sub _sortAlleles {
  $a->{sort_date} cmp $b->{sort_date}
    or $a->{current_allele} cmp $b->{current_allele};
}

sub _getAlleles {
  my ( $allele_name, $create_dates ) = @_;

  my $changeMap       = $tools->changeMap;
  my $hlaProteinMap   = $tools->hlaProteinMap;
  my $codingRegionMap = $tools->codingRegionMap;
  my $deletedNamesMap = $tools->deletedNamesMap;

  my $alleles = {};
  if ( defined( $changeMap->{$allele_name} ) ) {
    $alleles->{$allele_name} = $changeMap->{$allele_name}->{new_name};
  }
  elsif ( defined( $hlaProteinMap->{$allele_name} ) ) {
    foreach
      my $current_allele ( keys %{ $hlaProteinMap->{$allele_name}->{alleles} } )
    {
      my $new_allele =
        $hlaProteinMap->{$allele_name}->{alleles}->{$current_allele};
      $alleles->{$current_allele} = {
        current_allele => $current_allele,
        new_allele     => $new_allele,
        create_date    => $create_dates->{$new_allele},
        sort_date      => _sortableDate( $create_dates->{$new_allele} ),
      };
    }
  }
  elsif ( defined( $codingRegionMap->{$allele_name} ) ) {
    foreach my $current_allele (
      keys %{ $codingRegionMap->{$allele_name}->{alleles} } )
    {
      my $new_allele =
        $codingRegionMap->{$allele_name}->{alleles}->{$current_allele};
      $alleles->{$current_allele} = {
        current_allele => $current_allele,
        new_allele     => $new_allele,
        create_date    => $create_dates->{$new_allele},
        sort_date      => _sortableDate( $create_dates->{$new_allele} ),
      };
    }
  }
  elsif ( $deletedNamesMap->{$allele_name} ) {
    $alleles->{$allele_name} = DELETED_TAG;
  }
  else {
    $alleles->{$allele_name} = UNKNOWN_TAG;
  }

  return $alleles;
}

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties =
  $tools->setWorkspaceProperty(
  $tools->setContext( $opt_P, 'deletedNamesFile', 'hlaFile', 'canoTablesFile' )
  );

$tools->generateMaps;
$tools->generateDeletedNamesMap;

################################################################################
#
#				Main Program
#
################################################################################
###
### Read the HLA Data to determine Creation Dates of alleles
###
my $fh = new FileHandle;
$fh->open( $properties{hlaFile}, "<" );
my $create_dates        = {};
my $current_create_date = undef;
while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  next if ( $line !~ /^(DT.+Created|DE)/ );
  my @row = split( / +/, $line );
  if ( !defined($current_create_date) || $line =~ /^DT/ ) {
    $current_create_date = $row[1];
    next;
  }
  my $allele_name = $row[1];
  $allele_name =~ s/,$//;
  $allele_name =~ s/^HLA-//;
  $create_dates->{$allele_name} = $current_create_date;
}
$fh->close;
$tools->debugStruct( "create_dates", $create_dates );
###
### Read the Version 2 Cano CWD data
###
$fh->open( $properties{canoTablesFile}, "<" );
my $cwd_data = {};
while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  my @row = split( / +/, $line );
  my @cwd_row = ( $row[0], $row[1] );
  if ( defined( $row[2] ) && $row[2] ne '' && $row[2] =~ /^\d+/ ) {
    push( @cwd_row, $row[2] );
  }
  else {
    push( @cwd_row, util::Constants::EMPTY_STR );
  }
  my $locus_name  = $cwd_row[0];
  my $cwd_allele  = $cwd_row[1];
  my $hla_protein = $cwd_row[2];
  my $allele_name = join( util::Constants::ASTERISK, $locus_name, $cwd_allele );
  $cwd_data->{$allele_name} = _getAlleles( $allele_name, $create_dates );
}
$fh->close;
$tools->debugStruct( "cwd_data", $cwd_data );
###
### Now report CWD alleles that have been multiplied, deleted, or unknown
###
my $counts = {
  Deleted  => 0,
  Unknown  => 0,
  Multiple => 0,
};
$error_mgr->printHeader("Results");
$error_mgr->printMsg("CWD\tType\nAllele\n------\t--------");
my $replacement_file = $properties{canoTablesFile};
$replacement_file =~ s/\.txt/\.replacements/;
$fh->open( $replacement_file, '>' );
$fh->print(
  join( util::Constants::TAB, 'Allele', 'Type', 'Replacement' )
    . util::Constants::NEWLINE );
$fh->autoflush(util::Constants::TRUE);

foreach my $allele_name ( sort keys %{$cwd_data} ) {
  my $alleles     = $cwd_data->{$allele_name};
  my @allele_list = sort keys %{$alleles};
  if ( @allele_list == 1 ) {
    my $a_name  = $allele_list[0];
    my $a_value = $alleles->{$a_name};
    if ( $a_value eq DELETED_TAG || $a_value eq UNKNOWN_TAG ) {
      $counts->{$a_value}++;
      $error_mgr->printMsg("$allele_name\t$a_value");
      $error_mgr->printMsg(util::Constants::EMPTY_STR);
    }
  }
  else {
    $counts->{Multiple}++;
    $error_mgr->printMsg("$allele_name\tMultiple");
    my $first_row = util::Constants::TRUE;
    foreach my $allele ( sort _sortAlleles values %{$alleles} ) {
      my $current_allele = $allele->{current_allele};
      my $new_allele     = $allele->{new_allele};
      my $create_date    = $allele->{create_date};
      if ($first_row) {
        $first_row = util::Constants::FALSE;
        $fh->print(
          join( util::Constants::TAB,
            $allele_name, 'Multiple', $current_allele )
            . util::Constants::NEWLINE
        );
      }
      $error_mgr->printMsg("\t$current_allele\t$new_allele\t$create_date");
    }
    $error_mgr->printMsg(util::Constants::EMPTY_STR);
  }
}
$fh->close;
$error_mgr->printHeader( "Result Counts\n"
    . "Deleted  = "
    . $counts->{Deleted} . "\n"
    . "Multiple = "
    . $counts->{Multiple} . "\n"
    . "Unknown  = "
    . $counts->{Unknown} );

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

checkCanoCwdAlleles.pl

=head1 SYNOPSIS

   checkCanoCwdAlleles.pl
      -P properties_file

Fix the alignment files.

=cut
