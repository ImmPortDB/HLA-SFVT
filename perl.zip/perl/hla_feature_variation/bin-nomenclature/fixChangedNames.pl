#!/usr/bin/perl -w
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties =
  $tools->setWorkspaceProperty($tools->setContext( $opt_P, 'changesFile' ));
$tools->generateMaps(util::Constants::TRUE);

################################################################################
#
#				Main Program
#
################################################################################
###
### Get the change map
###
my $changeMap = $tools->changeMap;
###
### Read the content of the changes file
###
my $fh = new FileHandle;
$fh->open( $properties{changesFile}, "<" );
my $changes = {};
my $header  = undef;
while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  if ( $line =~ /Previous Name/ || $line =~ /=/ ) {
    $header .= "$line\n";
    next;
  }
  my ( $old_name, $new_name ) = split( / +/, $line );
  $changes->{$old_name} = $new_name;
}
$fh->close;
###
### Set the new_name to april 2010 names and write out contents
###
$fh->open( basename( $properties{changesFile} ), ">" );
$fh->autoflush(util::Constants::TRUE);
$fh->print($header);
foreach my $old_name ( sort keys %{$changes} ) {
  my $new_name = $changes->{$old_name};
  my $struct   = $changeMap->{$new_name};
  if ( defined($struct) ) {
    ###
    ### Use the april 2010 name directly
    ###
    $new_name = $struct->{new_name};
  }
  else {
    ###
    ### Create the april 2010 name synthetically and report it
    ###
    $new_name =~ /^(\w+)\*(\d+)[A-Z]?$/;
    my $locus  = $1;
    my $digits = $2;
    my $suffix = util::Constants::EMPTY_STR;
    if ( $new_name =~ /([A-Z])$/ ) { $suffix = $1; }
    $locus =~ s/^Cw$/C/;
    my $pos             = 0;
    my $digits_w_colons = undef;

    while ( $pos < length($digits) ) {
      if ( defined($digits_w_colons) ) { $digits_w_colons .= ':'; }
      $digits_w_colons .= substr( $digits, $pos, 2 );
      $pos += 2;
    }
    my $synthetic_name = $locus . '*' . $digits_w_colons . $suffix;
    $error_mgr->printMsg(
      "Generating ($old_name, $new_name, $synthetic_name) synthetically");
    $new_name = $synthetic_name;
  }
  $fh->print("$old_name     $new_name\n");
}
###
### Also write out the current names to april 2010 names
###
foreach my $current_name ( sort keys %{$changeMap} ) {
  my $struct = $changeMap->{$current_name};
  next if ( $struct->{current} eq $struct->{new_name} );
  $fh->print( $struct->{current} . '     ' . $struct->{new_name} . "\n" );
}
$fh->close;

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

fixChangedNames.pl

=head1 SYNOPSIS

   fixChangedNames.pl
      -P properties_file (nomenclatureFile, changesFile)

Fix the changed names file using April 2010 data.

=cut
