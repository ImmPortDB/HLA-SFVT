#!/usr/bin/perl
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::ErrMsgs;
use util::PathSpecifics;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);
my $cmds      = $tools->cmds;

################################################################################
#
#				Local Constants
#
################################################################################
###
### Standard tags
###
sub DELETED_TAG { return 'Deleted' }
sub UNKNOWN_TAG { return 'Unknown'; }
###
### Month translation
###
sub MONTH_NUM {
  my ($mon) = @_;
  return '01' if ( lc($mon) eq 'jan' );
  return '02' if ( lc($mon) eq 'feb' );
  return '03' if ( lc($mon) eq 'mar' );
  return '04' if ( lc($mon) eq 'apr' );
  return '05' if ( lc($mon) eq 'may' );
  return '06' if ( lc($mon) eq 'jun' );
  return '07' if ( lc($mon) eq 'jul' );
  return '08' if ( lc($mon) eq 'aug' );
  return '09' if ( lc($mon) eq 'sep' );
  return '10' if ( lc($mon) eq 'oct' );
  return '11' if ( lc($mon) eq 'nov' );
  return '12' if ( lc($mon) eq 'dec' );
  return util::Constants::EMPTY_STR;
}

################################################################################
#
#			    Local Functions
#
################################################################################

sub _sortableDate {
  my ($date) = @_;

  my ( $day, $month, $year ) = split( /-/, $date );
  $date = $year . MONTH_NUM($month) . $day;
  return $date;
}

sub _sortAlleles {
  $a->{sort_date} cmp $b->{sort_date}
    or $a->{current_allele} cmp $b->{current_allele};
}

sub _getAlleles {
  my ( $allele_name, $create_dates ) = @_;

  my $changeMap       = $tools->changeMap;
  my $hlaProteinMap   = $tools->hlaProteinMap;
  my $codingRegionMap = $tools->codingRegionMap;
  my $deletedNamesMap = $tools->deletedNamesMap;

  my $alleles = {};
  if ( defined( $changeMap->{$allele_name} ) ) {
    $alleles->{$allele_name} = $changeMap->{$allele_name}->{new_name};
  }
  elsif ( defined( $hlaProteinMap->{$allele_name} ) ) {
    foreach
      my $current_allele ( keys %{ $hlaProteinMap->{$allele_name}->{alleles} } )
    {
      my $new_allele =
        $hlaProteinMap->{$allele_name}->{alleles}->{$current_allele};
      $alleles->{$current_allele} = {
        current_allele => $current_allele,
        new_allele     => $new_allele,
        create_date    => $create_dates->{$new_allele},
        sort_date      => _sortableDate( $create_dates->{$new_allele} ),
      };
    }
  }
  elsif ( defined( $codingRegionMap->{$allele_name} ) ) {
    foreach my $current_allele (
      keys %{ $codingRegionMap->{$allele_name}->{alleles} } )
    {
      my $new_allele =
        $codingRegionMap->{$allele_name}->{alleles}->{$current_allele};
      $alleles->{$current_allele} = {
        current_allele => $current_allele,
        new_allele     => $new_allele,
        create_date    => $create_dates->{$new_allele},
        sort_date      => _sortableDate( $create_dates->{$new_allele} ),
      };
    }
  }
  elsif ( $deletedNamesMap->{$allele_name} ) {
    $alleles->{$allele_name} = DELETED_TAG;
  }
  else {
    $alleles->{$allele_name} = UNKNOWN_TAG;
  }

  return $alleles;
}

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties = $tools->setWorkspaceProperty(
  $tools->setContext(
    $opt_P,             'monoTool',
    'anttTool',         'anttTranslationDirectory',
    'canoTablesFile',   'canoFile',
    'canoReplacements', 'cwdAllelesFile',
    'deletedNamesFile', 'hlaFile'
  )
);
$tools->generateMaps;
$tools->generateDeletedNamesMap;

################################################################################
#
#			    Local Constants
#
################################################################################

my $ParseDataFile = "[ParseDataFile]
alleleDesignator=*
ambiguousAlleleSeparator=/
untypedAllele=-
validSampleFields=";

my $ConversionFiles = "[ConversionFiles]
conversionFilePath=" . $properties{anttTranslationDirectory} . "
dataFileMappings=";

my @CANO_HEADER = ( 'Locus', 'Name', '4 Digits' );

my $canoReplacements = eval $properties{canoReplacements};
###
### Error Category
###
sub ERR_CAT { return util::ErrMsgs::PROG_CAT; }

################################################################################
#
#				Main Program
#
################################################################################
###
### Read the HLA Data to determine Creation Dates of alleles
###
my $fh = new FileHandle;
$fh->open( $properties{hlaFile}, "<" );
my $create_dates        = {};
my $current_create_date = undef;
while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  next if ( $line !~ /^(DT.+Created|DE)/ );
  my @row = split( / +/, $line );
  if ( !defined($current_create_date) || $line =~ /^DT/ ) {
    $current_create_date = $row[1];
    next;
  }
  my $allele_name = $row[1];
  $allele_name =~ s/,$//;
  $allele_name =~ s/^HLA-//;
  $create_dates->{$allele_name} = $current_create_date;
}
$fh->close;
$tools->debugStruct( "create_dates", $create_dates );
###
### Read the Cano CWD file
###
my $loci        = {};
my $canoInputFh = new FileHandle;
$canoInputFh->open( $properties{canoTablesFile}, '<' );
while ( !$canoInputFh->eof ) {
  my $line = $canoInputFh->getline;
  chomp($line);
  my @row = split( / +/, $line );
  my @cwd_row = ( $row[0], $row[1] );
  if ( defined( $row[2] ) && $row[2] ne '' && $row[2] =~ /^\d+/ ) {
    push( @cwd_row, $row[2] );
  }
  else {
    push( @cwd_row, util::Constants::EMPTY_STR );
  }
  my $locus = $cwd_row[0];
  if ( !defined( $loci->{$locus} ) ) { $loci->{$locus} = []; }
  my $datum = [ $cwd_row[1], $cwd_row[2] ];
  push( @{ $loci->{$locus} }, $datum );
}
$canoInputFh->close;
###
### Run ANTT and generate IMGT/HLA version 3 file
###
$error_mgr->printHeader("Generating " . $properties{canoFile});
my $tmpFileName = $cmds->TMP_FILE('cano.file');
my $canoOutputFh = new FileHandle;
$canoOutputFh->open( $properties{canoFile}, '>' );
$canoOutputFh->autoflush(util::Constants::TRUE);
$canoOutputFh->print(
  join( util::Constants::TAB, @CANO_HEADER ) . util::Constants::NEWLINE );

my $alleles_written = {};
foreach my $locus ( sort keys %{$loci} ) {
  ###
  ### Generate the necessary file names
  ###
  my $cmd_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'cmd' );
  my $antt_file = join( util::Constants::DOT, $tmpFileName, $locus, 'txt' );
  my $ini_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'ini' );
  my $out_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'out' );

  my $antt_prefix = join( util::Constants::DOT, $tmpFileName,
    $locus . util::Constants::HYPHEN );
  my $antt_out = join( util::Constants::DOT, $antt_prefix,          'txt' );
  my $antt_log = join( util::Constants::DOT, $antt_prefix . '_log', 'txt' );
  ###
  ### Generate the ini-file
  ###
  my $outputFh = new FileHandle;
  $outputFh->open( $ini_file, '>' );
  my $locus_name = $locus;
  if ( $locus eq 'Cw' ) { $locus_name = 'C'; }
  $outputFh->print(
    $ParseDataFile . '*' . $locus_name . " 1\n *" . $locus_name . " 2\n\n" );
  $outputFh->print( $ConversionFiles
      . $locus_name
      . " 1:HLA-${locus_name}.upd\n "
      . $locus_name
      . " 2:HLA-${locus_name}.upd\n\n" );
  $outputFh->close;
  ###
  ### Generate the antt file
  ###
  $outputFh->open( $antt_file, '>' );
  $outputFh->print("$locus_name 1\t$locus_name 2\n");
  foreach my $data ( @{ $loci->{$locus} } ) {
    $outputFh->print( join( "\t", @{$data} ) . "\n" );
  }
  $outputFh->close;
  ###
  ### Run ANTT
  ###
  $outputFh->open( $cmd_file, '>' );
  my @rows = (
    '#!/bin/tcsh -f',
    'cd ' . $properties{executionDirectory},
    'setenv ANTT_TOOL "'
      . $properties{monoTool}
      . util::Constants::SPACE
      . $properties{anttTool} . '"',
    join( util::Constants::SPACE,
      '$ANTT_TOOL', $ini_file, $antt_file, $antt_prefix, '>&', $out_file
    ),
    util::Constants::EMPTY_STR

  );
  $outputFh->print( join( util::Constants::NEWLINE, @rows ) );
  $outputFh->close;
  chmod( 0777, $cmd_file );
  my $err_msgs = {
    cmd_file    => $cmd_file,
    antt_file   => $antt_file,
    antt_prefix => $antt_prefix,
    ini_file    => $ini_file,
    out_file    => $out_file,
  };
  my $status =
    $cmds->executeCommand( $err_msgs, $cmd_file, 'Running ANTT command' );

  $error_mgr->registerError( ERR_CAT, 1,
    [ 'run ANTT', 'text', $locus, $status ], $status );
  next if ($status);
  ###
  ### Now generate IMGT/HLA version 3.* file
  ###
  my $inputFh = new FileHandle;
  $inputFh->open( $antt_out, '<' );
  my $first_line = util::Constants::TRUE;
  while ( !$inputFh->eof ) {
    my $line = $inputFh->getline;
    chomp($line);
    $line =~ s///g;
    if ($first_line) {
      $first_line = util::Constants::FALSE;
      next;
    }
    my @row = split( /\t/, $line, 2 );
    unshift( @row, $locus_name );
    foreach my $index ( 1 .. $#row ) {
      my $allele = $locus . util::Constants::ASTERISK . $row[$index];
      next if ( $row[$index] !~ /^\d+N?$/ );
      my $replacement = $canoReplacements->{$allele};
      $error_mgr->registerError(
        ERR_CAT, 1,
        [
          'replacement', 'allele',
          $allele,       'unable to find version 3 replacement'
        ],
        !defined($replacement)
      );
      next if ( !defined($replacement) );
      $error_mgr->printNote("\nAllele $allele replaced by $replacement\n");
      $row[$index] = $replacement;
    }
    my $allele = $locus_name . util::Constants::ASTERISK . $row[1];
    if ( defined( $alleles_written->{$allele} ) ) {
      $error_mgr->printNote("\nAllele already written $allele\n");
      next;
    }
    $alleles_written->{$allele} = util::Constants::EMPTY_STR;
    $canoOutputFh->print(
      join( util::Constants::TAB, @row ) . util::Constants::NEWLINE );
    ###
    ### Cleanup
    ###
    unlink($antt_file);
    unlink($antt_log);
    unlink($antt_out);
    unlink($cmd_file);
    unlink($ini_file);
    unlink($out_file);
  }
}
$canoOutputFh->close;
###
### Run ANTT and generate IMGT/HLA version 3 for cwd alleles
###
$error_mgr->printHeader("Generating " . $properties{cwdAllelesFile});
$canoOutputFh->open( $properties{cwdAllelesFile}, '>' );
$canoOutputFh->autoflush(util::Constants::TRUE);
$canoOutputFh->print(
  join( util::Constants::TAB, @CANO_HEADER ) . util::Constants::NEWLINE );

$alleles_written = {};
foreach my $locus ( sort keys %{$loci} ) {
  ###
  ### Generate the necessary file names
  ###
  my $cmd_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'cmd' );
  my $antt_file = join( util::Constants::DOT, $tmpFileName, $locus, 'txt' );
  my $ini_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'ini' );
  my $out_file  = join( util::Constants::DOT, $tmpFileName, $locus, 'out' );

  my $antt_prefix = join( util::Constants::DOT, $tmpFileName,
    $locus . util::Constants::HYPHEN );
  my $antt_out = join( util::Constants::DOT, $antt_prefix,          'txt' );
  my $antt_log = join( util::Constants::DOT, $antt_prefix . '_log', 'txt' );
  ###
  ### Generate the ini-file
  ###
  my $outputFh = new FileHandle;
  $outputFh->open( $ini_file, '>' );
  my $locus_name = $locus;
  if ( $locus eq 'Cw' ) { $locus_name = 'C'; }
  $outputFh->print(
    $ParseDataFile . '*' . $locus_name . " 1\n *" . $locus_name . " 2\n\n" );
  $outputFh->print( $ConversionFiles
      . $locus_name
      . " 1:HLA-${locus_name}.upd\n "
      . $locus_name
      . " 2:HLA-${locus_name}.upd\n\n" );
  $outputFh->close;
  ###
  ### Generate the antt file
  ###
  $outputFh->open( $antt_file, '>' );
  $outputFh->print("$locus_name 1\t$locus_name 2\n");
  foreach my $data ( @{ $loci->{$locus} } ) {
    my $allele = join( util::Constants::ASTERISK, $locus, $data->[0] );
    my $alleles = _getAlleles( $allele, $create_dates );
    my @allele_list = sort keys %{$alleles};
    if ( @allele_list > 1 ) {
      my @allele_values  = sort _sortAlleles values %{$alleles};
      my $allele_value   = $allele_values[0];
      my $current_allele = $allele_value->{current_allele};
      my $new_allele     = $allele_value->{new_allele};
      my $create_date    = $allele_value->{create_date};
      $error_mgr->printNote("\nReplacing allele $allele with $current_allele\n");
      $data->[0] = $current_allele;
      $data->[0] =~ s/^.+\*//;
      if ( $data->[0] =~ /^(\d\d\d\d)\d/
        && util::Constants::EMPTY_LINE( $data->[1] ) )
      {
        $data->[1] = $1;
      }
    }
    $outputFh->print( join( "\t", @{$data} ) . "\n" );
  }
  $outputFh->close;
  ###
  ### Run ANTT
  ###
  $outputFh->open( $cmd_file, '>' );
  my @rows = (
    '#!/bin/tcsh -f',
    'cd ' . $properties{executionDirectory},
    'setenv ANTT_TOOL "'
      . $properties{monoTool}
      . util::Constants::SPACE
      . $properties{anttTool} . '"',
    join( util::Constants::SPACE,
      '$ANTT_TOOL', $ini_file, $antt_file, $antt_prefix, '>&', $out_file
    ),
    util::Constants::EMPTY_STR

  );
  $outputFh->print( join( util::Constants::NEWLINE, @rows ) );
  $outputFh->close;
  chmod( 0777, $cmd_file );
  my $err_msgs = {
    cmd_file    => $cmd_file,
    antt_file   => $antt_file,
    antt_prefix => $antt_prefix,
    ini_file    => $ini_file,
    out_file    => $out_file,
  };
  my $status =
    $cmds->executeCommand( $err_msgs, $cmd_file, 'Running ANTT command' );

  $error_mgr->registerError( ERR_CAT, 1,
    [ 'run ANTT', 'text', $locus, $status ], $status );
  next if ($status);
  ###
  ### Now generate IMGT/HLA version 3.* file
  ###
  my $inputFh = new FileHandle;
  $inputFh->open( $antt_out, '<' );
  my $first_line = util::Constants::TRUE;
  while ( !$inputFh->eof ) {
    my $line = $inputFh->getline;
    chomp($line);
    $line =~ s///g;
    if ($first_line) {
      $first_line = util::Constants::FALSE;
      next;
    }
    my @row = split( /\t/, $line, 2 );
    unshift( @row, $locus_name );
    foreach my $index ( 1 .. $#row ) {
      my $allele = $locus . util::Constants::ASTERISK . $row[$index];
      next if ( $row[$index] !~ /^\d+N?$/ );
      my $replacement = $canoReplacements->{$allele};
      $error_mgr->registerError(
        ERR_CAT, 1,
        [
          'replacement', 'allele',
          $allele,       'unable to find version 3 replacement'
        ],
        !defined($replacement)
      );
      next if ( !defined($replacement) );
      $error_mgr->printNote("\nAllele $allele replaced by $replacement\n");
      $row[$index] = $replacement;
    }
    my $allele = $locus_name . util::Constants::ASTERISK . $row[1];
    if ( defined( $alleles_written->{$allele} ) ) {
      $error_mgr->printNote("\nAllele already written $allele\n");
      next;
    }
    $alleles_written->{$allele} = util::Constants::EMPTY_STR;
    $canoOutputFh->print(
      join( util::Constants::TAB, @row ) . util::Constants::NEWLINE );
    ###
    ### Cleanup
    ###
    unlink($antt_file);
    unlink($antt_log);
    unlink($antt_out);
    unlink($cmd_file);
    unlink($ini_file);
    unlink($out_file);
  }
}
$canoOutputFh->close;

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

generateCanoFiles.pl

=head1 SYNOPSIS

   generateCanoFiles.pl
      -P properties_file ()

Generate the Cano CWD version 3 file.

=cut
