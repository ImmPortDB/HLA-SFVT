#!/usr/bin/perl -w
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use Spreadsheet::WriteExcel;

use file::Chunk::Excel;

use util::Constants;
use util::ErrMgr;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#				   Constants
#
################################################################################
###
### Column Names
###
my $FILE_ORD = [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ];
###
### Columns to modify
###
sub SEQUENCE_FEATURE_NO    { return 0; }
sub SEQUENCE_FEATURE_NAMES { return 2; }

################################################################################
#
#			    Local Functions
#
################################################################################

sub _getEntityLocusName {
  my ($entity) = @_;

  my $locus_name = undef;
  my $col_val    = $entity->{&SEQUENCE_FEATURE_NO};
  return $locus_name if ( util::Constants::EMPTY_LINE($col_val) );
  if ( $col_val =~ /^Hsa_(.+)_SF\d+$/ ) {
    $locus_name = $1;
    $locus_name =~ s/Cw$/C/;
  }
  return $locus_name;
}

sub _getLocusName {
  my ($entities) = @_;

  my $locus_name = undef;
  foreach my $entity ( @{$entities} ) {
    $locus_name = _getEntityLocusName($entity);
    next if ( !defined($locus_name) );
  }
  return $locus_name;
}

sub _writeRow {
  my ( $worksheet, $row, $entity ) = @_;
  foreach my $col_name ( @{$FILE_ORD} ) {
    my $col = int($col_name);
    $worksheet->write( $row, $col, $entity->{$col_name} );
  }
}

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties =
    $tools->setWorkspaceProperty($tools->setContext( $opt_P, 'sequenceFeatureFile' )
    );

################################################################################
#
#				Main Program
#
################################################################################
###
### Create the new Excel Spreadsheet
###
my $workbook =
  Spreadsheet::WriteExcel->new( basename( $properties{sequenceFeatureFile} ) );
###
### Read the Excel SpreadSheet
###
my $reader = new file::Chunk::Excel( undef, $FILE_ORD, $error_mgr );
$reader->setSourceFile( $properties{sequenceFeatureFile} );
$reader->readExcelFile;
###
### for each worksheet
###
foreach my $worksheet_num ( $reader->getWorksheetNums ) {
  my @entities   = $reader->getWorksheet($worksheet_num);
  my $locus_name = _getLocusName( \@entities );
  next if ( !defined($locus_name) );
  $error_mgr->printHeader( "Proccessing Worksheet\n"
      . "  worksheet  = $worksheet_num\n"
      . "  locus_name = $locus_name" );
  ###
  ### Create a new worksheet
  ###
  my $worksheet = $workbook->add_worksheet($locus_name);
  ###
  ### process the spreadsheet
  ###
  my $row = 0;
  foreach my $entity (@entities) {
    my $new_entity = { %{$entity} };
    my $locus_name = _getEntityLocusName($entity);
    if ( defined($locus_name) ) {
      my $sf_no    = $entity->{&SEQUENCE_FEATURE_NO};
      my $sf_names = $entity->{&SEQUENCE_FEATURE_NAMES};

      $sf_no =~ s/^Hsa_HLA-Cw/Hsa_HLA-C/;

      my @sfnames = split( /; /, $sf_names );
      foreach my $index ( 0 .. $#sfnames ) {
        $sfnames[$index] =~ s/^Hsa_HLA-Cw/Hsa_HLA-C/;
      }
      $sf_names = join( '; ', @sfnames );

      $new_entity->{&SEQUENCE_FEATURE_NO}    = $sf_no;
      $new_entity->{&SEQUENCE_FEATURE_NAMES} = $sf_names;
    }
    _writeRow( $worksheet, $row, $new_entity );
    $row++;
  }
}
$workbook->close;

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

fixSequenceFeature.pl

=head1 SYNOPSIS

   fixSequenceFeature.pl
      -P properties_file (sequenceFeatureFile)

Fix the sequence feature excel spreadsheet.

=cut
