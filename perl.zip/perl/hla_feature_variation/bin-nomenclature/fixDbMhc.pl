#!/usr/bin/perl -w
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::PathSpecifics;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#				   Constants
#
################################################################################
###
### Column Names
###
my $FILE_ORD = [
  '0',  '1',  '2',  '3',  '4',  '5',  '6',  '7',  '8',  '9',
  '10', '11', '12', '13', '14', '15', '16', '17', '18', '19',
  '20', '21', '22', '23', '24', '25', '26', '27', '28', '29',
  '30', '31', '32', '33', '34', '35', '36', '37', '38', '39',
];
###
### Columns to modify
###
sub SOURCE     { return 0; }
sub HLA_A_1    { return 10; }
sub HLA_A_2    { return 11; }
sub HLA_B_1    { return 13; }
sub HLA_B_2    { return 14; }
sub HLA_C_1    { return 16; }
sub HLA_C_2    { return 17; }
sub HLA_DRB1_1 { return 19; }
sub HLA_DRB1_2 { return 20; }
sub HLA_DQA1_1 { return 22; }
sub HLA_DQA1_2 { return 23; }
sub HLA_DQB1_1 { return 25; }
sub HLA_DQB1_2 { return 26; }
sub HLA_DPA1_1 { return 28; }
sub HLA_DPA1_2 { return 29; }
sub HLA_DPB1_1 { return 31; }
sub HLA_DPB1_2 { return 32; }

my $ALLELE_COLS = [
  HLA_A_1,    HLA_A_2,    HLA_B_1,    HLA_B_2,    HLA_C_1,    HLA_C_2,
  HLA_DRB1_1, HLA_DRB1_2, HLA_DQA1_1, HLA_DQA1_2, HLA_DQB1_1, HLA_DQB1_2,
  HLA_DPA1_1, HLA_DPA1_2, HLA_DPB1_1, HLA_DPB1_2,
];
###
### first row
###
sub FIRST_ROW { return 'Source'; }

################################################################################
#
#			    Local Functions
#
################################################################################

sub _writeRow {
  my ( $worksheet, $row, $entity ) = @_;
  foreach my $col_name ( @{$FILE_ORD} ) {
    my $col = int($col_name);
    $worksheet->write( $row, $col, $entity->{$col_name} );
  }
}

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties =
  $tools->setWorkspaceProperty( $tools->setContext( $opt_P, 'dbMhcFile' ) );
$tools->generateMaps;

################################################################################
#
#				Main Program
#
################################################################################

my $codingRegionMap = $tools->codingRegionMap;
my $hlaProteinMap   = $tools->hlaProteinMap;
my $alleleGroupMap  = $tools->alleleGroupMap;
###
### for each worksheet
###
my $inputFh  = new FileHandle;
my $outputFh = new FileHandle;
$inputFh->open( $properties{dbMhcFile}, "<" );
$outputFh->open(
  join( util::Constants::DOT, basename( $properties{dbMhcFile} ), 'fixed' ),
  ">" );
$outputFh->autoflush(util::Constants::TRUE);
my $lineno = 0;

while ( !$inputFh->eof ) {
  my $line = $inputFh->getline;
  $lineno++;
  chomp($line);
  my @row = split( /\t/, $line );
  if ( $row[&SOURCE] eq FIRST_ROW ) {
    $outputFh->print( join( util::Constants::TAB, @row ) . "\n" );
    next;
  }
  foreach my $col ( @{$ALLELE_COLS} ) {
    next if ( util::Constants::EMPTY_LINE( $row[$col] ) );
    $row[$col] = &strip_whitespace( $row[$col] );
    next if ( util::Constants::EMPTY_LINE( $row[$col] ) );
    ###
    ### If already 3.*, then fix the C-locus and skip
    ###
    if ( $row[$col] =~ /:/ ) {
      ###
      ### Fix Cw to C!
      ###
      $row[$col] =~ s/^Cw/C/;
      next;
    }
    $error_mgr->printWarning(
      "Allele has Suffix\n"
        . "  line num = $lineno\n"
        . "  allele   = "
        . $row[$col],
      $row[$col] =~ /[A-Z]$/
    );
    ###
    ### Now process line
    ###
    if ( $row[$col] =~ /^(\w+\*\d\d[A-Z]?)$/ ) {
      my $allele_group     = $1;
      my $new_allele_group = $alleleGroupMap->{$allele_group};
      if ( !defined($new_allele_group) ) {
        $error_mgr->printWarning(
          "Allele Group is NOT defined\n"
            . "  line num      = $lineno\n"
            . "  allele        = "
            . $row[$col] . "\n"
            . "  allele_group = $allele_group",
          util::Constants::TRUE
        );
        next;
      }
      $new_allele_group = $new_allele_group->{new_allele_group};
      next if ( $row[$col] eq $new_allele_group );
      $error_mgr->printMsg( "allele group = "
          . $row[$col]
          . ", new_allele_group = $new_allele_group" );
      $row[$col] = $new_allele_group;
    }
    elsif ( $row[$col] =~ /^(\w+\*\d\d\d\d\d\d[A-Z]?)$/ ) {
      my $coding_region     = $1;
      my $new_coding_region = $codingRegionMap->{$coding_region};
      if ( !defined($new_coding_region) ) {
        $error_mgr->printWarning(
          "Coding Region NOT defined\n"
            . "  line num      = $lineno\n"
            . "  allele        = "
            . $row[$col] . "\n"
            . "  coding_region = $coding_region",
          util::Constants::TRUE
        );
        next;
      }
      $new_coding_region = $new_coding_region->{new_coding_region};
      $error_mgr->printMsg( "coding region = "
          . $row[$col]
          . ", new_coding_region = $new_coding_region" );
      $row[$col] = $new_coding_region;
    }
    elsif ( $row[$col] =~ /^(\w+\*\d\d\d\d[A-Z]?)$/ ) {
      my $hla_protein     = $1;
      my $new_hla_protein = $hlaProteinMap->{$hla_protein};
      if ( !defined($new_hla_protein) ) {
        $error_mgr->printWarning(
          "HLA Protein is NOT defined\n"
            . "  line num   = $lineno\n"
            . "  allele     = "
            . $row[$col] . "\n"
            . "  hla_protein = $hla_protein",
          util::Constants::TRUE
        );
        next;
      }
      $new_hla_protein = $new_hla_protein->{new_hla_protein};
      $error_mgr->printMsg( "hla protein = "
          . $row[$col]
          . ", new_hla_protein = $new_hla_protein" );
      $row[$col] = $new_hla_protein;
    }
    else {
      $error_mgr->printWarning(
        "Unknown Allele\n"
          . "  line num   = $lineno\n"
          . "  allele     = "
          . $row[$col],
        util::Constants::TRUE
      );
    }
  }
  $outputFh->print( join( util::Constants::TAB, @row ) . "\n" );
}
$inputFh->close;
$outputFh->close;

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

fixDbMhc.pl

=head1 SYNOPSIS

   fixDbMhc.pl
      -P properties_file (nomenclatureFile, dbMhcFile)

Fix the dbMhc file.

=cut
