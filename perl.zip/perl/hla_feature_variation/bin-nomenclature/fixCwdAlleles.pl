#!/usr/bin/perl
######################################################################
#                  Copyright (c) 2007 Northrop Grumman.
#                          All rights reserved.
######################################################################

################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Getopt::Std;
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::Tools::imgtConversion;

################################################################################
#
#				Local Objects
#
################################################################################

my $error_mgr = new util::ErrMgr;
my $tools     = new util::Tools::imgtConversion($error_mgr);

################################################################################
#
#			    Parameter Initialization
#
################################################################################

use vars qw(
  $opt_P
);
getopts("P:");

###
### Make Sure Required Parameters Are Available
### Otherwise, print usage message.
###
if ( !defined($opt_P) ) {
  my $msg_opt = undef;
  if ( !defined($opt_P) ) { $msg_opt = "-P"; }
  my $message = "You must supply the $msg_opt option";
  pod2usage(
    -message => $message,
    -exitval => 2,
    -verbose => util::Constants::TRUE,
    -output  => \*STDERR
  );
}

STDERR->autoflush(util::Constants::TRUE);    ### Make unbuffered
STDOUT->autoflush(util::Constants::TRUE);    ### Make unbuffered
select STDOUT;

################################################################################
#
#				Parameter Setup
#
################################################################################
###
### Set Pipeline Context
###
my %properties =
  $tools->setWorkspaceProperty(
  $tools->setContext( $opt_P, 'alleleListFile', 'cwdFile' ) );

################################################################################
#
#				Main Program
#
################################################################################
###
### Read the HLA Data to determine Creation Dates of alleles
###
my $fh = new FileHandle;
$fh->open( $properties{alleleListFile}, "<" );
my $alleles = {};
while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  my @row            = split( / +/, $line );
  my $imgt_accession = $row[0];
  my $allele_name    = $row[1];
  $alleles->{$imgt_accession} = $allele_name;
}
$fh->close;
$tools->debugStruct( "alleles", $alleles );
###
### Read the CWD data
###
my $cwdFile    = $properties{cwdFile};
my $cwdFileOut = basename($cwdFile);
$cwdFileOut =~ s/\.txt$//;
$cwdFileOut = join( util::Constants::SLASH,
  $tools->executionDir,
  join( util::Constants::DOT, $cwdFileOut, 'fixed', 'txt' ) );
$error_mgr->printMsg("Fixed File:  $cwdFileOut");
$fh->open( $cwdFile, "<" );
my $ofh = new FileHandle;
$ofh->open( $cwdFileOut, ">" );
my $cwd_data = {};
my $counts   = {
  replaced => 0,
  deleted  => 0,
};

while ( !$fh->eof ) {
  my $line = $fh->getline;
  chomp($line);
  if ( $line =~ /Alleles/ || $line =~ /Locus/ ) {
    $ofh->print("$line\n");
    next;
  }
  my @row                 = split( /\t/, $line );
  my $imgt_accession      = $row[1];
  my $allele_name         = $row[2];
  my $current_allele_name = $alleles->{$imgt_accession};
  if ( !defined($current_allele_name) ) {
    $error_mgr->printMsg( "  Deleted allele ("
        . join( util::Constants::COMMA_SEPARATOR, $imgt_accession,
        $allele_name )
        . ")" );
    $counts->{deleted}++;
    next;
  }
  if ( $current_allele_name ne $allele_name ) {
    $error_mgr->printMsg(
      "  Updated allele ("
        . join( util::Constants::COMMA_SEPARATOR,
        $imgt_accession, $allele_name, $current_allele_name )
        . ")"
    );
    $counts->{replaced}++;
    $row[2] = $current_allele_name;
  }
  $ofh->print( join( util::Constants::TAB, @row ) . "\n" );
}
$fh->close;
$ofh->close;
$error_mgr->printHeader( "Change Counts\n"
    . "  replaced = "
    . $counts->{replaced} . "\n"
    . "  deleted  = "
    . $counts->{deleted} );

################################################################################
#
#				    Epilogue
#
################################################################################

$tools->closeLogging;
$tools->terminate;

################################################################################

__END__

=head1 NAME

checkCanoCwdAlleles.pl

=head1 SYNOPSIS

   checkCanoCwdAlleles.pl
      -P properties_file

Fix the alignment files.

=cut
