package ncbi::EUtils;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use File::Basename;
use FileHandle;
use LWP::Simple;
use Pod::Usage;

use util::Cmd;
use util::Constants;
use util::PathSpecifics;

use file::Index;

use ncbi::ErrMsgs;

use fields
  qw(
  cmds
  data_fh
  data_file
  db
  error_mgr
  num_ids
  num_size
  props
  read_ids
  read_ids_fh
  report
  sleep_int
);

################################################################################
#
#				Constants
#
################################################################################
###
### PubMed NCBI database specifics
###

sub ASN_REPORT  { 'asn.1'; }
sub NCBI_EUTILS { return 'http://www.ncbi.nlm.nih.gov/entrez/eutils'; }
sub PUBMED_DB   { return 'pubmed'; }
sub READ_SUFFIX { return 'read'; }
###
### Error Category
###
sub ERR_CAT { return ncbi::ErrMsgs::EUTILS_CAT; }

################################################################################
#
#				Private Methods
#
################################################################################

sub _openFile {
  my ncbi::EUtils $this = shift;
  my ( $file, $mode ) = @_;
  $file = getPath($file);
  $this->{error_mgr}
    ->printMsg( "Open File\n" . "  file = $file\n" . "  mode = $mode" );
  my $fh = new FileHandle;
  if ( $file =~ /(\.gz|\.Z)$/ ) {
    my $file_str = undef;
    if ( $mode eq '<' ) {
      $file_str = "gunzip -c $file |";
    }
    elsif ( $mode eq '>' ) {
      $file_str = "| gzip -c $file";
    }
    $this->{error_mgr}->hardDieOnError(
      ERR_CAT, 1,
      "Cannot open file = $file on mode = $mode",
      !$fh->open($file_str)
    );
  }
  else {
    $this->{error_mgr}->hardDieOnError(
      ERR_CAT, 1,
      "Cannot open file = $file on mode = $mode",
      !$fh->open( $file, $mode )
    );
  }
  $fh->autoflush(util::Constants::TRUE)
    if ( $mode eq '>' || $mode eq '>>' );
  return $fh;
}

sub _indexFile {
  my ncbi::EUtils $this = shift;
  ###
  ### Index data_file if no index exists
  ###
  my $db_file = join( util::Constants::DOT, $this->{data_file}, 'db' );
  return if ( -e $db_file );
  ###
  ### Now index the data_file
  ###
  my $properties = $this->{props};
  my $indexer    = new file::Index(
    $properties->getProperty('entity_expr'),
    $properties->getProperty('accession_expr'),
    $this->{error_mgr}
  );
  $indexer->createIndex( $this->{data_file} );
}

sub _writeData {
  my ncbi::EUtils $this = shift;
  my ( $result, @cids ) = @_;
  ###
  ### If get no data, return immediately
  ###
  return util::Constants::FALSE
    if ( util::Constants::EMPTY_LINE($result)
    || !$this->resultChecks( $result, scalar @cids ) );
  ###
  ### Proceed with writing process
  ###
  my $properties = $this->{props};
  ###
  ### At this point, increment read_ids count
  ### to determine what to do next:
  ### a.  write to data file, close and index it..
  ### b.  optionally open a data file, and write to it
  ###
  $this->{read_ids} += scalar @cids;
  ###
  ### Write data_file, close, and index it
  ### update the read ids, sleep and then return
  ###
  if ( $this->{read_ids} >= $this->{num_size} ) {
    $this->{read_ids} = 0;
    $this->{error_mgr}->hardDieOnError( "No open data file handle for data",
      !$this->{data_fh}->fileno );
    $this->{data_fh}->print($result);
    $this->{data_fh}->close;
    $this->_indexFile;
    ###
    ### update the read ids
    ###
    $this->{read_ids_fh}
      ->print( join( util::Constants::NEWLINE, @cids ) . "\n" );
    ###
    ### Sleep before resuming gets
    ###
    sleep( $this->{sleep_int} );
    return util::Constants::TRUE;
  }
  ###
  ### Open data file if needs be and update properties
  ###
  if ( !$this->{data_fh}->fileno ) {
    my $indexNum     = $properties->getProperty('index_num');
    my $file_pattern = '.+\.(\d+)\.' . $this->{report};
    my $prefix       = basename( $properties->getProperty('ids_file') );
    $properties->setProperty( 'index_num',    $indexNum + 1 );
    $properties->setProperty( 'pid',          $$ );
    $properties->setProperty( 'file_pattern', $file_pattern );
    $properties->storeFile( $properties->getProperty('property_file') );

    if    ( $indexNum < 10 )   { $indexNum = '000' . $indexNum; }
    elsif ( $indexNum < 100 )  { $indexNum = '00' . $indexNum; }
    elsif ( $indexNum < 1000 ) { $indexNum = '0' . $indexNum; }
    $this->{data_file} = join( util::Constants::SLASH,
      $properties->getProperty('output_directory'),
      join( util::Constants::DOT, $prefix, $indexNum, $this->{report} )
    );
    $this->{data_fh} = $this->_openFile( $this->{data_file}, '>' );
  }
  ###
  ### Write out data and update read ids
  ###
  $this->{data_fh}->print($result);
  $this->{read_ids_fh}->print( join( util::Constants::NEWLINE, @cids ) . "\n" );
  return util::Constants::TRUE;
}

sub _completeRun {
  my ncbi::EUtils $this = shift;
  $this->{read_ids_fh}->close;
  if ( $this->{data_fh}->fileno ) {
    $this->{data_fh}->close;
    $this->_indexFile;
  }
  my $properties = $this->{props};
  $properties->setProperty( 'run_complete', util::Constants::TRUE );
  $properties->storeFile( $properties->getProperty('property_file') );
}
################################################################################
#
#				    Methods
#
################################################################################

sub new {
  my ncbi::EUtils $this = shift;
  my ( $db, $report, $properties, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{cmds}        = new util::Cmd($error_mgr);
  $this->{db}          = $db;
  $this->{data_fh}     = new FileHandle;
  $this->{data_file}   = undef;
  $this->{error_mgr}   = $error_mgr;
  $this->{num_ids}     = 10;
  $this->{num_size}    = 1000;
  $this->{props}       = $properties;
  $this->{read_ids}    = 0;
  $this->{read_ids_fh} = new FileHandle;
  $this->{report}      = $report;
  $this->{sleep_int}   = 3;

  return $this;
}

sub setNumIds {
  my ncbi::EUtils $this = shift;
  my ($num) = @_;
  $num = int($num);
  return if ( $num <= 0 );
  $this->{num_ids} = $num;
}

sub setNumSize {
  my ncbi::EUtils $this = shift;
  my ($num) = @_;
  $num = int($num);
  return if ( $num <= 0 );
  $this->{num_size} = $num;
}

sub setSleepInterval {
  my ncbi::EUtils $this = shift;
  my ($num) = @_;
  $num = int($num);
  return if ( $num <= 0 );
  $this->{sleep_int} = $num;
}

sub resultChecks {
  my ncbi::EUtils $this = shift;
  my ( $eResult, $num_ids ) = @_;
  ###############################
  ### Re-implementable Method ###
  ###############################
  return util::Constants::TRUE;
}

sub getData {
  my ncbi::EUtils $this = shift;
  my $properties = $this->{props};
  ###
  ### short circuit if already got all the data
  ###
  return if ( $properties->getProperty('run_complete') );
  ###
  ### Make sure output directory exists
  ###
  my $outputDir = $properties->getProperty('output_directory');
  $this->{cmds}
    ->createDirectory( $outputDir, "Output Directory = " . $outputDir );
  ###
  ### Read the ids
  ###
  my $ids     = {};
  my $idsFile = $properties->getProperty('ids_file');
  my $idsFh   = $this->_openFile( $idsFile, '<' );
  while ( !$idsFh->eof ) {
    my $line = $idsFh->getline;
    chomp($line);
    if ( $line =~ /(\d+),?$/ ) {
      my $id = $1;
      $ids->{$id} = util::Constants::EMPTY_STR;
    }
  }
  $idsFh->close;
  ###
  ### read the done file and open for more output
  ###
  my $readIds      = {};
  my $readFileMode = undef;
  my $readFile     = $properties->getProperty('read_file');
  if ( -e $readFile ) {
    $readFileMode = '>>';
    my $readIdsFh = $this->_openFile( $readFile, '<' );
    while ( !$readIdsFh->eof ) {
      my $line = $readIdsFh->getline;
      chomp($line);
      if ( $line =~ /(\d+),?$/ ) {
        my $id = $1;
        $readIds->{$id} = util::Constants::EMPTY_STR;
      }
    }
    $readIdsFh->close;
  }
  else {
    $readFileMode = '>';
  }
  $this->{read_ids_fh} = $this->_openFile( $readFile, $readFileMode );
  ###
  ### Get the data for the ids
  ###
  my @ids         = keys %{$ids};
  my @cids        = ();
  my $have_result = util::Constants::TRUE;
  $this->{error_mgr}->printHeader( "Num Ids = " . scalar @ids );
  $this->{read_ids} = 0;
  while ( @ids != 0 ) {
    ###
    ### If do not have result from previous fetch
    ### try again until have a result so as not
    ### to miss data
    ###
    if ($have_result) {
      @cids = ();
      while ( @cids < $this->{num_ids} ) {
        last if ( @ids == 0 );
        my $id = shift(@ids);
        next if ( defined( $readIds->{$id} ) );
        push( @cids, $id );
      }
      last if ( @cids == 0 );
    }
    my $efetch = NCBI_EUTILS
      . "/efetch.fcgi"
      . "?rettype="
      . $this->{report}
      . "&retmode=text"
      . "&retstart=0"
      . "&retmax="
      . scalar @cids . "&db="
      . $this->{db} . "&id="
      . join( util::Constants::COMMA, @cids );
    my $EResult = get($efetch);
    $have_result = $this->_writeData( $EResult, @cids );
  }
  $this->_completeRun;
}

################################################################################

1;

__END__

=head1 NAME

EUtils.pm

=head1 SYNOPSIS

   use EUtils;

   my $eUtils = new ncbi::EUtils($db, $report, error_mgr);
   $eUtils->getData($properties);


=head1 DESCRIPTION

This class reads data from an NCBI database via the web.

=head1 METHODS

=head2 B<new ncbi::EUtils(db, report, properties, error_mgr)>

The new method is the constructor for this class. The B<db> and B<report>
parameters tells the class what NCBI database and report form to request
from NCBI.  The B<properties> object is an instance of L<util::Properties>
and contains the specific parameterization for the reading process.  The 
messaging object B<error_mgr> is an instance of L<util::ErrMgr> 
and is required.

=head2 B<setNumIds(num)>

This method set the number of ids requested the NCBI database at 
a time.  The default is 10.

=head2 B<setNumSize(num)>

This method set the number of ids to segment into a data file at a time.  The
defaut is 1000;

=head2 B<resultChecks(eResult, num_ids)>

This re-implementable method takes the result from the efetch 
and the number of ids requested, and then checks the the
result string conforms to the expected format.  The method
returns a Boolean value.  The default implementation
always return TRUE (1).  This method assumes that the result is non-trivial
since this case is always checked by this class.

=head2 B<getData>

This method generates the data files for the set of ids contained
in the B<ids_file> property.  It manages segmenting the data by size, 
B<num_ids> attributes.  The data files have the format:

  <output_directory>/basename(<ids_file>).index_num.<report>

=cut
