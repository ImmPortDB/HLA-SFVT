package ncbi::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

###
### Error Messages Header
###
sub ERROR_HEADER { return 'NCBI-ERROR: '; }

sub PUBMED_CAT { return -10001000; }    ### PubMed Class
sub EUTILS_CAT { return -10002000; }    ### EUtils Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &PUBMED_CAT =>
      { 1 => "Error has occurred, exting program...\n" . "  errMgs = __1__", },

    &EUTILS_CAT =>
      { 1 => "Error has occurred, exting program...\n" . "  errMgs = __1__", },
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {
    &PUBMED_CAT => 'ncbi::PubMed',
    &EUTILS_CAT => 'ncbi::EUtils'
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrorMsg.pm

=head1 SYNOPSIS

   use ncbi::ErrMsgs;
   $errMsgs = ncbi::ErrMsgs::ERROR_MSGS

=head1 DESCRIPTION

This static class exports one the error messages for this library
which includes those for L<util::ErrMsgs>.

=head1 CONSTANT CLASS METHODS

The following constants define the error message categories:

   ncbi::ErrMsgs::PUBMED_CAT  -- ( 1000) PubMed Class
   ncbi::ErrMsgs::EUTILS_CAT  -- ( 2000) EUtils Class

=head1 STATIC CLASS METHODS

=head2 B<ncbi::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.  It includes the error categories and
messages in L<util::ErrMsgs>.

=head2 B<ncbi::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.  It includes the error
category names in L<util::ErrMsgs>.

=cut
