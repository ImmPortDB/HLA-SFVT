package html::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#			     Constant Class Methods
#
################################################################################

###
### Error Messages Header
###
sub ERROR_HEADER { return 'HTML-ERROR: '; }

sub POD_CAT  { return -1000001000; }    ### Pod Class
sub REFS_CAT { return -1000002000; }    ### Refs Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &POD_CAT => {
      1 => "No file root\n" . "  fille_root = __1__",


      2 => "Static class but has a base class\n"
        . "  class name = __1__\n"
        . "  file       = __2__",

      3 => "Class not static, base or child\n"
        . "  class name = __1__\n"
        . "  file       = __2__",

      4 => "Cannot open template file to read\n" . "  template_file = __1__",

      5 => "Cannot open find code root\n" . "  code root = __1__",

      6 => "Unable to copy class structure file to library\n"
		 . "  source = __1__\n"
		 . "  destin = __2__",

    },

    &REFS_CAT => {
      1 => "Cannot open html_file to read\n" . "  html_file = __1__",

      2 => "Cannot open html_file to write\n" . "  html_file = __1__",

      3 => "No html root\n" . "  html_root = __1__",
    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {
    &POD_CAT  => 'html::Pod',
    &REFS_CAT => 'html::Refs',
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrorMsg.pm

=head1 SYNOPSIS

   use html::ErrMsgs;
   $errMsgs = html::ErrMsgs::ERROR_MSGS

=head1 DESCRIPTION

This static class exports one the error messages for this library
which includes those for L<util::ErrMsgs>.

=head1 CONSTANT CLASS METHODS

The following constants define the error message categories:

   html::ErrMsgs::POD_CAT   -- ( -1000001000) Pod Class
   html::ErrMsgs::REFS_CAT  -- ( -1000002000) Refs Class

=head1 STATIC CLASS METHODS

=head2 B<html::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.  It includes the error categories and
messages in L<util::ErrMsgs>.

=head2 B<html::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.  It includes the error
category names in L<util::ErrMsgs>.

=cut
