package html::Pod;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use File::Find ();
use Pod::Usage;

use util::Cmd;
use util::Constants;
use util::PathSpecifics;

use html::ErrMsgs;

use fields
  qw(
  cmds
  error_mgr
  file_suffixes
  html_path
  html_root
  html_suffix
  library_path
  library_suffix
);

################################################################################
#
#				Initializations
#
################################################################################

###
### for the convenience of &wanted calls,
### including -eval statements:
###
use vars qw(*FIND_NAME
  *FIND_DIR
  *FIND_PRUNE);
*FIND_NAME  = *File::Find::name;
*FIND_DIR   = *File::Find::dir;
*FIND_PRUNE = *File::Find::prune;

################################################################################
#
#				   Constants
#
################################################################################
###
### Suffixes
###
sub HTML_SUFFIX { return 'html'; }
sub PL_SUFFIX   { return 'pl'; }
sub PM_SUFFIX   { return 'pm'; }
###
### Paths
###
sub TRUNK_PATH { return 'trunk'; }
sub LIB_PATH   { return 'lib'; }
###
### any file
###
sub _ANY_STR_ { return util::Constants::EMPTY_STR; }
###
### Error Category
###
sub ERR_CAT { return html::ErrMsgs::POD_CAT; }

################################################################################
#
#				 Private Method
#
################################################################################

sub _fileType {
  my html::Pod $this = shift;
  my ($basename) = @_;
  foreach my $suffix ( keys %{ $this->{file_suffixes} } ) {
    next if ( $suffix eq &_ANY_STR_ );
    if ( $basename =~ /\.$suffix$/ ) {
      return $suffix;
    }
  }
  return util::Constants::EMPTY_STR;
}

sub _trimFile {
  my html::Pod $this = shift;
  my ($basename)     = @_;
  my $suffix         = $this->_fileType($basename);
  if ($suffix) { $basename =~ s/\.$suffix$//; }
  return $basename;
}

my @_FILES_ = ();

sub _filesWanted {
  my html::Pod $this = shift;
  my $file_pattern = util::Constants::ANY_STR;
  if ( !defined( $this->{file_suffixes}->{&_ANY_STR_} ) ) {
    my $first_suffix = util::Constants::TRUE;
    foreach my $suffix ( keys %{ $this->{file_suffixes} } ) {
      if ($first_suffix) { $file_pattern .= '\.('; }
      else { $file_pattern .= '|'; }
      $first_suffix = util::Constants::FALSE;
      my $suffix_pattern = $suffix;
      $suffix_pattern =~ s/\./\\\./;
      $file_pattern .= $suffix_pattern;
    }
    if ( !$first_suffix ) { $file_pattern .= ')'; }
  }
  return sub {
    my ( $dev, $ino, $mode, $nlink, $uid, $gid );

    ( ( $dev, $ino, $mode, $nlink, $uid, $gid ) = lstat($_) )
      && -f _
      && /^$file_pattern\z/s
      && push( @_FILES_, $FIND_NAME );
    }
}

###
### Given the full filename of the file generate its Html Page
###
sub _generate {
  my html::Pod $this = shift;
  my ($file) = @_;
  ###
  ### Html and Pod Roots
  ###
  my $html_root =
    join( util::Constants::SLASH, $this->{html_root}, @{ $this->{html_path} } );
  my $pod_root =
    join( util::Constants::SLASH, $html_root, @{ $this->{library_path} } );
  my @html_path_comps      = @{ $this->{html_path} };
  my $num_html_path_comps  = $#html_path_comps + 1;
  my $first_html_path_comp = shift(@html_path_comps);
  ###
  ### For library modules only use those that conform
  ###
  my ( $file_basename, $html_path ) = setPath($file);
  ###
  ### The html base filename (remove suffix and replace with html
  ###
  my $html_file = join( util::Constants::DOT,
    $this->_trimFile($file_basename),
    $this->{html_suffix}
  );
  ###
  ### Create the html path (this assumes that
  ### file exists in html hierarchy)
  ###
  $html_path =~ s/\/$//;
  my @html_comps = split( /\//, $html_path );
  shift(@html_comps);
  my $found_html_path = util::Constants::FALSE;
OUTER_LOOP:
  while ( @html_comps != 0 ) {
    my $comp = shift(@html_comps);
    if ( $comp eq $first_html_path_comp ) {
      my $index = 0;
      foreach my $path_comp (@html_path_comps) {
        last OUTER_LOOP if ( $path_comp ne $html_path_comps[$index] );
        $index++;
      }
      $found_html_path = util::Constants::TRUE;
      last;
    }
  }
  next if ( !$found_html_path );
  $html_path = join( util::Constants::SLASH, $html_root, @html_comps );
  ###
  ###
  ###
  my $html_title = undef;
  if ( $this->_fileType($file_basename) eq $this->{library_suffix} ) {
    $html_title = join(
      util::Constants::COLON . util::Constants::COLON,
      @html_comps[ $num_html_path_comps .. $#html_comps ],
      $this->_trimFile($file_basename)
    );
  }
  else {
    $html_title = $file_basename;
  }
  $this->{cmds}
    ->createDirectory( $html_path, "Creating html_path = $html_path" );
  ###
  ### Create the html file name and remove if already there
  ###
  $html_file = join( util::Constants::SLASH, $html_path, $html_file );
  unlink($html_file);
  $this->{cmds}->executeCommand(
    {
      title    => $html_title,
      infile   => $file,
      outfile  => $html_file,
      podroot  => $pod_root,
      htmlroot => $pod_root,
    },
    "pod2html"
      . " --header"
      . " --title=$html_title"
      . " --infile=$file"
      . " --outfile=$html_file"
      . " --podroot=$pod_root"
      . " --htmlroot=$pod_root",
    "Generating Pod html..."
  );
}

################################################################################
#
#				 Public Methods
#
################################################################################

sub new {
  my html::Pod $this = shift;
  my ( $html_root, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  $this->{cmds}           = new util::Cmd($error_mgr);
  $this->{file_suffixes}  = { &PM_SUFFIX => util::Constants::EMPTY_STR, };
  $this->{html_path}      = [TRUNK_PATH];
  $this->{html_suffix}    = HTML_SUFFIX;
  $this->{library_path}   = [LIB_PATH];
  $this->{library_suffix} = PM_SUFFIX;
  $this->{error_mgr}      = $error_mgr;

  chdir(util::Constants::DOT);
  $this->{html_root} = getPath($html_root);

  return $this;
}

sub generatePage {
  my html::Pod $this = shift;
  my ($file) = @_;

  my $current_dir = $ENV{PWD};
  $file = getPath($file);
  $this->_generate($file);
}

sub generatePages {
  my html::Pod $this = shift;
  my ($file_root) = @_;

  my $current_dir = $ENV{PWD};
  $file_root = getPath($file_root);
  ###
  ### Get the raw files
  ###
  $this->{error_mgr}->exitProgram( ERR_CAT, 1, [$file_root],
    !-e $file_root || !-d $file_root || !chdir($file_root) );
  @_FILES_ = ();
  File::Find::find( { wanted => $this->_filesWanted }, util::Constants::DOT );
  my @raw_files = @_FILES_;
  @_FILES_ = ();
  chdir($current_dir);
  foreach my $file (@raw_files) {
    ###
    ### Get the full filename
    ###
    $file =~ s/^\.\///;
    $file = join( util::Constants::SLASH, $file_root, $file );

    $this->_generate($file);
  }
}

sub setLibrarySuffix {
  my html::Pod $this = shift;
  my ($suffix) = @_;
  return if ( !defined($suffix)
    || $suffix eq util::Constants::EMPTY_STR );
  $suffix =~ s/^\.//;
  $this->{library_suffix} = $suffix;
}

sub setFileSuffix {
  my html::Pod $this = shift;
  my ($suffix) = @_;
  return if ( !defined($suffix) );
  $suffix =~ s/^\.//;
  $suffix =~ s/\.$//;
  $this->{file_suffixes}->{$suffix} = util::Constants::EMPTY_STR;
}

sub setHtmlSuffix {
  my html::Pod $this = shift;
  my ($suffix) = @_;
  return if ( !defined($suffix)
    || $suffix eq util::Constants::EMPTY_STR );
  $this->{html_suffix} = $suffix;
}

sub setLibraryPath {
  my html::Pod $this = shift;
  my ($library_path) = @_;
  return
    if ( !defined($library_path)
    || $library_path eq util::Constants::EMPTY_STR );
  $this->{library_path} = [ split( /\//, $library_path ) ];
}

sub setHtmlPath {
  my html::Pod $this = shift;
  my ($html_path) = @_;
  return
    if ( !defined($html_path)
    || $html_path eq util::Constants::EMPTY_STR );
  $this->{html_path} = [ split( /\//, $html_path ) ];
}

sub unsetFileSuffix {
  my html::Pod $this = shift;
  my ($suffix) = @_;
  return if ( !defined($suffix) );
  delete( $this->{file_suffixes}->{$suffix} );
}

################################################################################

1;

__END__

=head1 NAME

Pod.pm

=head1 SYNOPSIS

  use html::Pod;

  $html = new html::Pod($html_root);

=head1 DESCRIPTION

This class provides a mechanism for the generation of HTML pages form
Perl Pod files.  Also, it follows a protocol so that HTML pages can
reference one another.  This class use the pod2html tool.

=head1 CONSTANTS

The following suffix constants are exported by this class:

   html::Pod::HTML_SUFFIX -- 'html'
   html::Pod::PL_SUFFIX   -- 'pl'
   html::Pod::PM_SUFFIX   -- 'pm'

The following path constants are exportd by this class:

   html::Pod::TRUNK_PATH  -- 'trunk'
   html::Pod::LIB_PATH    -- 'lib'

=head1 SETTER METHODS

The following setter methods are exported by this class.

=head2 B<$html-E<gt>setLibrarySuffix(suffix)>

This method sets the library module suffix that will be used to
determine library modules for which Pod-based html pages will be
generated.  By default, the this suffix is B<'.pm'>.  The B<suffix>
must defined and non-empty.

=head2 B<$html-E<gt>setFileSuffix(suffix)>

This method adds a suffix to the files that will be used to determine
files for which Pod-based html pages will be generated.  By default,
these suffixes include the library module suffix.  Note that if the
B<suffix> is set to the empty string, then all files will be used.
The B<suffix> must defined.  The assumption is that the file suffix is
of the form B<.suffix>.

=head2 B<$html-E<gt>setHtmlSuffix(suffix)>

This method sets the html suffix to used for the html pages generated.
By default, the suffix is B<'.html'>.  The name of the htlm page file
generated will be basename of the file with its suffix replaced by the
html suffix.  The B<suffix> must defined and non-empty.

=head2 B<$html-E<gt>setLibraryPath(library_path)>

This method sets the standard perl library module path under the html
hierarchy path (B<html_root_path>.  All library modules will be
located under this path.  By default, the library path is B<'lib'>
(and under the B<html_root> it is B<'trunk/lib'>).  This library path is
essential for hyper-links between html pages to work correctly.  The
B<library_path> must defined and non-empty.

=head2 B<$html-E<gt>setHtmlPath(html_path)>

This method sets the standard relative B<html_root_path> for all Perl
and html files.  This is the relative root of the html hierarchy.  By
default, this root path is B<'trunk'>.  The B<html_path> must defined
and non-empty.

=head2 B<$html-E<gt>unsetFileSuffix(suffix)>

This method removes a suffix that will be used to determine files for
which Pod-based html pages will be generated.  The B<suffix> must
defined

=head1 METHODS

The following methods are provided for this class.

=head2 B<new html::Pod(html_root, error_mgr)>

This method is the constructor for the class.  This constructor
creates all attributes with default settings and set the html root
directory to B<html_root>.  This is the root of the html hierachy for
generating html pages using this object.

=head2 B<$html-E<gt>generatePages(file_root)>

This method generates Pod html pages for all files of the appropriate
type (with set suffixes) under the B<file_root> directory and deposits
them into the html hierarchy rooted at the B<html_root> of the object.
The mechanism assumes that the files used to generate the html pages
have a corresponding relative hierarchy starting at the
B<html_root_path>.

=head2 B<$html-E<gt>generatePage(file)>

This method generates Pod html page for the specified file and
deposits it into the html hierarchy rooted at the B<html_root> of the
object.  The mechanism assumes that the files used to generate the
html pages have a corresponding relative hierarchy starting at the
B<html_root_path>.

=cut
