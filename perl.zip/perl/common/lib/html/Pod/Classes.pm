package html::Pod::Classes;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use Pod::Usage;

use util::Constants;
use util::ErrMgr;
use util::PathSpecifics;
use util::PerlObject;
use util::Table;

use html::ErrMsgs;

use base 'html::Pod';

use fields
  qw(
  classes
  current_directory
  code_root
  file_to_class_map
  library_paths
  library_name
  log_mgr
);

################################################################################
#
#				   Constants
#
################################################################################

sub CLASS_FILE {
  return join( util::Constants::DOT, 'ClassStructure', 'pl' );
}

sub CLASS_LOG {
  return join( util::Constants::DOT, 'GenerateHtmlClasses', 'log', 'pl' );
}
###
### Class Path separator
###
sub CLASS_PATH_SEPARATOR { return '::'; }
###
### fnd class data
###
sub FIND_CLASS_HIERARCHY {
  return 'find . -name "*pm" -print -exec egrep "^(package|use base) " {} \;';
}
###
### find methods
###
sub LIBRARY_NAME { return '__library_name__'; }

sub FIND_METHODS {
  return
'find . -name "*pm" -print -exec egrep "^(sub |  my __library_name__::)" {} \;';
}
###
### Method types
###
sub METHOD_METHOD { return 'method'; }
sub STATIC_METHOD { return 'static'; }
###
### Class Types
###
sub BASE_CLASS_TYPE       { return 'base'; }
sub CHILD_CLASS_TYPE      { return 'child'; }
sub OTHER_BASE_CLASS_TYPE { return 'other_base'; }
sub STATIC_CLASS_TYPE     { return 'static'; }
###
### Special Methods
###
sub CONSTRUCTOR_METHOD { return '^(new|new.+)$'; }
###
### Reporting Stuff
###
sub CLASS_DEFINED_HEADER { return 'CLASS DEFINED'; }
sub CLASS_LINEAGE_HEADER { return 'CLASS LINEAGE'; }
sub METHOD_NAME_HEADER   { return 'METHOD NAME'; }

sub INDENT        { return '   '; }
sub INDENT_LENGTH { return length(INDENT); }
###
### Perl header
###
sub PERL_HEADER {
  return join( util::Constants::NEWLINE,
    '#!/usr/local/bin/perl',  util::Constants::EMPTY_STR,
    'use strict;',            util::Constants::EMPTY_STR,
    'use Pod::Usage;',        util::Constants::EMPTY_STR,
    '__END__',                util::Constants::EMPTY_STR,
    '=head1 NAME',            util::Constants::EMPTY_STR,
    'Class Structure Report', util::Constants::EMPTY_STR,
    '=head1 RUN INFORMATION', util::Constants::EMPTY_STR
  );
}
sub PERL_FOOTER { return '=cut'; }
###
### Error Category
###
sub ERR_CAT { return html::ErrMsgs::POD_CAT; }

################################################################################
#
#				 Private Method
#
################################################################################

sub _determineLibraries {
  my html::Pod::Classes $this = shift;

  chdir( $this->{code_root} );
  opendir( CODE_DIR, $this->{code_root} );
  my @projects = grep( !/^\.+$/, grep( -d, readdir(CODE_DIR) ) );
  closedir(CODE_DIR);
  $this->{library_paths} = {};
  foreach my $project (@projects) {
    my $library_path = join( util::Constants::SLASH,
      $this->{code_root}, $project, 'lib', $this->{library_name} );
    next if ( !-e $library_path || !-d $library_path );
    $this->{library_paths}->{$library_path} = $project;
  }

}

sub _processPackages {
  my html::Pod::Classes $this = shift;

  foreach my $library_path ( keys %{ $this->{library_paths} } ) {
    chdir($library_path);
    open( MY_DATA, &FIND_CLASS_HIERARCHY . '|' );
    my $class_file    = undef;
    my $current_class = undef;
    my $separator     = CLASS_PATH_SEPARATOR;
    while (<MY_DATA>) {
      chomp;
      my $line = $_;
      if ( $line =~ /^\.\/(.+)/ ) {
        $class_file = join( util::Constants::SLASH, $library_path, $1 );
        $current_class = undef;
      }
      elsif ( $line =~ /^package (.+);/ ) {
        $current_class = $1;
        my @class_path = split( /$separator/, $current_class );
        $this->{classes}->{$current_class} = {
          file        => $class_file,
          name        => $current_class,
          path        => \@class_path,
          base        => undef,
          type        => undef,
          methods     => {},
          all_methods => {}
        };
        $this->{file_to_class_map}->{$class_file} =
          $this->{classes}->{$current_class};
      }
      elsif ( $line =~ /^use base '(.+)';/ ) {
        $this->{classes}->{$current_class}->{base} = $1;
      }
    }
    close(MY_DATA);
  }
}

sub _processMethods {
  my html::Pod::Classes $this = shift;
  my $find_methods_pattern    = FIND_METHODS;
  my $library_name_pattern    = LIBRARY_NAME;
  my $library_name            = $this->{library_name};
  $find_methods_pattern =~ s/$library_name_pattern/$library_name/;

  foreach my $library_path ( keys %{ $this->{library_paths} } ) {
    chdir($library_path);
    open( MY_DATA, $find_methods_pattern . '|' );
    my $class       = undef;
    my $class_file  = undef;
    my $class_name  = undef;
    my $method_name = undef;
    while (<MY_DATA>) {
      chomp;
      my $line = $_;
      if ( $line =~ /^\.\/(.+)/ ) {
        $class_file = join( util::Constants::SLASH, $library_path, $1 );
        $class      = $this->{file_to_class_map}->{$class_file};
        $class_name = $class->{name};
      }
      elsif ( $line =~ /^sub (.+) \{/ ) {
        $method_name = $1;
        $class->{methods}->{$method_name} = STATIC_METHOD;
      }
      elsif ( $line =~ /^  my $class_name / ) {
        $class->{methods}->{$method_name} = METHOD_METHOD;
      }
    }
    close(MY_DATA);
  }
}

sub _determineClassType {
  my html::Pod::Classes $this = shift;
  my ($class) = @_;

  my $methods            = $class->{methods};
  my $found_method       = util::Constants::FALSE;
  my $found_constructor  = util::Constants::FALSE;
  my $constructor_method = CONSTRUCTOR_METHOD;
  while ( my ( $method, $type ) = each %{$methods} ) {
    if ( $type eq METHOD_METHOD ) {
      $found_method = util::Constants::TRUE;
    }
    if ( $method =~ /$constructor_method/ ) {
      $found_constructor = util::Constants::TRUE;
    }
  }
  if ( !$found_method && !$found_constructor ) {
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 2,
      [ $class->{name}, $class->{file} ],
      defined( $class->{base} )
    );
    $class->{type} = STATIC_CLASS_TYPE;
  }
  elsif ( $found_method && $found_constructor ) {
    if ( defined( $class->{base} ) ) {
      $class->{type} = CHILD_CLASS_TYPE;
    }
    else {
      $class->{type} = BASE_CLASS_TYPE;
    }
  }
  elsif ($found_constructor) {
    $class->{type} = OTHER_BASE_CLASS_TYPE;
  }
  else {
    $this->{error_mgr}
      ->exitProgram( ERR_CAT, 3, [ $class->{name}, $class->{file} ],
      util::Constants::TRUE );
  }
}

sub _determineMethods {
  my html::Pod::Classes $this = shift;
  my ( $class_name, $methods ) = @_;
  return if ( !defined($class_name) );
  my $class = $this->{classes}->{$class_name};
  return if ( !defined($class) );
  foreach my $method ( keys %{ $class->{methods} } ) {
    if ( defined( $methods->{$method} ) ) {
      unshift( @{ $methods->{$method}->{lineage} }, $class_name );
    }
    else {
      $methods->{$method} = {
        name    => $method,
        type    => $class->{methods}->{$method},
        defn    => $class_name,
        lineage => [$class_name],
      };
    }
  }
  $this->_determineMethods( $class->{base}, $methods );
}

sub _printMessage {
  my html::Pod::Classes $this = shift;
  my ($msg) = @_;
  my @msg_comps = split( /\n/, $msg );
  my @msg = ();
  foreach my $comp (@msg_comps) {
    push( @msg, &INDENT . $comp );
  }
  $this->{log_mgr}->printMsg( join( util::Constants::NEWLINE, @msg ) );
}

sub _printTemplate {
  my html::Pod::Classes $this = shift;
  my ($library_template) = @_;
  $this->{error_mgr}->exitProgram( ERR_CAT, 4, [$library_template],
    !open( INTRO, "<$library_template" ) );
  my $description = util::Constants::NEWLINE;
  while (<INTRO>) { $description .= $_; }
  close(INTRO);
  $description .= util::Constants::NEWLINE;
  $this->{log_mgr}->printMsg($description);
}

sub _printDebug {
  my html::Pod::Classes $this = shift;
  my ( $file, @structs ) = @_;
  return if ( !$this->{error_mgr}->isDebugging );
  unlink($file);
  my $objFile = new util::PerlObject( $file, undef, $this->{error_mgr} );
  foreach my $struct (@structs) {
    $objFile->writeStream( $struct,
      util::PerlObject::PERL_OBJECT_WRITE_OPTIONS );
  }
  $objFile->closeIo;
}

################################################################################
#
#				 Public Methods
#
################################################################################

sub new {
  my ( $that, $code_root, $html_root, $error_mgr ) = @_;
  my html::Pod::Classes $this = $that->SUPER::new( $html_root, $error_mgr );

  $this->{classes}           = undef;
  $this->{current_directory} = undef;
  $this->{code_root}         = getPath($code_root);
  $this->{file_to_class_map} = undef;
  $this->{library_paths}     = undef;
  $this->{log_mgr}           = undef;
  $this->{library_name}      = undef;
  ###
  ### Make sure code root exists...
  ###
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 5,
    [ $this->{code_root} ],
    !-e $this->{code_root} | !-d $this->{code_root}
  );

  return $this;
}

sub generateClassFile {
  my html::Pod::Classes $this = shift;
  my ( $library_name, $library_template ) = @_;

  chdir(util::Constants::DOT);
  $this->{current_directory} = $ENV{PWD};
  ###
  ### Initialize attributes
  ###
  $this->{classes}           = {};
  $this->{file_to_class_map} = {};
  $this->{library_name}      = $library_name;

  $this->_determineLibraries;
  ###
  ### Open logging file and write header including tempate
  ###
  $this->{log_mgr} = new util::ErrMgr;
  my $log_mgr      = $this->{log_mgr};
  my $logging_file =
    join( util::Constants::SLASH, $this->{code_root}, CLASS_LOG );
  $log_mgr->openFile($logging_file);
  $log_mgr->printMsg(PERL_HEADER);
  $log_mgr->printMsg(util::Constants::EMPTY_STR);
  $this->_printMessage(
    CLASS_LOG . "
  Library Name   - $library_name
  Code Root      - " . $this->{code_root} . "
  Template File  - $library_template
  CURRENT_TIME   - " . `date`
  );
  $this->_printTemplate($library_template);
  $log_mgr->printMsg(
    join( util::Constants::NEWLINE,
      util::Constants::EMPTY_STR, '=head1 CLASS DECOMPOSITION',
      util::Constants::EMPTY_STR
    )
  );
  $log_mgr->printMsg(util::Constants::EMPTY_STR);
  ###
  ### Compute Class Structure
  ###
  $this->{error_mgr}->printDebug('Class Hierarchy');
  $this->_processPackages;
  $this->{error_mgr}->printDebug('Class Methods');
  $this->_processMethods;
  ###
  ### Write Intermediate File
  ###
  my $classes_file =
    join( util::Constants::SLASH, $this->{html_root}, CLASS_LOG );
  $this->_printDebug(
    join( util::Constants::DOT, $classes_file, 'INTERMEDIATE' ),
    $this->{classes}, $this->{file_to_class_map} );
  ###
  ### Perform the post processing operations:
  ### 1.  Determine Class Type and verify constructor
  ### 2.  Determine methods and lineage and definition
  ###
  foreach my $class ( values %{ $this->{classes} } ) {
    $this->_determineClassType($class);
  }
  foreach my $class_name ( keys %{ $this->{classes} } ) {
    my $all_methods = $this->{classes}->{$class_name}->{all_methods};
    $this->_determineMethods( $class_name, $all_methods );
  }
  ###
  ### Create Table and Write Classes File
  ###
  $this->_printDebug( $classes_file, $this->{classes} );
  my @single_ord = ( 'method', 'class' );
  my @multiple_ord = ( 'method', 'class', 'lineage' );
  my $ord_fcn = 'sub {$a->{method} cmp $b->{method};}';
  my $table   = new util::Table(
    $log_mgr,
    class   => CLASS_DEFINED_HEADER,
    lineage => CLASS_LINEAGE_HEADER,
    method  => METHOD_NAME_HEADER
  );
  $table->setIndent(INDENT_LENGTH);
  foreach my $col (@multiple_ord) {
    $table->setColumnJustification( $col, util::Table::LEFT_JUSTIFY );
  }
  my @data    = ();
  my $heading = util::Constants::EMPTY_STR;
  ###
  ### Report Findings
  ###
  $this->{error_mgr}->printDebug("Report Findings");
  foreach my $class_name ( sort keys %{ $this->{classes} } ) {
    my $class = $this->{classes}->{$class_name};
    my $base  = $class->{base};
    $base = ( defined($base) ) ? $base : util::Constants::EMPTY_STR;
    $log_mgr->printHeader(
      "Class Information\n"
        . "name = $class_name\n"
        . "file = "
        . $class->{file} . "\n"
        . "type = "
        . $class->{type} . "\n"
        . "base = $base",
      INDENT_LENGTH
    );
    $log_mgr->printMsg(util::Constants::EMPTY_STR);
    ###
    ### First Static Methods
    ###
    $table->setColumnOrder(@single_ord);
    $table->setRowOrder($ord_fcn);
    @data    = ();
    $heading = 'STATIC METHODS';
    foreach my $method_name ( keys %{ $class->{all_methods} } ) {
      my $method = $class->{all_methods}->{$method_name};
      next if ( $method->{type} ne STATIC_METHOD );
      my $struct = {
        method => $method_name,
        class  => $method->{defn},
      };
      push( @data, $struct );
    }
    if ( @data > 0 ) {
      $table->setData(@data);
      $table->generateTable($heading);
      $log_mgr->printMsg(util::Constants::EMPTY_STR);
    }
    ###
    ### Second, Non-Static singly defined
    ###
    @data    = ();
    $heading = 'NON-STATIC METHODS SINGLY DEFINED';
    foreach my $method_name ( keys %{ $class->{all_methods} } ) {
      my $method = $class->{all_methods}->{$method_name};
      next
        if ( $method->{type} ne METHOD_METHOD
        || @{ $method->{lineage} } > 1 );
      my $struct = {
        method => $method_name,
        class  => $method->{defn},
      };
      push( @data, $struct );
    }
    if ( @data > 0 ) {
      $table->setData(@data);
      $table->generateTable($heading);
      $log_mgr->printMsg(util::Constants::EMPTY_STR);
    }
    ###
    ### Second, Non-Static multiply defined
    ###
    $table->setColumnOrder(@multiple_ord);
    $table->setRowOrder(undef);
    @data    = ();
    $heading = 'NON-STATIC METHODS MULTIPLY DEFINED';
    foreach my $method_name ( sort keys %{ $class->{all_methods} } ) {
      my $method = $class->{all_methods}->{$method_name};
      next
        if ( $method->{type} ne METHOD_METHOD
        || @{ $method->{lineage} } == 1 );
      my $first_lineage = util::Constants::TRUE;
      foreach my $lineage ( @{ $method->{lineage} } ) {
        my $struct = {
          method => $first_lineage ? $method_name : util::Constants::EMPTY_STR,
          class => $first_lineage
          ? $method->{defn}
          : util::Constants::EMPTY_STR,
          lineage => $lineage,
        };
        push( @data, $struct );
        $first_lineage = util::Constants::FALSE;
      }
    }
    if ( @data > 0 ) {
      $table->setData(@data);
      $table->generateTable($heading);
    }
  }
  $log_mgr->printMsg(
    CLASS_LOG . "
     CURRENT_TIME          - " . `date`
  );
  $log_mgr->printMsg(util::Constants::EMPTY_STR);
  $log_mgr->printMsg(PERL_FOOTER);
  $log_mgr->closeFile;
  ###
  ### Foreach html_path for which the library exists,
  ### copy the file and generate pod
  ###
  while ( my ( $library_path, $html_path ) = each %{ $this->{library_paths} } )
  {
    my $class_file = join( util::Constants::SLASH, $library_path, CLASS_FILE );
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 6,
      [ $logging_file, $class_file ],
      $this->{cmds}->executeCommand(
        {
          source => $logging_file,
          target => $class_file
        },
        $this->{cmds}->COPY_FILE( $logging_file, $class_file ),
        "Copying class file..."
      )
    );
    $this->setHtmlPath($html_path);
    $this->generatePage($class_file);
  }
  unlink($logging_file);

  chdir( $this->{current_directory} );
}

################################################################################

1;

__END__

=head1 NAME

Classes.pm

=head1 SYNOPSIS

  use html::Pod::Classes;

  $html = new html::Pod::Classes($code_root, $html_root, $log_mgr );
  $html->generateClassFile(library_name, library_template);

=head1 DESCRIPTION

This class provides a mechanism for the generation of HTML Class structure page
for a a given html_path.  This class is a subclass of L<html::Pod>.

=head1 METHODS

The following methods are provided for this class.

=head2 B<new html::Pod::Classes(code_root, html_root, error_mgr)>

This method is the constructor for the class.

=head2 B<$html-E<gt>generateClassFile(html_path, library_template)>

This method generates the Pod html class structure file for the html_path.

=cut
