package html::Refs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Cwd 'chdir';
use File::Find ();
use FileHandle;
use Pod::Usage;

use util::Constants;
use util::PathSpecifics;

use html::ErrMsgs;

use fields qw(
  error_mgr
  html_paths
  html_root
  refs
  replace_refs
);

################################################################################
#
#				Initializations
#
################################################################################

###
### for the convenience of &wanted calls,
### including -eval statements:
###
use vars qw(*FIND_NAME
  *FIND_DIR
  *FIND_PRUNE);
*FIND_NAME  = *File::Find::name;
*FIND_DIR   = *File::Find::dir;
*FIND_PRUNE = *File::Find::prune;

################################################################################
#
#				   Constants
#
################################################################################
###
### Suffixes
###
sub HTML_SUFFIX { return 'html'; }
###
### any file
###
sub _ANY_STR_ { return util::Constants::EMPTY_STR; }
###
### Error Category
###
sub ERR_CAT { return html::ErrMsgs::REFS_CAT; }

################################################################################
#
#				 Private Method
#
################################################################################

my @_HTML_FILES_ = ();

sub _filesWanted {
  my html::Refs $this = shift;
  my $file_pattern = '.+\.' . HTML_SUFFIX;
  return sub {
    my ( $dev, $ino, $mode, $nlink, $uid, $gid );

    ( ( $dev, $ino, $mode, $nlink, $uid, $gid ) = lstat($_) )
      && -f _
      && /^$file_pattern\z/s
      && push( @_HTML_FILES_, $FIND_NAME );
    }
}

sub _getRefSuffix {
  my html::Refs $this = shift;
  my ( $html_path, $ref ) = @_;
  my $ref_suffix = $ref;
  my $pattern    = join( util::Constants::SLASH,
    $this->{html_root}, $html_path, util::Constants::EMPTY_STR );
  $pattern    =~ s/\./\\\./;
  $pattern    =~ s/\//\\\//;
  $ref_suffix =~ s/^$pattern//;
  return $ref_suffix;
}

sub _getRef {
  my html::Refs $this = shift;
  my ( $html_path, $ref ) = @_;

  my $refs         = $this->{refs};
  my $replace_refs = $this->{replace_refs};
  ###
  ### return immediately if reference exists...
  ###
  return $ref if ( defined( $refs->{$ref} ) );
  ###
  ### determine new reference, if there is one.
  ###
  my $ref_suffix = $this->_getRefSuffix( $html_path, $ref );
  my $missing_ref = !defined( $replace_refs->{$ref_suffix} );
  $this->{error_mgr}->printWarning(
    "Cannot find reference\n"
      . "  html_root  = "
      . $this->{html_root} . "\n"
      . "  html_path  = $html_path\n"
      . "  html_paths = ("
      . join( util::Constants::COMMA_SEPARATOR, @{ $this->{html_paths} } )
      . ")\n"
      . "  ref suffix = $ref_suffix\n"
      . "  ref        = $ref",
    $missing_ref
  );
  return $ref if ($missing_ref);
  return $replace_refs->{$ref_suffix};
}

sub _fixHtmlFile {
  my html::Refs $this = shift;
  my ( $html_path, $file ) = @_;
  ###
  ### Get the html file
  ###
  my $fh = new FileHandle;
  $this->{error_mgr}
    ->exitProgram( ERR_CAT, 1, [$file], !$fh->open( $file, '<' ) );
  my @lines = ();
  while ( !$fh->eof ) {
    my $line = $fh->getline;
    push( @lines, $line );
  }
  $fh->close;
  ###
  ### Write the html file
  ###
  $this->{error_mgr}
    ->exitProgram( ERR_CAT, 2, [$file], !$fh->open( $file, '>' ) );
  foreach my $line (@lines) {
    if ( $line =~ /<a href="(\/.+\.html)">/ ) {
      ###
      ### There may be more than one <a href=" on a line
      ###
      my $working_line = $line;
      $working_line =~ s/<\/a>/<\/a>\n/g;
      my @segments = split( /\n/, $working_line );
      foreach my $segment (@segments) {
        next if ( $segment !~ /<a href="(\/.+\.html)">/ );
        my $ref = $1;
        my $new_ref = $this->_getRef( $html_path, $ref );
        if ( $new_ref ne $ref ) {
          $line =~ s/<a href="$ref">/<a href="$new_ref">/;
        }
      }
    }
    $fh->print($line);
  }
  $fh->close;
}

sub _computeRefs {
  my html::Refs $this = shift;
  my ($html_files) = @_;

  $this->{refs}         = {};
  $this->{replace_refs} = {};
  my $replace_refs = $this->{replace_refs};
  foreach my $html_path ( @{ $this->{html_paths} } ) {
    my $files = $html_files->{$html_path};
    foreach my $html_file ( keys %{$files} ) {
      my $ref = $files->{$html_file};
      $this->{refs}->{$ref} = util::Constants::EMPTY_STR;
      my $ref_suffix = $this->_getRefSuffix( $html_path, $ref );
      next if ( defined( $replace_refs->{$ref_suffix} ) );
      $replace_refs->{$ref_suffix} = $files->{$html_file};
    }
  }
}

################################################################################
#
#				 Public Methods
#
################################################################################

sub new {
  my html::Refs $this = shift;
  my ( $html_root, $error_mgr ) = @_;
  $this = fields::new($this) unless ref($this);

  chdir(util::Constants::DOT);

  $this->{html_paths}   = [];
  $this->{html_root}    = getPath($html_root);
  $this->{error_mgr}    = $error_mgr;
  $this->{replace_refs} = {};
  $this->{refs}         = {};

  return $this;
}

sub fixHtmlRefs {
  my html::Refs $this = shift;
  my (@html_paths) = @_;
  ###
  ### Set the html paths
  ###
  my $current_dir = $ENV{PWD};
  $this->{html_paths} = [@html_paths];
  my $html_files = {};
  foreach my $html_path ( @{ $this->{html_paths} } ) {
    $html_files->{$html_path} = {};
  }
  ###
  ### Get the raw files
  ###
  my $html_root = $this->{html_root};
  $this->{error_mgr}->exitProgram( ERR_CAT, 3, [$html_root],
    !-e $html_root || !-d $html_root || !chdir($html_root) );
  @_HTML_FILES_ = ();
  File::Find::find( { wanted => $this->_filesWanted }, util::Constants::DOT );
  my @html_files = @_HTML_FILES_;
  @_HTML_FILES_ = ();
  chdir($current_dir);

  foreach my $file (@html_files) {
    ###
    ### Get the full filename and store in library
    ###
    $file =~ s/^\.\///;
    foreach my $html_path ( @{ $this->{html_paths} } ) {
      next if ( $file !~ /^$html_path\// );
      my $full_file = join( util::Constants::SLASH, $html_root, $file );
      $file =~ s/^$html_path\///;
      $html_files->{$html_path}->{$file} = $full_file;
    }
  }
  ###
  ### Compute References
  ###
  $this->_computeRefs($html_files);
  ###
  ### Fix References
  ###
  foreach my $html_path ( @{ $this->{html_paths} } ) {
    $this->{error_mgr}->printMsg("html_path = $html_path");
    my $files = $html_files->{$html_path};
    foreach my $html_file ( keys %{$files} ) {
      $this->{error_mgr}->printMsg( "  " . $files->{$html_file} );
      $this->_fixHtmlFile( $html_path, $files->{$html_file} );
    }
  }
}

################################################################################

1;

__END__

=head1 NAME

Refs.pm

=head1 SYNOPSIS

  use html::Refs;

  $html = new html::Refs($html_root, $error_mgr);
  $html->fixHtmlRefs(@html_paths);

=head1 DESCRIPTION

This class provides a mechanism for correcting html pathnames
in the html files to corrected pathnames.

=head1 CONSTANTS

The following suffix constants are exported by this class:

   html::Refs::HTML_SUFFIX -- 'html'

=head1 METHODS

The following methods are provided for this class.

=head2 B<new html::Refs(html_root[, msg])>

This method is the constructor for the class.  This constructor
creates all attributes with default settings and set the html root
directory to B<html_root>.  This is the root of the html hierachy for
generating html pages using this object.

=head2 B<$html-E<gt>fixHtmlRefs(@html_paths)>

This method corrects the href attributes for the html files using the
list of html_paths that are subdirectories under the html_root. Also,
the list B<html_paths> is in the search order for replacements.

=cut
