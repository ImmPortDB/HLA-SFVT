package xml::CkControlledVocab;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;
use XML::Parser;

use util::Constants;
use util::Msg;
use util::PathSpecifics;

use xml::Types;

use fields qw(
  compressed
  id_element
  id_value
  elements
  msg
  outer_tag
  strip_whitespace
  tabs
  text_node
  xml_output
  xml_output_file
);

################################################################################
#
#				Constants
#
################################################################################

sub BEFORE { return 'before'; }
sub AFTER  { return 'after'; }

################################################################################
#
#				Private Methods
#
################################################################################
###
### Print the header of an element
###
sub _printStart {
  my xml::CkControlledVocab $this = shift;
  my ( $name, $attr_ref ) = @_;
  if ( $name eq $this->{outer_tag} ) {
    $this->{tabs} = util::Constants::EMPTY_STR;
  }
  else { $this->{tabs} .= xml::Types::XML_INDENT; }
  my $txt = xml::Types::getOpenTag( $name, $attr_ref, $this->{tabs} );
  $this->{xml_output}->print($txt);
}
###
### Print the end of an element
###
sub _printEnd {
  my xml::CkControlledVocab $this = shift;
  my ($name) = @_;

  my $txt = util::Constants::EMPTY_STR;
  if ( defined( $this->{text_node} ) && $this->{text_node} =~ /\S/ ) {
    ###
    ### Only if it is the end the text node.
    ###
    if ( $this->{strip_whitespace} ) { $this->{text_node} =~ s/\s+$//; }
    my $text_str =
        $this->{tabs}
      . xml::Types::XML_INDENT
      . $this->{text_node}
      . util::Constants::NEWLINE;
    xml::Types::escapeReplacement( \$text_str );
    $txt = $text_str;
    if ( $name eq $this->{id_element} ) {
      $this->{id_value} = $this->{text_node};
    }
  }
  $txt .= xml::Types::getCloseTag( $name, $this->{tabs} );
  $this->{xml_output}->print($txt);
  $this->{tabs} = substr( $this->{tabs}, 0, length( $this->{tabs} ) - 2 );
}
###
### The Call-Backs for an Object
###
sub _ckVocab_handle_start {
  my xml::CkControlledVocab $this = shift;
  return sub {
    my ( $expat, $name, %attr ) = @_;
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printStart( $name, \%attr );
    }
    }
}

sub _ckVocab_handle_end {
  my xml::CkControlledVocab $this = shift;
  return sub {
    my ( $expat, $name ) = @_;
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printEnd($name);
      my $elements = $this->{elements};
      if ( defined( $elements->{$name} ) ) {
        my $vocabulary = $elements->{$name};
        my $text_node  = strip_whitespace( $this->{text_node} );
        if ( util::Constants::EMPTY_LINE($text_node) ) {
          ###
          ### missing error
          ###
          $this->{msg}->printError(
            "Missing data for controlled vocabulary\n"
              . "  id element    = "
              . $this->{id_element} . "\n"
              . "  id value      = "
              . $this->{id_value} . "\n"
              . "  vocab element = $name",
            util::Constants::TRUE
          );
        }
        elsif ( !defined( $vocabulary->{$text_node} ) ) {
          ###
          ### not defined error
          ###
          $this->{msg}->printError(
            "Unknown data for controlled vocabulary\n"
              . "  id element    = "
              . $this->{id_element} . "\n"
              . "  id value      = "
              . $this->{id_value} . "\n"
              . "  vocab element = $name\n"
              . "  vocab value   = $text_node",
            util::Constants::TRUE
          );
        }
      }
    }
    $this->{text_node} = undef;
    }
}

sub _ckVocab_handle_char {
  my xml::CkControlledVocab $this = shift;
  return sub {
    my ( $expat, $string ) = @_;
    ###
    ### strip leading tabs and whitespace but NOT spaces
    ###
    $string =~ s/^\t+//;
    $string =~ s/[\t\n\r\f]+$//;
    if ( $string =~ /\S+/ ) {
      if ( !defined( $this->{text_node} ) ) {
        ###
        ### Only if it is the beginning of the text node.
        ###
        if ( $this->{strip_whitespace} ) { $string =~ s/^\s+//; }
        $this->{text_node} = $string;
      }
      else {
        $this->{text_node} .= $string;
      }
    }
    }
}

################################################################################
#
#				    Methods
#
################################################################################

sub new {
  my xml::CkControlledVocab $this = shift;
  my ($msg) = @_;
  $this = fields::new($this) unless ref($this);
  if ( !defined($msg) || !ref($msg) ) { $msg = new util::Msg; }

  $this->{compressed}       = util::Constants::FALSE;
  $this->{elements}         = {};
  $this->{id_element}       = undef;
  $this->{id_value}         = undef;
  $this->{msg}              = $msg;
  $this->{outer_tag}        = util::Constants::EMPTY_STR;
  $this->{strip_whitespace} = util::Constants::TRUE;
  $this->{tabs}             = undef;
  $this->{text_node}        = undef;
  $this->{xml_output_file}  = undef;
  $this->{xml_output}       = new FileHandle;

  return $this;
}

sub setOuterTag {
  my xml::CkControlledVocab $this = shift;
  my ($outer_tag) = @_;
  return
    if ( !defined($outer_tag) || $outer_tag eq util::Constants::EMPTY_STR );
  $this->{outer_tag} = $outer_tag;
}
###
### Methods to set compression type for
### merged file.  The default is uncompressed
###
sub setCompressed {
  my xml::CkControlledVocab $this = shift;
  $this->{compressed} = util::Constants::TRUE;
}

sub setUnCompressed {
  my xml::CkControlledVocab $this = shift;
  $this->{compressed} = util::Constants::FALSE;
}

sub setStripWhitespace {
  my xml::CkControlledVocab $this = shift;
  $this->{strip_whitespace} = util::Constants::TRUE;
}

sub unsetStripWhitespace {
  my xml::CkControlledVocab $this = shift;
  $this->{strip_whitespace} = util::Constants::FALSE;
}

sub setIdElement {
  my xml::CkControlledVocab $this = shift;
  my ($element) = @_;

  return if ( util::Constants::EMPTY_LINE($element) );
  $this->{id_element} = $element;
}
###
### set elements to delete
###
sub resetElements {
  my xml::CkControlledVocab $this = shift;

  $this->{elements} = {};
}

sub setElement {
  my xml::CkControlledVocab $this = shift;
  my ( $element, $vocabulary ) = @_;

  return
    if ( util::Constants::EMPTY_LINE($element)
    || util::Constants::EMPTY_LINE($vocabulary)
    || ref($vocabulary) ne 'ARRAY'
    || scalar @{$vocabulary} == 0 );
  my $elements = $this->{elements};
  $elements->{$element} = {};
  foreach my $item ( @{$vocabulary} ) {
    next if ( util::Constants::EMPTY_LINE($item) );
    $item = strip_whitespace($item);
    next if ( util::Constants::EMPTY_LINE($item) );
    $elements->{$element}->{"$item"} = util::Constants::EMPTY_STR;
  }
}
###
### The Method that actually merges xml files
###
sub ckVocabulary {
  my xml::CkControlledVocab $this = shift;
  my ( $output_dir, $xml_file ) = @_;
  $output_dir = &getPath($output_dir);
  $this->{msg}->dieOnError(
    "Cannot Access output_dir = $output_dir",
    !-e $output_dir || !-d $output_dir
  );
  ###
  ### Create modified xml_file
  ###
  $xml_file = getPath($xml_file);
  my $prefix                  = basename($xml_file);
  my $xml_file_suffix_pattern = xml::Types::XML_FILE_SUFFIX_PATTERN;
  $prefix =~ s/$xml_file_suffix_pattern$//;
  my $xml_suffix;
  if   ( defined($1) ) { $xml_suffix = $1; }
  else                 { $xml_suffix = xml::Types::XML_FILE_SUFFIX; }
  $this->{xml_output_file} = join( util::Constants::SLASH,
    $output_dir,
    join( util::Constants::DOT, $prefix, 'ckVocab', $xml_suffix ) );
  if ( $this->{compressed} ) { $this->{xml_output_file} .= '.gz'; }
  ###
  ### Set variables
  ###
  $this->{id_value}  = undef;
  $this->{tabs}      = util::Constants::EMPTY_STR;
  $this->{text_node} = undef;
  ###
  ### Create the xml parser
  ###
  my $xml_parser = new XML::Parser(
    Handlers => {
      Start => $this->_ckVocab_handle_start(),
      End   => $this->_ckVocab_handle_end(),
      Char  => $this->_ckVocab_handle_char()
    },
    ProtocolEncoding => 'ISO-8859-1'
  );
  ###
  ### Process xml_file
  ###
  if ( $xml_file =~ /(\.gz|\.Z)$/ ) {
    $this->{msg}->dieOnError(
      "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "gunzip -c $xml_file |" )
    );
  }
  else {
    $this->{msg}->dieOnError( "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "<$xml_file" ) );
  }
  if ( $this->{compressed} ) {
    $this->{msg}->dieOnError(
      "Could not open xml_file = " . $this->{xml_output_file} . ": $!",
      !$this->{xml_output}->open( "| gzip -c > " . $this->{xml_output_file} )
    );
  }
  else {
    $this->{msg}->dieOnError(
      "Could not open xml_file = " . $this->{xml_output_file} . ": $!",
      !$this->{xml_output}->open( $this->{xml_output_file}, '>' )
    );
  }
  my $data        = util::Constants::EMPTY_STR;
  my $xml_parsing = $xml_parser->parse_start();
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::OPEN_SUPER_XML);
  }
  while ( read( XML_INPUT, $data, xml::Types::STANDARD_BLOCK_SIZE ) ) {
    $xml_parsing->parse_more($data);
  }
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::CLOSE_SUPER_XML);
  }
  $xml_parsing->parse_done();
  $this->{xml_output}->close();
  close(XML_INPUT);
}
###
### Get the xml file generated
###
sub getXmlFile {
  my xml::CkControlledVocab $this = shift;
  return $this->{xml_output_file};
}

################################################################################

1;

__END__

=head1 NAME

CkControlledVocab.pm

=head1 SYNOPSIS

use xml::CkControlledVocab;

   my $xmlCkContVocab = new xml::CkControlledVocab();
   $xmlCkContVocab->setElement($element, $vocabulary);
   $xmlCkContVocab->ckVocabulary($myOutputDir, $myXmlFile);
   my $myNewXmlFile = $xmlCkContVocab->getXmlFile;
   
=head1 DESCRIPTION

This module checks controlled vocabularies for tags.

This module allows several xml tags to co-exist in the same file.
To accomodate this, the parser uses the outer-element B<super_game>.

=head1 METHODS

=head2 B<new xml::CkControlledVocab>

The new method is the constructor for this Object class.  It creates
an object for handling XML-file modification using B<modifyXml>.

=head2 B<setCompressed>

This method sets the compression switch to compressed for the merged
file.

=head2 B<setUnCompressed>

This method sets the compression switch to uncompressed for the merged
file.  This is the default for the compression switch.

=head2 B<setElement(element, vocabulary)>

This method sets the B<element> and its controlled vocabulary (B<vocabulary>) to
be check.  This method can be executed as many times for all
elements to be checked.

=head2 B<getXmlFile()>

This method returns the name of the modified B<xml_file> that has been
created by the B<modifyXml>.  If B<modifyXml> has not be executed, 
then the list is empty.

=cut
