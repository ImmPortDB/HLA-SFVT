package xml::RemoveTags;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;
use XML::Parser;

use util::Constants;
use util::Msg;
use util::PathSpecifics;

use xml::Types;

use fields qw(
  compressed
  elements
  elements_with_attr
  elements_with_value
  msg
  outer_tag
  pending_stack
  printing_off
  printing_pending
  stack
  strip_whitespace
  tabs
  text_node
  xml_output
  xml_output_file
);

################################################################################
#
#				Private Methods
#
################################################################################
###
### set Printing at the beginning of an element
###
sub _setPrintingOn {
  my xml::RemoveTags $this = shift;
  my ( $name, %attr ) = @_;
  if ( defined( $this->{elements}->{$name} ) ) {
    my $struct = { name => $name, attr => {%attr}, };
    push( @{ $this->{stack} }, $struct );
  }
  elsif ( defined( $this->{elements_with_attr}->{$name} ) ) {
    foreach my $attrib ( keys %{ $this->{elements_with_attr}->{$name} } ) {
      my $vals = $this->{elements_with_attr}->{$name}->{$attrib};
      if ( defined( $attr{$attrib} ) && defined( $vals->{ $attr{$attrib} } ) ) {
        my $struct = { name => $name, attr => {%attr}, };
        push( @{ $this->{stack} }, $struct );
        last;
      }
    }
  }
  $this->{printing_off} =
    ( @{ $this->{stack} } != 0 )
    ? util::Constants::TRUE
    : $this->{printing_off};
}

sub _setPrintingPending {
  my xml::RemoveTags $this = shift;
  my ($name) = @_;
  return if ( $this->{printing_off} );

  if ( defined( $this->{elements_with_value}->{$name} ) ) {
    my $struct = {
      name => $name,
      txt  => util::Constants::EMPTY_STR,
      elem => undef,
      val  => undef
    };
    push( @{ $this->{pending_stack} }, $struct );
  }
  $this->{printing_pending} =
    ( @{ $this->{pending_stack} } != 0 )
    ? util::Constants::TRUE
    : $this->{printing_pending};
}
###
### set Printing at the end of an element
###
sub _setElemVal {
  my xml::RemoveTags $this = shift;
  my ($name) = @_;
  return if ( !$this->{printing_pending} );

  my $struct = $this->{pending_stack}->[ $#{ $this->{pending_stack} } ];
  return
    if ( !util::Constants::EMPTY_LINE( $struct->{elem} )
    && !util::Constants::EMPTY_LINE( $struct->{val} ) );
  my $element_with_value = $this->{elements_with_value}->{ $struct->{name} };
  return if ( !defined( $element_with_value->{$name} ) );
  my $text_node = $this->{text_node};
  if ( defined($text_node) && $text_node =~ /\S/ ) {
    if ( $this->{strip_whitespace} ) { $text_node =~ s/\s+$//; }
  }
  $struct->{val}  = $text_node;
  $struct->{elem} = $name;
}

sub _unsetPrintingPending {
  my xml::RemoveTags $this = shift;
  my ($name) = @_;

  return if ( $this->{printing_off} );

  if ( defined( $this->{elements_with_value}->{$name} ) ) {
    my $struct             = pop( @{ $this->{pending_stack} } );
    my $elem               = $struct->{elem};
    my $val                = $struct->{val};
    my $element_with_value = $this->{elements_with_value}->{$name}->{$elem};
    if ( util::Constants::EMPTY_LINE($val)
      || !defined( $element_with_value->{$val} ) )
    {
      if ( @{ $this->{pending_stack} } == 0 ) {
        $this->{xml_output}->print( $struct->{txt} );
      }
      else {
        my $tstruct = $this->{pending_stack}->[ $#{ $this->{pending_stack} } ];
        $tstruct->{txt} .= $struct->{txt};
      }
    }
  }
  $this->{printing_pending} =
    ( @{ $this->{pending_stack} } == 0 )
    ? util::Constants::FALSE
    : $this->{printing_pending};
}

sub _setPrintingOff {
  my xml::RemoveTags $this = shift;
  my ($name) = @_;
  if ( defined( $this->{elements}->{$name} ) ) {
    pop( @{ $this->{stack} } );
  }
  elsif ( defined( $this->{elements_with_attr}->{$name} ) ) {
    my $struct = $this->{stack}->[ $#{ $this->{stack} } ];
    my $attr   = $struct->{attr};
    foreach my $attrib ( keys %{ $this->{elements_with_attr}->{$name} } ) {
      my $vals = $this->{elements_with_attr}->{$name}->{$attrib};
      if ( defined( $attr->{$attrib} )
        && defined( $vals->{ $attr->{$attrib} } ) )
      {
        pop( @{ $this->{stack} } );
        last;
      }
    }
  }
  $this->{printing_off} =
    ( @{ $this->{stack} } == 0 )
    ? util::Constants::FALSE
    : $this->{printing_off};
}
###
### Print the header of an element
###
sub _printStart {
  my xml::RemoveTags $this = shift;
  my ( $name, $attr_ref ) = @_;
  return if ( $this->{printing_off} );
  if ( $name eq $this->{outer_tag} ) {
    $this->{tabs} = util::Constants::EMPTY_STR;
  }
  else { $this->{tabs} .= xml::Types::XML_INDENT; }
  my $txt = xml::Types::getOpenTag( $name, $attr_ref, $this->{tabs} );
  if ( $this->{printing_pending} ) {
    $this->{pending_stack}->[ $#{ $this->{pending_stack} } ]->{txt} .= $txt;
  }
  else {
    $this->{xml_output}->print($txt);
  }
}
###
### Print the end of an element
###
sub _printEnd {
  my xml::RemoveTags $this = shift;
  my ($name) = @_;
  return if ( $this->{printing_off} );

  my $txt = util::Constants::EMPTY_STR;
  if ( defined( $this->{text_node} ) && $this->{text_node} =~ /\S/ ) {
    ###
    ### Only if it is the end the text node.
    ###
    if ( $this->{strip_whitespace} ) { $this->{text_node} =~ s/\s+$//; }
    my $text_str =
        $this->{tabs}
      . xml::Types::XML_INDENT
      . $this->{text_node}
      . util::Constants::NEWLINE;
    xml::Types::escapeReplacement( \$text_str );
    $txt = $text_str;
  }
  $txt .= xml::Types::getCloseTag( $name, $this->{tabs} );
  if ( $this->{printing_pending} ) {
    $this->{pending_stack}->[ $#{ $this->{pending_stack} } ]->{txt} .= $txt;
  }
  else {
    $this->{xml_output}->print($txt);
  }
  $this->{tabs} = substr( $this->{tabs}, 0, length( $this->{tabs} ) - 2 );
}
###
### The Call-Backs for an Object
###
sub _removeTags_handle_start {
  my xml::RemoveTags $this = shift;
  return sub {
    my ( $expat, $name, %attr ) = @_;
    $this->_setPrintingOn( $name, %attr );
    $this->_setPrintingPending($name);
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printStart( $name, \%attr );
    }
    }
}

sub _removeTags_handle_end {
  my xml::RemoveTags $this = shift;
  return sub {
    my ( $expat, $name ) = @_;
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printEnd($name);
    }
    $this->_setElemVal($name);
    $this->_unsetPrintingPending($name);
    $this->_setPrintingOff($name);
    $this->{text_node} = undef;
    }
}

sub _removeTags_handle_char {
  my xml::RemoveTags $this = shift;
  return sub {
    my ( $expat, $string ) = @_;
    ###
    ### strip leading tabs and whitespace but NOT spaces
    ###
    $string =~ s/^\t+//;
    $string =~ s/[\t\n\r\f]+$//;
    if ( $string =~ /\S+/ ) {
      if ( !defined( $this->{text_node} ) ) {
        ###
        ### Only if it is the beginning of the text node.
        ###
        if ( $this->{strip_whitespace} ) { $string =~ s/^\s+//; }
        $this->{text_node} = $string;
      }
      else {
        $this->{text_node} .= $string;
      }
    }
    }
}

################################################################################
#
#				    Methods
#
################################################################################

sub new {
  my xml::RemoveTags $this = shift;
  my ($msg) = @_;
  $this = fields::new($this) unless ref($this);
  if ( !defined($msg) || !ref($msg) ) { $msg = new util::Msg; }

  $this->{compressed}          = util::Constants::FALSE;
  $this->{elements_with_attr}  = {};
  $this->{elements_with_value} = {};
  $this->{elements}            = {};
  $this->{msg}                 = $msg;
  $this->{outer_tag}           = util::Constants::EMPTY_STR;
  $this->{pending_stack}       = undef;
  $this->{printing_off}        = undef;
  $this->{printing_pending}    = undef;
  $this->{stack}               = undef;
  $this->{strip_whitespace}    = util::Constants::TRUE;
  $this->{tabs}                = undef;
  $this->{text_node}           = undef;
  $this->{xml_output_file}     = undef;
  $this->{xml_output}          = new FileHandle;

  return $this;
}

sub setOuterTag {
  my xml::RemoveTags $this = shift;
  my ($outer_tag) = @_;
  return
    if ( !defined($outer_tag) || $outer_tag eq util::Constants::EMPTY_STR );
  $this->{outer_tag} = $outer_tag;
}

###
### Methods to set compression type for
### merged file.  The default is uncompressed
###
sub setCompressed {
  my xml::RemoveTags $this = shift;
  $this->{compressed} = util::Constants::TRUE;
}

sub setUnCompressed {
  my xml::RemoveTags $this = shift;
  $this->{compressed} = util::Constants::FALSE;
}

sub setStripWhitespace {
  my xml::RemoveTags $this = shift;
  $this->{strip_whitespace} = util::Constants::TRUE;
}

sub unsetStripWhitespace {
  my xml::RemoveTags $this = shift;
  $this->{strip_whitespace} = util::Constants::FALSE;
}

###
### set elements to delete
###
sub resetElements {
  my xml::RemoveTags $this = shift;

  $this->{elements_with_attr}  = {};
  $this->{elements_with_value} = {};
  $this->{elements}            = {};
}

sub setElement {
  my xml::RemoveTags $this = shift;
  my ($element) = @_;
  $this->{elements}->{$element} = util::Constants::EMPTY_STR;

  my $elements_with_attr = $this->{elements_with_attr};
  if ( defined( $elements_with_attr->{$element} ) ) {
    delete( $elements_with_attr->{$element} );
  }
  my $elements_with_value = $this->{elements_with_value};
  if ( defined( $elements_with_value->{$element} ) ) {
    delete( $elements_with_value->{$element} );
  }
}

sub setElementWithAttribute {
  my xml::RemoveTags $this = shift;
  my ( $element, $attr, $value ) = @_;
  my $elements           = $this->{elements};
  my $elements_with_attr = $this->{elements_with_attr};
  return if ( defined( $elements->{$element} ) );
  if ( !defined( $elements_with_attr->{$element} ) ) {
    $elements_with_attr->{$element} = {};
  }
  my $element_with_attr = $elements_with_attr->{$element};
  if ( !defined( $element_with_attr->{$attr} ) ) {
    $element_with_attr->{$attr} = {};
  }
  $element_with_attr->{$attr}->{$value} = util::Constants::EMPTY_STR;
}

sub setElementWithValue {
  my xml::RemoveTags $this = shift;
  my ( $element, $elem, $value ) = @_;
  my $elements            = $this->{elements};
  my $elements_with_value = $this->{elements_with_value};
  return if ( defined( $elements->{$element} ) );
  if ( !defined( $elements_with_value->{$element} ) ) {
    $elements_with_value->{$element} = {};
  }
  my $element_with_value = $elements_with_value->{$element};
  if ( !defined( $element_with_value->{$elem} ) ) {
    $element_with_value->{$elem} = {};
  }
  $element_with_value->{$elem}->{$value} = util::Constants::EMPTY_STR;
}
###
### The Method that actually merges xml files
###
sub removeTags {
  my xml::RemoveTags $this = shift;
  my ( $output_dir, $xml_file ) = @_;
  $output_dir = &getPath($output_dir);
  $this->{msg}->dieOnError(
    "Cannot Access output_dir = $output_dir",
    !-e $output_dir || !-d $output_dir
  );
  ###
  ### Create modified xml_file
  ###
  $xml_file = getPath($xml_file);
  my $prefix                  = basename($xml_file);
  my $xml_file_suffix_pattern = xml::Types::XML_FILE_SUFFIX_PATTERN;
  $prefix =~ s/$xml_file_suffix_pattern$//;
  my $xml_suffix;
  if   ( defined($1) ) { $xml_suffix = $1; }
  else                 { $xml_suffix = xml::Types::XML_FILE_SUFFIX; }
  $this->{xml_output_file} = join( util::Constants::SLASH,
    $output_dir,
    join( util::Constants::DOT, $prefix, 'removeTags', $xml_suffix ) );
  if ( $this->{compressed} ) { $this->{xml_output_file} .= '.gz'; }
  ###
  ### Set variables
  ###
  $this->{pending_stack}    = [];
  $this->{printing_off}     = util::Constants::FALSE;
  $this->{printing_pending} = util::Constants::FALSE;
  $this->{stack}            = [];
  $this->{tabs}             = util::Constants::EMPTY_STR;
  $this->{text_node}        = undef;
  ###
  ### Create the xml parser
  ###
  my $xml_parser = new XML::Parser(
    Handlers => {
      Start => $this->_removeTags_handle_start(),
      End   => $this->_removeTags_handle_end(),
      Char  => $this->_removeTags_handle_char()
    },
    ProtocolEncoding => 'ISO-8859-1'
  );
  ###
  ### Process xml_file
  ###
  if ( $xml_file =~ /(\.gz|\.Z)$/ ) {
    $this->{msg}->dieOnError(
      "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "gunzip -c $xml_file |" )
    );
  }
  else {
    $this->{msg}->dieOnError( "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "<$xml_file" ) );
  }
  if ( $this->{compressed} ) {
    $this->{msg}->dieOnError(
      "Could not open xml_file = " . $this->{xml_output_file} . ": $!",
      !$this->{xml_output}->open( "| gzip -c > " . $this->{xml_output_file} )
    );
  }
  else {
    $this->{msg}->dieOnError(
      "Could not open xml_file = " . $this->{xml_output_file} . ": $!",
      !$this->{xml_output}->open( $this->{xml_output_file}, '>' )
    );
  }
  my $data        = util::Constants::EMPTY_STR;
  my $xml_parsing = $xml_parser->parse_start();
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::OPEN_SUPER_XML);
  }
  while ( read( XML_INPUT, $data, xml::Types::STANDARD_BLOCK_SIZE ) ) {
    $xml_parsing->parse_more($data);
  }
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::CLOSE_SUPER_XML);
  }
  $xml_parsing->parse_done();
  $this->{xml_output}->close();
  close(XML_INPUT);
}
###
### Get the xml file generated
###
sub getXmlFile {
  my xml::RemoveTags $this = shift;
  return $this->{xml_output_file};
}

################################################################################

1;

__END__

=head1 NAME

RemoveTags.pm

=head1 SYNOPSIS

use xml::RemoveTags;

   my $xmlRemoveTags = new xml::RemoveTags();
   $xmlRemoveTags->setElement($element);
   $xmlRemoveTags->setElementWithAttribute($element_a, $attr, $value);
   $xmlRemoveTags->setElementWithValue($element_v, $elem, $value);
   $xmlRemoveTags->removeTags($myOutputDir, $myXmlFile);
   my $myNewXmlFile = $xmlRemoveTags->getXmlFile;
   
=head1 DESCRIPTION

This module allows several elements to be globally removed from
an xml document.

This module allows several xml tags to co-exist in the same file.
To accomodate this, the parser uses the outer-element B<super_game>.

=head1 METHODS

=head2 B<new xml::RemoveTags>

The new method is the constructor for this Object class.  It creates
an object for handling XML-file modification using B<modifyXml>.

=head2 B<setCompressed>

This method sets the compression switch to compressed for the merged
file.

=head2 B<setUnCompressed>

This method sets the compression switch to uncompressed for the merged
file.  This is the default for the compression switch.

=head2 B<setElement(element)>

This method sets the B<element> that is to be deleted from from the
xml document.  This method can be executed as many times for all
elements to be removed from the document.  If this element occurs for
either attributes or text node values, it is removed from those lists.

=head2 B<setElementWithAttribute(element, attr, value)>

This method sets the B<element> that is to be deleted from from the
xml document that has attr with value.  This method can be executed as
many times for all elements to be removed from the document.  If
element is added by setElement, then the attribute and value is not
added.

=head2 B<setElementWithValue(element, value)>

This method sets the B<element> that is to be deleted from from the
xml document that has text node value.  This method can be executed as
many times for all elements to be removed from the document.  If
element is added by setElement, then the text node value is not added.

=head2 B<removeTags(output_dir, xml_file)>

This method takes in an B<output_dir> and a <xml_file>.
It removes the elements from the xml document and generates a new xml-file:

   <output_dir>/<prefix>.removeTags.<suffix>[.gz]?

where the B<prefix> is defined to

   <xml_file> ::= <dir_name>/<prefix>.<suffix>[.gz|.Z]?

The B<xml_file> can either plain or gzipped.

=head2 B<getXmlFile()>

This method returns the name of the modified B<xml_file> that has been
created by the B<modifyXml>.  If B<modifyXml> has not be executed, 
then the list is empty.

=cut
