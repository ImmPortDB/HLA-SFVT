package xml::ReduceTags;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use File::Basename;
use FileHandle;
use Pod::Usage;
use XML::Parser;

use util::Constants;
use util::Msg;
use util::PathSpecifics;

use xml::Types;

use fields qw(
  compressed
  msg
  outer_tag
  strip_whitespace
  tabs
  tag_level
  tag_stack
  text_node
  xml_output
  xml_output_file
);

################################################################################
#
#				Private Methods
#
################################################################################
###
### Print the header of an element
###
sub _printStart {
  my xml::ReduceTags $this = shift;
  my ( $name, $attr_ref ) = @_;
  if ( $name eq $this->{outer_tag} ) {
    $this->{tabs} = util::Constants::EMPTY_STR;
  }
  else {
    $this->{tabs} .= xml::Types::XML_INDENT;
  }
  $this->{tag_level}++;
  my @keys       = keys %{$attr_ref};
  my $tag_struct = {
    level     => $this->{tag_level},
    keep      => util::Constants::FALSE,
    has_attrs => ( scalar @keys )
    ? util::Constants::TRUE
    : util::Constants::FALSE,
    str => xml::Types::getOpenTag( $name, $attr_ref, $this->{tabs} ),
  };
  push( @{ $this->{tag_stack} }, $tag_struct );
}
###
### Print the end of an element
###
sub _printEnd {
  my xml::ReduceTags $this = shift;
  my ($name)               = @_;
  my $has_text_node        = util::Constants::FALSE;
  my $text_str             = util::Constants::EMPTY_STR;
  if ( !util::Constants::EMPTY_LINE( $this->{text_node} )
    && $this->{text_node} =~ /\S/ )
  {
    $has_text_node = util::Constants::TRUE;
    ###
    ### Only if it is the end the text node.
    ###
    if ( $this->{strip_whitespace} ) { $this->{text_node} =~ s/\s+$//; }
    $text_str = $this->{text_node};
    xml::Types::escapeReplacement( \$text_str );
  }

  my $tag_struct = pop( @{ $this->{tag_stack} } );
  if ( $this->{tag_level} == 1 && $tag_struct->{keep} ) {
    ###
    ### Print the contents
    ###
    my $str =
        $tag_struct->{str}
      . $text_str
      . xml::Types::getCloseTag( $name, $this->{tabs} );
    $this->{xml_output}->print($str);
  }
  else {
    my $prev_struct = $this->{tag_stack}->[ $#{ $this->{tag_stack} } ];
    if ( $tag_struct->{keep} ) {
      $prev_struct->{str} .=
          $tag_struct->{str}
        . $text_str
        . xml::Types::getCloseTag( $name, $this->{tabs} );
      $prev_struct->{keep} = util::Constants::TRUE;
    }
    elsif ( !$tag_struct->{has_attrs} && !$has_text_node ) {
      ### NO OP
    }
    elsif ( $tag_struct->{has_attrs} && !$has_text_node ) {
      my $str = $tag_struct->{str};
      $str =~ s/>\n$//;
      $str .= xml::Types::SHORT_END_XML_TAG . util::Constants::NEWLINE;
      $prev_struct->{str} .= $str;
      $prev_struct->{keep} = util::Constants::TRUE;
    }
    elsif ($has_text_node) {
      my $str = $tag_struct->{str};
      $str =~ s/\n$//;
      $prev_struct->{str} .=
          $str
        . $text_str
        . xml::Types::getCloseTag( $name, util::Constants::EMPTY_STR );
      $prev_struct->{keep} = util::Constants::TRUE;
    }
  }
  $this->{tag_level}--;
  $this->{tabs} = substr( $this->{tabs}, 0, length( $this->{tabs} ) - 2 );
}
###
### The reduceXml Call-Backs for an Object
###
sub _reduceXml_handle_start {
  my xml::ReduceTags $this = shift;
  return sub {
    my ( $expat, $name, %attr ) = @_;
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printStart( $name, \%attr );
    }
    }
}

sub _reduceXml_handle_end {
  my xml::ReduceTags $this = shift;
  return sub {
    my ( $expat, $name ) = @_;
    if ( $name ne xml::Types::SUPER_XML_TAG ) {
      $this->_printEnd($name);
    }
    $this->{text_node} = undef;
    }
}

sub _reduceXml_handle_char {
  my xml::ReduceTags $this = shift;
  return sub {
    my ( $expat, $string ) = @_;
    ###
    ### strip leading tabs and whitespace but NOT spaces
    ###
    $string =~ s/^\t+//;
    $string =~ s/[\t\n\r\f]+$//;
    if ( $string =~ /\S+/ ) {
      if ( !defined( $this->{text_node} ) ) {
        ###
        ### Only if it is the beginning of the text node.
        ###
        if ( $this->{strip_whitespace} ) { $string =~ s/^\s+//; }
        $this->{text_node} = $string;
      }
      else {
        $this->{text_node} .= $string;
      }
    }
    }
}

################################################################################
#
#				    Methods
#
################################################################################

sub new {
  my xml::ReduceTags $this = shift;
  my ($msg) = @_;
  $this = fields::new($this) unless ref($this);
  if ( !defined($msg) || !ref($msg) ) { $msg = new util::Msg; }
  $this->{compressed}       = util::Constants::FALSE;
  $this->{msg}              = $msg;
  $this->{outer_tag}        = util::Constants::EMPTY_STR;
  $this->{strip_whitespace} = util::Constants::TRUE;
  $this->{tabs}             = undef;
  $this->{tag_level}        = undef;
  $this->{tag_stack}        = undef;
  $this->{text_node}        = undef;
  $this->{xml_output_file}  = undef;
  $this->{xml_output}       = new FileHandle;
  return $this;
}

sub setOuterTag {
  my xml::ReduceTags $this = shift;
  my ($outer_tag) = @_;
  return
    if ( !defined($outer_tag) || $outer_tag eq util::Constants::EMPTY_STR );
  $this->{outer_tag} = $outer_tag;
}

sub setCompressed {
  my xml::ReduceTags $this = shift;
  $this->{compressed} = util::Constants::TRUE;
}

sub setUnCompressed {
  my xml::ReduceTags $this = shift;
  $this->{compressed} = util::Constants::FALSE;
}

sub setStripWhitespace {
  my xml::ReduceTags $this = shift;
  $this->{strip_whitespace} = util::Constants::TRUE;
}

sub unsetStripWhitespace {
  my xml::ReduceTags $this = shift;
  $this->{strip_whitespace} = util::Constants::FALSE;
}

sub reduceXml {
  my xml::ReduceTags $this = shift;
  my ( $output_dir, $xml_file ) = @_;
  $output_dir = &getPath($output_dir);
  $this->{msg}->dieOnError(
    "Cannot Access output_dir = $output_dir",
    !-e $output_dir || !-d $output_dir
  );
  ###
  ### Create modified xml_file
  ###
  $xml_file = getPath($xml_file);
  my $prefix             = basename($xml_file);
  my $xml_suffix         = xml::Types::REDUCED_FILE_INFIX;
  my $xml_suffix_pattern = xml::Types::XML_FILE_SUFFIX_PATTERN;
  $prefix =~ s/$xml_suffix_pattern$//;
  if ( defined($1) ) {
    $xml_suffix = join( util::Constants::DOT, $xml_suffix, $1 );
  }
  else {
    $xml_suffix =
      join( util::Constants::DOT, $xml_suffix, xml::Types::XML_FILE_SUFFIX );
  }
  $this->{xml_output_file} = join( util::Constants::SLASH,
    $output_dir, join( util::Constants::DOT, $prefix, $xml_suffix ) );
  if ( $this->{compressed} ) { $this->{xml_output_file} .= '.gz'; }
  ###
  ### Set variables
  ###
  $this->{tabs}      = util::Constants::EMPTY_STR;
  $this->{text_node} = undef;
  $this->{tag_level} = 0;
  $this->{tag_stack} = [];
  ###
  ### Create the xml parser
  ###
  my $xml_parser = new XML::Parser(
    Handlers => {
      Start => $this->_reduceXml_handle_start,
      End   => $this->_reduceXml_handle_end,
      Char  => $this->_reduceXml_handle_char,
    },
    ProtocolEncoding => 'ISO-8859-1'
  );
  ###
  ### Process xml_file
  ###
  my $zipped_file_pattern = xml::Types::ZIPPED_FILE_PATTERN;
  if ( $xml_file =~ /$zipped_file_pattern/ ) {
    $this->{msg}->dieOnError(
      "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "gunzip -c $xml_file |" )
    );
  }
  else {
    $this->{msg}->dieOnError( "Cannot open xml file = $xml_file",
      !open( XML_INPUT, "<$xml_file" ) );
  }
  if ( $this->{compressed} ) {
    $this->{msg}->dieOnError(
      "Could not open xml_file = "
        . $this->{xml_output_file} . "\n"
        . "  errMsg = $!",
      !$this->{xml_output}->open( "| gzip -c > " . $this->{xml_output_file} )
    );
  }
  else {
    $this->{msg}->dieOnError(
      "Could not open xml_file = "
        . $this->{xml_output_file} . "\n"
        . "  errMsg = $!",
      !$this->{xml_output}->open( $this->{xml_output_file}, '>' )
    );
  }
  my $data        = util::Constants::EMPTY_STR;
  my $xml_parsing = $xml_parser->parse_start;
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::OPEN_SUPER_XML);
  }
  while ( read( XML_INPUT, $data, xml::Types::STANDARD_BLOCK_SIZE ) ) {
    $xml_parsing->parse_more($data);
  }
  if ( $this->{outer_tag} eq xml::Types::XML_TAG ) {
    $xml_parsing->parse_more(xml::Types::CLOSE_SUPER_XML);
  }
  $xml_parsing->parse_done;
  $this->{xml_output}->close;
  close(XML_INPUT);
}

sub getXmlFile {
  my xml::ReduceTags $this = shift;
  return $this->{xml_output_file};
}

################################################################################

1;

__END__

=head1 NAME

ReduceTags.pm

=head1 SYNOPSIS

   use xml::ReduceTags;

   my $xmlReducer = new xml::ReduceTags();
   $xmlReducer->reduceXml($myOutputDir, $myXmlFile);
   my $myNewXmlFile = $xmlReducer->getXmlFile;

=head1 DESCRIPTION

This module reduces xml by removing tags with no attributes and
text-nodes and reduces tags with attributes and no text-nodes to
reduced format ('/>).

=head1 METHODS

=head2 B<new xml::ReduceTags>

The new method is the constructor for this Object class.  It creates
an object for formating xml documents.  By default, compression is
FALSE, skipping white-space is TRUE, and the outer xml-tag is
B<'game'>.

=head2 B<setCompressed>

This method sets the compression switch to compressed output file.

=head2 B<setUnCompressed>

This method sets the compression switch to uncompressed for the output
file.  This is the default for the compression switch.

=head2 B<setOuterTag(outer_tag)>

This method sets the outer xml-tag.  This determines formating and
parsing behavior.  By default, the outer_tag is set to B<'game'> and
parsing encapsulates the xml-file with B<'super_game'> tag in case
there are several B<'game'> tags in the file.  Otherwise, the
assumption is that there is only one outer_tag.

=head2 B<setStripWhitespace>

This method instructs the formater to strip the whitespace from the
beginning of the text node and at its end.  This this the default for
the formater.

=head2 B<unsetStripWhitespace>

This method instructs the formater not to strip the whitespace from
the beginning and the end of the text node.

=head2 B<reduceXml(output_dir, xml_file)>

This method takes in an B<output_dir> and a <xml_file>.  It formats
the document writing it to the following xml document:

   <output_dir>/<prefix>.formated(\.xml|\.gbw)(\.gz)?

where the B<prefix> is defined by the expression

   <xml_file> ::= <dir_name>/<prefix>(\.xml|\.gbw)(\.gz|\.Z)?

The B<xml_file> can either plain or gzipped.

=head2 B<getXmlFile>

This method returns the name of the formated B<xml_file> that has been
created by the B<reduceXml>.  If B<reduceXml> has not be executed,
then the list is empty.

=cut
