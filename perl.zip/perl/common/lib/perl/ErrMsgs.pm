package perl::ErrMsgs;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::ErrMsgs;

################################################################################
#
#				Initializations
#
################################################################################

BEGIN {
  use vars qw($VERSION);

  my $rev = '$Revision: 2.76 $';
  ###
  ### '$'
  ### The comment above fixes a syntax highlighting bug in XEmacs.
  ###
  if ( $rev =~ /((\d|\.)+)/ ) {
    $perl::ErrMsgs::VERSION = $1;
  }
}

################################################################################
#
#			     Constant Class Methods
#
################################################################################

sub ERROR_HEADER { return 'PERL-ERROR: '; }

sub STRUCT_CAT       { return -100001000; }    ### Perl Struct Class
sub READPROFILE_CAT  { return -100002000; }    ### Read Perl Profile Class
sub STATSPROFILE_CAT { return -100003000; }    ### Statistics Profile Class

################################################################################
#
#			     Public Static Constant
#
################################################################################

sub ERROR_MSGS {
  my $errMsgs = {

    &STRUCT_CAT => {
      1 => "Missing hash structure for tag, exiting...\n" . "  tag = __1__",

      2 => "Bad structs format for tag, exiting...\n"
        . "  tag  = __1__\n"
        . "  kind = __2__\n"
        . "  type = __3__",

      3 => "Top-level struct not found, exitng...\n" . "  tag = __1__",

      4 => "Array tag does not reference a hash tag, exiting...\n"
        . "  tag  = __1__\n"
        . "  kind = __2__\n"
        . "  type = __3__",

      5 => "Invalid map name\n" . "  map_path = __1__",

      6 => "Source and target objects do not have same structure\n"
        . "  source_tag = __1__\n"
        . "  target_tag = __2__",

      7 => "Path to key mapping incorrectly specified, exiting...\n"
        . "  path  = __1__\n"
        . "  key   = __2__\n"
        . "  comps = __3__\n"
        . "  tag   = __4__",

      8 => "Path to key mapping does not have the key in the tag, exiting...\n"
        . "  path  = __1__\n"
        . "  key   = __2__\n"
        . "  comps = (__3__)\n"
        . "  tag   = __4__",

      9 => "Maps defined but no mapping_rec defined in structure, exiting...\n"
        . "  maps  = (__1__)",

      10 => "No id defined for map, exiting...\n" . "  map = __1__",

      11 => "Not valid mapping parameters, exiting...\n"
        . "  map             = __1__\n"
        . "  map_params      = (__2__)\n"
        . "  mapping_scalars = (__3__)",

      12 => "Hostess class not specified, exiting",

      13 => "Top-level tag not part of search paths, exiting...\n"
        . "  tag = __1__",

      14 => "Search path is not a hash tag, exiting...\n" . "  tag = __1__",

      15 => "Search path has no locators, exiting...\n"
        . "  search_path = __1__",

    },

    &READPROFILE_CAT => {
      1 => "Database object not defined, exiting ...",

      2 => "Profile object not defined, exiting...",

      4 => "Component undefined for query, exiting...\n"
        . "  query = __1__\n"
        . "  comp  = __2__",

      5 => "Tag does not reference a hash or an array, exiting ...\n"
        . "  query = __1__\n"
        . "  tag   = __2__",

      6 => "Missing component in tag for query, exiting...\n"
        . "  query  = __1__\n"
        . "  tag    = __2__\n"
        . "  comp   = __3__\n"
        . "  struct = (__4__)",

      7 => "Query not defined or entity not a hash, exiting...\n"
        . "  query = __1__\n"
        . "  ref   = __2__",

      8 => "Target structure undefined or not correct Perl type, exiting...\n"
        . "  query    = __1__\n"
        . "  tag      = __2__\n"
        . "  ref\n"
        . "    tag    = __3__\n"
        . "    entity = __4__",

      9 => "Access info structure is not defined, exiting...",

      10 =>
"Need product predicate, but there is not productName in product, exiting...\n"
        . "  query = __1__",

      11 => "To to query map already defined for key, exiting...\n"
        . "  key           = __1__\n"
        . "  query         = __2__\n"
        . "  current query = __3__",

      12 =>
"Both ptag undefined and usesp tag undefined or FALSE for query, exiting...\n"
        . "  query = __1__\n"
        . "  usesp = __2__",

    },

    &STATSPROFILE_CAT => {
      1 => "Profile object not defined, exiting...",

      2 => "File entity is not in database\n"
        . "  tag       = __1__\n"
        . "  entity_id = __2__",

      3 => "Inconsistent data between file and database\n"
        . "  component = __1__\n"
        . "  entity_id = __2__\n"
        . "  column    = __3__\n"
        . "  value\n"
        . "    file    = __4__\n"
        . "    db      = __5__",

      4 => "Inconsistent number of the entities between file and database\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  file num  = __3__\n"
        . "  db num    = __4__",

      5 => "No database entity for file entity\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  key       = __3__",

      6 => "Issue raised in file, but not in database\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  key       = __3__\n"
        . "  issue_id  = __4__",

      7 => "Issue raised in database, but not in file\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  key       = __3__\n"
        . "  issue_id  = __4__",

      8 => "No database entities for file entities\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  file num  = __3__\n"
        . "  db num    = __4__",

      9 => "Set table to tag map failed, exiting...\n"
        . "  table_name = __1__\n"
        . "  tag        = __2__\n"
        . "  c_table    = __3__",

      10 => "Excess database entities for file entities\n"
        . "  entity    = __1__\n"
        . "  entity_id = __2__\n"
        . "  file num  = __3__\n"
        . "  db num    = __4__",

      11 => "Reduce tag is not an array or hash tag, exiting...\n"
        . "  reduce_tag = __1__",

      12 => "readStatsData:  Undefined attribute\n"
        . "  filename  = __1__\n"
        . "  attribute = __2__",

      13 => "readStatsData:  Undefined component of attribute\n"
        . "  filename  = __1__\n"
        . "  attribute = __2__\n"
        . "  component = __3__",

      14 =>
        "readStatsData:  Undefined sub-component of a component of attribute\n"
        . "  filename     = __1__\n"
        . "  attribute    = __2__\n"
        . "  component    = __3__\n"
        . "  subcomponent = __4__",

      15 => "Table map undefined, exiting...",

      16 => "No table maps found, exiting..",

      17 => "No entity_id found for entity\n"
        . "  tag         = __1__\n"
        . "  access path = __2__",

    },

  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilMsgs = util::ErrMsgs::ERROR_MSGS;
  while ( my ( $category, $msgs ) = each %{$utilMsgs} ) {
    $errMsgs->{$category} = $msgs;
  }
  return $errMsgs;
}

sub ERROR_CATS {
  my $errCats = {

    &STRUCT_CAT       => 'perl::Struct',
    &READPROFILE_CAT  => 'perl::ReadProfile',
    &STATSPROFILE_CAT => 'perl::StatsProfile',
  };
  ###
  ### Now add the util::ErrMsgs categories
  ###
  my $utilCats = util::ErrMsgs::ERROR_CATS;
  while ( my ( $category, $name ) = each %{$utilCats} ) {
    $errCats->{$category} = $name;
  }
  return $errCats;
}

################################################################################

1;

__END__

=head1 NAME

ErrMsgs.pm

=head1 SYNOPSIS

   use perl::ErrMsgs;

   my $error_msgs  = perl::ErrMsgs::ERROR_MSGS;
   my $error_names = perl::ErrMsgs::ERROR_CATS;
   my $err_cat     = perl::ErrMsgs::STRUCT_CAT;

=head1 DESCRIPTION

This static class returns the error message templates for the perl library.

=head1 CONSTANTS

The following constants define the pre-defined error message
categories define by this class.

   perl::ErrMsgs::PERLSTRUCT_CAT   -- (-1000000000) Perl Struct Class
   perl::ErrMsgs::READPROFILE_CAT  -- (-1000000001) Read Perl Profile Class
   perl::ErrMsgs::STATSPROFILE_CAT -- (-1000000002) Statistics Profile Class

=head1 STATIC CLASS METHODS

=head2 B<perl::ErrMsgs::ERROR_MSGS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorMsgs> that deploys error messages to
error categories and numbers.

=head2 B<perl::ErrMsgs::ERROR_CATS>

This method returns a data-structure acceptable to the class
L<util::ErrMsg> method B<addErrorCats> that deploys that deploys
category names for statistics reporting.

=cut
