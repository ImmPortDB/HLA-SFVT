package perl::Struct::StatsProfile;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Fcntl;
use Pod::Usage;

use util::Constants;
use util::PerlObject;

use perl::ErrMsgs;

use fields
  qw(
  entities
  error_mgr
  filename
  issue_id_map
  profile
  read_write_ord
  reduce_tags
  scalar_keys
  table_map
  tables
);

################################################################################
#
#				   Constants
#
################################################################################
###
### Error Category
###
sub ERR_CAT { return perl::ErrMsgs::STATSPROFILE_CAT; }
###
### Entity Location
###
sub FROM_FILE { return 'file'; }
sub FROM_DB   { return 'db'; }
###
### Entity Counts Struct
###
sub ENTITY_COUNTS_STRUCT {
  return {
    &FROM_FILE => 0,
    &FROM_DB   => 0,
  };
}

sub ISSUE_COUNTS_STRUCT {
  return {
    total      => ENTITY_COUNTS_STRUCT,
    &FROM_FILE => {},
    &FROM_DB   => {},
  };
}

sub TABLE_COUNTS_STRUCT {
  return {
    count        => 0,
    db_count     => 0,
    missing      => 0,
    column_total => 0,
    columns      => {},
    ###
    ### No issue for type but there
    ### is an issue in the other
    ###
    no_issues => ISSUE_COUNTS_STRUCT,
    issues    => ISSUE_COUNTS_STRUCT,
  };
}
###
### read/write order
###
sub READ_WRITE_ORDER {
  return [ 'entities', 'issue_id_map', 'scalar_keys', 'table_map', 'tables', ];
}

################################################################################
#
#			     Statistic Computation
#				Private Methods
#
################################################################################

sub _addColumnError {
  my perl::Struct::StatsProfile $this = shift;
  my ( $tag, $scalar_key ) = @_;
  my $table_name = $this->tableName($tag);
  my $columns    = $this->{tables}->{$table_name}->{columns};
  $columns->{$scalar_key}++;
}

sub _addEntityCount {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity_type, $entity_location ) = @_;
  my $entities = $this->{entities};
  $entities->{$entity_type}->{$entity_location}++;
}

sub _addError {
  my perl::Struct::StatsProfile $this = shift;
  my ( $tag, $error ) = @_;
  return if ( !$error );
  my $table_name = $this->tableName($tag);
  my $data       = $this->{tables}->{$table_name};
  $data->{column_total}++;
}

sub _addMissingCount {
  my perl::Struct::StatsProfile $this = shift;
  my ( $comp_path, $missing_entity ) = @_;
  my $table_name = $this->tableName($comp_path);
  return if ( !defined($table_name) || !$missing_entity );
  my $table = $this->{tables}->{$table_name};
  $table->{missing}++;
}

sub _addTableCount {
  my perl::Struct::StatsProfile $this = shift;
  my ($tag)                   = @_;
  my $table_name              = $this->tableName($tag);
  return if ( !defined($table_name) );
  $this->{tables}->{$table_name}->{count}++;
}

sub _addDbTableCount {
  my perl::Struct::StatsProfile $this = shift;
  my ($tag)                   = @_;
  my $table_name              = $this->tableName($tag);
  return if ( !defined($table_name) );
  $this->{tables}->{$table_name}->{db_count}++;
}

sub _convertIssueId {
  my perl::Struct::StatsProfile $this = shift;
  my ($issue_id) = @_;
  return undef if ( !defined($issue_id) );
  my $issue_str = $this->{issue_id_map}->{$issue_id};
  return $issue_str if ( defined($issue_str) );
  return $issue_id;
}

sub _addIssue {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity_id, $comp_path, $component_path, $comp, $db_comp ) = @_;
  my $table = $this->tableName($component_path);
  ###
  ### Get the file issue
  ###
  my $issue_id = $this->_convertIssueId( $comp->{issue_id} );
  my $issue    =
    ( defined($issue_id) && $issue_id ne util::Constants::EMPTY_STR )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### Get the database issue
  ###
  my $db_issue_id = $db_comp->{issue_id};
  my $db_issue    =
    ( defined($db_issue_id) && int($db_issue_id) > 0 )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  ###
  ### Record the issues
  ###
  my $issues    = $this->{tables}->{$table}->{issues};
  my $no_issues = $this->{tables}->{$table}->{no_issues};

  $issues->{&FROM_FILE}->{$issue_id}++  if ( $issue && $db_issue );
  $issues->{total}->{&FROM_FILE}++      if ( $issue && $db_issue );
  $issues->{&FROM_DB}->{$db_issue_id}++ if ( $issue && $db_issue );
  $issues->{total}->{&FROM_DB}++        if ( $issue && $db_issue );

  $no_issues->{&FROM_FILE}->{$db_issue_id}++ if ( !$issue && $db_issue );
  $no_issues->{total}->{&FROM_FILE}++        if ( !$issue && $db_issue );

  $no_issues->{&FROM_DB}->{$issue_id}++ if ( $issue && !$db_issue );
  $no_issues->{total}->{&FROM_DB}++     if ( $issue && !$db_issue );

  my $keyname     = $this->{profile}->findKey($comp_path);
  my $comp_key    = ( defined($keyname) ) ? $comp->{$keyname} : undef;
  my $db_comp_key = ( defined($keyname) ) ? $db_comp->{$keyname} : undef;
  $this->{error_mgr}->registerError(
    ERR_CAT, 6,
    [ $comp_path, $entity_id, $comp_key, $issue_id ],
    $issue && !$db_issue
  );
  $this->{error_mgr}->registerError(
    ERR_CAT, 7,
    [ $comp_path, $entity_id, $db_comp_key, $db_issue_id ],
    !$issue && $db_issue
  );
}

sub _addMissingTableCount {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity_id, $comp_path, $num_comps, $num_db_comps ) = @_;
  my $component_path = $this->{profile}->getComponentTag($comp_path);
  $this->{error_mgr}->registerError(
    ERR_CAT, 4,
    [ $comp_path, $entity_id, $num_comps, $num_db_comps ],
    $num_comps != $num_db_comps
  );
  if ( $num_db_comps - $num_comps > 0 ) {
    ###
    ### Count excess database entities
    ###
    $this->{error_mgr}->registerError( ERR_CAT, 10,
      [ $comp_path, $entity_id, $num_comps, $num_db_comps ],
      util::Constants::TRUE );
    foreach ( 1 .. ( $num_db_comps - $num_comps ) ) {
      $this->_addDbTableCount($component_path);
    }
  }
  elsif ( $num_comps > 0 && $num_db_comps == 0 ) {
    ###
    ### The file has values but the database has none
    ###
    $this->{error_mgr}->registerError( ERR_CAT, 8,
      [ $comp_path, $entity_id, $num_comps, $num_db_comps ],
      util::Constants::TRUE );
    foreach ( 1 .. $num_comps ) {
      $this->_addTableCount($component_path);
      $this->_addMissingCount( $component_path, util::Constants::TRUE );
    }
  }
}

sub _checkComp {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity_id, $comp_path, $comp, $db_comp ) = @_;
  my $component_path = $this->{profile}->getComponentTag($comp_path);
  if ( !defined($component_path) ) { $component_path = $comp_path; }
  ###
  ### Immediate return for structures with no table mapping
  ###
  my @scalar_keys = $this->scalarKeys($component_path);
  return if ( @scalar_keys == 0 );
  ###
  ### Now process component
  ###
  my $errors = util::Constants::FALSE;
  foreach my $scalar_key (@scalar_keys) {
    my $value        = $comp->{$scalar_key};
    my $db_value     = $db_comp->{$scalar_key};
    my $column_error = (
      ( defined($value) || defined($db_value) ) && ( !defined($value)
        || !defined($db_value)
        || $value ne $db_value )
    );
    next if ( !$column_error );
    $errors = util::Constants::TRUE;
    $this->_addColumnError( $component_path, $scalar_key );
    $this->{error_mgr}->registerError( ERR_CAT, 3,
      [ $component_path, $entity_id, $scalar_key, $value, $db_value ],
      $column_error );
  }
  $this->_addError( $component_path, $errors );
  $this->_addIssue( $entity_id, $comp_path, $component_path, $comp, $db_comp );
}

sub _computeStatistics {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity, $db_entity, $tag, $id ) = @_;
  my $profile           = $this->{profile};
  my $orig_tag          = $tag;
  my $missing_db_entity = ( !defined($db_entity) );
  ###
  ### First, determine the component path tag name
  ### if there is one
  ###
  my $comp_path = $profile->getComponentTag($tag);
  if ( defined($comp_path) ) { $tag = $comp_path; }
  ###
  ### Second, if this is a search path
  ### entity, determine its id to use
  ###
  my $entities = $this->{entities};
  if ( defined( $entities->{$tag} ) ) {
    $this->_addEntityCount( $tag, FROM_FILE );
    foreach my $locator_path ( $profile->locatorsForSearchPath($tag) ) {
      my $new_id = $profile->getCValue( $entity, $locator_path );
      next if ( !defined($new_id) );
      $id = $new_id;
      last;
    }
    $this->{error_mgr}
      ->registerError( ERR_CAT, 2, [ $tag, $id ], $missing_db_entity );
  }
  ###
  ### Third, add table count, missing count,
  ### and return if database entity undefined
  ###
  $this->_addTableCount($tag);
  $this->_addMissingCount( $tag, $missing_db_entity );
  return if ($missing_db_entity);
  $this->_addDbTableCount($tag);
  ###
  ### Fourth, Add database entity count
  ### and table count, and check entities
  ###
  $this->_addEntityCount( $tag, FROM_DB ) if ( defined( $entities->{$tag} ) );
  $this->_checkComp( $id, $orig_tag, $entity, $db_entity );
  ###
  ### Fifth, process the entity
  ###
  my @comps = keys %{$entity};
  foreach my $comp (@comps) {
    my $comp_ref = $profile->tagRef($comp);
    next if ( !defined($comp_ref) || $this->isSkipTag($comp) );
    my $comp_entity    = $entity->{$comp};
    my $db_comp_entity = $db_entity->{$comp};
    next if ( !defined($comp_entity)
      || ref($comp_entity) ne $comp_ref );
    if ( $comp_ref eq util::PerlObject::HASH_TYPE ) {
      $this->_computeStatistics( $comp_entity, $db_comp_entity, $comp, $id );
    }
    elsif ( $comp_ref eq util::PerlObject::ARRAY_TYPE ) {
      my $num_comps    = @{$comp_entity};
      my $num_db_comps = @{$db_comp_entity};
      next if ( $num_comps == 0 && $num_db_comps == 0 );
      $this->_addMissingTableCount( $id, $comp, $num_comps, $num_db_comps );
      next if ( $num_comps == 0 || $num_db_comps == 0 );
      foreach my $sub_entity ( @{$comp_entity} ) {
        my $db_sub_entity =
          $profile->findEntity( $db_entity, $comp, $sub_entity );
        $this->{error_mgr}->registerError(
          ERR_CAT, 5,
          [ $comp, $id, $sub_entity->{ $profile->findKey($comp) } ],
          !defined($db_sub_entity)
        );
        $this->_computeStatistics( $sub_entity, $db_sub_entity, $comp, $id );
      }
    }
  }
}

################################################################################
#
#			    Reading Statistics Data
#				 Private Method
#
################################################################################

sub _addContentType {
  my perl::Struct::StatsProfile $this = shift;
  my ( $read_data, $obj_data, $attr_name, $attr_type ) = @_;
  my $attr_data = $read_data->{$attr_type};
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 13,
    [ $this->{filename}, $attr_name, $attr_type ],
    !defined($attr_data) || ref($attr_data) ne util::PerlObject::HASH_TYPE
  );
  foreach my $content_type ( FROM_FILE, FROM_DB ) {
    my $datum = $attr_data->{$content_type};
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 14,
      [ $this->{filename}, $attr_name, $attr_type, $content_type ],
      !defined($datum) || $datum !~ /^\d+$/
    );
    $obj_data->{$attr_type}->{$content_type} += $datum;
  }
}

sub _addContentData {
  my perl::Struct::StatsProfile $this = shift;
  my ( $read_data, $obj_data, $attr_name ) = @_;
  while ( my ( $datum, $datum_num ) = each %{$read_data} ) {
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 14,
      [ $this->{filename}, $attr_name, $datum, $datum_num ],
      !defined($datum_num) || $datum_num !~ /^\d+$/
    );
    if ( defined( $obj_data->{$datum} ) ) { $obj_data->{$datum} += $datum_num; }
    else { $obj_data->{$datum} = $datum_num; }
  }
}

################################################################################
#
#			       Statistics Logging
#				 Private Method
#
################################################################################

sub _generateEntityStats {
  my perl::Struct::StatsProfile $this = shift;
  my $entities                = $this->{entities};
  my $max_type_length         = 0;
  foreach my $entity_type ( sort keys %{$entities} ) {
    my $type_length = length($entity_type);
    next if ( $type_length <= $max_type_length );
    $max_type_length = $type_length;
  }
  my $msg = "Entity Counts\n";
  foreach my $content_type ( FROM_FILE, FROM_DB ) {
    $msg .= "  $content_type\n";
    foreach my $entity_type ( sort keys %{$entities} ) {
      my $spaces_length = $max_type_length - length($entity_type);
      $msg .=
          "    $entity_type"
        . &util::Constants::SPACE x $spaces_length . " = "
        . $entities->{$entity_type}->{$content_type} . "\n";
    }
  }
  return $msg;
}

sub _generateStats {
  my perl::Struct::StatsProfile $this = shift;
  my ( $heading, $data, $total ) = @_;
  my @columns = sort keys %{$data};
  return util::Constants::EMPTY_STR if ( @columns == 0 );
  my $msg               = "\n" . "  $heading = $total";
  my $max_column_length = 0;
  foreach my $column (@columns) {
    my $column_length = length($column);
    next if ( $column_length <= $max_column_length );
    $max_column_length = $column_length;
  }
  foreach my $column (@columns) {
    my $spaces_length = $max_column_length - length($column);
    $msg .= "\n"
      . "    $column"
      . &util::Constants::SPACE x $spaces_length . " = "
      . $data->{$column};
  }
  return $msg;
}

################################################################################
#
#				 Instantiation
#				 Private Method
#
# _setTables:
# This method sets the table associated with the tag.  The tag must be a
# hash structure in the object's struct.  If it that tag is a hash, then
# this method sets the table map of the tag to the table_name, acquires
# the list of sclar components for the tag, and initials the statistics
# gathering data-structure for the table_name.
#
# _setIssues:
# This method sets the mapping of an issue_id to its text message.
#
# _reduceScalarKeys:
# This method reduces all scalar key sets for all defined tags/tables in
# the object for the given B<@reduce_set> list.  This method assumes
# that all tables have been set by setTable(table_name, tag).
#
# _reduceTags:
# This method reduces the tags (@reduce_tags) to traverse in computing
# the statistics.  All tags in the list must be an array or hash tag.
# Any tag in the list is skipped.
#
################################################################################

sub _setTables {
  my perl::Struct::StatsProfile $this = shift;
  my ($table_map)             = @_;
  my $profile                 = $this->{profile};
  my $found_map               = util::Constants::FALSE;
  while ( my ( $tag, $table_name ) = each %{$table_map} ) {
    my $tag_ref = $profile->tagRef($tag);
    my $c_table = $this->tableName($tag);
    $this->{error_mgr}->exitProgram(
      ERR_CAT,
      9,
      [ $table_name, $tag, $c_table ],
      defined($c_table)
        || !defined($tag_ref)
        || $tag_ref ne util::PerlObject::HASH_TYPE
    );
    $found_map                     = util::Constants::TRUE;
    $this->{scalar_keys}->{$tag}   = [ $profile->scalarKeys($tag) ];
    $this->{table_map}->{$tag}     = $table_name;
    $this->{tables}->{$table_name} = TABLE_COUNTS_STRUCT;
  }
  $this->{error_mgr}->exitProgram( ERR_CAT, 16, [], !$found_map );
}

sub _setIssues {
  my perl::Struct::StatsProfile $this = shift;
  my ($issue_id_map) = @_;
  return
    if ( !defined($issue_id_map)
    || ref($issue_id_map) ne util::PerlObject::HASH_TYPE );
  while ( my ( $issue_id, $issue_str ) = each %{$issue_id_map} ) {
    $this->{issue_id_map}->{$issue_id} = $issue_str;
  }
}

sub _reduceScalarKeys {
  my perl::Struct::StatsProfile $this = shift;
  my ($reduce_set) = @_;
  return
    if ( !defined($reduce_set)
    || ref($reduce_set) ne util::PerlObject::ARRAY_TYPE );
  my %reduce_set = ();
  foreach my $reduce_key ( @{$reduce_set} ) {
    $reduce_set{$reduce_key} = util::Constants::EMPTY_STR;
  }
  foreach my $tag ( $this->tablePaths ) {
    my $tag_keys = [];
    foreach my $key ( $this->scalarKeys($tag) ) {
      next if ( defined( $reduce_set{$key} ) );
      push( @{$tag_keys}, $key );
    }
    $this->{scalar_keys}->{$tag} = $tag_keys;
  }
}

sub _reduceTags {
  my perl::Struct::StatsProfile $this = shift;
  my ($reduce_tags) = @_;
  return
    if ( !defined($reduce_tags)
    || ref($reduce_tags) ne util::PerlObject::ARRAY_TYPE );
  foreach my $reduce_tag ( @{$reduce_tags} ) {
    my $tag_ref = $this->{profile}->tagRef($reduce_tag);
    $this->{error_mgr}
      ->exitProgram( ERR_CAT, 11, [$reduce_tag], !defined($tag_ref) );
    $this->{reduce_tags}->{$reduce_tag} = util::Constants::EMPTY_STR;
  }
}

################################################################################
#
#				 Public Methods
#
################################################################################

sub new {
  my perl::Struct::StatsProfile $this = shift;
  my (
    $profile,     $table_map,    $reduce_set,
    $reduce_tags, $issue_id_map, $error_mgr
    )
    = @_;
  $this = fields::new($this) unless ref($this);
  ###
  ### Must be an Oracle Database
  ###
  $error_mgr->exitProgram( ERR_CAT, 1, [],
    !defined($profile) || !ref($profile) );
  $error_mgr->exitProgram( ERR_CAT, 15, [],
    !defined($table_map) || ref($table_map) ne util::PerlObject::HASH_TYPE );

  $this->{error_mgr}      = $error_mgr;
  $this->{issue_id_map}   = {};
  $this->{profile}        = $profile;
  $this->{read_write_ord} = READ_WRITE_ORDER;
  $this->{reduce_tags}    = {};
  $this->{scalar_keys}    = {};
  $this->{table_map}      = {};
  $this->{tables}         = {};

  foreach my $search_path ( $this->{profile}->searchPaths ) {
    $this->{entities}->{$search_path} = ENTITY_COUNTS_STRUCT;
  }
  $this->_setTables($table_map);
  $this->_reduceScalarKeys($reduce_set);
  $this->_reduceTags($reduce_tags);
  $this->_setIssues($issue_id_map);

  return $this;
}

sub computeStatistics {
  my perl::Struct::StatsProfile $this = shift;
  my ( $entity, $db_entity ) = @_;
  $this->_computeStatistics( $entity, $db_entity, $this->{profile}->tag );
}

sub computeProfileStatistics {
  my perl::Struct::StatsProfile $this = shift;
  ###
  ### Read the file
  ###
  my $profile = $this->{profile};
  $profile->generateEntities;
  ###
  ### Read the database
  ###
  my $db_profile = $profile->dbProfile;
  my @locators   = $profile->locatorsForSearchPath( $profile->tag );
  $this->{error_mgr}->printHeader('Acquiring Database Entities From File');
  foreach my $entity ( $profile->entities ) {
    my $entity_id = $profile->getCValue( $entity, $profile->accessPath );
    my $missing_entity =
      ( !defined($entity_id) || $entity_id eq util::Constants::EMPTY_STR );
    $this->{error_mgr}
      ->registerError( ERR_CAT, 17, [ $profile->tag, $profile->accessPath ],
      $missing_entity );
    next if ($missing_entity);
    $this->{error_mgr}->printMsg("Entity = $entity_id");
    $this->{error_mgr}->printWarning(
      "Entity ($entity_id) missing from database",
      !$db_profile->generateProfile(
        $entity_id, $profile->tag, $profile->accessPath
      )
    );
  }
  $db_profile->closeQueries;
  ###
  ### Validate the file data against the database data
  ###
  $this->{error_mgr}->printHeader('Comparing File and Database');
  foreach my $entity ( $profile->entities ) {
    my $db_entity = undef;
    foreach my $locator (@locators) {
      my $entity_id = $profile->getCValue( $entity, $locator );
      next
        if ( !defined($entity_id)
        || $entity_id eq util::Constants::EMPTY_STR );
      $db_entity =
        $db_profile->entityByKind( $entity_id, $profile->tag, $locator );
      last if ( defined($db_entity) );
    }
    $this->computeStatistics( $entity, $db_entity );
  }
}

sub printStats {
  my perl::Struct::StatsProfile $this = shift;
  $this->{error_mgr}->printDateHeader('Comparison Statistics');
  my $msg              = $this->_generateEntityStats;
  my $tables_processed = {};
  foreach my $table_name ( $this->tableNames ) {
    my $table = $this->{tables}->{$table_name};
    next
      if ( defined( $tables_processed->{$table_name} )
      || $table->{count} == 0 );
    $tables_processed->{$table_name} = util::Constants::EMPTY_STR;
    my $count_issues = util::Constants::EMPTY_STR;
    if ( $table->{count} != $table->{db_count} ) {
      $count_issues .= "  DIFFERING COUNTS\n";
    }
    if ( $table->{missing} > 0 ) { $count_issues .= "  MISSING ENTITIES\n"; }
    $msg .= "\n\n"
      . "$table_name Table Counts\n"
      . $count_issues
      . "  file\n"
      . "    count   = "
      . $table->{count} . "\n"
      . "    missing = "
      . $table->{missing} . "\n"
      . "  db\n"
      . "    count   = "
      . $table->{db_count};
    $msg .=
      $this->_generateStats( 'column_errors', $table->{columns},
      $table->{column_total} );
    $msg .= $this->_generateStats(
      'file issues',
      $table->{issues}->{&FROM_FILE},
      $table->{issues}->{total}->{&FROM_FILE}
    );
    $msg .= $this->_generateStats(
      'db issues',
      $table->{issues}->{&FROM_DB},
      $table->{issues}->{total}->{&FROM_DB}
    );
    $msg .= $this->_generateStats(
      'only file issues',
      $table->{no_issues}->{&FROM_DB},
      $table->{no_issues}->{total}->{&FROM_DB}
    );
    $msg .= $this->_generateStats(
      'only db issues',
      $table->{no_issues}->{&FROM_FILE},
      $table->{no_issues}->{total}->{&FROM_FILE}
    );
  }
  $this->{error_mgr}->printMsg($msg);
  $this->{error_mgr}->printStats;
}

sub passValidation {
  my perl::Struct::StatsProfile $this = shift;
  $this->{error_mgr}->printDateHeader('Determine if Pass Validation');
  ###
  ### Check Entity Counts
  ###
  my $entities          = $this->{entities};
  my $no_data_from_file = util::Constants::TRUE;
  foreach my $entity_type ( keys %{$entities} ) {
    my $from_db   = $entities->{$entity_type}->{&FROM_DB};
    my $from_file = $entities->{$entity_type}->{&FROM_FILE};
    return util::Constants::FALSE if ( $from_file != $from_db );
    $no_data_from_file =
      ( $from_file == 0 ) ? $no_data_from_file : util::Constants::FALSE;
  }
  return util::Constants::FALSE if ($no_data_from_file);
  ###
  ### Check Tables
  ###
  my $tables_processed = {};
  foreach my $table_name ( $this->tableNames ) {
    my $table = $this->{tables}->{$table_name};
    next
      if ( defined( $tables_processed->{$table_name} )
      || $table->{count} == 0 );
    $tables_processed->{$table_name} = util::Constants::EMPTY_STR;
    ###
    ### counts differ
    ### missing data
    ###
    return util::Constants::FALSE
      if ( $table->{count} != $table->{db_count}
      || $table->{missing} > 0 );
    ###
    ### column errors
    ###
    my @columns = keys %{ $table->{columns} };
    return util::Constants::FALSE if ( @columns != 0 );
##########    ###
##########    ### only file issues
##########    ###
##########    @columns = keys %{$table->{no_issues}->{&FROM_DB}};
##########    return util::Constants::FALSE if (@columns != 0);
##########    ###
##########    ### only db issues
##########    ###
##########    @columns = keys %{$table->{no_issues}->{&FROM_FILE}};
##########    return util::Constants::FALSE if (@columns != 0);
  }
  return util::Constants::TRUE;
}

sub writeStatsData {
  my perl::Struct::StatsProfile $this = shift;
  my ($log_prefix) = @_;
  my $filename = join( util::Constants::DOT, $log_prefix, 'stats', 'pl' );
  unlink($filename);
  my $objfile = new util::PerlObject( $filename, undef, $this->{error_mgr} );
  foreach my $attr ( @{ $this->{read_write_ord} } ) {
    $objfile->writeStream( $this->{$attr},
      util::PerlObject::PERL_OBJECT_WRITE_OPTIONS );
  }
  $objfile->closeIo;
  $this->{error_mgr}->writeStatsData($log_prefix);
}

sub readStatsData {
  my perl::Struct::StatsProfile $this = shift;
  my ($filename) = @_;
  $this->{filename} = $filename;
  my $objfile = new util::PerlObject( $filename, O_RDONLY, $this->{error_mgr} );
  my $stats_data = {};
  foreach my $attr ( @{ $this->{read_write_ord} } ) {
    $stats_data->{$attr} = $objfile->readStream;
  }
  $objfile->closeIo;
  ###
  ### Add entity statistics to object
  ###
  my $entities = $stats_data->{entities};
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 12,
    [ $filename, 'entities' ],
    !defined($entities) || ref($entities) ne util::PerlObject::HASH_TYPE
  );
  my @entity_types = keys %{ $this->{entities} };
  foreach my $entity_type (@entity_types) {
    my $entity_data = $entities->{$entity_type};
    $this->_addContentType( $entities, $this->{entities}, 'entities',
      $entity_type );
  }
  ###
  ### Add table statistics to object
  ###
  my $tables = $stats_data->{tables};
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 12,
    [ $filename, 'tables' ],
    !defined($tables) || ref($tables) ne util::PerlObject::HASH_TYPE
  );
  my @tables = keys %{ $this->{tables} };
  foreach my $table (@tables) {
    my $table_data = $tables->{$table};
    $this->{error_mgr}->exitProgram(
      ERR_CAT,
      13,
      [ $filename, 'tables', $table ],
      !defined($table_data) || ref($table_data) ne util::PerlObject::HASH_TYPE
    );
    foreach my $comp ( 'count', 'db_count', 'missing', 'column_total' ) {
      my $datum = $table_data->{$comp};
      $this->{error_mgr}->exitProgram(
        ERR_CAT, 14,
        [ $filename, 'tables', $table, $comp ],
        !defined($datum) || $datum !~ /^\d+$/
      );
      $this->{tables}->{$table}->{$comp} += $datum;
    }
    foreach my $comp ( 'columns', 'no_issues', 'issues' ) {
      my $attr      = $this->{tables}->{$table}->{$comp};
      my $attr_name = join( '->', 'tables', $table );
      my $comp_data = $table_data->{$comp};
      $this->{error_mgr}->exitProgram(
        ERR_CAT,
        13,
        [ $filename, $attr_name, $comp ],
        !defined($comp_data) || ref($comp_data) ne util::PerlObject::HASH_TYPE
      );
      $attr_name = join( '->', $attr_name, $comp );
      if ( $comp eq 'columns' ) {
        $this->_addContentData( $comp_data, $attr, $attr_name );
      }
      else {
        $this->_addContentType( $comp_data, $attr, $attr_name, 'total' );
        foreach my $content_type ( FROM_FILE, FROM_DB ) {
          my $issue_data = $comp_data->{$content_type};
          $this->{error_mgr}->exitProgram(
            ERR_CAT,
            13,
            [ $filename, $attr_name, $content_type ],
            !defined($issue_data)
              || ref($issue_data) ne util::PerlObject::HASH_TYPE
          );
          $this->_addContentData(
            $issue_data,
            $attr->{$content_type},
            join( '->', $attr_name, $content_type )
          );
        }
      }
    }
  }
}

sub scalarKeys {
  my perl::Struct::StatsProfile $this = shift;
  my ($tag)                   = @_;
  my $scalar_keys             = $this->{scalar_keys};
  return () if ( !defined( $scalar_keys->{$tag} ) );
  return @{ $scalar_keys->{$tag} };
}

sub tableName {
  my perl::Struct::StatsProfile $this = shift;
  my ($path) = @_;
  return $this->{table_map}->{$path};
}

sub tableNames {
  my perl::Struct::StatsProfile $this = shift;
  return sort values %{ $this->{table_map} };
}

sub tablePaths {
  my perl::Struct::StatsProfile $this = shift;
  return sort keys %{ $this->{table_map} };
}

sub isSkipTag {
  my perl::Struct::StatsProfile $this = shift;
  my ($tag)                   = @_;
  my $reduce_tags             = $this->{reduce_tags};
  return (
    defined( $reduce_tags->{$tag} )
    ? util::Constants::TRUE
    : util::Constants::FALSE
  );
}

################################################################################

1;

__END__

=head1 NAME

StatsProfile.pm

=head1 SYNOPSIS

   use util::Constants;
   use util::ErrMgr;
   use perl::Struct::StatsProfile;

   use eSNP:: Profile;

   my $error_mgr = new util::ErrMgr;

   my $profile =
     new eSNP::Profile
       ($product,
        $db,
        $release_ts,
        $error_mgr)

   my $stats =
     new perl::Struct::StatsProfile
       ($profile,
        $table_map,
        $reduce_set,
        $reduce_tags,
        $issue_id_map,
        $error_mgr);

=head1 DESCRIPTION

This concrete class implements the statistics gathering for profiles.
The profile is compared against a database version of the profile
(B<dbProfile>).  Both the profile and the database version must be
instances of the same subclass (same structure) of L<perl::Struct::Profile>.
This statistics comparision consists of identification of the
differences in


=over 4

=item * table versus component counts

=item * field/column counts

=item * issue_id differences.

=back


The context of the instantiation of this class defines the required
parameters to the constructor that are described below and
illustrated:

=over 4

=item B<profile>

The profile defines the profile object instance that describes the
entity data-structure, the data product, database connection, and
release timestamp.  The profile provides the following class-back
methods: B<generateEntities> and B<dbProfile>.  The generateEntities
method generates data into the profile as specified by it subclass
implementation.  The dbProfile method will create and return a
database profile reader for the profile.  This database profile
(B<db_profile>) needs to provide the following call-back methods:
B<generateProfile> and B<closeQueries>.  generateProfile will have the
following signature:

B<$status = generateProfile(accession, entity_tag, access_path)>

and will read into the db_profile B<entities> attribute list the data
specified by the parameters.  closeQueries will close the queries
created in the db_profile.

=item B<table_map>

The table map is a required reference hash that maps the hash profile
tags to the corresponding table that they represent.

=item B<reduce_set>

The optional referenced array is a list of scalar component names in
hash tags that will not be compared for statistics gathering.  In
every tag, that such a scalar component occurs, it is removed from
comparision.  In particular, one column usually not inspected by
direct comparison is the B<'issue_id'> field.  Therefore, it should be
included in B<reduce_set> if it occurs in the profile is not to be
compared directly.

=item B<reduce_tags>

This optional referenced array of profile tags (either hash or array)
are not to be compared at all.  This means that any structure under
these tags are not inspected either.

=item B<issue_id_map>

This optional referenced hash specifies how issue ids determined in
the profile generation are to be represented in the statistics.  These
issue_ids are not the ones defined and stored in the database, but
rather ones generated as part of profile createion using
B<generateEntities>.  The B<'issue_id'> field is also compared
separately from regular fields to identify where issues are defined in
both the database and profile or only in one or the other.

=item B<error_mgr>

The error messaging object is an instance of L<util::ErrMgr> and is
required.

=back


The following example fully describes the specification of the eSNP
file comparator.


=over 4

=item B<table_map>

    {
     cluster_mapping   => 'CLUSTER_MAPPING',
     dbsnp_rs_cluster  => 'DBSNP_RS_CLUSTER',
     dbsnp_submission  => 'DBSNP_SUBMISSION',
     location          => 'LOCATION',
     mrna_dta          => 'MRNA_DTA',
     population        => 'POPULATION',
     protein_dta       => 'PROTEIN_DTA',
     submission        => 'SUBMISSION',
     submission_allele => 'SUBMISSION_ALLELE',
     submission_seq    => 'SUBMISSION_SEQ',
    };

=item B<reduce_set>

    [
     'cre_ts',
     'dta_run_name',
     'esnp_pop_id',
     'issue_id',
     'last_trans_id',
     'location_id',
     'mrna_domain_id',
     'obs_ts',
     'subm_allele_id'
    ];

=item B<reduce_tags>

   [];

=item B<issue_id_map>

    {
     1001 => 'no reference',
     1002 => 'only reference',
     1003 => 'multiple references',
     1004 => 'data missing',
     1005 => 'inconsistent data',
     1006 => 'unknown value',
     1007 => 'mrna_dta count error',
    };

=back

A sample output of the execution of L<"computeProfileStatistics">
using the writer L<"printStats"> that write the following to the
logging file:

   ###############################################
   ###                                         ###
   ###  Comparison Statistics                  ###
   ###    date = Thu Jun  1 17:56:08 EDT 2006  ###
   ###                                         ###
   ###############################################

   Entity Counts
     file
       rs = 1000
       ss = 4826
     db
       rs = 1000
       ss = 4826

   CLUSTER_MAPPING Table Counts
     file
       count   = 1017
       missing = 0
     db
       count   = 1017

   DBSNP_RS_CLUSTER Table Counts
     file
       count   = 1000
       missing = 0
     db
       count   = 1000

   DBSNP_SUBMISSION Table Counts
     file
       count   = 4826
       missing = 0
     db
       count   = 4826

   LOCATION Table Counts
     file
       count   = 1017
       missing = 0
     db
       count   = 1017

   MRNA_DTA Table Counts
     file
       count   = 1022
       missing = 0
     db
       count   = 1022

   POPULATION Table Counts
     file
       count   = 549
       missing = 0
     db
       count   = 549

   PROTEIN_DTA Table Counts
     file
       count   = 498
       missing = 0
     db
       count   = 498

   SUBMISSION Table Counts
     file
       count   = 5826
       missing = 0
     db
       count   = 5826

   SUBMISSION_ALLELE Table Counts
     DIFFERING COUNTS
     file
       count   = 549
       missing = 0
     db
       count   = 559

   SUBMISSION_SEQ Table Counts
     file
       count   = 5826
       missing = 0
     db
       count   = 5826

   #######################################################
   ###                                                 ###
   ###  Category Errors                                ###
   ###    category                                     ###
   ###      name   = eSNP::Profile::File::dbSNPRs      ###
   ###      number = 7000                              ###
   ###    errors                                       ###
   ###      7002 = 11 (No location data found for RS)  ###
   ###                                                 ###
   #######################################################

   ########################################################################################
   ###                                                                                  ###
   ###  Category Errors                                                                 ###
   ###    category                                                                      ###
   ###      name   = perl::Struct::StatsProfile                                                 ###
   ###      number = -13000                                                             ###
   ###    errors                                                                        ###
   ###      -13004 = 2 (Inconsistent number of the entities between file and database)  ###
   ###      -13010 = 2 (Excess database entities for file entities)                     ###
   ###                                                                                  ###
   ########################################################################################


=head1 METHODS

These methods are used for populating a this class.

=head2 B<new perl::Struct::StatsProfile(profile, table_map, reduce_set, reduce_tags, issue_id_map, error_mgr)>

This method is the constructor for the class.  The constructor
requires an instance of a subclass of L<perl::Struct::Profile>, a
B<table_map>, and an error messsage handler L<util::ErrMgr>.  This
constructor initializes the statistics gathering data-structure.  If
defined, the constructor will also use B<reduce_set>, B<reduce_tags>,
and B<issue_id_map>.

=head2 B<computeStatistics(entity, db_entity)>

This method computes and updates the statistics for two top-level
B<tag> objects.  It assumes that both are entities with the same
structure as the profile for the object and both entities are
top-level.  Normally, this method is used internlly by the class, but
can be executed by a caller also if necessary.

=head2 B<computeProfileStatistics>

This method computes and updates the statistics for the profile
provided to the object.  This method generates the content of the
profile using the profile's method B<generateEntities>.  The method
accesses the database profile for the profile by the profile's method
B<dbProfile> and generates the database profile data using the
database profile's method B<generateProfile>.  The method assumes that
both the profile and its database profile have the same structure.
The results of the computation can be viewed by L<"printStats"> or
L<"writeStatsData(log_prefix)">.

=head1 SETTER METHODS

These methods are used to set the statistics attributes.

=head2 B<readStatsData(filename)>

This method reads the B<filename> assuming that the file has been
created by L<"writeStatsData(log_prefix)"> for an profile of the same
type as the object (i.e., must have common subclass of
L<perl::Struct::Profile>).  The method reads in the Perl object components in
the order as the writer:

   entities
   issue_id_map
   scalar_keys
   table_map
   tables

Next, this method checks the consistency of the data.  Finally, this
method adds the statistics in the entities and tables into entites and
tables of the object.  This allows statistics from several runs to be
accumulated into one object before being written or printed.

=head1 GETTER METHODS

These methods are used to set the attributes for generation.

=head2 B<@scalar_keys = sclarsKeys(tag)>

The method method returns the list of scalar keys associated to the
tag in the profile for direct comparison.  This list is created by
B<table_map> and reduced B<reduce_set>.

=head2 B<$table_name = tableName(path)>

The method method returns the table name associated with a given path
set by B<table_map>.

=head2 B<@table_names = tableNames>

This method returns the list of table names assigned to all paths set by
B<table_map>.

=head2 B<@table_paths = tablePaths>

This method returns the list of paths that have assigned tables set by
B<table_map>.

=head2 B<$boolean = isSkipTag(tag)>

This method returns TRUE (1) if the tag is tag to skip as defined by
B<reduce_tags>, otherwise it returns FALSE (0).

=head2 B<printStats>

This method prints the current accumulative statistics to the logging
file (see L<"DESCRIPTION">) and also reports the error_mgr statistics.

=head2 B<passValidation>

This method returns TRUE (1) if there are no errors in the validation
(summary statistics), otherwise it returns FALSE (0).  The following
lists includes reasons for failure (FALSE):


=over 4

=item *

For any of the search entities the counts differ between the file and
the database.

=item *

For a any table, if the row counts differ between the file and databset
or there is missing data from the file or database.

=item *

For a any table, if there are any column errors for any row.

=item *

For a any table, if there are issues raised in a row in the file but
not the database.

=item *

For a any table, if there are issues raised in a row in the database
but not the file.

=back


=head2 B<writeStatsData(log_prefix)>

This method writes the following object's attributes as Perl objects
to the file B<log_prefix.stats.pl>:

   entities
   issue_id_map
   scalar_keys
   table_map
   tables

This method calls the error_mgr to write its error statistics also.

=cut
