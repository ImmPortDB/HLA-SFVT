package perl::Struct::Profile;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PerlObject;

use base 'perl::Struct';

use fields
  qw(
  access_path
  db
  generator
  product
  release_ts
  skip_hashes
);

################################################################################
#
#				 Private Methods
#
################################################################################

sub _writeHash {
  my perl::Struct::Profile $this = shift;
  my ( $entity, $tag, $generate_schema, $do_not_write ) = @_;
  $do_not_write =
    ( !util::Constants::EMPTY_LINE($do_not_write) && $do_not_write )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  $generate_schema->generateRow( $tag, $entity )
    if ( $generate_schema->fileInSchema($tag) && !$do_not_write );
  my $skip_hashes = $this->{skip_hashes};
  foreach my $comp ( keys %{$entity} ) {
    if ( ref( $entity->{$comp} ) eq util::PerlObject::HASH_TYPE
	 && !defined($skip_hashes->{$comp})) {
      $this->_writeHash( $entity->{$comp}, $comp, $generate_schema );
    }
    elsif ( ref( $entity->{$comp} ) eq util::PerlObject::ARRAY_TYPE ) {
      foreach my $subentity ( @{ $entity->{$comp} } ) {
        $this->_writeHash( $subentity, $this->getComponentTag($comp),
          $generate_schema );
      }
    }
  }

}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my (
    $that,         $generator, $product,      $db,
    $release_ts,   $tag,       $access_path,  $structs,
    $search_paths, $map_paths, $path_to_keys, $error_mgr
    )
    = @_;
  my perl::Struct::Profile $this =
    $that->SUPER::new( $tag, $structs, $search_paths, $map_paths, $path_to_keys,
    $error_mgr );
  ###
  ### Initialize Attributes
  ###
  $this->{access_path} = $access_path;

  $this->{db} = ( defined($db) && ref($db) ) ? $db : undef;

  $this->{generator} =
    ( defined($generator) && $generator )
    ? util::Constants::TRUE
    : util::Constants::FALSE;

  $this->{product} = ( defined($product) && ref($product) ) ? $product : undef;

  $this->{release_ts} =
    ( defined($release_ts) && $release_ts =~ /^\d+$/ && $release_ts > 0 )
    ? $release_ts
    : undef;

  $this->{skip_hashes} = {};
  ###
  ### Return the object
  ###
  return $this;
}

sub generateProfile {
  my perl::Struct::Profile $this = shift;
  my (@params) = @_;
  #######################
  ### Abstract Method ###
  #######################
  $this->{error_mgr}->printDebug("Abstract Method Profile::generateProfile");
}

################################################################################
###
### Getter Methods
###
################################################################################

sub accessPath {
  my perl::Struct::Profile $this = shift;
  return $this->{access_path};
}

sub db {
  my perl::Struct::Profile $this = shift;
  return $this->{db};
}

sub isGenerator {
  my perl::Struct::Profile $this = shift;
  return $this->{generator};
}

sub product {
  my perl::Struct::Profile $this = shift;
  return $this->{product};
}

sub releaseTs {
  my perl::Struct::Profile $this = shift;
  return $this->{release_ts};
}

sub setSkipHash {
  my perl::Struct::Profile $this = shift;
  my ($tag) = @_;
  $this->{skip_hashes}->{$tag} = util::Constants::EMPTY_STR;
}

sub writeProfile {
  my perl::Struct::Profile $this = shift;
  my ( $generate_schema, $do_not_write_top_level ) = @_;
  return if ( !$this->isGenerator );
  ###############################
  ### Re-Implementable Method ###
  ###############################
  ###
  ### The default implementation assumes that a generate schema
  ### (an instance or subclass of db::Schema::Generate) is provided
  ### that corresponds to perl structure (hash structs are table/file
  ### names and components are column names)
  ###
  foreach my $entity ( $this->entities ) {
    $this->_writeHash( $entity, $this->tag, $generate_schema,
      $do_not_write_top_level );
  }
}

################################################################################

1;

__END__

=head1 NAME

Profile.pm

=head1 DESCRIPTION

This abstract class defines the base class for generating and writing
profiles.  It is a subclass of L<perl::Struct> that defines the
profile data-structure defined by specific profile generators that
created by subclasses of this class.  That is, a subclass specify the
PerlStruct data-structure.  This class is abstract in that it exports
the abstract method: L<"generateProfile(@params)">.  This class also
defines a re-implementable method B<"writeProfile">.

An instance of this class contains the following components:

=over 4

=item * PerlStruct data-structure

The class is a subclass of L<perl::Struct> as defined by the
constructor parameters: tag, structs, search_paths, map_paths,
path_to_keys

=item * generator

This required boolean value indicates whether the class is a generator
(TRUE--1) or just a user entities (FALSE--0).

=item * product

The product (if defined) defines the data product from which then
entities of the data-structure are acquired and is an object of a
product class.

=item * db

The database session (if defined) defines the database connection is
is normally an object or subclass object of L<util::Db>.

=item * release_ts

The release timestamp (if defined) defines the timestamp to use for
acquiring data from the database session.  If not defined, then
current data is to be acquired.

=item * error_mgr

The error_mgr is an instance of L<util::ErrMgr>.  The object uses it
to manage registration of errors.

=back


=head1 METHODS

These methods are used for creating and populating a profile.

=head2 B<new perl::Struct::Profile(generator, product, db, release_ts, tag, access_path, structs, search_paths, map_paths, path_to_keys, error_mgr)>

This method is the constructor for this class.  It creates an empty
profile.  All parameters are required and described above in
L<"DESCRIPTION">.

=head2 B<generateProfile(@params)>

This is an abstract method for generating profiles that a subclasses
implements to generate the profile's B<entities> attribute.

=head1 GETTER METHODS

These methods defines getter methods defined for this class.

=head2 B<$access_path = accessPath>

This method returns the access path for database reader.

=head2 B<$db = db>

This method returns the database session for the object.

=head2 B<isGenerator>

This method returns TRUE (1) is the profiler is a generator, otherwise
it returns FALSE (0)--not a generator.

=head2 B<$product = product>

This method returns the product for the object.

=head2 B<$release_timestamp = releaseTs>

This method returns the release timestamp for the object.

=head2 B<writeProfile (generate_schema[, do_not_write_top_level]>

This is a re-implementable method for writing a profile that
subclasses can implement to write a profile somewhere.  By default,
this method generates the bcp files for the current entities using
B<generate_schema> which is assumed to be an instance of the class
or subclass of L<db::Schema::Generate>.  The optional parameter 
(if defined and TRUE (1))specifies that only lower-level structures 
will be written, otherwise the top-level structure will also be written.

=cut
