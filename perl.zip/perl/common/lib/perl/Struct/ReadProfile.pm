package perl::Struct::ReadProfile;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::DbQuery;
use util::FileTime;
use util::PerlObject;

use perl::ErrMsgs;

use fields
  qw(
  access_comps
  access_info
  entities
  error_mgr
  infinite_time
  oracle_dates
  oracle_date_format
  product_name
  profile
  queries
  release_ts
  set_dates
  tag_to_query
  unix_timestamps
);

################################################################################
#
#				   Constants
#
################################################################################
###
### Error Category
###
sub ERR_CAT { return perl::ErrMsgs::READPROFILE_CAT; }
###
### Components for a Query in Access Info
###
sub ACCESS_COMPONENTS {
  return [
    'acts', 'cmd',  'fort', 'hint', 'map',  'nopp', 'nosub', 'notp',
    'ord',  'prdn', 'ptag', 'tag',  'tsot', 'tspf', 'usesp',
  ];
}
###
### Time Predicates
###
### 1.  Current Data:  OBS_TS = MAXTS
###
### 2.  Release Data (release timestamp = T):
###
###     All new and updated rows associated with a release R will have a
###     CRE_TS column value = T.  All made obsolete by the same release will
###     have OBS_TS = T.  In order to retrieve all rows associated with that
###     release, the where clause should be WHERE CRE_TS <= T and OBS_TS > T.
###
sub RELEASE_TS_PARAM { return '__RELEASE_TS__'; }
sub TS_PREFIX_PARAM  { return '__TS_PREFIX__'; }

sub CURRENT_TIME_PREDICATE {
  return 'and   ' . &TS_PREFIX_PARAM . 'obs_ts = maxTs' . "\n";
}

sub RELEASE_TIME_PREDICATE {
  return 'and   '
    . &TS_PREFIX_PARAM
    . 'cre_ts <= '
    . &RELEASE_TS_PARAM . ' and '
    . &TS_PREFIX_PARAM
    . 'obs_ts > '
    . &RELEASE_TS_PARAM . "\n";
}
###
### Product Name Predicate
###
sub PRODUCT_NAME     { return '__PRODUCT_NAME__'; }
sub PRODUCT_NAME_COL { return 'product_name'; }
sub PRODUCT_PARAM    { return '__PRODUCT_PARAM__'; }

sub PRODUCT_PREDICATE {
  return 'and   ' . &PRODUCT_NAME . " = '" . &PRODUCT_PARAM . "'\n";
}

################################################################################
#
#			 Private Data Gathering Methods
#
################################################################################

################################################################################
###
### _setDates:
### If set_dates is not defined leave date 'as-is' (defaulted to DD-Mon-YYYY).
### If set_dates is TRUE, then set to Oracle date (DD-Mon-YYYY), otherwise
### convert to UNIX timestamp.
###
################################################################################

sub _setDates {
  my perl::Struct::ReadProfile $this = shift;
  my ($struct) = @_;
  return if ( !defined( $this->{set_dates} ) );
  foreach my $oracle_date ( keys %{ $this->{oracle_dates} } ) {
    next if ( !defined( $struct->{$oracle_date} ) );
    if ( $struct->{$oracle_date} eq util::Constants::EMPTY_STR ) {
      $struct->{$oracle_date} = undef;
    }
    else {
      $struct->{$oracle_date} = &get_str_time( $struct->{$oracle_date} );
      if ( $this->{set_dates} ) {
        $struct->{$oracle_date} =
          &get_oracle_str( $struct->{$oracle_date}, util::Constants::TRUE );
      }
      else {
        $struct->{$oracle_date} = &get_unix_str( $struct->{$oracle_date} );
      }
    }
  }
  foreach my $unix_timestamp ( keys %{ $this->{unix_timestamps} } ) {
    next if ( !defined( $struct->{$unix_timestamp} ) );
    if ( $struct->{$unix_timestamp} eq util::Constants::EMPTY_STR
      || $struct->{$unix_timestamp} == 0 )
    {
      $struct->{$unix_timestamp} = undef;
    }
    elsif ( $struct->{$unix_timestamp} != $this->{infinite_time} ) {
      $struct->{$unix_timestamp} = &get_unix_time( $struct->{$unix_timestamp} );
      if ( $this->{set_dates} ) {
        $struct->{$unix_timestamp} =
          &get_oracle_str( $struct->{$unix_timestamp}, util::Constants::TRUE );
      }
      else {
        $struct->{$unix_timestamp} =
          &get_unix_str( $struct->{$unix_timestamp} );
      }
    }
  }
}

################################################################################
###
### _moveDbDataIntoStruct:
### Get the database data retrieved by the query and deposit into struct.
###
################################################################################

sub _moveDbDataIntoStruct {
  my perl::Struct::ReadProfile $this = shift;
  my ( $query, $struct, $row ) = @_;
  my $acts  = $this->{access_info}->{$query}->{acts};
  my $order = $this->{access_info}->{$query}->{ord};
  foreach my $index ( 0 .. $#{$order} ) {
    my $column = $order->[$index];
    my $value  = $row->[$index];
    if ( defined( $acts->{$column} ) ) {
      $value = &{ $acts->{$column} }($value);
    }
    $struct->{$column} = $value;
  }
  $this->_setDates($struct);
}

################################################################################
###
### _setOracleDates:
### sets the list of oracle date columns
###
################################################################################

sub _setOracleDates {
  my perl::Struct::ReadProfile $this = shift;
  my ($oracle_dates) = @_;
  return
    if ( !defined($oracle_dates)
    || ref($oracle_dates) ne util::PerlObject::ARRAY_TYPE );
  foreach my $oracle_date ( @{$oracle_dates} ) {
    $this->{oracle_dates}->{$oracle_date} = util::Constants::EMPTY_STR;
  }
}

################################################################################
###
### _setUnixTimestamps:
### sets the list of oracle date columns
###
################################################################################

sub _setUnixTimestamps {
  my perl::Struct::ReadProfile $this = shift;
  my ($unix_timestamps) = @_;
  return
    if ( !defined($unix_timestamps)
    || ref($unix_timestamps) ne util::PerlObject::ARRAY_TYPE );
  foreach my $unix_timestamp ( @{$unix_timestamps} ) {
    $this->{unix_timestamps}->{$unix_timestamp} = util::Constants::EMPTY_STR;
  }
}

################################################################################
###
### _setOracleDateFormat:
### For Oracle databases, this method allows the date format to be specified for
### acquisition of Oracle date columns.  By default, the format is  date only
### format:  B<'DD-Mon-yyyy'>.
###
################################################################################

sub _setOracleDateFormat {
  my perl::Struct::ReadProfile $this = shift;
  my ($oracle_date_format) = @_;
  return
    if ( !defined($oracle_date_format)
    || $oracle_date_format eq util::Constants::EMPTY_STR );
  if ( $oracle_date_format !~ /^'/ ) {
    $oracle_date_format = "`$oracle_date_format";
  }
  if ( $oracle_date_format !~ /'$/ ) {
    $oracle_date_format = "$oracle_date_format'";
  }
  $this->{oracle_date_format} = $oracle_date_format;
}

################################################################################
###
### _setupAccessQueries:
###
### This method prepares all the queries specified in the reference hash
### access_info for populating the struct from the database.  Each key is a
### query that can be used in the method getData(query).
###
################################################################################

sub _setupAccessQueries {
  my perl::Struct::ReadProfile $this = shift;
  my ($access_info)          = @_;
  my $profile                = $this->{profile};
  ###
  ### Setup the time predicate
  ###
  my $time_predicate   = undef;
  my $release_ts_param = RELEASE_TS_PARAM;
  my $ts_prefix_param  = TS_PREFIX_PARAM;
  my $release_ts_sub   = $this->{release_ts};
  if ( defined($release_ts_sub) ) {
    $time_predicate = RELEASE_TIME_PREDICATE;
    $time_predicate =~ s/$release_ts_param/$release_ts_sub/g;
  }
  else {
    $time_predicate = CURRENT_TIME_PREDICATE;
  }
  ###
  ### Setup the product name predicate
  ###
  my $product_predicate = undef;
  my $product_name      = PRODUCT_NAME;
  my $product_name_col  = PRODUCT_NAME_COL;
  my $product_param     = PRODUCT_PARAM;
  my $product_name_sub  = $this->{product_name};
  if ( defined($product_name_sub) ) {
    $product_predicate = PRODUCT_PREDICATE;
    $product_predicate =~ s/$product_param/$product_name_sub/g;
  }
  ###
  ### Create access_info
  ###
  my $tag_to_query = $this->{tag_to_query};
  $this->{access_info} = {};
  while ( my ( $query_name, $query_struct ) = each %{$access_info} ) {
    my $struct = { msg => "$query_name query", };
    foreach my $comp ( @{ $this->{access_comps} } ) {
      my $value = $query_struct->{$comp};
      if ( $comp eq 'cmd'
        || $comp eq 'tag' )
      {
        $this->{error_mgr}->exitProgram(
          ERR_CAT, 4,
          [ $query_name, $comp ],
          !defined($value) || $value eq util::Constants::EMPTY_STR
        );
      }
      elsif ( $comp eq 'ord' ) {
        $this->{error_mgr}->exitProgram( ERR_CAT, 4, [ $query_name, $comp ],
               !defined($value)
            || ref($value) ne util::PerlObject::ARRAY_TYPE
            || @{$value} == 0 );
        $value = [ @{$value} ];
      }
      elsif ( $comp eq 'acts'
        || $comp eq 'map' )
      {
        if ( defined($value)
          && ref($value) eq util::PerlObject::HASH_TYPE )
        {
          $value = { %{$value} };
        }
        else {
          $value = {};
        }
      }
      elsif ( $comp eq 'ptag' ) {
        if ( defined($value)
          && ref($value) eq util::PerlObject::ARRAY_TYPE )
        {
          $value = [ @{$value} ];
        }
        elsif ( defined($value)
          && $value ne util::Constants::EMPTY_STR )
        {
          $value = [$value];
        }
        else {
          $value = [];
        }
      }
      elsif ( $comp eq 'tsot' ) {
        if ( defined($value)
          && ref($value) eq util::PerlObject::ARRAY_TYPE )
        {
          $value = [ @{$value} ];
        }
        else {
          $value = [];
        }
      }
      elsif ( $comp eq 'fort'
        || $comp eq 'hint'
        || $comp eq 'prdn'
        || $comp eq 'tspf' )
      {
        $value =
          ( defined($value) && $value ne util::Constants::EMPTY_STR )
          ? $value
          : undef;
      }
      elsif ( $comp eq 'nopp'
        || $comp eq 'nosub'
        || $comp eq 'notp'
        || $comp eq 'usesp' )
      {
        $value =
          ( defined($value) && $value )
          ? util::Constants::TRUE
          : util::Constants::FALSE;
      }
      $struct->{$comp} = $value;
    }
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 12,
      [ $query_name, $struct->{usesp} ],
      !( scalar @{ $struct->{ptag} } > 0 || $struct->{usesp} )
    );
    ###
    ### Test need for product predicate
    ###
    $this->{error_mgr}->exitProgram( ERR_CAT, 10, [$query_name],
      !( $struct->{nopp} || defined($product_predicate) ) );
    ###
    ### Set tag to query map
    ###
    my $tag_to_query_key = $struct->{tag};
    if ( defined( $struct->{fort} ) ) {
      $tag_to_query_key .= '.' . $struct->{fort};
    }
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 11,
      [ $tag_to_query_key, $query_name, $tag_to_query->{$tag_to_query_key} ],
      defined( $tag_to_query->{$tag_to_query_key} )
    );
    $tag_to_query->{$tag_to_query_key} = $query_name;
    ###
    ### Add the time predicate to the query
    ### command only if notp is FALSE (0).
    ###
    if ( !$struct->{notp} ) {
      my $prefix       = $ts_prefix_param;
      my $prefix_value = util::Constants::EMPTY_STR;
      ###
      ### Use designated timestamp
      ### prefix if tspf is defined
      ###
      if ( defined( $struct->{tspf} ) ) {
        $prefix_value = $struct->{tspf} . '.';
      }
      $struct->{cmd} .= $time_predicate;
      $struct->{cmd} =~ s/$prefix/$prefix_value/g;
      ###
      ### Add other time predicates, as necessary
      ###
      foreach my $other_prefix ( @{ $struct->{tsot} } ) {
        $other_prefix  .= '.';
        $struct->{cmd} .= $time_predicate;
        $struct->{cmd} =~ s/$prefix/$other_prefix/g;
      }
    }
    ###
    ### Add the product predicate to the query
    ### command only if nopp is FALSE (0).
    ###
    if ( !$struct->{nopp} ) {
      my $prod_col = $product_name_col;
      ###
      ### Use designated product name
      ### if prdn is defined
      ###
      if ( defined( $struct->{prdn} ) ) { $prod_col = $struct->{prdn}; }
      $struct->{cmd} .= $product_predicate;
      $struct->{cmd} =~ s/$product_name/$prod_col/g;
    }
    ###
    ### Verify query and struct
    ### 1.  Tag must be either an ARRAY or HASH
    ### 2.  Check ord components against structure
    ###
    $struct->{tag_ref} = $profile->tagRef( $struct->{tag} );
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 5,
      [ $query_name, $struct->{tag} ],
      !defined( $struct->{tag_ref} )
    );
    my $s_struct = undef;
    if ( $struct->{tag_ref} eq util::PerlObject::ARRAY_TYPE ) {
      $s_struct = $profile->initializeSubstructByComponent( $struct->{tag} );
    }
    else {
      $s_struct = $profile->initializeSubstruct( $struct->{tag} );
    }
    foreach my $comp ( @{ $struct->{ord} } ) {
      $this->{error_mgr}->exitProgram(
        ERR_CAT, 6,
        [ $query_name, $struct->{tag}, $comp, join( ', ', %{$s_struct} ) ],
        !exists( $s_struct->{$comp} ) || ref( $s_struct->{$comp} )
      );
    }

    $this->{access_info}->{$query_name} = $struct;
  }
  ###
  ### Create the Queries
  ###
  my $oracle_dates = $this->{oracle_dates};
  while ( my ( $query_name, $query_struct ) = each %{ $this->{access_info} } ) {
    if ( !$query_struct->{nosub} ) {
      my $select_cmd = 'select ';
      my $indent     = length($select_cmd);
      my $hint       = $query_struct->{hint};
      my $map        = $query_struct->{map};
      if ( defined($hint) ) {
        $select_cmd .=
          '/*+ index(HINT ' . $hint . ')*/' . "\n"
          . &util::Constants::SPACE x $indent;
      }
      foreach my $index ( 0 .. $#{ $query_struct->{ord} } ) {
        my $column = $query_struct->{ord}->[$index];
        if ( $index > 0 ) {
          $select_cmd .=
            util::Constants::COMMA_SEPARATOR . "\n"
            . &util::Constants::SPACE x $indent;
        }
        if ( defined( $map->{$column} ) ) { $column = $map->{$column}; }
        if ( defined( $oracle_dates->{$column} ) ) {
          $select_cmd .=
            "to_char($column, " . $this->{oracle_date_format} . ')';
        }
        else {
          $select_cmd .= $column;
        }
      }
      $query_struct->{cmd} = $select_cmd . "\n" . $query_struct->{cmd};
    }
  }
  $this->{queries}->createAndPrepareQueries( $this->{access_info} );
}

################################################################################
###
### _generateEntity:
###
################################################################################

sub _getData {
  my perl::Struct::ReadProfile $this = shift;
  my ( $entity, $tag, $query_tag, $id ) = @_;
  my $tag_to_query = $this->{tag_to_query};
  my $query_name   = (
    !defined($query_tag)
    ? (
      defined( $tag_to_query->{$tag} )
      ? $tag_to_query->{$tag}
      : undef
      )
    : (
      defined( $tag_to_query->{$query_tag} )
      ? $tag_to_query->{$query_tag}
      : (
        defined( $tag_to_query->{"$query_tag.$tag"} )
        ? $tag_to_query->{"$query_tag.$tag"}
        : undef
      )
    )
  );
  return if ( !defined($query_name) );
  my $query_struct = $this->{access_info}->{$query_name};
  my @query_array  = ();
  if ( $query_struct->{usesp} ) { push( @query_array, $id ); }

  foreach my $path ( @{ $query_struct->{ptag} } ) {
    push( @query_array, $this->{profile}->getCValue( $entity, $path ) );
  }
  $this->getData( $query_name, $entity, @query_array );
}

sub _generateEntity {
  my perl::Struct::ReadProfile $this = shift;
  my ( $entity, $tag, $id ) = @_;
  my $profile = $this->{profile};
  ###
  ### First, determine the component
  ### path tag name if there is one
  ###
  my $comp_path = $profile->getComponentTag($tag);
  if ( defined($comp_path) ) { $tag = $comp_path; }
  ###
  ### Second, if this is a search path
  ### entity, determine its id to use
  ###
  my $entities = $this->{entities};
  if ( defined( $entities->{$tag} ) ) {
    $id = undef;
    foreach my $locator_path ( $profile->locatorsForSearchPath($tag) ) {
      my $new_id = $profile->getCValue( $entity, $locator_path );
      next if ( !defined($new_id) );
      $id = $new_id;
      last;
    }
  }
  return if ( !defined($id) );
  ###
  ### Fourth, process the entity
  ###
  my @comps = keys %{$entity};
  foreach my $comp (@comps) {
    my $comp_ref = $profile->tagRef($comp);
    next if ( !defined($comp_ref) );
    my $comp_entity = $entity->{$comp};
    next if ( !defined($comp_entity)
      || ref($comp_entity) ne $comp_ref );
    $this->_getData( $entity, $tag, $comp, $id );
    if ( $comp_ref eq util::PerlObject::HASH_TYPE ) {
      $this->_generateEntity( $comp_entity, $comp, $id );
    }
    elsif ( $comp_ref eq util::PerlObject::ARRAY_TYPE ) {
      foreach my $sub_entity ( @{$comp_entity} ) {
        $this->_generateEntity( $sub_entity, $comp, $id );
      }
    }
  }
}

################################################################################
#
#				 Object Methods
#
################################################################################
###
### Constructor Method
###
sub new {
  my perl::Struct::ReadProfile $this = shift;
  my ( $profile, $oracle_date_format, $oracle_dates, $unix_timestamps,
    $access_info, $error_mgr )
    = @_;
  $this = fields::new($this) unless ref($this);
  ###
  ### Check for missing data
  ###
  $error_mgr->exitProgram( ERR_CAT, 2, [],
    !defined($profile) || !ref($profile) );
  $error_mgr->exitProgram( ERR_CAT, 1, [],
    !defined( $profile->db ) || !ref( $profile->db ) );
  $error_mgr->exitProgram( ERR_CAT, 9, [],
    !defined($access_info)
      || ref($access_info) ne util::PerlObject::HASH_TYPE );

  $this->{access_comps}       = ACCESS_COMPONENTS;
  $this->{access_info}        = undef;
  $this->{error_mgr}          = $error_mgr;
  $this->{infinite_time}      = $profile->db->INFINITE_TIME;
  $this->{oracle_date_format} = OracleDateOnlyFormat;
  $this->{oracle_dates}       = {};
  $this->{profile}            = $profile;
  $this->{queries}            = new util::DbQuery( $profile->db );
  $this->{release_ts}         = $profile->releaseTs;
  $this->{set_dates}          = undef;
  $this->{tag_to_query}       = {};
  $this->{unix_timestamps}    = {};
  ###
  ### Product Name defined by profile product
  ### (if none, then undef)
  ###
  $this->{product_name} =
    ( defined( $profile->product ) && ref( $profile->product ) )
    ? $profile->product->productName
    : undef;
  ###
  ### Database access information setup
  ###
  $profile->db->setLongReadLen( $profile->db->LOB_LENGTH )
    if ( $profile->db->getServer eq 'OracleDB' );
  ###
  ### Set Oracle Dates and Unix Timestamps
  ###
  $this->_setOracleDateFormat($oracle_date_format);
  $this->_setOracleDates($oracle_dates);
  $this->_setUnixTimestamps($unix_timestamps);
  ###
  ### Create the queries
  ###
  $this->_setupAccessQueries($access_info);
  ###
  ### entities
  ###
  foreach my $search_path ( $this->{profile}->searchPaths ) {
    $this->{entities}->{$search_path} = util::Constants::EMPTY_STR;
  }

  return $this;
}

sub setDatesFlag {
  my perl::Struct::ReadProfile $this = shift;
  my ($set_dates) = @_;
  $this->{set_dates} =
    ( !defined($set_dates) )
    ? undef
    : ( ($set_dates) ? util::Constants::TRUE: util::Constants::FALSE );
}

sub getData {
  my perl::Struct::ReadProfile $this = shift;
  my ( $query, $entity_struct, @query_array ) = @_;
  my $profile = $this->{profile};
  $this->{error_mgr}->printDebug("Executing query $query");
  $this->{error_mgr}->exitProgram( ERR_CAT, 7, [ $query, ref($entity_struct) ],
    !defined( $this->{access_info}->{$query} )
      || ref($entity_struct) ne util::PerlObject::HASH_TYPE );
  my $tag     = $this->{access_info}->{$query}->{tag};
  my $tag_ref = $this->{access_info}->{$query}->{tag_ref};
  my $struct  = undef;
  if ( $profile->tag eq $tag ) { $struct = $entity_struct; }
  else { $struct = $entity_struct->{$tag}; }
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 8,
    [ $query, $tag, $tag_ref, ref($struct) ],
    !defined($struct) || ref($struct) ne $tag_ref
  );
  $this->{queries}->executeQuery( $query, @query_array );
  my $acquired_data = util::Constants::FALSE;

  while ( my $row_ref = $this->{queries}->fetchRowRef($query) ) {
    $acquired_data = util::Constants::TRUE;
    my $component = $struct;
    if ( $tag_ref eq util::PerlObject::ARRAY_TYPE ) {
      $component = $profile->initializeSubstructByComponent($tag);
    }
    $this->_moveDbDataIntoStruct( $query, $component, $row_ref );
    push( @{$struct}, $component )
      if ( $tag_ref eq util::PerlObject::ARRAY_TYPE );
  }
  return $acquired_data;
}

sub generateProfileEntity {
  my perl::Struct::ReadProfile $this = shift;
  my ( $accession, $entity_tag, $access_path ) = @_;

  ######################################################
  ### !!!Must make sure accession is bland string!!! ###
  ######################################################
  $accession = eval "'" . $accession . "'";

  my $profile = $this->{profile};
  ###
  ### Get accession and check status.  If status
  ### is FALSE, then return immediately.
  ###
  my $entity_ids =
    $profile->getEntityIds( $accession, $entity_tag, $access_path );
  return util::Constants::FALSE if ( @{$entity_ids} == 0 );
  ###
  ### Process
  ###
  foreach my $entity_id ( @{$entity_ids} ) {
    $this->{error_mgr}->printDebug("Entity ID = $entity_id");
    $profile->setEntity;
    my $entity = $profile->entity;
    my $tag    = $profile->tag;
    $this->_getData( $entity, $tag, undef, $entity_id );
    $this->_generateEntity( $entity, $tag );
    $profile->moveEntity;
  }
  ###
  ### Return the status
  ###
  return util::Constants::TRUE;
}

sub closeQueries {
  my perl::Struct::ReadProfile $this = shift;
  ###
  ### Finish the queries; Do NOT Close DB Connection
  ###
  foreach my $query ( keys %{ $this->{access_info} } ) {
    $this->{queries}->finishQuery($query);
  }
}

################################################################################

1;

__END__

=head1 NAME

ReadProfile.pm

=head1 SYNOPSIS

   use util::Constants;
   use util::Db;
   use util::ErrMgr;
   use util::PerlStruct;
   use perl::Struct::ReadProfile;

   use eSNP:: Profile;

   my $error_mgr = new util::ErrMgr;

   my $db =
     new util::Db
       ($db_config,
        $error_mgr);
   $error_mgr->addDb($db);

   my $profile =
     new eSNP::Profile
       ($product,
        $db,
        $release_ts,
        $error_mgr)

   my $reader =
     new perl::Struct::ReadProfile
       ($profile,
        $oracle_date_format,
        $oracle_dates,
        $unix_timestamps,
        $access_info,
        $error_mgr);

=head1 DESCRIPTION

This concrete class implements the database reader that loads a
profile from a database.  The context of the instantiation of this
class defines the required parameters to the constructor that are
described below and illustrated:


=over 4

=item B<profile>

The profile defines the profile object instance that describes the
entity data-structure, the data product, database connection, and
release timestamp.  A profile is assumed to be a subclass of
L<perl::Struct::Profile> and must provide the following call-back method:

B<$entity_ids = getEntityIds(accession, entity_tag, access_path)>.

This method return a referenced array (entity_ids) that defines the
entity identifier(s) for accessing top-level B<tag> (entity_tag)
entity(ies) data-structure(s) from the database.  These identifiers
must represent existing database data.

=item B<oracle_date_format>

The optional (may be undef) oracle date format is useful with Oracle
databases and defines the string format for an oracle date to
returned.  By default, this format is B<DD-Mon-YYYY>.

=item B<oracle_dates>

This optional (may be undef or empty) referenced array of columns that
are Oracle dates.

=item B<unix_timestamps>

This optional (may be undef or empty) referenced array of columns that
are UNIX timestamps.

=item B<access_info>

This required reference hash defines the queries for accessing the
database and loading the profile.  Information in this data-structure
uses SQL and specifics about the profile data-structure specification.

=item B<error_mgr>

The error messaging object is an instance of L<util::ErrMgr> and is
required.

=back


The B<access_info> reference hash data-structure is specified
specified as follows.  Each key of access_info defines a query for
retrieving information from the database for loading into the profile.
The value of the key is a referenced hash data-structure with the
following query specification keys.  Missing required keys cause
program termination.

B<Required Keys:>

=over 4


=item B<cmd>

Either the full query (B<nosub> key defined and has value TRUE (1)) or
the query cmd suffix (e.g., "from ...") to execute.

=item B<tag>

The profile tag into which the data is to be deposited.  This tag must
either represent a hash or an array in the profile.  Both cases are
handled appropiately.

=item B<ptag>

This key defines the scalar component(s) in the the parent hash
structure that contains the query execution parameter value.  If not
defined, B<usesp> must be defined and TRUE (1).  Both values can be
defined in which case B<usesp> comes first in the query execution
parameter list.  The B<ptag> value can be a scalar value which is
interpreted as a single column or a reference array of several
columns.

=item B<ord>

The referenced array of ordered fields in the tag or tag components
(in case the B<tag> is an array).  That is, these fields must be
scalar component values for the B<tag> or its component tag.  If nosub
is is not defined or FALSE (0), then this list also specifies the
column names modulo B<map> for the select portion of the query command
B<cmd>.

=item B<usesp>

If this key is defined and TRUE (1), then the search parent id must be
used in the query execution parameter list as the first entry.
Otherwise, it is not used.  If not defined or FALSE (0), then B<ptag>
must be defined above.  Both values can be defined.  The search parent
id is defined for the entity or sub-entity id as defined the profile's
B<search_path> (see L<perl::Struct>).

=back


B<Optional Keys:>

=over 4

=item B<nosub>

If this key is defined and TRUE (1), then the cmd key is a full query
and is executed 'as-is'.  Otherwise, the B<ord> key list also
specifies the columns of the the select portion of of the query modulo
the B<map> key if it is defined.

=item B<map>

If the may key is defined, then it is a reference hash whose keys are
B<ord> list values and its values are table column values that they
are mapped to.  This hash therefore specifies the columns of the
select portion of the B<cmd> query that are not identical to the
B<ord> list values.

=item B<fort>

If more than one query command uses the same B<tag>, then this key
provides the parent tag into which the data is to be deposited.  If
there are two query commands with the same B<tag> but no B<fort> key,
then the program will terminate.

=item B<notp>

If the notp key is defined and TRUE (1), then NO time predicate is
appended to the query command, otherwise a time predicate is appended
to the query comamnd.

If notp is not defined or FALSE (0), then time predicates are defined
as follows.  If the profile's release timestamp as acquired by the
B<releaseTs> method is defined, then the time predicate is:

    and   cre_ts <= <releaseTs> and obs_ts > <releaseTs>

If the profile's release timestamp is not defined, then it is:

    and   obs_ts = maxTs

where B<maxTs> is by convention is the PL/SQL function returning the
infinite UNIX time (99999999999).

=item B<tspf>

If the timestamp columns (B<cre_ts> and B<obs_ts>) for the query
command B<cmd> must be prefix by a table alias, then this key
indicates the prefix to assign to these columns, namely B<tspf>.cre_ts
and B<tspf>.obs_ts.

=item B<tsot>

If this tag is defined as an array of table alias prefixes and B<notp>
is FALSE (0), then an appropriate time predicate will be added to the
B<cmd> for each prefix in the array, otherwise no action will be
taken.

=item B<prdn>

If the product name column name for the query command B<cmd> is not
B<'product_name'>, then this key indicates the column name to use for
the product name predicate.

=item B<nopp>

If the nopp key is defined and TRUE (1), then NO product name
predicate is appended to the query command <cmd>, otherwise a product
name predicate is appended the query comamnd.

If B<nopp> is not defined or FALSE (0), the a product name predicate
is appended to query command B<cmd>.  The value of thd data product
name is determined from the profile's product method B<productName>.
If B<prdn> is not defined, then the product name predicate is:

  and   product_name = <productName>

If B<prdn> is defined, then the product name predicate is:

  and   <prdn> = <productName>

=item B<hint>

For Oracle queries, this key represents the index of the query command
B<cmd>.  By convention, the hint table must has an aliased of
B<'HINT'>.

=item B<acts>

If the acts key is defined, then it is a reference hash whose keys are
B<ord> list values and its value is a function (Perl sub) that expects
one parameter (the column value).  The function will be applied to the
column value, before it is assigned to the scalar component in the
structure of component.

=back

The following example fully describes the specification of the eSNP
reader.  In the B<access_info> specification
below the strings like B<__.+__> are replaced with specific values by
the eSNP class being provided to the constructor of ReadProfile.


=over 4

=item B<oracle_date_format>

B<undef> --uses default format

=item B<oracle_dates>

   [
    'date_created',
    'date_last_updated',
   ]

=item B<unix_timestamps>

   [
    'cre_ts',
    'obs_ts',
   ]

=item B<access_info>

    {
     getRsByRsAccession =>
     {
      tag   => 'rs',
      usesp => 1,
      ord   => [
		'subm_acc',
		'rs_acc',
	       ],
      map   => {
		'rs_acc' => 'subm_acc',
	       },
      nopp  => 1,
      hint  => 'XI_SUBM_SUBM_ACC_ISCLUSTER',
      cmd   => "
                from  esnp.submission HINT
                where is_cluster = 1
                and   subm_acc   = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getRsBySsAccession =>
     {
      tag   => 'rs',
      fort  => 'ss',
      ptag  => 'rs_cluster_acc',
      ord   => [
		'subm_acc',
	       ],
      map   => {
		'subm_acc' => 'rs_cluster_acc',
	       },
      nopp  => 1,
      hint  => 'XPKDBSNP_SUBMISSION',
      cmd   => "
                from  esnp.dbsnp_submission HINT
                where subm_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getRs =>
     {
      tag   => 'dbsnp_rs_cluster',
      usesp => 1,
      ord   => [
		'build_created',
		'build_last_updated',
		'cre_ts',
		'date_created',
		'date_last_updated',
		'exemplar_acc',
		'issue_id',
		'last_trans_id',
		'map_weight',
		'mol_type_name',
		'num_chr_hits',
		'num_ctg_hits',
		'num_seq_loc',
		'obs_ts',
		'rs_het',
		'snp_class_name',
		'snp_type_name',
		'sts_id',
		'valid_prob_max',
		'valid_prob_min',
	       ],
      nopp  => 1,
      hint  => 'XPKDBSNP_RS_CLUSTER',
      cmd   => "
                from  esnp.dbsnp_rs_cluster HINT
                where rs_cluster_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getSss =>
     {
      tag   => 'sss',
      usesp => 1,
      ord   => [
		'subm_acc',
		'rs_acc',
	       ],
      map   => {
		'rs_acc' => 'rs_cluster_acc',
	       },
      nopp  => 1,
      hint  => 'XI_DBSNP_SUBM_RS_ACC',
      cmd   => "
                from  esnp.dbsnp_submission HINT
                where rs_cluster_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getSs =>
     {
      tag   => 'dbsnp_submission',
      usesp => 1,
      ord   => [
		'comment1',
		'cre_ts',
		'issue_id',
		'lab_name',
		'last_trans_id',
		'meth_class_name',
		'mol_type_name',
		'obs_ts',
		'rs_cluster_acc',
		'snp_class_name',
		'ss_linkout_url',
		'ss_rs_orientation',
		'ss_validated',
		'submitter_snp_id',
	       ],
      nopp  => 1,
      hint  => 'XPKDBSNP_SUBMISSION',
      cmd   => "
                from  esnp.dbsnp_submission HINT
                where subm_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getSubmission =>
     {
      tag   => 'submission',
      usesp => 1,
      ord   => [
		'assay3_len',
		'assay5_len',
		'cre_ts',
		'flank_3',
		'flank_5',
		'is_cluster',
		'is_seq_truncated',
		'is_validated',
		'issue_id',
		'last_trans_id',
		'obs_ts',
		'observed_alleleset',
	       ],
      nopp  => 1,
      hint  => 'XPKSUBMISSION',
      cmd   => "
                from  esnp.submission HINT
                where subm_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getSubmissionSeq =>
     {
      tag   => 'submission_seq',
      usesp => 1,
      ord   => [
		'assay3_len',
		'assay5_len',
		'cre_ts',
		'flank_3',
		'flank_5',
		'issue_id',
		'last_trans_id',
		'obs_ts',
	       ],
      nopp  => 1,
      hint  => 'XPKSUBM_SEQ',
      cmd   => "
                from  esnp.submission_seq HINT
                where subm_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getClusterMappings =>
     {
      tag   => 'cluster_mappings',
      usesp => 1,
      ord   => [
		'cre_ts',
		'hit_quality',
		'issue_id',
		'last_trans_id',
		'location_id',
		'location_type',
		'obs_ts',
	       ],
      nopp  => 1,
      hint  => 'XPKCLUSTER_MAPPING',
      cmd   => "
                from  esnp.cluster_mapping HINT
                where cluster_acc      = ?
                and   loc_part_key     = __LOC_PART_KEY__
                and   mapping_part_key = __MAPPING_PART_KEY__
               ",
     },

     getLocation =>
     {
      tag   => 'location',
      ptag  => 'location_id',
      ord   => [
		'chr_left',
		'chr_name',
		'chr_orientation',
		'chr_right',
		'cre_ts',
		'ga_acc',
		'ga_accver',
		'ga_left',
		'ga_orientation',
		'ga_right',
		'issue_id',
		'last_trans_id',
		'location_id',
	       ],
      nopp  => 1,
      hint  => 'XPKLOCATION',
      notp  => 1,
      cmd   => "
                from  esnp.location HINT
                where location_id  = ?
                and   loc_part_key = __LOC_PART_KEY__
     },

     },

     &GETMRNADTAS =>
     {
      tag   => 'mrna_dtas',
      usesp => 1
      ptag  => 'location_id',
      ord   => [
		'allele_set',
		'cre_ts',
		'dta_run_name',
		'gene_acc',
		'gene_symbol',
		'issue_id',
		'last_trans_id',
		'mrna_acc',
		'mrna_domain_name',
		'mrna_domain_id',
		'obs_ts',
	       ],
      nopp  => util::Constants::TRUE,
      hint  => 'XI_MRNA_LOCATION',
      cmd   => "
                from  esnp.cluster_dta_map cdm,
                      esnp.mrna_dta        HINT
                where cdm.cluster_acc          = ?
                and   HINT.location_id         = ?
                and   cdm.mrna_domain_id       = HINT.mrna_domain_id
                and   HINT.loc_part_key        = __LOC_PART_KEY__
                and   HINT.dta_part_key        = __DTA_PART_KEY__
                and   cdm.cluster_dta_part_key = __CLUSTER_DTA_PART_KEY__
               ",
     },

     getProteinDtas =>
     {
      tag   => 'protein_dtas',
      ptag  => 'mrna_domain_id',
      ord   => [
		'allele_value',
		'cre_ts',
		'frame',
		'is_reference',
		'issue_id',
		'last_trans_id',
		'obs_ts',
		'protein_acc',
		'protein_begin',
		'protein_end',
		'residue',
	       ],
      nopp  => 1,
      hint  => 'XPKPROTEIN_DTA',
      cmd   => "
                from  esnp.protein_dta HINT
                where mrna_domain_id = ?
                and   dta_part_key   = __DTA_PART_KEY__
               ",
     },

     getSubmissionAlleles =>
     {
      tag   => 'submission_alleles',
      usesp => 1,
      ord   => [
		'allele_count',
		'allele_freq',
		'allele_value',
		'cre_ts',
		'issue_id',
		'last_trans_id',
		'obs_ts',
		'sample_size',
		'study',
		'subm_allele_id',
                'esnp_pop_id',
	       ],
      nopp  => 1,
      hint  => 'XI_SUBMALLELE_SUBM_ACC',
      cmd   => "
                from  esnp.submission_allele HINT
                where subm_acc = ?
                and   subm_part_key = __SUBM_PART_KEY__
               ",
     },

     getPopulation =>
     {
      tag   => 'population',
      ptag  => 'esnp_pop_id',
      ord   => [
		'cre_ts',
		'issue_id',
		'last_trans_id',
		'obs_ts',
		'submsrc_pop_class',
		'submsrc_pop_id',
		'submsrc_pop_type',
		'submsrc_submitter_pop_id',
	       ],
      nopp  => 1,
      hint  => 'XPKPOPULATION',
      cmd   => "
                from  esnp.population HINT
                where esnp_pop_id    = ?
               ",
     },

    };


=back


=head1 METHODS

These methods are used for populating a PerlStruct.

=head2 B<new perl::Struct::ReadProfile(profile, oracle_date_format, oracle_dates, unix_timestamps, access_info, error_mgr)>

This method is the constructor for the class.  The constructor
requires an instance of a subclass of L<perl::Struct::Profile> and an error
messsage handler l<util::ErrMgr>.  The constructor's parameters are
specified above in L<"DESCRIPTION">.

=head2 B<generateProfileEntity(accession, entity_tag, access_path)>

The method reads the profile entity data for the accession parameter
where it is of the entity_tag type and access_path path parameters.
This method assumes that the object's profile has the method
B<getEntityIds> as described above in L<"DESCRIPTION"> that will
generate the set of top-level B<tag> entity identifiers to generate
profile entity(ies) that will be added to the profiles's B<entities>
attribute list.

=head2 B<closeQueries>

The method allows a 'gentle' manner for closing the queries associated
with an object once they are no longer needed.  That is, once all
profile entities have been generated that are required by the calling
program.

=head1 SETTER METHODS

These methods are used to set the attributes for generation.

=head2 B<setDatesFlag(set_dates)>

This method sets B<set_dates> attribute.  It can be TRUE (1), FALSE
(0), or undefined (default value for the class).  If B<set_dates> is
undef, then Oracle date and UNIX timestamp columns will be left as
acccessed from the database.  If B<set_dates> is TRUE (1), then all
Oracle date columns and UNIX timestamp columns will be converted to
Oracle-style date format, B<DD-Mon-YYYY>.  If B<set_dates> is
FALSE (0), thne all Oracle date and UNIX timestamp colums will be
converted to UNIX timestamps.

=head1 GETTER METHODS

These methods are used to acquire data from the database.

=head2 B<$acquired_data = getData(query, entity_struct, @query_array)>

This method is used to execute a specif query B<query> with the
execution query parameters B<@query_array> and assign the result to
entity_struct as specified as follows.  The B<entity_struct> must be
hash.  If the B<tag> for the B<query> is a B<hash> and represents the
top-level B<tag> for the profile, then it assigns the query result
directly to B<entity_struct>.  Othewise, if the B<tag> is B<hash>,
then the B<entity_struct> must have this B<tag> as component and it
must be a hash.  The data is assigned to this component.  Finally, if
the B<tag> is an array, then the B<entity_struct> must have this tag
as component and is an array.  Each row of data from the query result
is assigned to a component struct for the array and added to array.
If data is assigned to the entity_struct, then this method returns
TRUE (0), otherwise it returns FALSE (0).

=cut
