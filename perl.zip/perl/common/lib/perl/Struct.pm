package perl::Struct;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Pod::Usage;

use util::Constants;
use util::PerlObject;

use perl::ErrMsgs;

use fields
  qw(
  array_of
  arrays
  entities
  entity
  error_mgr
  hashes
  locators
  map_params
  maps
  path_to_key
  scalar_keys
  search_entities
  search_to_locators
  structs
  tag
);

################################################################################
#
#				   Constants
#
################################################################################
###
### Error Class
###
sub ERR_CAT { return perl::ErrMsgs::STRUCT_CAT; }
###
### Mapping Record Tag
###
sub MAPPING_REC_PATH { return 'mapping_rec'; }
###
### Key component separator
###
sub KEY_SEPARATOR { return util::Constants::SLASH; }

################################################################################
#
#				Private Methods
#
################################################################################

################################################################################
###
### _initializeStructs
###   This method initializes the structs and validate the structure.
###
################################################################################

sub _initializeStructs {
  my perl::Struct $this = shift;
  my ($structs) = @_;
  $this->{array_of} = {};
  $this->{arrays}   = {};
  $this->{hashes}   = {};
  $this->{structs}  = {};
  my $found_tag = util::Constants::FALSE;
  while ( my ( $tag, $struct ) = each %{$structs} ) {
    $this->{error_mgr}->exitProgram( ERR_CAT, 1, [$tag],
      !defined($struct) || ref($struct) ne util::PerlObject::HASH_TYPE );
    my $kind     = $struct->{kind};
    my $type     = $struct->{type};
    my $type_ref = ref($type);
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 2,
      [ $tag, $kind, $type ],
      !defined($kind) || ( $kind ne util::PerlObject::ARRAY_TYPE
        && $kind ne util::PerlObject::HASH_TYPE )
        || !exists( $struct->{type} )
        || ( $type_ref
        && $type_ref ne util::PerlObject::HASH_TYPE )
    );
    $found_tag =
      ( $tag eq $this->tag && $kind eq util::PerlObject::HASH_TYPE )
      ? util::Constants::TRUE
      : $found_tag;
    $this->{structs}->{$tag} = {
      kind => $kind,
      type => ($type_ref) ? { %{$type} } : $type,
    };
    if ( $kind eq util::PerlObject::ARRAY_TYPE
      && defined($type) )
    {
      $this->{arrays}->{$tag}    = [];
      $this->{array_of}->{$type} = $tag;
    }
    elsif ( $kind eq util::PerlObject::HASH_TYPE ) {
      $this->{hashes}->{$tag} = [];
    }
  }
  $this->{error_mgr}->exitProgram( ERR_CAT, 3, [ $this->tag ], !$found_tag );
  foreach my $tag ( keys %{ $this->{structs} } ) {
    my $struct   = $this->{structs}->{$tag};
    my $kind     = $struct->{kind};
    my $type     = $struct->{type};
    my $type_ref = ref($type);
    $this->{error_mgr}->exitProgram(
      ERR_CAT, 4,
      [ $tag, $kind, $type ],
      (
        $kind eq util::PerlObject::ARRAY_TYPE && defined($type) && ( ref($type)
          || !defined( $this->{structs}->{$type} )
          || $this->{structs}->{$type}->{kind} ne util::PerlObject::HASH_TYPE )
        )
        || ( $kind eq util::PerlObject::HASH_TYPE
        && $type_ref ne util::PerlObject::HASH_TYPE )
    );
    next if ( $type_ref ne util::PerlObject::HASH_TYPE );
    foreach my $comp ( keys %{$type} ) {
      my $comp_struct = $this->{structs}->{$comp};
      next if ( !defined($comp_struct) );
      if ( defined( $this->{hashes}->{$comp} ) ) {
        push( @{ $this->{hashes}->{$comp} }, $tag );
      }
      elsif ( defined( $this->{arrays}->{$comp} ) ) {
        push( @{ $this->{arrays}->{$comp} }, $tag );
      }
    }
  }
}

################################################################################
###
### _generateScalarKeys:
###   This method generates the scalar key lists for the hash structures.
###
################################################################################

sub _generateScalarKeys {
  my perl::Struct $this = shift;
  $this->{scalar_keys} = {};
  my @struct_keys = keys %{ $this->{structs} };
  foreach my $struct_key (@struct_keys) {
    next
      if (
      $this->{structs}->{$struct_key}->{kind} ne util::PerlObject::HASH_TYPE );
    my $struct   = $this->initializeSubstruct($struct_key);
    my @tag_keys = keys %{$struct};
    $this->{scalar_keys}->{$struct_key} = [];
    foreach my $tag_key (@tag_keys) {
      next if ( ref( $struct->{$tag_key} ) );
      push( @{ $this->{scalar_keys}->{$struct_key} }, $tag_key );
    }
  }
}

################################################################################
###
### _setupSearching:
###   Set up searching strategy
###
################################################################################

sub _setupSearching {
  my perl::Struct $this = shift;
  my ($search_paths) = @_;
  ###
  ### Top-level tag must be part of search paths
  ###
  $this->{error_mgr}->exitProgram( ERR_CAT, 13, [ $this->tag ],
         !defined($search_paths)
      || ref($search_paths) ne util::PerlObject::HASH_TYPE
      || !defined( $search_paths->{ $this->tag } ) );
  my $search_entities = {};
  ###
  ### Earch search path must be a hash tag
  ###
  my @search_paths = keys %{$search_paths};
  foreach my $tag (@search_paths) {
    my $hashes = $this->{hashes}->{$tag};
    $this->{error_mgr}->exitProgram( ERR_CAT, 14, [$tag], !defined($hashes) );
    $search_entities->{$tag} = [];
  }
  foreach my $tag (@search_paths) {
    my $array_tag = $this->{array_of}->{$tag};
    next if ( !defined($array_tag) );
    foreach my $with_tag ( @{ $this->{arrays}->{$array_tag} } ) {
      next if ( !defined( $search_entities->{$with_tag} ) );
      push( @{ $search_entities->{$with_tag} }, $array_tag );
    }
  }
  foreach my $tag (@search_paths) {
    foreach my $hash_tag ( @{ $this->{hashes}->{$tag} } ) {
      next if ( !defined( $search_entities->{$hash_tag} ) );
      push( @{ $search_entities->{$hash_tag} }, $tag );
    }
  }
  $this->{search_entities} = $search_entities;
}

################################################################################
###
### _setupLocators:  This method create the locators attribute.
###
################################################################################

sub _setupLocators {
  my perl::Struct $this  = shift;
  my ($search_paths)     = @_;
  my $search_to_locators = {};
  my %all_locator_paths  = ();
  while ( my ( $search_path, $locators ) = each %{$search_paths} ) {
    $this->{error_mgr}->exitProgram( ERR_CAT, 15, [$search_path],
           !defined($locators)
        || ref($locators) ne util::PerlObject::ARRAY_TYPE
        || @{$locators} == 0 );
    ###
    ### Associate the locator_paths to the search paths
    ###
    my $search_to_locator = {};
    foreach my $locator ( @{$locators} ) {
      $search_to_locator->{$locator} = util::Constants::EMPTY_STR;
      $all_locator_paths{$locator} = util::Constants::EMPTY_STR;
    }
    $search_to_locators->{$search_path} = $search_to_locator;
  }
  ###
  ### Create locator paths
  ###
  my $all_locator_paths = [ keys %all_locator_paths ];
  $this->_setupPathStruct( 'locators', $all_locator_paths );
  $this->{search_to_locators} = $search_to_locators;
}

################################################################################
###
### _setupPathStruct:  This method create a path structure attribute.
###
################################################################################

sub _setupPathStruct {
  my perl::Struct $this = shift;
  my ( $attribute, $paths, $initialize ) = @_;
  $initialize =
    ( defined($initialize) && $initialize )
    ? util::Constants::TRUE
    : util::Constants::FALSE;
  my @paths = ();
  if ( defined($paths)
    && ref($paths) eq util::PerlObject::ARRAY_TYPE )
  {
    $this->{$attribute} = {};
    push( @paths, @{$paths} );
  }
  else {
    @paths = keys %{ $this->{$attribute} };
  }
  foreach my $path (@paths) {
    $this->{$attribute}->{$path} = ($initialize) ? {} : undef;
  }
}

################################################################################
###
### _searchEntities:
###   Determine the search entities at a given level.
###
################################################################################

sub _searchEntities {
  my perl::Struct $this = shift;
  my ($level_kind) = @_;
  return $this->{search_entities}->{$level_kind};
}

################################################################################
###
### _validMap:
###    Checks for a valid map and that it exists.
###
################################################################################

sub _validMap {
  my perl::Struct $this = shift;
  my ($map_path)        = @_;
  my $is_valid_map      = defined( $this->{maps}->{$map_path} );
  $this->{error_mgr}->registerError( ERR_CAT, 5, [$map_path], !$is_valid_map );
  return $is_valid_map;
}

################################################################################
###
### _evaluateMapping:
### This method creates an evaluation of the mappings for an entity.
###
################################################################################

sub _evaluateMapping {
  my perl::Struct $this = shift;
  my ($entity) = @_;
  while ( my ( $map, $param_struct ) = each %{ $this->{map_params} } ) {
    my $id = $this->getCValue( $entity, $param_struct->{id} );
    next if ( !defined($id)
      || $id eq util::Constants::EMPTY_STR );
    my $comp_map    = $param_struct->{comp_map};
    my $mapping_rec = $this->initializeSubstruct(MAPPING_REC_PATH);
    foreach my $comp ( keys %{$comp_map} ) {
      my $value = $this->getCValue( $entity, $comp_map->{$comp} );
      next if ( !defined($value)
        || $value eq util::Constants::EMPTY_STR );
      $mapping_rec->{$comp} = $value;
    }
    $this->{maps}->{$map}->{$id} = $mapping_rec;
  }
}

sub _generateMaps {
  my perl::Struct $this = shift;
  my ( $entity, $entity_kind ) = @_;
  my $search_entities = $this->_searchEntities($entity_kind);
  $this->_evaluateMapping($entity) if ( defined($search_entities) );
  ###
  ### Descend into the Entity
  ###
  my @comps = keys %{$entity};
  foreach my $comp (@comps) {
    my $comp_tag_ref = $this->tagRef($comp);
    if ( $comp_tag_ref eq util::PerlObject::HASH_TYPE ) {
      $this->_generateMaps( $entity->{$comp}, $comp );
    }
    elsif ( $comp_tag_ref eq util::PerlObject::ARRAY_TYPE ) {
      my $sub_entity_tag = $this->getComponentTag($comp);
      foreach my $sub_entity ( @{ $entity->{$comp} } ) {
        $this->_generateMaps( $sub_entity, $sub_entity_tag );
      }
    }
  }
}

################################################################################
###
### entity:
###    Determines the entity based on an id, (entity) kind, and path.
###
################################################################################

sub _entity {
  my perl::Struct $this = shift;
  my ( $entity, $entity_kind, $id, $kind, $path ) = @_;
  ###
  ### Is the entity_kind a search entity?
  ###
  my $search_entities = $this->_searchEntities($entity_kind);
  return undef if ( !defined($search_entities) );
  ###
  ### Search the entity is a search_entity and
  ### it is the kind (i.e., equals entity_kind),
  ### then check it
  ###
  if ( $entity_kind eq $kind ) {
    my $entity_id = $this->getCValue( $entity, $path );
    return $entity if ( $id eq $entity_id );
    return undef;
  }
  ###
  ### Since the entity is not the kind,
  ### process its search entities
  ###
  my $result = undef;
OUTER_LOOP:
  foreach my $search_kind ( @{$search_entities} ) {
    my $search_entity     = $this->getCValue( $entity, $search_kind );
    my $search_entity_ref = $this->tagRef($search_kind);
    if ( $search_entity_ref eq util::PerlObject::HASH_TYPE
      && $search_kind eq $kind )
    {
      my $entity_id = $this->getCValue( $search_entity, $path );
      next if ( $id ne $entity_id );
      $result = $entity;
      last;
    }
    elsif ( $search_entity_ref eq util::PerlObject::ARRAY_TYPE ) {
      foreach my $comp ( @{$search_entity} ) {
        $result = $this->_entity( $comp, $this->getComponentTag($search_kind),
          $id, $kind, $path );
        last OUTER_LOOP if ( defined($result) );
      }
    }
  }
  return $result;
}

################################################################################
###
### _locator:
###    Determines the entity based on an id, type, and path via reference
###
################################################################################

sub _locator {
  my perl::Struct $this = shift;
  my ( $id, $kind, $path ) = @_;
  my $locator = $this->{locators}->{$path};
  return undef if ( !defined($locator) );
  my $locator_struct = $locator->{$id};
  return undef
    if ( !defined($locator_struct)
    || $locator_struct->{kind} ne $kind );
  return $locator_struct->{entity};
}

################################################################################
###
### _generateLocators:
###    Determines the locators for an entity structure of entity_kind.
###
################################################################################

sub _generateLocators {
  my perl::Struct $this = shift;
  my ( $entity, $entity_kind ) = @_;
  ###
  ### Is the entity_kind a search entity?
  ###
  my $search_entities = $this->_searchEntities($entity_kind);
  return if ( !defined($search_entities) );
  ###
  ### Set the locators for the entity.
  ###
  foreach my $path ( $this->locatorsForSearchPath($entity_kind) ) {
    my $entity_id = $this->getCValue( $entity, $path );
    next
      if ( !defined($entity_id)
      || $entity_id eq util::Constants::EMPTY_STR );
    $this->{locators}->{$path}->{$entity_id} = {
      kind   => $entity_kind,
      entity => $entity,
    };
  }
  ###
  ### Now setup locators for sub_entities
  ###
  foreach my $search_kind ( @{$search_entities} ) {
    my $search_entity = $this->getCValue( $entity, $search_kind );
    my $search_entity_ref = $this->tagRef($search_kind);
    if ( $search_entity_ref eq util::PerlObject::HASH_TYPE ) {
      $this->_generateLocators( $search_entity, $search_kind );
    }
    elsif ( $search_entity_ref eq util::PerlObject::ARRAY_TYPE ) {
      my $search_tag = $this->getComponentTag($search_kind);
      foreach my $comp ( @{$search_entity} ) {
        $this->_generateLocators( $comp, $search_tag );
      }
    }
  }
}

################################################################################
###
### _findComps:
### This method returns the (unreferenced) list of component names that form the
### key for the given path.  If none is found, then an empty list is returned.
###
### _generateKey:
### This method generates the key for the given entity
###
### _generateKeys:
### This recursive method generates the keys for the array components in the
### entity.
###
################################################################################

sub _findComps {
  my perl::Struct $this = shift;
  my ($path) = @_;
  return () if ( !defined( $this->{path_to_key}->{$path} ) );
  return @{ $this->{path_to_key}->{$path}->{cmps} };
}

sub _generateKey {
  my perl::Struct $this = shift;
  my ( $entity, $path ) = @_;
  my $keyname = $this->findKey($path);
  my @comps   = $this->_findComps($path);
  return if ( !defined($keyname) || @comps == 0 );
  $entity->{$keyname} = util::Constants::EMPTY_STR;
  foreach my $comp (@comps) {
    my $value = $this->getCValue( $entity, $comp );
    $value = ( !defined($value) ) ? util::Constants::EMPTY_STR: $value;
    $entity->{$keyname} .= $value . &KEY_SEPARATOR;
  }
}

sub _generateKeys {
  my perl::Struct $this = shift;
  my ($entity) = @_;
  ###
  ### Generate Keys and Order
  ###
  my @paths = keys %{ $this->{path_to_key} };
  foreach my $path (@paths) {
    my $sub_entities = $entity->{$path};
    next if ( !defined($sub_entities) );
    foreach my $sub_entity ( @{$sub_entities} ) {
      $this->_generateKey( $sub_entity, $path );
      ###
      ### Descend into the sub_entity
      ###
      $this->_generateKeys($sub_entity);
    }
    next if ( @{$sub_entities} <= 1 );
    my $order = $this->{path_to_key}->{$path}->{ord};
    @{$sub_entities} = sort $order @{$sub_entities};
  }
  ###
  ### Descend into the Entity
  ###
  my @comps = keys %{$entity};
  foreach my $comp (@comps) {
    my $comp_tag_ref = $this->tagRef($comp);
    next if ( $comp_tag_ref ne util::PerlObject::HASH_TYPE );
    $this->_generateKeys( $entity->{$comp} );
  }
}

################################################################################
###
### _setupPathToKeys:  This method creates path to key generation information in
###                    in the path_to_key attribute
###
################################################################################

sub _setupPathToKeys {
  my perl::Struct $this = shift;
  my ($path_to_keys) = @_;
  return
    if ( !defined($path_to_keys)
    || ref($path_to_keys) ne util::PerlObject::HASH_TYPE );
  while ( my ( $path, $struct ) = each %{$path_to_keys} ) {
    my $key     = $struct->{key};
    my $comps   = $struct->{cmps};
    my $tag     = $this->getComponentTag($path);
    my $tag_ref = $this->tagRef($tag);
    $this->{error_mgr}->exitProgram( ERR_CAT, 7, [ $path, $key, $comps, $tag ],
           !defined($key)
        || $key eq util::Constants::EMPTY_STR
        || !defined($comps)
        || ref($comps) ne util::PerlObject::ARRAY_TYPE
        || !defined($tag)
        || !defined($tag_ref)
        || $tag_ref ne util::PerlObject::HASH_TYPE );
    my $found_key = util::Constants::FALSE;
    foreach my $scalar_key ( $this->scalarKeys($tag) ) {
      if ( $key eq $scalar_key ) {
        $found_key = util::Constants::TRUE;
        last;
      }
    }
    $this->{error_mgr}
      ->exitProgram( ERR_CAT, 8, [ $path, $key, join( ', ', @{$comps} ), $tag ],
      !$found_key );
    $this->{path_to_key}->{$path} = {
      key  => $key,
      cmps => [ @{$comps} ],
      ord  => eval 'sub {return ($a->{' . $key . '} cmp $b->{' . $key . '});}',
    };
  }
}

################################################################################
###
### _setupMapParams:  This method creates map parameters for generating mappings
###
################################################################################

sub _setupMapParams {
  my perl::Struct $this = shift;
  my ($map_paths)       = @_;
  my @mapping_scalars   = $this->scalarKeys(MAPPING_REC_PATH);
  while ( my ( $map, $struct ) = each %{$map_paths} ) {
    my $id = $struct->{id};
    $this->{error_mgr}->exitProgram( ERR_CAT, 10, [$map],
      !defined($id) || $id eq util::Constants::EMPTY_STR );
    my $param_struct = {
      id       => $id,
      comp_map => {},
    };
    my $found_mapping = util::Constants::FALSE;
    foreach my $mapping_scalar (@mapping_scalars) {
      my $path = $struct->{$mapping_scalar};
      next if ( !defined($path) );
      $found_mapping = util::Constants::TRUE;
      $param_struct->{comp_map}->{$mapping_scalar} = $path;
    }
    $this->{error_mgr}->exitProgram( ERR_CAT, 11,
      [ $map, join( ', ', %{$struct} ), join( ', ', @mapping_scalars ) ],
      !$found_mapping );
    $this->{map_params}->{$map} = $param_struct;
  }
}

################################################################################
#
#			       Constructor Method
#
################################################################################

sub new {
  my perl::Struct $this = shift;
  my ( $tag, $structs, $search_paths, $map_paths, $path_to_keys, $error_mgr ) =
    @_;
  $this = fields::new($this) unless ref($this);

  $this->{entities}           = [];
  $this->{entity}             = undef;
  $this->{error_mgr}          = $error_mgr;
  $this->{locators}           = {};
  $this->{map_params}         = {};
  $this->{maps}               = {};
  $this->{path_to_key}        = {};
  $this->{search_entities}    = {};
  $this->{search_to_locators} = {};
  $this->{tag}                = $tag;
  ###
  ### Initialize structs and scalar keys
  ###
  $this->_initializeStructs($structs);
  $this->_generateScalarKeys;
  ###
  ### Setup searching
  ###
  $this->_setupSearching($search_paths);
  ###
  ### Setup Locators
  ###
  $this->_setupLocators($search_paths);
  ###
  ### Setup Maps
  ###
  my @mapping_scalars = $this->scalarKeys(MAPPING_REC_PATH);
  my $maps            = [];
  if ( defined($map_paths)
    && ref($map_paths) eq util::PerlObject::HASH_TYPE )
  {
    push( @{$maps}, keys %{$map_paths} );
  }
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 9,
    [ join( ', ', @{$maps} ) ],
    @{$maps} > 0 && @mapping_scalars == 0
  );
  if ( @{$maps} > 0 ) {
    $this->_setupPathStruct( 'maps', $maps, util::Constants::TRUE );
    $this->_setupMapParams($map_paths);
  }
  ### Setup Path to Keys Map
  ###
  $this->_setupPathToKeys($path_to_keys);
  ###
  ### Return the object
  ###
  return $this;
}

################################################################################
#
#				 Setter Methods
#
################################################################################

sub initializeObject {
  my perl::Struct $this = shift;
  ###
  ### Initialize the entities, entity, and locators
  ###
  $this->unsetEntities;
  $this->unsetEntity;
  ###
  ### Initialize maps
  ###
  $this->_setupPathStruct( 'maps', undef, util::Constants::TRUE );
}

sub setEntity {
  my perl::Struct $this = shift;
  $this->{entity} = $this->initializeSubstruct( $this->tag );
}

sub addEntity {
  my perl::Struct $this = shift;
  my $entity = $this->initializeSubstruct( $this->tag );
  push( @{ $this->{entities} }, $entity );
  return $entity;
}

sub unsetEntity {
  my perl::Struct $this = shift;
  $this->{entity} = undef;
}

sub computeEntity {
  my perl::Struct $this = shift;
  my ($entity) = @_;
  return if ( !defined($entity) );
  ###############################
  ### Re-Implementable Method ###
  ###############################
  ###
  ### NO-OP
  ###
}

sub moveEntity {
  my perl::Struct $this = shift;
  my $entity = $this->entity;
  return if ( !defined($entity) );
  ###
  ### Create locators only if not defined
  ###
  my $locators = $this->{locators};
  foreach my $locator ( $this->locatorPaths ) {
    next if ( defined( $locators->{$locator} ) );
    $locators->{$locator} = {};
  }
  $this->_generateMaps( $entity, $this->tag );
  $this->_generateKeys($entity);
  $this->computeEntity($entity);
  $this->_generateLocators( $this->entity, $this->tag );
  push( @{ $this->{entities} }, $entity );
  $this->{entity} = undef;
}

sub addEntities {
  my perl::Struct $this = shift;
  my ( $source, $remove_from_source ) = @_;
  $this->{error_mgr}->exitProgram(
    ERR_CAT, 6,
    [ $source->tag, $this->tag ],
    !ref($source) || $source->tag ne $this->tag
  );
  foreach my $entity ( $source->entities ) {
    push( @{ $this->{entities} }, $entity );
  }
  if ( defined($remove_from_source) && $remove_from_source ) {
    $source->unsetEntities;
  }
}

sub unsetEntities {
  my perl::Struct $this = shift;
  $this->{entities} = [];
  $this->_setupPathStruct('locators');
}

sub generateLocators {
  my perl::Struct $this = shift;
  ###
  ### Create locators
  ###
  my $locators = $this->{locators};
  foreach my $locator ( $this->locatorPaths ) {
    $locators->{$locator} = {};
  }
  ###
  ### Walk through the search_entities
  ### from the top and generate locators
  ###
  foreach my $entity ( $this->entities ) {
    $this->_generateLocators( $entity, $this->tag );
  }
}

sub addComp {
  my perl::Struct $this = shift;
  my ($entity, $comp, $value, $path) = @_;
  my $comp_entity = undef;
  if (defined($path)) {
    $comp_entity = $this->getCValue($entity, $path);
  } else {
    $comp_entity = $entity;
  }
  return if (ref($comp_entity) ne util::PerlObject::HASH_TYPE);
  $comp_entity->{$comp} = $value;
}

################################################################################
#
#				 Getter Methods
#
################################################################################

sub tag {
  my perl::Struct $this = shift;
  return $this->{tag};
}

sub entity {
  my perl::Struct $this = shift;
  return $this->{entity};
}

sub entities {
  my perl::Struct $this = shift;
  return @{ $this->{entities} };
}

sub locatorPaths {
  my perl::Struct $this = shift;
  return keys %{ $this->{locators} };
}

sub locatorPathDefined {
  my perl::Struct $this = shift;
  my ($locator_path)    = @_;
  my $locators          = $this->{locators};
  return (
    defined( $locators->{$locator_path} )
    ? util::Constants::TRUE
    : util::Constants::FALSE );
}

sub mapPaths {
  my perl::Struct $this = shift;
  return keys %{ $this->{maps} };
}

sub searchPaths {
  my perl::Struct $this = shift;
  return keys %{ $this->{search_entities} };
}

sub locatorsForSearchPath {
  my perl::Struct $this  = shift;
  my ($search_path)      = @_;
  my $search_to_locators = $this->{search_to_locators};
  return () if ( !defined( $search_to_locators->{$search_path} ) );
  return keys %{ $search_to_locators->{$search_path} };
}

sub locatorForSearchPath {
  my perl::Struct $this = shift;
  my ( $search_path, $locator_path ) = @_;
  my $search_to_locators = $this->{search_to_locators};
  return util::Constants::FALSE
    if ( !defined( $search_to_locators->{$search_path} ) );
  my $search_to_locator = $search_to_locators->{$search_path};
  return (
    defined( $search_to_locator->{$locator_path} )
    ? util::Constants::TRUE
    : util::Constants::FALSE );
}

sub scalarKeys {
  my perl::Struct $this = shift;
  my ($tag) = @_;
  return () if ( !defined( $this->{scalar_keys}->{$tag} ) );
  return @{ $this->{scalar_keys}->{$tag} };
}

sub tagRef {
  my perl::Struct $this = shift;
  my ($tag) = @_;
  return undef if ( !defined($tag) );
  my $arrays = $this->{arrays};
  my $hashes = $this->{hashes};
  return util::PerlObject::ARRAY_TYPE if ( defined( $arrays->{$tag} ) );
  return util::PerlObject::HASH_TYPE  if ( defined( $hashes->{$tag} ) );
  return undef;
}

sub findKey {
  my perl::Struct $this = shift;
  my ($path) = @_;
  return undef if ( !defined( $this->{path_to_key}->{$path} ) );
  return $this->{path_to_key}->{$path}->{key};
}

sub findEntity {
  my perl::Struct $this = shift;
  my ( $root, $path, $entity ) = @_;
  my $keyname = $this->findKey($path);
  return undef if ( !defined($keyname) );
  my $key = $entity->{$keyname};
  my $subentities = $this->getCValue( $root, $path );
  return undef
    if ( !defined($subentities)
    || ref($subentities) ne util::PerlObject::ARRAY_TYPE
    || !defined($key)
    || $key eq util::Constants::EMPTY_STR );
  foreach my $subentity ( @{$subentities} ) {
    return $subentity if ( $subentity->{$keyname} eq $key );
  }
  return undef;
}

sub entityByKind {
  my perl::Struct $this = shift;
  my ( $id, $kind, $path ) = @_;
  return undef if ( !$this->locatorForSearchPath( $kind, $path ) );
  return $this->_locator( $id, $kind, $path )
    if ( $this->locatorPathDefined($path) );
  foreach my $entity ( $this->entities ) {
    my $result = $this->_entity( $entity, $this->tag, $id, $kind, $path );
    return $result if ( defined($result) );
  }
  return undef;
}

sub getCValue {
  my perl::Struct $this = shift;
  my ( $entity, $path, $index ) = @_;
  my @comps = split( /\./, $path );
  my $value = undef;
  if ( @comps == 1 && defined( $entity->{$path} ) ) {
    $value = $entity->{$path};
    my $comp = $comps[0];
    if ( defined( $this->{structs}->{$comp} )
      && $this->{structs}->{$comp}->{kind} eq util::PerlObject::ARRAY_TYPE
      && defined($index) )
    {
      if ( defined( $value->[$index] ) ) {
        $value = $value->[$index];
      }
      else {
        $value = undef;
      }
    }
  }
  elsif ( @comps > 1 ) {
    $value = $entity;
    my $last_index = $#comps;
    foreach my $I ( 0 .. $last_index ) {
      my $comp = $comps[$I];
      if ( defined( $this->{structs}->{$comp} )
        && $this->{structs}->{$comp}->{kind} eq util::PerlObject::ARRAY_TYPE )
      {
        if ( defined($index) ) {
          if ( defined( $value->{$comp} )
            && defined( $value->{$comp}->[$index] ) )
          {
            $value = $value->{$comp}->[$index];
          }
          else {
            $value = undef;
            last;
          }
        }
        elsif ( $I == $last_index && defined( $value->{$comp} ) ) {
          $value = $value->{$comp};
        }
        else {
          $value = undef;
          last;
        }
      }
      elsif ( defined( $this->{structs}->{$comp} )
        && $this->{structs}->{$comp}->{kind} eq util::PerlObject::HASH_TYPE
        && $I == $last_index
        && defined( $value->{$comp} ) )
      {
        $value = $value->{$comp};
      }
      else {
        if ( defined( $value->{$comp} ) ) {
          $value = $value->{$comp};
        }
        else {
          $value = undef;
          last;
        }
      }
    }
  }
  return $value;
}

sub getCValueTrimmed {
  my perl::Struct $this = shift;
  my ( $entity, $path, $trim_prefix, $index ) = @_;
  my $value = $this->getCValue( $entity, $path, $index );
  if ( defined($value) ) {
    my $ref = ref($value);
    return $value
      if ( $ref eq util::PerlObject::ARRAY_TYPE
      || $ref eq util::PerlObject::HASH_TYPE );
  }
  if ( defined($trim_prefix) && defined($value) ) {
    $value =~ s/^$trim_prefix//;
  }
  return $value;
}

sub getLValues {
  my perl::Struct $this = shift;
  my ( $entity, $path_list, $trim_prefix, $index ) = @_;
  my @list = ();
  foreach my $path ( @{$path_list} ) {
    push( @list,
      $this->getCValueTrimmed( $entity, $path, $trim_prefix, $index ) );
  }
  return @list;
}

sub getSubstruct {
  my perl::Struct $this = shift;
  my ( $tag, $entity ) = @_;
  return undef
    if ( !defined( $entity->{$tag} )
    || !defined( $this->{structs}->{$tag} ) );
  my $ref = ref( $entity->{$tag} );
  return undef if ( $ref ne $this->{structs}->{$tag}->{kind} );
  return $entity->{$tag};
}

sub getMap {
  my perl::Struct $this = shift;
  my ($map_path) = @_;
  return undef if ( !$this->_validMap($map_path) );
  my $map = $this->{maps}->{$map_path};
  return $map;
}

sub getMapRec {
  my perl::Struct $this = shift;
  my ( $id, $map_path ) = @_;
  return undef if ( !$this->_validMap($map_path) );
  my $map = $this->{maps}->{$map_path};
  return $map->{$id};
}

sub initializeSubstruct {
  my perl::Struct $this = shift;
  my ($tag) = @_;
  return undef if ( !defined($tag) );
  my $data = $this->{structs}->{$tag};
  return undef
    if ( !defined($data)
    || $data->{kind} ne util::PerlObject::HASH_TYPE );
  my $struct = { %{ $data->{type} } };
  foreach my $tag ( keys %{$struct} ) {
    my $template = $this->{structs}->{$tag};
    next if ( !defined($template) );
    if ( $template->{kind} eq util::PerlObject::ARRAY_TYPE ) {
      $struct->{$tag} = [];
    }
    elsif ( $template->{kind} eq util::PerlObject::HASH_TYPE ) {
      $struct->{$tag} = $this->initializeSubstruct($tag);
    }
  }
  return $struct;
}

sub getComponentTag {
  my perl::Struct $this = shift;
  my ($tag) = @_;
  return undef if ( !defined($tag) );
  my $data = $this->{structs}->{$tag};
  return undef
    if ( !defined($data)
    || $data->{kind} ne util::PerlObject::ARRAY_TYPE );
  return $data->{type};
}

sub initializeSubstructByComponent {
  my perl::Struct $this = shift;
  my ($tag) = @_;
  return $this->initializeSubstruct( $this->getComponentTag($tag) );
}

sub printData {
  my perl::Struct $this = shift;
  my ( $log_prefix, $log_suffix ) = @_;
  $log_suffix =
    ( defined($log_suffix) && $log_suffix ne util::Constants::EMPTY_STR )
    ? $log_suffix
    : 'profile';
  my $filename = join( util::Constants::DOT, $log_prefix, $log_suffix, 'pl' );
  unlink($filename);
  my $objfile = new util::PerlObject( $filename, undef, $this->{error_mgr} );
  foreach my $map_path ( $this->mapPaths ) {
    $objfile->writeStream( $this->getMap($map_path),
      util::PerlObject::PERL_OBJECT_WRITE_OPTIONS );
  }
  foreach my $entity ( $this->entities ) {
    $objfile->writeStream( $entity,
      util::PerlObject::PERL_OBJECT_WRITE_OPTIONS );
  }
  $objfile->closeIo;
  if ( $this->{error_mgr}->isDebugging ) {
    my $attr_filename =
      join( util::Constants::DOT, $log_prefix, $log_suffix, 'attributes',
      'pl' );
    unlink($attr_filename);
    my $attr_objfile =
      new util::PerlObject( $attr_filename, undef, $this->{error_mgr} );
    foreach my $attr (
      'array_of',        'arrays',
      'entities',        'entity',
      'hashes',          'locators',
      'map_params',      'maps',
      'path_to_key',     'scalar_keys',
      'search_entities', 'search_to_locators',
      'structs',         'tag'
      )
    {
      $attr_objfile->writeStream( $this->{$attr},
        util::PerlObject::PERL_OBJECT_WRITE_OPTIONS );
    }
    $attr_objfile->closeIo;
  }
}

################################################################################

1;

__END__

=head1 NAME

PerlStruct.pm

=head1 DESCRIPTION

This class defines the mechanism for generating and supporting a
generalized Perl data-structure.  The class defines a single entity
and a list of entities of this data-structure.  The requirements for
defining the data-structure include:

=over 4

=item B<top-level tag>

A required tag name representing a hash structure in the structs below
defining the top-level entity data-structure.  This tag name must be a
a key to a hash structure in B<structs> below.

=item B<structs>

A required referenced hash defining the data-structures (hashes and
arrays) further define the entity data-structure.

=item B<search_paths>

The searching paths is a required referenced hash data-structure
defining the tags (hash structures in B<structs> that can be searched.
At a minimum, the the top-level tag must be defined in the
data-structure.  The values are an array of search paths that they can
be used to search each tag.  Also, this allows fast locators
(associative lookup) to be generated.

=item B<map_paths>

The mapping paths is an optional referenced hash data-structure that
defines the mapping for the class.  If this parameter is defined, then
the mapping is generated for each search tag defined in
B<search_paths>.  The map defines the B<id> path for generating the
domain of the map.  If B<map_paths> is defined, then one of the hash
tags defined in B<structs> must be B<mapping_rec>.  This hash defines
the value of the mappings.  The value of a mapping in B<map_paths>
defines how the B<mapping_rec> is evaluated for a given mapping.

=item B<path_to_keys>

The path to keys is an optional reference hash data-structure how to
generate keys in the data-structure.  The keys of the data-structure
must be array tags in B<structs> and the value specifies the component
key name tag and how the key is composed.  The key can single field
evaluated by loading the data-structure in which case the key is need
not be explicitly generated.  Keys allow an array tag to be searched
for a particular value of the key.

=item B<error_mgr>

The error messaging object is an instance of L<util::ErrMgr> and is
required.

=back


The B<structs> data-structure is a (referenced) hash data-structure
with following foramt.  Each entry is either a hash or an array
defined by the B<kind> component and the type defines it hash
component type name (ARRAY) or its record structure (HASH).  An array
can be a list of scalars when the type component is B<undef>.  Any
other usage is an error.  The interconnection of the data structure is
defined by structure names appearing as components in hashes and the
B<type> component for ARRAY.  The B<mapping_rec> HASH structure is
special in that it is required for mapping specifications as described
above.  This record defines the range values for mappings that are
defined by B<map_paths>.

The following is a synthetic sample B<structs>:

    {
     ###
     ### Schema related lists
     ###
     array_spec1 =>
     {
      ###
      ### A list of hash_rec1
      ###
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'hash_rec1',
     },

     array_spec2 =>
     {
      ###
      ### A list of scalars
      ###
      kind => util::PerlObject::ARRAY_TYPE,
      type => undef,
     },

     hash_rec1 =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### attributes (scalars)
	       ###
               attrib_1    => undef,
	       attrib_2    => undef,
	       ###
	       ### Substructures (Hashes)
	       ###
	       hash_rec2   => undef,
	       ###
	       ### Substructures (Arrays)
	       ###
	       array_spec2 => undef,
	      }
     },

     .
     .
     .

     mapping_rec =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### mapping attributes
	       ###
	       map_attr1 => undef,
	       map_attr2 => undef,
	       map_attr3 => undef,
	      }
     },

    };

The following example fully describes the specification of the eSNP
data-structure.

=over 4

=item B<top-level tag>

B<rs>

=item B<structs>

    {
     ###
     ### Schema related lists
     ###
     cluster_mappings =>
     {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'cluster_mapping',
     },

     mrna_dtas =>
     {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'mrna_dta',
     },

     protein_dtas =>
     {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'protein_dta',
     },

     sss =>
     {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'ss',
     },

     submission_alleles =>
     {
      kind => util::PerlObject::ARRAY_TYPE,
      type => 'submission_allele',
     },

     rs =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### RS specific attributes
	       ###
               subm_acc         => undef,
               rs_acc           => undef,
	       ###
	       ### Substructures (Hashes)
	       ###
	       dbsnp_rs_cluster => undef,
	       submission       => undef,
	       submission_seq   => undef,
	       ###
	       ### Substructures (Arrays)
	       ###
	       cluster_mappings => undef,
	       sss              => undef,
	      }
     },

     submission =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
               assay3_len         => undef,
               assay5_len         => undef,
               flank_3            => undef,
               flank_5            => undef,
	       is_cluster         => undef,
	       is_seq_truncated   => undef,
               is_validated       => undef,
               issue_id           => undef,
               observed_alleleset => undef,

               cre_ts             => undef,
               obs_ts             => undef,
               last_trans_id      => undef,
	      }
     },

     submission_seq =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
               assay3_len    => undef,
               assay5_len    => undef,
               flank_3       => undef,
               flank_5       => undef,
               issue_id      => undef,

               cre_ts        => undef,
               obs_ts        => undef,
               last_trans_id => undef,
	      }
     },

     dbsnp_rs_cluster =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       build_created      => undef,
	       build_last_updated => undef,
	       date_created       => undef,
	       date_last_updated  => undef,
               exemplar_acc       => undef,
               issue_id           => undef,
               map_weight         => undef,
               mol_type_name      => undef,
               num_chr_hits       => undef,
               num_ctg_hits       => undef,
               num_seq_loc        => undef,
               rs_het             => undef,
               snp_class_name     => undef,
               snp_type_name      => undef,
               sts_id             => undef,
               valid_prob_max     => undef,
               valid_prob_min     => undef,

               cre_ts             => undef,
               obs_ts             => undef,
               last_trans_id      => undef,
	      }
     },

     cluster_mapping =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### Defined by Loader
	       ###
	       cluster_mapping_key => undef,

               hit_quality         => undef,
               issue_id            => undef,
	       location_id         => undef,
               location_type       => undef,

               cre_ts              => undef,
               obs_ts              => undef,
               last_trans_id       => undef,
	       ###
	       ### Substructures (Hashes)
	       ###
	       location            => undef,
	      }
     },

     location =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       location_id     => undef,

               ga_acc          => undef,
               ga_accver       => undef,
               ga_left         => undef,
               ga_right        => undef,
               ga_orientation  => undef,

               chr_left        => undef,
               chr_name        => undef,
               chr_orientation => undef,
               chr_right       => undef,

               issue_id        => undef,

               cre_ts          => undef,
               last_trans_id   => undef,
	       ###
	       ### Substructures (Arrays)
	       ###
	       mrna_dtas       => undef,
	      }
     },

     mrna_dta =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### Defined by Loader
	       ###
	       mrna_dta_key     => undef,

               allele_set       => undef,
               dta_run_name     => undef,
               gene_acc         => undef,
               gene_symbol      => undef,
               issue_id         => undef,
               mrna_domain_name => undef,
               mrna_acc         => undef,
               mrna_domain_id   => undef,

               cre_ts           => undef,
               obs_ts           => undef,
               last_trans_id    => undef,
	       ###
	       ### Substructures (Arrays)
	       ###
	       protein_dtas     => undef,
	      }
     },

     protein_dta =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       allele_value  => undef,
               frame         => undef,
	       is_reference  => undef,
               issue_id      => undef,
               protein_acc   => undef,
               protein_begin => undef,
               protein_end   => undef,
	       residue       => undef,

               cre_ts        => undef,
               obs_ts        => undef,
               last_trans_id => undef,
	      }
     },

     ss =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       ###
	       ### SS specific attributes
	       ###
	       subm_acc          => undef,
	       rs_acc            => undef,
	       ###
	       ### Substructures (Hashes)
	       ###
	       dbsnp_submission  => undef,
	       submission        => undef,
	       submission_seq    => undef,
	       ###
	       ### Substructures (Arrays)
	       ###
	       submission_alleles => undef,
	      }
     },

     dbsnp_submission =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
               comment1          => undef,
               issue_id          => undef,
               lab_name          => undef,
               meth_class_name   => undef,
               mol_type_name     => undef,
	       rs_cluster_acc    => undef,
               snp_class_name    => undef,
               ss_linkout_url    => undef,
               ss_rs_orientation => undef,
               ss_validated      => undef,
               submitter_snp_id  => undef,

               cre_ts            => undef,
               obs_ts            => undef,
               last_trans_id     => undef,
	      }
     },

     submission_allele =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
               subm_allele_key => undef,

               allele_count   => undef,
               allele_freq    => undef,
               allele_value   => undef,
	       esnp_pop_id    => undef,
               issue_id       => undef,
               sample_size    => undef,
               study          => undef,
               subm_allele_id => undef,

               cre_ts         => undef,
               obs_ts         => undef,
               last_trans_id  => undef,
	       ###
	       ### Substructures (Hashes)
	       ###
	       population     => undef,
	      }
     },

     population =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
               issue_id                 => undef,
               submsrc_pop_class        => undef,
               submsrc_pop_id           => undef,
               submsrc_pop_type         => undef,
               submsrc_submitter_pop_id => undef,

               cre_ts                   => undef,
               obs_ts                   => undef,
               last_trans_id            => undef,
	      }
     },

     mapping_rec =>
     {
      kind => util::PerlObject::HASH_TYPE,
      type => {
	       rs_acc => undef,
	      }
     },

    };

=item B<search_paths>

    {
     rs => ['subm_acc',],

     ss => ['subm_acc',],

    };

=item B<map_paths>

    {
     accession_map => {
                       id     => 'subm_acc',
                       rs_acc => 'rs_acc',
                      },

    };

=item B<path_to_keys>

    {
     sss =>
     {
      key  => 'subm_acc',
      cmps => [],
     },

     cluster_mappings =>
     {
      key  => 'cluster_mapping_key',
      cmps => [
	       'location.ga_acc',
	       'location.ga_accver',
	       'location.ga_left',
	       'location.ga_right',
	       'location.ga_orientation',
	       'location.chr_left',
	       'location.chr_name',
	       'location.chr_orientation',
	       'location.chr_right',
	      ],
     },

     mrna_dtas =>
     {
      key  => 'mrna_dta_key',
      cmps => [
	       'mrna_acc',
	       'gene_acc',
	       'allele_set',
	      ],
     },

     protein_dtas =>
     {
      key  => 'allele_value',
      cmps => [],
     },

     submission_alleles =>
     {
      key  => 'subm_allele_key',
      cmps => [
	       'allele_value',
	       'population.submsrc_submitter_pop_id',
	       'population.submsrc_pop_type',
	       'population.submsrc_pop_id',
	       'population.submsrc_pop_class',
	      ],
     },

    };

=back


=head1 METHODS

These methods are used for creating and populating a Perl
data-structure.

=head2 B<new perl::Struct(tag, structs, search_paths, map_paths, path_to_keys, error_mgr)>

This method is the constructor for this class. and creates a
data-structure the class as described using the parameters in the
L<"DESCRIPTION">.  For the top-level tag it creates an entity
(L<"entity"> and list of entities (L<"entities">) attributes which are
undef and empty list respectively.  The B<error_mgr> is the the error
messaging object of L<util::ErrMgr>.  A subclass is assumed to have
implemented the re-implementable method L<"computeEntity(entity)"> as
necessary.  This method is used in L<"moveEntity">.

=head1 SETTER METHODS

The following setter methods which allow manipulation of the B<entity>
and B<entities> attributes are exported by this class.

=head2 B<initializeObject>

This method re-initializes the object to empty.  This means that the
entity and entities attributes are re-initialized to undef and empty.
Also, all mappings evaluated and locators calculated are deleted.

=head2 B<setEntity>

This method initializes the B<entity> attribute with the
data-structure associated with the top-level B<tag>. This entity can
be accessed via L<"entity">.

=head2 B<$top_level_entity = addEntity>

This method creates an entity data-structure associated with the
top-level B<tag>, adds this entity to the the B<entities> list, and
returns its.  This method does not effect the entity attribute.

=head2 B<unsetEntity>

This method resets the B<entity> attribute.  That is, the entity is
set to the undef.

=head2 B<computeEntity(entity)>

This re-implementable method computes specific information for the
B<entity> attribute.  This method is executed just prior to locators
being generated and being added to the B<entities> attribute list.
This method can assume that the keys and maps for the entity have been
generated.  This method is executed by L<"moveEntity">.  The default
implementation of the method is a NO-OP.

=head2 B<moveEntity>

If the B<entity> attribute is defined, then this method generates the
keys and maps for the entity, then it executes the method
L<"computeEntity(entity)"> on the entity, next it computes locators
for the entity, moves the entity into the B<entities> attribute list,
and finally resets the B<entity> attribute to undef.

=head2 B<addEntities(source[, remove_from_source])>

This method adds the entities in the B<entities> attribute for the
B<source> object to the B<entities> attribute list of the target
object--this object.  This method allows transfer of entities among
objects.  The only restriction is that the source must have the same
top-level B<tag> as the target and the structs definitions must be
identical.  If B<remove_from_source> is defined and TRUE (1), then
B<entities> attribute in the the B<source> is reset to empty.

=head2 B<unsetEntities>

This method resets the B<entities> attribute list to empty.  Also, the
currently calcuated locators are deleted.  Maps aren not affected by
this method.

=head2 B<generateLocators>

This method creates the fast locators for entities in the B<entities>
attribute list.  This method initializes the locators before
calculating them.

=head1 GETTER METHODS

The following getter methods are exported by this class.

=head2 B<$tag = tag>

This method returns the top-level tag for the object.

=head2 B<$entity = entity>

This method returns the B<entity> attribute.  This is a reference to
the entity data-structure.

=head2 B<@entities = entities>

This method returns the (unreferenced) list of entities currently in
the B<entities> attribute list.

=head2 B<@locator_paths = locatorPaths>

This method returns the list of locator paths.  Each locator path
defines a path in an entity or sub-entity that defines the identifier
for mapping the identifier to the entity or sub-entity.  This is
unique the list all of path values in B<map_paths>.

=head2 B<@map_paths = mapPaths>

This method returns the list of mappings defined by the object (i.e.,
the keys of B<map_paths>).

=head2 B<@search_paths = searchPaths>

This method returns the list of search tags as defined by the keys of
B<search_paths> one of which must be the top-level B<tag>.

=head2 B<@scalar_keys = scalarKeys(tag)>

This method returns the list of scalar component names for the tag
that represents a HASH data-structure.

=head2 B<$tag_ref = tagRef(tag)>

This method returns the value B<'HASH'> if the tag B<kind> is a hash,
or B<'ARRAY'> if tag B<kind> is an array, or undef otherwise.

=head2 B<$key_name = findKey(path)>

This method returns component name for the key to given path.  If none
is found, undef is returned.  The path must be array tag in the
data-structure and one of the keys in B<path_to_keys>.

=head2 B<$entity = findEntity(root, path, entity)>

This method uses the generated keys to return the the sub-entity
located in the list defined by the path from the root having the key
value as defined in the entity for the key_name defined by
L<"$key_name = findKey(path)">.  If key_name is not defined or no
sub-entity can be found, then undef is returned.

=head2 B<$entity = entityByKind(id, kind, path)>

This method returns the reference to the entity of the B<kind> tag
defined by the id for the given path.  This method uses fast locators
if they have been generated, otherwise it does a complete search.  The
B<kind> tag must be a search path as defined by L<"@search_paths =
searchPaths">, B<path> must be a locator path for the search path (see
B<search_paths>) otherwise undef is returned.  The B<id> must be value
of the locator path for the sub-entity defined by the B<kind> tag.

=head2 B<$value = getCValue(entity, path[, index])>

This method computes the component value for the path expression in
the structure referenced by entity.  Optionally, the path can contain
an array, in which case it uses the index value.  If a value cannot be
found, then it returns an undef value.  If the last component in the
path is a hash or array, then a reference to this entity is returned.
The B<path> has the following format B<comp1.comp2.comp3. ...>.

=head2 B<$value = getCValueTrimmed(entity, path, trim_prefix[, index])>

This method computes the component value for the path expression in
the structure referenced by entity.  Optionally, the path can contain
an array, in which case it uses the index value.  If a value cannot be
found, then it returns an undef value.  If trim_prefix is defined,
then this prefix will be trimmed from be beginning of the value before
it is returned.  If the last component in the path is a hash or array,
then this entity is returned.  In this case, trim_prefix is ignored.
The B<path> has the following format B<comp1.comp2.comp3. ...>.

=head2 B<@values = getLValues(enyity, path_list, trim_prefix[, index])>

This method evalutes a list of path expressions in the path_list array
for the structure referenced by entity and returns the values in
path_list order.  An optional index is provided for expressions that
contain arrays.  If the trim_prefix is defined, then it will be
trimmed from each value in the list.

=head2 B<$struct = getSubstruct(tag, entity)>

This method returns the reference to appropriate sub-structure
identified by the B<tag> in the B<entity>.  This B<tag> must be
defined directly in the B<entity>.

=head2 B<$map = getMap(map_path)>

This method returns a reference to the map for the given B<map_path>.
The maps generated are defined by B<map_paths>.  If the B<map_path> is
invalid, undef if returned.

=head2 B<$map_rec = getMapRec(id, map_path)>

This method returns the reference to the map record from the map of
B<map_path> for the B<id>.  unndef is returned if the mapping is not
defined for the B<id> in the B<map_path>.  If the B<map_path> is
invalid, undef is also returned.  The mapped record contains the
components specified in B<mapping_rec> definition in structs.

=head2 B<$struct = initializeSubstruct(tag)>

This method creates and returns the data-structure component defined
by the B<tag>.  This B<tag> must occur as a component in the
B<structs> data-structure specified above and must represent a
B<'HASH'>.

=head2 B<$tag = getComponentTag(tag)>

This method returns the component tag name for the tag if the tag
represents an array, otherwise it returns undef.  This B<tag> must
occur as a B<'ARRAY'> component in the B<structs>.

=head2 B<$struct = initializeSubstructByComponent(tag)>

This method creates and returns the data-structure component for an
array component defined by the B<tag>.  This B<tag> must occur as an
B<'ARRAY'> component in the B<structs>.

=head2 B<printData(log_prefix[, log_suffix])>

This method prints the maps and entities to the file:

   <log_prefix>.<log_suffix>.pl

for object.  If the B<log_suffix> is not defined or empty, then the
log_suffix is set to B<profile>.  In debugging mode is set for the
B<error_mgr>, then this method also writes out the following
attributes of the object to the file:

   <log_prefix>.<log_suffix>.attributes.pl

The list of attributes include the following:

   array_of
   arrays
   entities
   entity
   hashes
   locators
   map_params
   maps
   path_to_key
   scalar_keys
   search_entities
   search_to_locators
   structs
   tag

=cut
