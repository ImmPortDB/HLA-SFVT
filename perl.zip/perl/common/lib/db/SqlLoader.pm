package db::SqlLoader;
################################################################################
###
### Module: SqlLoader.pm
### Description:
###
###   For more information about the use of this script, use 'perldoc' on
###   this module to extract the documentation.
###
################################################################################

use strict;

use Class::Struct;
use Cwd 'chdir', 'cwd';
use File::Basename;
use File::Copy;
use FileHandle;

use util::DbConfig;
use util::Constants;
use util::Msg;

use db::SqlPurger;

################################################################################
###
### BEGIN block is used to set the VERSION symbol
###
################################################################################

BEGIN {
  my $rev = '$Revision: 1.61 $';
  ###
  ### '$'
  ###
  if ( $rev =~ /((\d|\.)+)/ ) {
    $db::SqlLoader::VERSION = $1;
  }
}
###
###
### Another useful structure contains the state information of the load.
### After completion of the load, this structure is populated with the
### state of the load.
###
struct(
  LoadStatus => [
    version        => '$',
    run_date       => '$',
    table_name     => '$',
    elapsed_time   => '$',
    cpu_time       => '$',
    control_file   => '$',
    data_file      => '$',
    bad_file       => '$',
    discard_file   => '$',
    errors_allowed => '$',
    insert_option  => '$',
    recs_loaded    => '$',
    recs_skipped   => '$',
    recs_rejected  => '$',
    recs_discarded => '$',
  ]
);

struct(
  'db::SqlLoader' => {    ###
    ### Setters and accessors
    ###
    dbconfig_file    => '$',
    dbconfig         => '%',
    owner            => '$',
    table            => '$',
    data_file        => '$',
    log_file         => '$',
    purge_log_file   => '$',
    batch_size       => '$',
    control_file     => '$',
    readsize         => '$',
    bindsize         => '$',
    fields           => '@',
    field_separator  => '$',
    record_separator => '$',
    error_limit      => '$',
    rows             => '$',
    field_enclosure  => '$',
    insert_option    => '$',
    trailing_nulls   => '$',
    force_purge      => '$',
    ###
    ### Accessors only:
    ### These will be evaluated by load and purge
    ###
    errors      => '$',
    status_code => '$',
    sqlpurger   => 'db::SqlPurger',
    ###
    ### Private Data Members
    ###
    control_flushed => '$',
    bad_file        => '$',
    discard_file    => '$',
    discard_limit   => '$',
    data_opened     => '$',
    first_row_out   => '$',            ### Flag indicating first row written ###
    df_handle       => 'FileHandle',
    control_opened  => '$',
    cf_handle       => 'FileHandle',
    load_state      => 'LoadStatus',
    msg             => 'util::Msg',
    needs_reloading => '$',
  }
);                                     # bug => '$'
###
### The comment above fixes a syntax highlighting bug in XEmacs.
###
################################################################################
###
### control_file
###
### This overloads the default method to provide additional functionality
### for naming the other files.
###
################################################################################

sub control_file($$) {
  my ( $self, $file_name ) = @_;
  return $self->{'db::SqlLoader::control_file'} if ( !defined($file_name) );

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  my ( $name, $path, $suffix ) =
    fileparse( $file_name, '.ctl', '.dat', '.bcp' );
  $path = util::Constants::EMPTY_STR if ( $path eq './' );
  if ( $suffix ne '.ctl' ) {
    $file_name = "$path$name.ctl";
  }
  $self->{'db::SqlLoader::control_file'} = $file_name;
  ###
  ### Set the log file names
  ###
  $self->log_file("$path$name.log");
  $self->purge_log_file("$path$name.pge");
  ###
  ### If the control file already exists, then initialize this object based
  ### on information contained in the control file.  Also check to see if
  ### there is a log file.  If there is, then further initialize this object
  ### to continue the load operation from wherever the previous one left off.
  ###
  if ( -e $file_name ) {
    ###
    ### Parse the control file
    ###
    $self->_parseControl($file_name);
    ###
    ### If the log file actually exists, then parse it too.
    ###
    my $log_file       = $self->log_file;
    my $purge_log_file = $self->purge_log_file;
    $self->msg->dieOnError(
      'SQLLoader detected both SQL*Loader log and SqlPurger log',
      -e $log_file && -e $purge_log_file );
    if ( -e $log_file ) {
      $self->_parseLog;
    }
    elsif ( -e $purge_log_file ) {
      $self->sqlpurger( new db::SqlPurger );
      $self->sqlpurger->parse_log($purge_log_file);
    }
  }
  else {
    ###
    ### Set the default data file name, if necessary
    ###
    $self->data_file("$path$name.dat") if ( !defined( $self->data_file ) );
  }

  return $file_name;
}

################################################################################
###
### dbconfig_file
###
### This method re-implements this class method so that the
### db_config file is processed to acquire its tags.
###
################################################################################

sub dbconfig_file($$) {
  my ( $self, $dbconfig_file ) = @_;
  return $self->{'db::SqlLoader::dbconfig_file'}
    if ( !defined($dbconfig_file) );
  ###
  ### Get DB Configuration Parameters
  ###
  my $db_config = {};
  my $db_params = undef;
  (
    $db_config->{server}, $db_config->{db}, $db_config->{user},
    $db_config->{pass},   $db_params
    )
    = read_db_config_file($dbconfig_file);
  ###
  ### Make sure owner is set correctly
  ### before writing control file!
  ###
  if ( defined($db_params) && defined( $db_params->{&util::Db::SCHEMA_OWNER} ) ) {
    $self->owner( uc( $db_params->{&util::Db::SCHEMA_OWNER} ) );
  }
  $self->dbconfig($db_config);

  return $self->{'db::SqlLoader::dbconfig_file'} = $dbconfig_file;
}

################################################################################
###
### data_file
###
### This overloads the default method to provide additional functionality
### for limiting the names of data files.
###
################################################################################

sub data_file($$) {
  my ( $self, $file_name ) = @_;
  return $self->{'db::SqlLoader::data_file'} if ( !defined($file_name) );

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  $self->msg->dieOnError(
'SQLLoader does not allow data in the control file; choose a different name for the data file',
    $file_name eq $self->control_file
  );
  $self->first_row_out(undef);
  ###
  ### If the file already exists, then check to see if any data already
  ### exists in the file.  If so, then consider the first row written.
  ###
  if ( -e $file_name ) {
    my (
      $dev,  $ino,   $mode,  $nlink, $uid,     $gid, $rdev,
      $size, $atime, $mtime, $ctime, $blksize, $blocks
      )
      = stat $file_name;
    if ( $size > 0 ) {
      $self->first_row_out(util::Constants::TRUE);
    }
  }
  return $self->{'db::SqlLoader::data_file'} = $file_name;
}
###
### Now define other useful methods of objects of this type
###
################################################################################
###
### load
###
################################################################################

sub load {
  my ( $self, $dbconfig ) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  $self->dbconfig_file($dbconfig) if ( defined($dbconfig) );
  ###
  ### Make certain the name is uppercase
  ###
  $self->table( uc( $self->table ) );
  ###
  ### Compute continuation load, if necessary
  ###
  ### In the case, where either the log_file or purge_log_file
  ### exists, then this method assumes that the control_file
  ### method has been executed.
  ###
  my $log_file       = $self->log_file;
  my $purge_log_file = $self->purge_log_file;
  $self->msg->dieOnError(
    'SQLLoader detected both SQL*Loader log and SqlPurger log',
    -e $log_file && -e $purge_log_file );
  if ( -e $log_file ) {
    ###
    ### Setup a continuation load, if necessary
    ###
    $self->_continueLoad;
  }
  elsif ( -e $purge_log_file ) {
    $self->msg->dieOnError(
'SQLLoader detected SqlPurger log with a failed deletion(s); will not load.',
      defined( $self->sqlpurger->record_failed )
    );
    ###
    ### Setup a continuation load from a purge
    ###
    $self->_continuePurgedLoad;
  }
  ###
  ### Make certain all control information is flushed before closing files
  ###
  $self->_writeControl;
  $self->_closeFiles;
  ###
  ### Early return if table was previously load and
  ### does not need reloading
  ###
  if ( defined( $self->needs_reloading ) && !$self->needs_reloading ) {
    $self->msg->printMsg(
      'Loader for table ' . $self->table . ' has no data to reload.' );
    return util::Constants::FALSE;
  }
  ###
  ### If no data was written to the data file, then we can return
  ### successfully now.
  ###
  if ( !defined( $self->first_row_out ) ) {
    $self->msg->printMsg(
      'Loader for table ' . $self->table . ' has no data to load.' );
  }
  ###
  ### Create the SQL*Loader command with database information
  ###
  $self->msg->dieOnError(
    'No database configuration file specified as argument',
    !defined( $self->dbconfig_file ) );
  $self->msg->dieOnError( 'Environment variable ORACLE_HOME is not defined.',
    !defined( $ENV{ORACLE_HOME} ) );
  my $ctl_file = $self->control_file;
  #########################################################
  ######## MUST DETERMINE HOW TO ADDRESS SQLLDR ###########
  #########################################################
  my $command  =
      join( util::Constants::SLASH, $ENV{ORACLE_HOME}, 'bin', 'sqlldr' )
    . ' userid='
    . $self->dbconfig('user')
    . util::Constants::SLASH
    . $self->dbconfig('pass') . '@'
    . $self->dbconfig('db')
    . " control=$ctl_file log=$log_file";
  #########################################################
  ######## MUST DETERMINE HOW TO ADDRESS SQLLDR ###########
  #########################################################
  my $rc = undef;
  if ( $self->msg->isDebugging ) {
    $rc = util::Constants::FALSE;
    my $msg = "db::SqlLoader::load:  Would execute cmd = $command\n";
    $self->msg->printMsg($msg);
  }
  else {
    ###
    ### Run the command
    ###
    $self->msg->printMsg("executing command = $command");
    $rc = $self->_runCommand($command);
    $self->msg->printMsg("status from executing command = $rc");
    $self->_parseLog;
    if ( $rc == 0 ) {
      ###
      ### Read the log file to see if any other errors occurred while
      ### loading some of the records.  Even if just one record failed
      ### to load, the error status should indicate this.
      ###
      if ( $self->load_state()->recs_rejected > 0 ) {
        ###
        ### Some errors occurred, so set $rc to an error code (2).
        ###
        $rc = 2;
      }
    }
  }
  $self->status_code($rc);
  return $rc;
}

################################################################################
###
### addData
###
################################################################################

sub addData {
  my ($self) = @_;
  ###
  ### Make certain the data file is opened
  ###
  if ( !defined( $self->data_opened ) || !$self->data_opened ) {
    $self->_openFiles;
  }
  my $fh = $self->df_handle;
  ###
  ### If there is more than one argument, then it must be a list of individual
  ### fields which need to be written with the field separator.
  ###
  my @fields = @_;
  if ( $#fields > 0 ) {
    my $count = 1;
    foreach my $f (@fields) {
      my $field_sep = $self->field_separator;
      if ( $field_sep eq 'WHITESPACE' ) {
        $field_sep = util::Constants::TAB;
      }
      if ( $count != 1 ) {
        ###
        ### Write field separator before next field
        ###
        print $fh "$field_sep";
      }
      ###
      ### Check for presence of field separator in the data of the field.
      ### If this occurs, then the optional field enclosure characters are
      ### used to help delimit the field properly.
      ###
      if ( $f =~ /$field_sep/ ) {
        if ( defined( $self->field_enclosure ) ) {
          print $fh $self->field_enclosure, $f, $self->field_enclosure;
        }
        else {
          ###
          ### Try duplicating the field separator anywhere it occurs in
          ### the field.  SQL*Loader will interpret that as a single
          ### instance of the separator in the data.
          ###
          $f =~ s/$field_sep/$field_sep$field_sep/g;
        }
      }
      else {
        print $fh $f;
      }
      $count++;
    }
  }
  else {
    ###
    ### The one argument should be a string of separated fields
    ###
    print $fh $fields[0];
  }
  if ( defined( $self->record_separator ) ) {
    print $fh $self->record_separator;
  }
  else {
    print $fh util::Constants::NEWLINE;
  }
  $self->first_row_out(util::Constants::TRUE);
}

################################################################################
###
### purge
###
################################################################################

sub purge {
  my ( $self, $dbconfig ) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  $self->dbconfig_file($dbconfig) if ( defined($dbconfig) );
  $self->table( uc( $self->table ) );    # Make certain the name is uppercase
  ###
  ### Make certain all control information is flushed and close file
  ### handles
  ###
  $self->_writeControl;
  $self->_closeFiles;
  ###
  ### Setup Purge
  ###
  ### In the case, where either the log_file or purge_log_file
  ### exists, then this method assumes that the control_file
  ### method has been executed.
  ###
  my $log_file       = $self->log_file;
  my $purge_log_file = $self->purge_log_file;
  $self->msg->dieOnError(
    'SqlLoader detected both SQL*Loader log and SqlPurger log',
    !defined( $self->force_purge ) && -e $log_file && -e $purge_log_file
  );
  if ( defined( $self->force_purge ) || -e $log_file ) {
    $self->sqlpurger( new db::SqlPurger );
    $self->_newDataLoad;    ### Setup for a complete purge
    if ( !defined( $self->first_row_out ) ) {
      $self->msg->printMsg(
        'Purger for table ' . $self->table . ' has no data to purge.' );
      return util::Constants::FALSE;
    }
    ###
    ### Setup purge
    ###
    $self->sqlpurger->table( $self->table );
    foreach my $index ( 0 .. $#{ $self->fields } ) {
      $self->sqlpurger->fields( $index, $self->fields($index) );
    }
    $self->sqlpurger->dbconfig_file( $self->dbconfig_file );
    $self->sqlpurger->data_file( $self->data_file );
    $self->sqlpurger->log_file( $self->purge_log_file );
    $self->sqlpurger->field_separator( $self->field_separator );
    if ( defined( $self->record_separator ) ) {
      $self->sqlpurger->record_separator( $self->record_separator );
    }
  }
  elsif ( -e $purge_log_file ) {
    if ( !defined( $self->sqlpurger->record_failed ) ) {
      $self->msg->printMsg(
        'Purger for table ' . $self->table . ' has already purged data.' );
      return util::Constants::FALSE;
    }
    $self->_continuePurgedLoad;
    ###
    ### Check For Conformance
    ###
    $self->msg->dieOnError(
      'SQL*Loader Control File ('
        . $self->table . ') and'
        . ' Purge Log ('
        . $self->sqlpurger->table
        . ') do not conform in table',
      $self->sqlpurger->table ne $self->table
    );
    $self->msg->dieOnError(
      'SQL*Loader Control File ('
        . $self->data_file . ') and'
        . ' Purge Log ('
        . $self->sqlpurger->data_file
        . ') do not conform in data_file',
      $self->sqlpurger->data_file ne $self->data_file
    );
    $self->msg->dieOnError(
      'SQL*Loader Control File ('
        . self->field_separator . ') and'
        . ' Purge Log ('
        . $self->sqlpurger->field_separator
        . ') do not conform in field_separator',
      $self->sqlpurger->field_separator ne $self->field_separator
    );
    $self->msg->dieOnError(
      'SQL*Loader Control File ('
        . $self->record_separator . ') and'
        . ' Purge Log ('
        . $self->sqlpurger->record_separator
        . ') do not conform in record_separator',
      defined( $self->record_separator )
        && defined( $self->sqlpurger->record_separator )
        && $self->sqlpurger->record_separator ne $self->record_separator
    );
    ###
    ### Setup for a continuation purge starting a the first failure
    ###
    foreach my $index ( 0 .. $#{ $self->fields } ) {
      $self->sqlpurger->fields( $index, $self->fields($index) );
    }
    $self->sqlpurger->dbconfig_file( $self->dbconfig_file );
    $self->sqlpurger->skip_records( $self->sqlpurger->record_failed - 1 );
  }
  else {
    $self->msg->printMsg( 'Purger for table '
        . $self->table
        . ' cannot purge data that was never loaded.' );
    return util::Constants::FALSE;
  }
  if ( defined( $self->batch_size ) ) {
    $self->sqlpurger->batch_size( $self->batch_size );
  }
  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  my $rc = undef;
  if ( $self->msg->isDebugging ) {
    $rc = util::Constants::FALSE;
    my $msg = "db::SqlLoader::purge:  Would purge now...\n";
    $self->msg->printMsg($msg);
  }
  else {
    $rc = $self->sqlpurger->purge;
  }
  $self->status_code($rc);
  if ($rc) {
    $self->errors( $self->sqlpurger->errors );
  }
  return $rc;
}

################################################################################
###
### _parseLog
###
################################################################################

sub _parseLog {
  my ($self) = @_;
  ###
  ### New structure to hold state information
  ###
  my $log_state = new LoadStatus;
  $self->msg->dieOnError( 'Could not open log file ' . $self->log_file . ": $!",
    !open( LOG, $self->log_file ) );
  ###
  ### Process the header section of the file
  ###
  while (<LOG>) {
    chomp;
    if (/SQL\*Loader:\s*Release\s*((\d|\.)+).*Production on (.*)/) {
      $log_state->version($1);
      $log_state->run_date($3);
      ###
      ### Proceed to next section
      ###
      last;
    }
  }
  ###
  ### Process the Global Information section of the file, including any early
  ### errors that might have occurred.
  ###
  while (<LOG>) {
    chomp;
    if (/data file:\s*((\w|\.|\/|-)+)/i) {
      if ( $1 !~ /none/i ) {
        $self->data_file($1);
      }
    }
    elsif (/bad file:\s*((\w|\.|\/|-)+)/i) {
      if ( $1 !~ /none/i ) {
        $self->bad_file($1);
      }
    }
    elsif (/discard file:\s*((\w|\.|\/|-)+)/i) {
      if ( $1 !~ /none/i ) {
        $self->discard_file($1);
      }
    }
    elsif (/Number to skip:\s*(\d+)/) {
      $log_state->recs_skipped($1);
    }
    elsif (/Errors allowed:\s*(\d+)/) {
      $log_state->errors_allowed($1);
      ###
      ### Proceed to next section
      ###
      last;
    }
    elsif (/(\S+-\d+:)|(unix error:)/i) {
      my $err = $self->errors;
      $err .= $_ . util::Constants::NEWLINE;
      $self->errors($err);
    }
  }
  ###
  ### Process the Table information
  ###
  while (<LOG>) {
    chomp;
    if (/Table\s*(\w+)/) {
      $log_state->table_name($1);
    }
    elsif (/Insert option.*:\s*(\w+)/) {
      $log_state->insert_option($1);
      ###
      ### Proceed to next section
      ###
      last;
    }
  }
  ###
  ### Process the Data file and Table Load information
  ###
  my @rec_errors;
  while (<LOG>) {
    chomp;
    if (/Record\s*(\d+):/) {
      push( @rec_errors, $_ );
      $_ = <LOG>;
      chomp;
      push( @rec_errors, $_ );
    }
    elsif (/(\S+-\d+:)|(unix error:)/i) {
      push( @rec_errors, $_ );
    }
    elsif (/(\d+)\s*Row.? successfully loaded/) {
      $log_state->recs_loaded($1);
    }
    elsif (/(\d+)\s*Row.? not loaded due to data errors/) {
      $log_state->recs_rejected($1);
    }
    elsif (/(\d+)\s*Row.? not loaded because all WHEN/) {
      $log_state->recs_discarded($1);
      ###
      ### Proceed to next section
      ###
      last;
    }
  }
  ###
  ### We'll put the record errors directly into the parent object as
  ### errors since no other error could possibly have occurred (considering
  ### we are actually reading the log file produced by a "successful" run).
  ###
  $self->errors(
    $self->errors . join( util::Constants::NEWLINE, @rec_errors ) );
  ###
  ### Process the summary statistics
  ###
  while (<LOG>) {
    chomp;
    if (/Elapsed time was:\s*([0-9:\.]+)/) {
      $log_state->elapsed_time($1);
    }
    elsif (/CPU time was:\s*([0-9:\.]+)/) {
      $log_state->cpu_time($1);
    }
  }
  ###
  ### We are finished with the log file at this point
  ###
  close(LOG);
  ###
  ### If the record counts are still undefined, then some fatal error
  ### must have occurred with the database software.  In this case, set
  ### all the record counts to zero so that a subsequent load will start
  ### from scratch.
  ###
  if ( !defined( $log_state->recs_loaded ) ) {
    $log_state->recs_loaded(0);
    $log_state->recs_rejected(0);
    $log_state->recs_discarded(0);
  }
  $self->load_state($log_state);
}

################################################################################
###
### _parseControl
###
### Parses the control file specified to set all the member variables of this
### object.
###
################################################################################

sub _parseControl {
  my ( $self, $ctl_file ) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  ###
  ### State variables
  ###
  ### Indicates when the 'fields' keyword is parsed
  ###
  my $field_seen = util::Constants::FALSE;
  $self->msg->dieOnError( "Could not open control file $ctl_file: $!",
    !open( CTL, "< $ctl_file" ) );
  while (<CTL>) {
    chomp;
    ###
    ### Extract options, if present
    ###
    if (/options/i) {
      if (/bindsize\s*=\s*(\d+)/i) {
        $self->bindsize($1);
      }
      if (/readsize\s*=\s*(\d+)/i) {
        $self->readsize($1);
      }
      if (/errors\s*=\s*(\d+)/i) {
        $self->error_limit($1);
      }
      if (/rows\s*=\s*(\d+)/i) {
        $self->rows($1);
      }
    }
    elsif (/infile\s*\'*((\w|\.|\/|-)+)\'*/i) {
      ###
      ### Extract data file name and other options
      ###
      $self->data_file($1);
      $self->first_row_out(undef);
      if ( -e $self->data_file ) {
        my (
          $dev,  $ino,   $mode,  $nlink, $uid,     $gid, $rdev,
          $size, $atime, $mtime, $ctime, $blksize, $blocks
          )
          = stat $self->data_file;
        if ( $size > 0 ) {
          $self->first_row_out(util::Constants::TRUE);
        }
      }
      if (/str\s*\'(.+)\'/i) {
        $self->record_separator($1);
      }
      if (/badfile\s*\'*((\w|\.|\/|-)+)\'*/i) {
        $self->bad_file($1);
      }
      if (/discardfile\s*\'*((\w|\.|\/|-)+)\'*/i) {
        $self->discard_file($1);
      }
      if (/discards|discardmax/i) {
        $self->discard_limit($1);
      }
    }
    elsif (/into\s*table\s*(\w+\.)?(\w+)/i) {
      ###
      ### Extract the INTO clause
      ###
      my $owner = $1;
      my $table = $2;
      if ( defined($owner) ) { $owner =~ s/\.//; }
      $self->owner($owner);
      $self->table($table);
    }
    elsif (/^(append|insert|replace|truncate)$/i) {
      ###
      ### Check for the insert option
      ###
      $self->insert_option($1);
    }
    ###
    ### Extract delimiters
    ###
    if (/fields\s*terminated\s*by\s*\'([^\']*)\'/i) {
      $self->field_separator($1);
      $field_seen = util::Constants::TRUE;
    }
    if (/optionally\s*enclosed\s*by\s*\'([^\']*)\'/i) {
      $self->field_enclosure($1);
    }
    ###
    ### If trailing null columns is specified, set the flag
    ###
    if (/trailing\s+nullcols/i) {
      $self->trailing_nulls(util::Constants::TRUE);
    }
    ###
    ### Check for beginning of field specifiers
    ###
    if ( $field_seen && (/\(/) ) {
      ###
      ### Concatenate all lines up to and including the closing parenthesis.
      ###
      my $field_specs = $_;
      next if (/\)/);
      while (<CTL>) {
        chomp;
        $field_specs .= $_;
        last if (/^\s*\)/);
      }
      ###
      ### Now remove the parentheses
      ###
      $field_specs =~ s/^\s*\(//;
      $field_specs =~ s/\s*\)$//;
      ###
      ### Split into individual columns by the comma separator
      ###
      my @fields = split( ',', $field_specs );
      ###
      ### Now replace leading spaces with nothing
      ###
      for ( my $i = 0 ; $i <= $#fields ; $i++ ) {
        $fields[$i] =~ s/^\s*(\S+)/$1/;
        ###
        ### Now add the field into the object's array
        ###
        $self->fields( $i, $fields[$i] );
      }
    }
  }
  ###
  ### We are finished with the control file at this point
  ###
  close(CTL);
}

################################################################################
###
### _closeFiles
###
################################################################################

sub _closeFiles {
  my ($self) = @_;

  $self->df_handle->close
    if ( defined( $self->data_opened )
    && $self->data_opened
    && defined( $self->df_handle ) );
  $self->data_opened(util::Constants::FALSE);

  $self->cf_handle->close
    if ( defined( $self->control_opened )
    && $self->control_opened
    && defined( $self->cf_handle ) );
  $self->control_opened(util::Constants::FALSE);
}

################################################################################
###
### _openFiles
###
################################################################################

sub _openFiles {
  my ($self) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  ###
  ### If the data file already exists, then open it for append access
  ###
  $self->df_handle( new FileHandle );
  my $df_name = $self->data_file;
  if ( -e $df_name ) {
    $self->msg->dieOnError(
      'Could not open data file ' . $self->data_file . ": $!",
      !$self->df_handle->open(">> $df_name") );
  }
  else {
    $self->msg->dieOnError(
      'Could not open data file ' . $self->data_file . ": $!",
      !$self->df_handle->open("> $df_name") );
  }
  $self->data_opened(util::Constants::TRUE);
  ###
  ### Open the control file as well
  ###
  $self->cf_handle( new FileHandle );
  my $cf_name = $self->control_file;
  $self->msg->dieOnError(
    'Could not open control file ' . $self->control_file . ": $!",
    !$self->cf_handle->open("> $cf_name") );
  $self->control_opened(util::Constants::TRUE);
}

################################################################################
###
### _writeControl
###
################################################################################

sub _writeControl {
  my ($self) = @_;
  ###
  ### If the control file was already flushed, then return immediately
  ###
  return if ( $self->control_flushed );
  ###
  ### If the control file is not already opened, open it and set the
  ### handle object
  ###
  if ( !defined( $self->control_opened ) || !$self->control_opened ) {
    $self->_openFiles;
  }
  my $control = $self->cf_handle;
  ###
  ### Write the options first
  ###
  my $bind = defined( $self->bindsize ) ? $self->bindsize : 10000000;
  print $control "OPTIONS (BINDSIZE=$bind";
  my $rdsize = defined( $self->readsize ) ? $self->readsize : 10000000;
  print $control ", READSIZE=$rdsize";
  my $rows = defined( $self->rows ) ? $self->rows : 50000;
  print $control ", ROWS=$rows";
  my $errs = defined( $self->error_limit ) ? $self->error_limit : 1;
  print $control ", ERRORS=$errs)\n";

  print $control "LOAD DATA\n";
  ###
  ### Write the INFILE specification based on what files are being used
  ###
  print $control "INFILE '", $self->data_file, util::Constants::SINGLE_QUOTE;
  ###
  ### If a record separator is specified, this is where it must be setup
  ###
  if ( defined( $self->record_separator ) ) {
    print $control ' "str ', util::Constants::SINGLE_QUOTE,
      $self->record_separator, util::Constants::SINGLE_QUOTE,
      util::Constants::QUOTE;
  }
  print $control util::Constants::NEWLINE;
  ###
  ### The insert option will have a default value of APPEND, but can be
  ### set to whatever the application program desires.
  ###
  my $ins_opt =
    defined( $self->insert_option ) ? $self->insert_option : 'APPEND';
  print $control "$ins_opt\nINTO TABLE ";
  if ( defined( $self->owner ) ) {
    print $control $self->owner . util::Constants::DOT;
  }
  print $control $self->table, util::Constants::NEWLINE;
  ###
  ### Now get the field separator
  ###
  $self->field_separator('WHITESPACE') if ( $self->field_separator =~ /^\s+$/ );
  print $control "fields terminated by '", $self->field_separator,
    util::Constants::SINGLE_QUOTE;
  if ( defined( $self->field_enclosure ) ) {
    print $control " optionally enclosed by '", $self->field_enclosure,
      util::Constants::SINGLE_QUOTE;
  }
  print $control util::Constants::NEWLINE;
  ###
  ### If trailing null columns are permitted, add the option
  ###
  if ( defined( $self->trailing_nulls ) && $self->trailing_nulls > 0 ) {
    print $control "trailing nullcols\n";
  }
  ###
  ### Now write the field specifiers
  ###
  $self->_writeFieldSpecs;
  $self->control_flushed(util::Constants::TRUE);
}

################################################################################
###
### _writeFieldSpecs
###
################################################################################

sub _writeFieldSpecs {
  my ($self) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  $self->msg->dieOnError(
    'Control file not opened in SQLLoader::_writeFieldSpecs',
    !defined( $self->control_opened ) || !$self->control_opened
  );
  my $control   = $self->cf_handle;
  my $index     = 0;
  my $fld_array = $self->fields;
  print $control "        (\n";

  foreach my $field (@$fld_array) {
    ###
    ### Split the field specification into parts so that column names
    ### can nicely be segregated from the rest of the spec.
    ###
    $field =~ s/^\s+//;    # Remove any space at the beginning
    my @parts = split( /\s+/, $field );
    my $col_name = shift(@parts);
    ###
    ### Must do it this way since CONSTANT spec and
    ### NULLIF spec may have a quoted (string) value
    ###
    my $rest = $field;
    $rest =~ s/^$col_name\s+//;
    printf $control "         %-32.32s %s", $col_name, $rest;
    if ( $index != $#{$fld_array} ) {
      print $control ",\n";
    }
    else {
      print $control util::Constants::NEWLINE;
    }
    $index++;
  }
  print $control "        )\n";
}

################################################################################
###
### _runCommand
###
################################################################################

sub _runCommand {
  my ( $self, $command ) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  ###
  ### Open a pipe so that output from the command can be processed
  ###
  if ( open( CMD, "$command 2>&1 |" ) ) {
    ###
    ### Loop through the output and extract error messages
    ###
    my @err_messages;
    while (<CMD>) {
      chomp;
      if (/(\S+-\d+:)|(unix error:)/i) {
        ###
        ### Error line
        ###
        push( @err_messages, $_ );
      }
    }
    ###
    ### Close the pipe and examine the return status
    ###
    close(CMD);
    my $rc = $? & 0xffff;
    if ( $rc == 0 ) {
      return util::Constants::FALSE;
    }
    else {
      $! = $rc >> 8;
      my $errcode = $rc >> 8;
      my $signal  = $rc & 0x007f;
      my $message = 'SQL*Loader command failed with ';
      $self->errors( join( util::Constants::NEWLINE, @err_messages ) );
      if ( $rc & 0x80 ) {
        $message .= 'coredump ';
      }
      if ($signal) {
        $message .= 'from signal $signal ';
      }
      if ( $! != 0 ) {
        $message .= "error $! (code $errcode)";
      }
      $self->msg->printError( $message, util::Constants::TRUE );
      if    ( $rc & 0x80 ) { $rc = 0x80; }
      elsif ($signal)      { $rc = $signal; }
      elsif ( $! != 0 )    { $rc = $!; }
      return $rc;
    }
  }
  else {
    my $status = $!;
    $self->msg->printError( "Failed to run SQL*Loader: $status", $status );
    return $status;
  }
}

################################################################################
###
### _continueLoad
###
### Setup this object so that the load() method will continue loading where
### the last attempt left off.
###
################################################################################

sub _continueLoad {
  my ($self) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  ###
  ### Move all the current files which are going to be overwritten to new
  ### names with a time stamp appended.
  ###
  my $timestamp = util::Constants::DOT . time();
  my $data      = $self->data_file;
  my $bad       = $self->bad_file;
  my $log       = $self->log_file;
  if ( -e $data ) {
    $data .= $timestamp;
    rename $self->data_file, $data;
  }
  if ( -e $log ) {
    $log .= $timestamp;
    rename $self->log_file, $log;
  }
  if ( -e $bad ) {
    $bad .= $timestamp;
    rename $self->bad_file, $bad;
  }
  $self->first_row_out(undef);
  $self->needs_reloading(util::Constants::FALSE);
  ###
  ### Copy any remaining records from the original data file into the new
  ### data file.
  ###
  if ( -e $data ) {
    ###
    ### Compute the number of records to skip in this file based on the total
    ### records loaded or placed into the bad file (or discarded).  In case
    ### any records were skipped deliberately, add that number as well.
    ###
    my $skip_cnt =
      $self->load_state->recs_loaded + $self->load_state->recs_rejected +
      $self->load_state->recs_discarded + $self->load_state->recs_skipped;
    ###
    ### If there are records rejected and there are more than
    ### error limit, then to get the correct skip count,
    ### you must decrement it by one.
    ###
    $skip_cnt--
      if ( $self->load_state->recs_rejected > 0
      && $self->load_state->recs_rejected > $self->error_limit );
    ###
    ### Determine the reject record numbers to be sure to
    ### include them in the load
    ###
    my %error_rec_nums = ();
    if ( defined( $self->errors ) ) {
      my @errors = split( /\n/, $self->errors );
      foreach my $index ( 0 .. $#errors ) {
        if ( $errors[$index] =~ /^Record\s+(\d+):\s+Rejected/i ) {
          $error_rec_nums{$1} = $1;
        }
      }
    }
    my $previous_record_separator = $/;
    if ( defined( $self->record_separator ) ) {
      $/ = $self->record_separator;
    }
    $self->msg->dieOnError( "Could not open old data file $data: $!",
      !open( DATA, "<$data" ) );
    my $rec_cnt = 0;
    while (<DATA>) {
      chomp;
      $rec_cnt++;
      ###
      ### Take the record 'as-is'.
      ### Do not make any assumptions about its content!
      ###
      if ( $rec_cnt > $skip_cnt
        || defined( $error_rec_nums{$rec_cnt} ) )
      {
        $self->addData($_);
        $self->needs_reloading(util::Constants::TRUE);
      }
    }
    close(DATA);
    if ( defined( $self->record_separator ) ) {
      $/ = $previous_record_separator;
    }
  }
  if ( !$self->needs_reloading ) {
    if ( -e $data ) {
      rename $data, $self->data_file;
    }
    if ( -e $log ) {
      rename $log, $self->log_file;
    }
    if ( -e $bad ) {
      rename $bad, $self->bad_file;
    }
  }
  ###
  ### Everything should be ready to load now.
  ###
}

################################################################################
###
### _continuePurgedLoad
###
### Setup this object so that the load() nad purge() methods will load an
### entirely new load from the current data file or continue purging the
### load, respectively
###
################################################################################

sub _continuePurgedLoad {
  my ($self) = @_;
  ###
  ### Move all the current files which are going to be overwritten to new
  ### names with a time stamp appended.
  ###
  my $timestamp = util::Constants::DOT . time();
  $self->first_row_out(undef);
  if ( defined( $self->data_file ) && -e $self->data_file ) {
    copy( $self->data_file, $self->data_file . $timestamp );
    my (
      $dev,  $ino,   $mode,  $nlink, $uid,     $gid, $rdev,
      $size, $atime, $mtime, $ctime, $blksize, $blocks
      )
      = stat $self->data_file;
    if ( $size > 0 ) {
      $self->first_row_out(util::Constants::TRUE);
    }
  }
  if ( defined( $self->purge_log_file ) && -e $self->purge_log_file ) {
    rename( $self->purge_log_file, $self->purge_log_file . $timestamp );
  }
  ###
  ### Everything should be ready to load or purge now.  Additional data
  ### can also be added to this load by calling the addData() method.
}

################################################################################
###
### _newDataLoad
###
### Setup this object so that the purge() method will purge the original
### data file.
###
################################################################################

sub _newDataLoad {
  my ($self) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  ###
  ### Move all the current files which are going to be overwritten to new
  ### names with a time stamp appended.
  ###
  my $timestamp = util::Constants::DOT . time();
  if ( defined( $self->data_file ) && -e $self->data_file ) {
    rename( $self->data_file, $self->data_file . $timestamp );
  }
  if ( defined( $self->log_file ) && -e $self->log_file ) {
    rename( $self->log_file, $self->log_file . $timestamp );
  }
  if ( defined( $self->bad_file ) && -e $self->bad_file ) {
    rename( $self->bad_file, $self->bad_file . $timestamp );
  }

  # Next detetermine the data file with oldest timestamp
  chdir(util::Constants::DOT);
  my ( $data_filename, $data_filedir ) = _setPath( $self->data_file );
  chdir($data_filedir);
  opendir( LOAD_DIR, $data_filedir );
  $data_filename =~ s/\./\\\./g;
  my @data_files =
    grep( /^$data_filename\.\d+$/, grep( -f, readdir(LOAD_DIR) ) );
  closedir(LOAD_DIR);
  @data_files = sort _date_sort @data_files;
  $self->msg->dieOnError( 'Could not find a data file for ' . $self->data_file,
    @data_files < 1 );
  $self->first_row_out(undef);
  my (
    $dev,  $ino,   $mode,  $nlink, $uid,     $gid, $rdev,
    $size, $atime, $mtime, $ctime, $blksize, $blocks
    )
    = stat $data_files[0];

  if ( $size > 0 ) {
    $self->first_row_out(util::Constants::TRUE);
  }
  ###
  ### Make a copy of it into the data_file
  ###
  copy( $data_files[0], $self->data_file );
  ###
  ### Everything should be ready to load now.  Additional data can also
  ### be added to this load by calling the addData() method.
  #
}

sub _date_sort {
  $a =~ /^.*\.(\d+)$/;
  my $a_date = $1;
  $b =~ /^.*\.(\d+)$/;
  my $b_date = $1;
  $a_date <=> $b_date;
}

sub _setPath {
  my ($filename) = @_;
  ###
  ### Remove whitespace at either end
  ###
  my $whitespace = '\s+';
  $filename =~ s/^$whitespace//;
  $filename =~ s/$whitespace$//;
  ###
  ### Remove spurious slashes
  ### 1.  Multiple slashes to one slash (\/(\/)+)
  ### 2.  Trailing slash and optional dot (\/\.?$)
  ###
  $filename =~ s/\/\/+/\//g;
  $filename =~ s/\/\.?$//;
  ###
  ### Decompose filename to file_name and file_path
  ### Then adjust file_path by
  ### 1.  Removing spurious dot-slashes (\.\/) (This assumes
  ###     that filenames do not end in dot (.)
  ### 2.  Make absolute file_path
  ###
  my ( $file_name, $file_path, $file_suffix ) = fileparse($filename);
  $file_path =~ s/\.\///g if ( $file_path !~ /\.\./ );
  if ( $file_path eq util::Constants::EMPTY_STR
    || $file_path =~ /^[^\/]/ )
  {
    ###
    ### Relative path!
    ### Add current working directory to this.
    ###
    $file_path = join( util::Constants::SLASH, cwd(), $file_path );
  }
  return ( $file_name, $file_path );
}

################################################################################
###
### DESTROY
###
### This method is called automatically in Perl when objects of this type
### are being garbage collected.  This method will cleanup any outstanding
### work that needs to be done before the object goes away (like persistence).
###
################################################################################

sub DESTROY {
  my ($self) = @_;

  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->unsetHardDie;

  if ( defined( $self->control_opened ) && $self->control_opened ) {
    if ( !defined( $self->cf_handle ) ) {
      ###
      ### Create the file handle again so that the file can be flushed.
      ###
      $self->cf_handle( new FileHandle );
      my $cf_name = $self->control_file;
      $self->msg->dieOnError(
        'Could not open control file ' . $self->control_file,
        !$self->cf_handle->open("> $cf_name") );
      $self->control_flushed(util::Constants::FALSE);
    }
    $self->_writeControl;
    $self->_closeFiles;
  }

}

################################################################################

1;

__END__

=head1 NAME

SQLLoader - Collects data to load and handles the loading via
SQL*Loader

=head1 SYNOPSIS

    use db::SqlLoader;

    $sl = new db::SqlLoader;


=head1 DESCRIPTION

The L<db::SqlLoader> module can be used to load rows of data into
one table using Oracle SQL*Loader or delete rows of data into one
table using L<db::SqlPurger>.  This module handles all interactions
with SQL*Loader and L<db::SqlPurger> including specifying the
control header information, and interpreting the results through easy
to use methods.  All errors are made available through a single method
for easy reporting of results.


=head2 Data Members

Each data member has its own accessor methods for setting and
retrieving the current values.

=over

=item my $curr_owner = $sl->owner

=item $sl->owner( $name )

Accesses the name of the owner of the table to be loaded.  This data
member is necessary in those schemas where a table must be prefixed by
its owner.  The owner defined by the B<ALTERNATENAME> key in the
dbconfig_file takes precedence over the value that is manually set by
this method.

=item my $curr_table_name = $sl->table

=item $sl->table( $name )

Accesses the name of the table which will be loaded by this object.
This data member must be set in order to load data into the table.

=item my $curr_dbconfig = $sl->dbconfig_file

=item $sl->dbconfig_file( "ids.dbconfig" )

Sets or retrieves the current database configuration file name used by
the loader object.  When SQL*Loader runs, it will need the name of the
Oracle database, account name, and password to connect to the correct
database for loading.  This file is parsed using the function
B<read_db_config_file> from the module L<util::DbConfig>.

=item my @curr_fields = @{$sl->fields}

=item my $curr_component = $sl->fields($index)

=item $sl->fields( list )

=item $sl->fields( \@field_array )

=item $sl->fields( $index, $component )

The fields defined for loading is implemented in an array structure of
strings.  Each string specifies a field in the file being loaded.
They must be in the correct order, namely the order in which the
fields appear in each data row.

The string which specifies the field in the file can consist of any
valid syntax permitted in a field_list sentential form (See the BNF in
Section 5, SQL*Loader Control File Reference, Oracle 8i Utilities
Manual).  At a minimum, this must consist of a column name which
exists in the table being loaded.  Specifying only the column name
will default to the CHAR datatype.  In general, this can easily be
converted to all other Oracle datatypes, but it does have a size limit
of less than 256 characters.

=item my $curr_datafile = $sl->data_file

=item $sl->data_file( "sample.dat" )

This accessor method controls the name of the file used to hold all
the data rows to be loaded into the table.  For convenience, it should
use the B<dat> suffix, but this is not required.

=item my $curr_control = $sl->control_file

=item $sl->control_file( "sample.ctl" )

This accessor method controls the name of the file used to hold the
SQL*Loader control information.  Essentially, this is header
information for the data to be loaded.  For convenience, it is better
to use a separate control file from the datafile so that the same
control file can be used for subsequent loads of previously bad data
where the bad data resides in a separate file with the suffix B<bad>.

=item my $curr_log = $sl->log_file

=item $sl->log_file( "sample.log" )

Accessor to control the name of the file that contains the logging
information produced by SQL*Loader.  By default, this file is named
the same as the datafile, but with a B<log> suffix.  Using the default
will enable L<db::SqlLoader> objects to automatically detect and
recover from previous loads.

=item my $curr_purge_log = $sl->purge_log_file

=item $sl->purge_log_file( "sample.pge" )

Accessor to control the name of the file that contains the logging
information produced by L<db::SqlPurger>.  By default, this file is
named the same as the datafile, but with a B<pge> suffix.  Using the
default will enable L<db::SqlLoader> objects to automatically detect
and recover from previous purges.

=item my $curr_batch_size = $sl->batch_size

=item $sl->batch_size( $batch_size )

Accesses the batch size for delete commits in the B<purge()> method.
If this data member is not set, it defaults to 100.

=item my $curr_ioption = $sl->insert_option

=item $sl->insert_option( $option )

The insert option determines how SQL*Loader handles the loading of
data into the table.  The default used by this module is B<APPEND>.
However, the usual SQL*Loader default is B<INSERT>, which means the
table must be empty before SQL*Loader runs.  The B<APPEND> option will
simply insert the rows as new to an existing table.  Other options
include B<REPLACE>, which deletes B<all> rows from the table before
the inserts, and B<TRUNCATE>, which truncates the table first, and
then loads the new rows.

For most databases at Celera, the default B<APPEND> option should always
be used.

=item my $curr_rows = $sl->rows

=item $sl->rows( 1000 )

The B<rows> parameter controls the number of rows to insert before a
checkpoint (commit) can occur in SQL*Loader.  The default rows value
is 50000.  The actual number of rows at which to checkpoint is
determined in SQL*Loader by using the rows, bindsize, and readsize
attributes.

=item my $curr_elimit = $sl->error_limit

=item $sl->error_limit( 0 )

The B<error_limit> parameter controls the number of insert errors that
can occur before SQL*Loader decides to terminate the loading.  When
this limit is reached, all loading ceases.  A certain number of rows
may already be loaded and committed depending on how recently a commit
point was reached.

If your application process cannot tolerate any errors, this should be
left at the default value of zero (0).  If the limit were set to 50,
then the first 50 errors would be tolerated, but on the next error,
for whatever reason, the loader is terminated.  All logging
information is then recorded in the file(s) which provides the
recovery information used by this class at a later time.

=item my $curr_fseparator = $sl->field_separator

=item $sl->field_separator( ',' )

The field separator can be any string of characters.  All of the
fields in each data row are required to be separated by the field
separator unless overrided by the fields specification.  This field
separator is automatically used to format data if you provide the
L<db::SqlLoader> object with a list of individual fields for each
data row.

=item my $curr_fenclosure = $sl->field_enclosure

=item $sl->field_enclosure( '"' )

The field enclosure comes in handy for strings which might contain the
field separator somewhere in their text.  The enclosure character(s)
are not required by this module, nor SQL*Loader.  If provided, it will
be optionally used to enclose any field which is determined to contain
the field separator string.  If you format your own data rows, you
must ensure this field enclosure is used as needed, but it will not be
required in all data rows.

=item $sl->trailing_nulls(1)

Sets or resets the interpretation of null columns at the end of a
record.  Setting this option will treat missing columns as NULLs for
the database insert.  These missing columns must always be at the end
of a record; they cannot be embedded in the record somewhere or at the
beginning since there would be no way to identify which columns are
missing.

If a set of column(s) will always be missing from the data set, then
do not include its definition in the fields() array.  This will speed
up loads since NULLs will not have to be transferred over to the
server as values for the insert.  Columns that are not included in a
load are automatically treated as NULLs.

=item my $curr_rec_separator = $sl->record_separator

=item $sl->record_separator( "<string>" )

Sets or retrieves the record separator to use for each row of data in
the datafile.  If your data is likely to contain newlines embedded in
the field(s), then choosing a more complex record separator will help
delineate the rows in the file.  The default is just the newline
character.

=item my $curr_bindsize = $sl->bindsize

=item $sl->bindsize( 10000 )

The bindsize is essentially the amount of memory allocated to the
array which holds all the data.  This array may need to be larger than
the amount of memory needed for one row of data in the datafile.  It
depends on the actual types of the columns being loaded plus some
overhead.  In general, it is recommended to set this value large
enough to hold 100 rows worth of data.  Setting it larger has mimimal
performance gain, and a value too large may cause operating system
performance degredation on the machine where SQL*Loader is running.

=item my $curr_readsize = $sl->readsize

=item $sl->readsize ( 10000 )

The readsize is the of the the read buffer.  The default value is
65536 bytes, however, you can specify a read buffer of any size
depending on your system.  Since, when using the conventional path
method, the bind array is limited by the size of the read buffer, the
advantage of a larger read buffer is that more data can be read before
a commit is required.  Basically, if you specify both read size and
bind size, you should set them equal since SQL*Loader will do that
anyways.

=item $my $current_action = $sl->force_purge

=item $sl->force_purge( $action )

This method allows the user to force the purge operation regardless of
whether there is an existing load or purge log for the table to be
purged.  If the action is defined, then the purge will be forced,
otherwise the purge will depend on the corresponding pre-existing
load- or purge- logs.

=item my $err_str = $sl->errors

This accessor can be used to retrieve a string value which contains
all the errors which occurred when either loading or purging.  If the
load error limit is set to 50, then exactly 51 errors will be stored
in this string (very large).  For rows of data that have load errors,
there are always two lines of text: the first identifies the row by
relative number from the datafile, and the second contains the actual
error message from Oracle.

=item my $status = $sl->status_code

This accessor will return the same value last returned from a call to
the B<load()> and B<purge()> methods.  If no such call has been made,
the value is undefined.

=item my $sqlpurger = $sl->sqlpurger

This accessor allows returns the L<db::SqlPurger> that was used in
the B<purge()> method.  This object allows access to the purge log
data through its accessor methods.  If the the B<purge()> method was
never executed, then it is undefined.

=back

=head2 Operations

Each member function below is used to perform more complex operations
as compared to accessor methods documented above.

=over

=item my $status = $sl->load

=item my $status = $sl->load( "ids.dbconfig" )

This is the most commonly used method of this class.  Once all the
necessary files are specified (data and control), and the control
information is fully specified by accessor methods or an existing
control file, then this method can be used to perform the load.  If
this method is used assuming an existing control file, then the
B<control_file()> method must have been executed beforehand to make
the continuation semantics work correctly when a load log or purge log
file exists.

=item my $status = $sl->purge

=item my $status = $sl->purge( "ids.dbconfig" )

Once all the necessary files are specified (data and control), and the
control information is fully specified by accessor methods or an
existing control file, then this method can be used to perform the
purge.  If this method is used assuming an existing control file, then
the B<control_file()> method must have been executed beforehand to
make the continuation semantics work correctly when a load log or
purge log file exists.

=back

=head1 SEE ALSO

L<db::SqlLoader>

=head1 NOTES

This is version
C<$Revision: 1.61 $>
of the
C<db::SqlLoader::OrderedSet>
module dated
C<$Date: 2007/08/08 18:00:10 $>.

=cut
