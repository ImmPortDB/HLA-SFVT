package db::Schema::LoadMgr;
################################################################################
###
### Module: LoadMgr.pm
### Description:
###
###   For more information about the use of this script, use 'perldoc' on
###   this module to extract the documentation.
###
################################################################################

use strict;
use Class::Struct;
use FileHandle;

use util::Constants;
use util::Db;
use util::DbConfig;
use util::DbQuery;
use util::Msg;

use db::SqlLoader;

################################################################################
###
### BEGIN block is used to set the VERSION symbol
###
################################################################################
###
### All data members for this class are defined by a struct.
###
struct(
  'db::Schema::LoadMgr' => {
    loaders       => '@',
    loader_poset  => '@',
    dbconfig_file => '$',
    db            => 'util::Db',
    force_purge   => '$',
    msg           => 'util::Msg',
    order         => '$'
  }
);    # bug => '$'
###
### The bug comment above fixes an Emacs syntax highlighting problem.
###
###
### Class methods used to define constants
###
sub EXACT   { return 0; }
sub PARTIAL { return 1; }

################################################################################
### addLoader
###
### This method is used to add a new reference to a SqlLoader object
###
################################################################################

sub addLoader {
  my ( $self, $loader ) = @_;
  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->msg->dieOnError( "Undefined object passed to addLoader method",
    !defined($loader) );

  push @{ $self->loaders },      $loader;
  push @{ $self->loader_poset }, 0;
  ###
  ### Since the table name must be uppercase for
  ### these algorithms to work, make sure they are now.
  ###
  my $tabname = uc $loader->table;
  $loader->table($tabname);
}

################################################################################
### newLoader
###
### Similar to addLoader, but will return a newly instantiated loader object.
###
################################################################################

sub newLoader {
  my ($self) = @_;
  my $loader = new db::SqlLoader;
  $self->addLoader($loader);
  return $loader;
}

################################################################################
### load
###
### Orders the loaders based on foreign key constraints and runs each loader
### in the correct order.
###
################################################################################

sub load {
  my ( $self, $no_action ) = @_;
  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  ###
  ### If the order is PARTIAL, then order the tables properly
  ###
  $self->order(PARTIAL) if ( !defined( $self->order ) );
  if ( $self->order == PARTIAL ) {
    ###
    ### If there is more than one loader, then arrange the tables
    ###
    if ( $#{ $self->loaders } > 0 ) {
      $self->_setPartialOrdering;
    }
  }
  ###
  ### Load each table individually watching for errors.  As soon as any
  ### loader has an error, the load process is terminated immediately, and
  ### that last status is used as the return code.
  ###
  ### The outer loop goes from 0 to n+1 where n is the highest numbered
  ### partially ordered set in the collection.  In the last iteration, the
  ### poset number n+1 will not be found which will terminate the outer loop.
  ### This works since poset numbers are assigned sequentially from 0 to n,
  ### so there must be at least one member in each partially ordered
  ### set numbered from 0 to n.
  ###
  ### Flag indicating if poset number exists in collection
  ###
  my $poset_found = util::Constants::TRUE;
  ###
  ### If any loader exists, then poset #0 must exist.
  ###
  my $poset_number = 0;
  my $ret_code     = util::Constants::FALSE;
  while ( $ret_code == 0 && $poset_found ) {
    ###
    ### Must be set true in the inner loop to continue
    ###
    $poset_found = util::Constants::FALSE;
    for ( my $i = 0 ; $i <= $#{ $self->loaders } ; $i++ ) {
      if ( $self->loader_poset->[$i] == $poset_number ) {
        ###
        ### Indicate that we found at least one in this set
        ###
        $poset_found = util::Constants::TRUE;
        if ( defined($no_action) ) {
          $self->msg->printMsg( "POSET #"
              . $poset_number
              . "--Would now load table "
              . $self->loaders->[$i]->table
              . "\n" );
          $ret_code = util::Constants::FALSE;
        }
        else {
          $ret_code = $self->loaders->[$i]->load( $self->dbconfig_file );
        }
        ###
        ### Leave inner loop if non-zero status
        ###
        last if ($ret_code);
      }
    }
    ###
    ### Try the next set number over all loaders
    ###
    $poset_number++;
  }
  return $ret_code;
}

################################################################################
### purge
###
### This method will purge all the records loaded by any of the loaders in
### the collection.  The purge is done in the opposite order they are loaded
### so that foreign key constraints are not violated by removing primary
### keys before the rows that refer to them.
###
################################################################################

sub purge {
  my ( $self, $no_action ) = @_;
  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  ###
  ### If the order is PARTIAL, then order the tables properly
  ###
  $self->order(PARTIAL) if ( !defined( $self->order ) );
  if ( $self->order == PARTIAL ) {
    ###
    ### If there is more than one loader, then arrange the tables
    ###
    if ( $#{ $self->loaders } > 0 ) {
      $self->_setPartialOrdering;
    }
  }
  ###
  ### Get the maximum poset number of this collection so that we can iterate
  ### backwards through the numbers.
  ###
  my $max_poset_number = -1;
  for ( my $i = 0 ; $i <= $#{ $self->loaders } ; $i++ ) {
    if ( $self->loader_poset->[$i] > $max_poset_number ) {
      $max_poset_number = $self->loader_poset->[$i];
    }
  }
  ###
  ### Now proceed through the loaders proceeding in reverse poset
  ### numbering starting with the max_poset_number.
  ###
  ### The outer loop goes from 0 to n+1 where n is the highest numbered
  ### partially ordered set in the collection.  In the last iteration, the
  ### poset number n+1 will not be found which will terminate the outer loop.
  ### This works since poset numbers are assigned sequentially from 0 to n,
  ### so there must be at least one member in each partially ordered
  ### set numbered from 0 to n.
  ###
  my $poset_number = $max_poset_number;
  my $ret_code     = util::Constants::FALSE;
  while ( $ret_code == 0 && $poset_number >= 0 ) {
    for ( my $i = 0 ; $i <= $#{ $self->loaders } ; $i++ ) {
      if ( $self->loader_poset->[$i] == $poset_number ) {
        if ( defined($no_action) ) {
          $self->msg->printMsg( "POSET #"
              . $poset_number
              . "--Would now purge table "
              . $self->loaders->[$i]->table
              . "\n" );
          $ret_code = util::Constants::FALSE;
        }
        else {
          $self->loaders->[$i]->force_purge( $self->force_purge );
          $ret_code = $self->loaders->[$i]->purge( $self->dbconfig_file );
        }
        ###
        ### Leave inner loop if non-zero status
        ###
        last if ($ret_code);
      }
    }
    ###
    ### Try the next set number over all loaders
    ###
    $poset_number--;
  }
  return $ret_code;
}

################################################################################
### _setPartialOrdering
###
### After return from this private method, the poset values are set for each
### loader giving partially ordered sets of loader objects.
###
################################################################################

sub _setPartialOrdering {
  my ($self) = @_;
  ###
  ### The first step is to build a list of tables to limit the query
  ### for relationships to only these tables.  This will greatly reduce
  ### the number of edges that must be iterated over in the algorithm
  ### below.
  ###
  my %table_index;
  my @table_list;
  foreach my $loader ( @{ $self->loaders } ) {
    my $tabname = $loader->table;
    $table_index{$tabname} = 0;
    push @table_list, "'$tabname'";
  }
  ###
  ### The SQL query to use to fetch the edges of the graph.  Each edge is
  ### directed in that the edge goes from a table to a referenced table.
  ###
  $self->msg( new util::Msg ) if ( !defined( $self->msg ) );
  $self->db( new util::Db( $self->dbconfig_file, $self->msg ) );
  my $owner = $self->db->getSchemaOwner;
  $self->msg->dieOnError(
    "Schema Owner is not defined\n" . "  db_config = " . $self->dbconfig_file,
    !defined($owner) );
  my $queries    = new util::DbQuery( $self->db );
  my $query_name = 'ordering';
  $queries->doQuery(
    $query_name,
    "
select c1.table_name,
       c2.table_name
from   all_constraints c1,
       all_constraints c2
where  c1.constraint_type = 'R'
and    c2.constraint_type = 'P'
and    c1.owner           = '$owner'
and    c2.owner           = c1.owner
and    c1.table_name     in (" . join( ',', @table_list ) . ")
and    c2.constraint_name = c1.r_constraint_name
and    c2.table_name     in (" . join( ',', @table_list ) . ")
",
    'Partial Order Query'
  );
  $self->msg->dieOnError(
    "Ordering query unsuccessfull\n"
      . "  db_config = "
      . $self->dbconfig_file . "\n"
      . "  tables    = "
      . join( util::Constants::COMMA_SEPARATOR, @table_list ),
    $queries->queryStatus($query_name)
  );
  my @edges = ();
  while ( my $ref = $queries->fetchRowRef($query_name) ) {
    my @edge = @{$ref};
    next if ( $edge[0] eq $edge[1] );
    push( @edges, [@edge] );
  }
  $queries->finishQuery($query_name);
  $self->db->closeSession;
  ###
  ### The algorithm here simply iterates over the edges where each edge
  ### connects a source vertex s to a referenced vertex r.  The current
  ### poset number of s is set to the poset number of r plus 1, unless
  ### this number is less than the current poset number of s.  The algorithm
  ### is complete as long as it iterates through the edges d times where
  ### d is the longest directed path, or diameter, of the graph.  Since d
  ### is not known here, we can place an upper limit on d of |E| where in
  ### the worst case the diameter of the graph is equal to |E| (all vertices
  ### are on a single path).  To make the algorithm efficient, though, we
  ### can quit iterating through the edges as soon as one iteration produces
  ### no changes to the poset numbers.  This occurs when the actual diameter
  ### of the graph is less than the current iteration number.
  ###
  my $edge_count  = $#edges + 1;
  my $change_flag = util::Constants::FALSE;
  ###
  ### One more time on the outer loop
  ### so that the degenerate case (one-edge)
  ### can be handled correctly.
  ###
  for ( my $i = 0 ; $i < ( $edge_count + 1 ) ; $i++ ) {
    $change_flag = util::Constants::FALSE;
    for ( my $j = 0 ; $j < $edge_count ; $j++ ) {
      my $new_poset = $table_index{ $edges[$j][1] } + 1;
      if ( $new_poset > $table_index{ $edges[$j][0] } ) {
        $change_flag = util::Constants::TRUE;
        $table_index{ $edges[$j][0] } = $new_poset;
      }
    }
    last if ( !$change_flag );
  }
  ###
  ### A cycle exists in the graph. This
  ### is unlikely for relational tables.
  ###
  $self->msg->unsetHardDie;
  $self->msg->dieOnError( "A cycle was found in the database constraints",
    $change_flag );
  $self->msg->setHardDie;
  ###
  ### Finally, transfer the poset numbers to the loader_poset array
  ###
  for ( my $lcv = 0 ; $lcv <= $#{ $self->loaders } ; $lcv++ ) {
    $self->loader_poset->[$lcv] = $table_index{ $self->loaders->[$lcv]->table };
  }
  ###
  ### That's it.  The tables with poset number 0 should
  ### be loaded first, followed by poset number 1, ..., n.
  ###
}

################################################################################

1;

__END__

=head1 NAME

LoadMgr - Places SqlLoader objects into (partially) ordered set(s).

=head1 SYNOPSIS

   use db::Schema::LoadMgr;

   $os = new db::Schema::LoadMgr;
   $sl = new db::SqLLoader;
   $os->addLoader($sl);

   $sl = $os->newLoader;

   $os->order(db::Schema::LoadMgr::EXACT);
   $os->order(db::Schema::LoadMgr::PARTIAL);

   $os->dbconfig_file(".dbconfig.prd_hum");

   my @status = $os->load;

   my @status = $os->purge;

=head1 DESCRIPTION

The L<db::Schema::LoadMgr> module is used to order a set of
loader objects for the purpose of execution (either load or purge).
With foreign key constraints, it is important to load parent tables
before loading child tables since the key back to the parent must be
valid at that time or conversely purging parent tables before child
tables.

This module can be used to create an object which manages the order
and performs the load for each loader.  The order can be EXACT,
meaning that the order in which the application program placed the
loaders into this collection is the same order of execution.  Or the
order can be PARTIAL, which consists of partially ordered sets based
on table relationship information for the tables being loaded.  The
latter ordering guarantees that no load errors will occur as a result
of loading tables out of order.

=head2 METHODS

After instantiating this class, any of the following methods may be
used on the object.

=over

=item $os->addLoader( $sl )

Adds a reference to the L<db::SqlLoader> object to the collection of
loaders.  The B<OrderedSet> object will retain the order in which the
loaders are added so that EXACT ordering can be used.

=item $os->dbconfig_file( $file )

Provides the path to a database configuration file.  See
L<util::DbConfig> for more details about the contents of the file.
When a connection to the database is needed, this file is used to
specify the account and database to use.  The file also contains the
value for the B<Alternatename> tag which is used for the owner of the
foreign constraints used in PARTIAL ordering.

=item $os->load

Executes the load method for each of the loaders in the collection in
the order specified by this object (see B<order>).  If all loaders
succeed, a return value of zero indicates global success.  If any
loader fails, then its return code is immediately returned.  To
determine which loader failed, examine the status code of each loader
to find the non-zero status (see L<db::SqlLoader> for appropriate
methods).  The SqlLoaders that did not execute will have a status code
of B<undef> while the successful ones will have status codes of zero.

=item $os->newLoader

A convenience method which performs the new operation on the
L<db::SqlLoader> class and adds the loader reference to the
collection like B<addLoader>.

=item $os->order( $type )

This method allows the user to decide which ordering to use.  The
B<db::Schema::LoadMgr::EXACT> type will cause the
B<OrderedSet> to execute the loaders in the same order that they were
added to the collection.

Using B<db::Schema::LoadMgr::PARTIAL>, which is the default,
will apply a graph algorithm to determine the partially ordered sets
of loaders based on relationships found in the database.  This is the
simplest of the two orderings since it automatically guarantees proper
ordering for loading into a given database.

=item $os->force_purge( $action )

This method allows the user to force the purge operation regardless of
whether there is an existing load or purge log for the tables to be
purged.  If the action is defined, then the purge will be forced,
otherwise the purge will depend on the corresponding pre-existing
load- or purge- logs.

=item $os->purge

Executes the purge method for each of the loaders in the collection in
the reverse of the order specified by this object (see B<order>).  If
all loaders succeed, a return value of zero indicates global success.
If any loader fails, then its return code is immediately returned.  To
determine which loader failed, examine the status code of each loader
to find the non-zero status (see <db::SqlLoader> for appropriate
methods).  The SqlLoaders that did not execute will have a status code
of B<undef> while the successful ones will have status codes of zero.

=back

=head1 SEE ALSO

L<db::SqlLoader>
L<db::SqlPurger>

=cut
