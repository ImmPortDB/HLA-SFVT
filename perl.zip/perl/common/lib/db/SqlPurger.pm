package db::SqlPurger;
################################################################################
#
#				Required Modules
#
################################################################################

use strict;

use Class::Struct;
use Cwd 'chdir', 'cwd';
use File::Basename;
use FileHandle;

use util::Constants;
use util::Db;
use util::DbQuery;
use util::FileTime;
use util::Msg;

################################################################################
#
#				Initializations
#
################################################################################
###
###
### Another useful structure contains the state information of the purge.
### After completion of the purge, this structure is populated with the
### state of the purge.
###
struct(
  'PurgeStatus' => [
    recs_skipped    => '$',
    recs_purged     => '$',
    recs_not_purged => '$',
    start_time      => '$',
    end_time        => '$',
    elapsed_time    => '$'
      ###
      ### '$'
      ### The comment above fixes a syntax highlighting bug in XEmacs.
      ###
  ]
);

struct(
  'db::SqlPurger' => {    ###
    ### Setters and accessors
    ###
    table            => '$',
    fields           => '@',
    batch_size       => '$',
    dbconfig_file    => '$',
    data_file        => '$',
    log_file         => '$',
    field_separator  => '$',
    record_separator => '$',
    skip_records     => '$',
    ###
    ### Accessors only:
    ### These will be evaluated by purge and parse_log
    ###
    unique_key      => '@',
    unique_key_name => '$',
    errors          => '$',
    status_code     => '$',
    record_failed   => '$',
    ###
    ### Private Data Members
    ###
    schema_owner    => '$',
    all_fields      => '%',
    constant_fields => '%',
    variable_fields => '@',
    db              => 'util::Db',
    df_handle       => 'FileHandle',
    data_opened     => '$',
    pl_handle       => 'FileHandle',
    log_opened      => '$',
    msg             => 'util::Msg',
    purge_state     => 'PurgeStatus'
      ###
      ### '$'
      ### The comment above fixes a syntax highlighting bug in XEmacs.
      ###
  }
);

################################################################################
#
#				   Constants
#
################################################################################

my $MINUTE = 60;                   ### Seconds
my $HOUR   = $MINUTE * $MINUTE;    ### Seconds

my $DEFAULT_BATCH_SIZE       = 100;
my $DEFAULT_RECORD_SEPARATOR = "\n";
my $DEFAULT_SKIP_RECORDS     = 0;

###
### Log File Headers
###
my $HEADER = "Purge Results\n\n";

my $TABLE            = 'Table Name:        ';
my $DATA             = 'Data File:         ';
my $RECORD_SEPARATOR = 'Record Separator:  ';
my $FIELD_SEPARATOR  = 'Field Separator:   ';
my $DELETE_KEY_NAME  = 'Delete Key Name:   ';
my $DELETE_KEY       = 'Delete Key:        ';
my $BATCH_SIZE       = 'Batch Size:        ';
my $SKIP_RECORDS     = 'Skip Records:      ';
my $FIELDS           = 'Fields:';
my $END_FIELDS       = 'End Fields:';

my $MESSAGES = "\nDeletion Messages\n\n";

my $ROWS_DELETED = " rows deleted.\n";

my $ERROR_MESSAGES     = 'Error Messages:';
my $END_ERROR_MESSAGES = 'End Error Messages:';
my $FAILURE_CODE       = 'Failure Code:  ';

my $DELETE_CMD     = 'Delete Command:';
my $END_DELETE_CMD = 'End Delete Command:';

my $KEY_ARRAY     = 'Key Array = (';
my $END_KEY_ARRAY = ")\n";

my $RECORD_HEADER  = 'Record ';
my $RECORD_TRAILER = ' failed to delete.';

my $COMMIT_HEADER  = 'Next ';
my $COMMIT_TRAILER = ' rows failed to commit.';

my $DELETION_STATS = 'Deletion Statistics';
my $SKIPPED        = ' Rows skipped.';
my $DELETED        = ' Rows successfully deleted.';
my $NOT_DELETED    = ' Rows not deleted.';

my $RUN_BEGIN    = 'Run began on ';
my $RUN_ENDED    = 'Run ended on ';
my $ELAPSED_TIME = 'Elapsed time was ';
###
### Table Queries
###
sub PRIMARY_KEY_NAME_QUERY { return 'primary_key_name'; }
sub PRIMARY_KEY_QUERY      { return 'primary_key'; }
sub UNIQUE_KEY_NAME_QUERY  { return 'unique_key_name'; }
sub UNIQUE_KEY_QUERY       { return 'unique_key'; }

my $QUERIES = {
  &PRIMARY_KEY_NAME_QUERY => {
    msg => 'select primary key name',
    cmd => "
select constraint_name
from   all_constraints
where  table_name      = ?
and    owner           = ?
and    constraint_type = 'P'
",
  },

  &PRIMARY_KEY_QUERY => {
    msg => 'select primary key columns',
    cmd => "
select acc.column_name
from   all_constraints  ac,
       all_cons_columns acc
where  ac.table_name      = acc.table_name
and    ac.table_name      = ?
and    ac.constraint_name = acc.constraint_name
and    ac.constraint_name = ?
and    ac.owner           = acc.owner
and    ac.owner           = ?
",
  },

  &UNIQUE_KEY_NAME_QUERY => {
    msg => 'select unique key name',
    cmd => "
select index_name
from   all_indexes
where  table_name  = ?
and    table_owner = ?
and    uniqueness  = 'UNIQUE'
and    rownum      = 1
",
  },

  &UNIQUE_KEY_NAME_QUERY => {
    msg => 'select unique key columns',
    cmd => "
select column_name
from   all_ind_columns
where  table_name  = ?
and    table_owner = ?
and    index_name  = ?
",
  },

};

################################################################################
#
#				 Class Methods
#
################################################################################
###
### Status Codes
###
sub SUCCESSFUL       { return 0; }
sub DELETION_FAILURE { return 100; }
sub COMMIT_FAILURE   { return 101; }

################################################################################
#
#				    Methods
#
################################################################################

sub purge {
  my ( $self, $dbconfig_file ) = @_;
  $self->dbconfig_file($dbconfig_file) if ( defined($dbconfig_file) );
  $self->msg( new util::Msg );
  ###
  ### Check for Attributes
  ###
  $self->msg->dieOnError(
    "No database configuration file specified as argument",
    !defined( $self->dbconfig_file ) );
  if ( !defined( $self->batch_size ) ) {
    $self->batch_size($DEFAULT_BATCH_SIZE);
  }
  $self->msg->dieOnError( "No table name provided", !defined( $self->table ) );
  $self->table( uc( $self->table ) );
  $self->msg->dieOnError( "Fields not specified", @{ $self->fields } == 0 );
  $self->all_fields(      {} );
  $self->constant_fields( {} );
  $self->variable_fields( [] );
  my $variable_field_index = 0;

  foreach my $index ( 0 .. $#{ $self->fields } ) {
    ###
    ### Split the field specification into parts so that
    ### column name can be extracted
    ###
    my $field = $self->fields($index);
    $field =~ s/^\s+//;    ### remove whitespace from the front
    $self->fields( $index, $field );
    my @parts = split( /\s+/, $field );
    my $field_name = shift(@parts);
    $self->all_fields( uc($field_name), util::Constants::EMPTY_STR );
    if ( uc( $parts[0] ) eq 'CONSTANT' ) {
      $field =~ s/^$field_name\s+CONSTANT\s+//i;
      if    ( $field =~ /^'.*'$/ ) { $field =~ s/^'(.*)'$/$1/; }
      elsif ( $field =~ /^".*"$/ ) { $field =~ s/^"(.*)"$/$1/; }
      $self->constant_fields( uc($field_name), $field );
    }
    else {
      $self->variable_fields( $variable_field_index, uc($field_name) );
      $variable_field_index++;
    }
  }
  $self->msg->dieOnError( "Data File not specified",
    !defined( $self->data_file ) );
  $self->msg->dieOnError( "Data File does not exist", !-e $self->data_file );
  if ( !defined( $self->log_file ) ) {
    my $log_file;
    my ( $name, $path, $suffix ) =
      fileparse( $self->data_file, ".pge", ".dat", ".bcp" );
    $path = "" if ( $path eq "./" );
    if ( $suffix ne ".pge" ) {
      $log_file = "$path$name.pge";
    }
    $self->log_file($log_file);
  }
  $self->msg->dieOnError( "field_separator not specified",
    !defined( $self->field_separator ) );
  if ( !defined( $self->record_separator ) ) {
    $self->record_separator($DEFAULT_RECORD_SEPARATOR);
  }
  if ( !defined( $self->skip_records ) ) {
    $self->skip_records($DEFAULT_SKIP_RECORDS);
  }
  $self->db( new util::Db( $self->dbconfig_file, $self->msg ) );
  $self->db->startTransaction;
  $self->schema_owner( $self->db->getSchemaOwner );
  $self->msg->dieOnError(
    "Schema Owner is not defined\n" . "  db_config = " . $self->dbconfig_file,
    !defined( $self->schema_owner ) );
  ###
  ### Get Unique Key Name and Key (if necessary)
  ###
  if ( !defined( $self->unique_key_name ) || @{ $self->unique_key } == 0 ) {
    $self->db->setDieOnError;
    $self->_getUniqueKey;
    $self->db->resetDieOnError;
  }
  $self->_validateUniqueKey;
  ###
  ### Create Query For Deleting Rows
  ###
  my $full_table_name = $self->schema_owner . '.' . $self->table;
  my $full_index_name = $self->schema_owner . '.' . $self->unique_key_name;
  my $delete_cmd      =
      '  delete /*+ INDEX(A '
    . $full_index_name . ') */' . "\n"
    . "  from   $full_table_name A\n"
    . "  where  ";
  my $first_field = util::Constants::TRUE;
  foreach my $field ( @{ $self->unique_key } ) {
    if ($first_field) { $first_field = util::Constants::FALSE; }
    else { $delete_cmd .= "\n  and    "; }
    $delete_cmd .= $field . ' = ?';
  }
  my $delete_sth = $self->db->prepareQuery( $delete_cmd, 'delete' );
  ###
  ### Open data file and log file
  ###
  $self->_openFiles;
  my $previous_input_record_separator = $/;
  $/ = $self->record_separator;
  my $plh = $self->pl_handle;
  $plh->print($HEADER);
  $plh->print( $TABLE . $self->table . "\n" );
  $plh->print( $DATA . $self->data_file . "\n" );

  if ( $self->record_separator ne $DEFAULT_RECORD_SEPARATOR ) {
    $plh->print( $RECORD_SEPARATOR . "'" . $self->record_separator . "'\n" );
  }
  $plh->print( $FIELD_SEPARATOR . "'" . $self->field_separator . "'\n" );
  $plh->print( $BATCH_SIZE . $self->batch_size . "\n" );
  $plh->print( $SKIP_RECORDS . $self->skip_records . "\n" );
  $plh->print( $DELETE_KEY_NAME . $self->unique_key_name . "\n" );
  $plh->print( $DELETE_KEY
      . join( util::Constants::COMMA_SEPARATOR, @{ $self->unique_key } )
      . "\n" );
  $plh->print(
    $DELETE_CMD . "\n" . $delete_cmd . "\n" . $END_DELETE_CMD . "\n" );
  $plh->print( $FIELDS . "\n" );

  foreach my $index ( 0 .. $#{ $self->fields } ) {
    my $field      = $self->fields($index);
    my @parts      = split( /\s+/, $field );
    my $field_name = shift(@parts);
    $field =~ s/^$field_name\s+//;
    $plh->printf( '  %-32.32s %s', $field_name, $field );
    $plh->print("\n");
  }
  $plh->print( $END_FIELDS . "\n" );
  $plh->print($MESSAGES);
  ###
  ### Start Purging
  ###
  $self->errors(undef);
  $self->record_failed(undef);
  $self->status_code(SUCCESSFUL);
  my $row_number = 0;
  while ( !$self->df_handle->eof && ( $self->skip_records > $row_number ) ) {
    $row_number++;
    $self->df_handle->getline;
  }
  my $deleted_row_number = $row_number;
  my $check_point_number = $row_number;
  my $errors             = util::Constants::EMPTY_STR;
  my $start_time         = &get_unix_time( time() );
  $self->msg->unsetHardDie;
  while ( !$self->df_handle->eof ) {
    $row_number++;
    my @query_values = $self->_getFields;
    eval { $self->db->executeUpdate( $delete_sth, 'delete', @query_values ); };
    my $delete_status = $@;
    if ( defined($delete_status) && $delete_status ) {
      $self->status_code(DELETION_FAILURE);
      $errors .=
          $RECORD_HEADER
        . $row_number
        . $RECORD_TRAILER . "\n"
        . $KEY_ARRAY
        . join( util::Constants::COMMA_SEPARATOR, @query_values )
        . $END_KEY_ARRAY . "\n";
      last;
    }
    if ( ( $row_number - $self->skip_records ) % $self->batch_size == 0 ) {
      if ( $self->db->commitTransaction ) {
        $self->status_code(COMMIT_FAILURE);
        $errors .= $COMMIT_HEADER . $self->batch_size . $COMMIT_TRAILER . "\n";
        last;
      }
      else {
        $check_point_number += $self->batch_size;
        $plh->print( $self->batch_size . $ROWS_DELETED );
      }
    }
    $deleted_row_number++;
  }
  if ( !$self->status_code && $deleted_row_number > $check_point_number ) {
    my $deleted_rows = $deleted_row_number - $check_point_number;
    if ( $self->db->commitTransaction ) {
      $self->status_code(COMMIT_FAILURE);
      $errors .= $COMMIT_HEADER . $deleted_rows . $COMMIT_TRAILER . "\n";
    }
    else {
      $check_point_number += $deleted_rows;
      $plh->print( $deleted_rows . $ROWS_DELETED );
    }
  }
  if ( $self->db->sessionOpen ) {
    $delete_sth->finish;
    $self->db->closeSession;
  }
  if ( $self->status_code ) {
    $self->errors($errors);
    $plh->print(
      join( "\n",
        util::Constants::EMPTY_STR,         $ERROR_MESSAGES,
        util::Constants::EMPTY_STR,         $errors,
        $END_ERROR_MESSAGES,                util::Constants::EMPTY_STR,
        $FAILURE_CODE . $self->status_code, util::Constants::EMPTY_STR )
    );
  }
  my $rows_deleted = 0;
  if ( $check_point_number > $self->skip_records ) {
    $rows_deleted = $check_point_number - $self->skip_records;
  }
  my $rows_skipped = $self->skip_records;
  if ( $row_number < $self->skip_records ) {
    $rows_skipped = $row_number;
  }
  my $rows_not_deleted = 0;
  if ( $row_number > $check_point_number ) {
    $rows_not_deleted = $row_number - $check_point_number;
    $self->record_failed( $check_point_number + 1 );
  }
  $plh->print( "\n" . $DELETION_STATS . "\n\n" );
  $plh->print( '  ' . $rows_skipped . $SKIPPED . "\n" );
  $plh->print( '  ' . $rows_deleted . $DELETED . "\n" );
  $plh->print( '  ' . $rows_not_deleted . $NOT_DELETED . "\n" );
  $plh->print("\n");
  my $end_time = &get_unix_time( time() );
  $plh->print( $RUN_BEGIN . &get_oracle_str($start_time) . "\n" );
  $plh->print( $RUN_ENDED . &get_oracle_str($end_time) . "\n\n" );
  my $elapsed_seconds =
    int( &get_unix_str($end_time) - &get_unix_str($start_time) );
  my $minutes = int( $elapsed_seconds % $HOUR );
  my $hours   = int( ( $elapsed_seconds - $minutes ) / $HOUR );
  my $seconds = int( $minutes % $MINUTE );
  $minutes = int( ( $minutes - $seconds ) / $MINUTE );
  if ( $hours < 10 )   { $hours   = '0' . $hours; }
  if ( $minutes < 10 ) { $minutes = '0' . $minutes; }
  if ( $seconds < 10 ) { $seconds = '0' . $seconds; }
  $plh->print( $ELAPSED_TIME
      . join( util::Constants::COLON, $hours, $minutes, $seconds )
      . "\n" );
  $self->_closeFiles;
  $/ = $previous_input_record_separator;
  return $self->status_code;
}

sub parse_log {
  my ( $self, $log_file ) = @_;
  $self->msg( new util::Msg );
  $self->log_file($log_file) if ( defined($log_file) );
  if ( !defined( $self->log_file ) ) {
    $self->msg->dieOnError( "Data File not specified",
      !defined( $self->data_file ) );
    my $log_file;
    my ( $name, $path, $suffix ) =
      fileparse( $self->data_file, ".pge", ".dat", ".bcp" );
    $path = "" if ( $path eq "./" );
    if ( $suffix ne ".pge" ) {
      $log_file = "$path$name.pge";
    }
    $self->log_file($log_file);
  }
  $self->msg->dieOnError( "Log File " . $self->log_file . "does not exist",
    !-e $self->log_file );
  $self->msg->dieOnError( "Could not open log file " . $self->log_file . ": $!",
    !open( LOG, $self->log_file ) );
  $self->table(undef);
  $self->data_file(undef);
  $self->record_separator(undef);
  $self->field_separator(undef);
  $self->skip_records(undef);
  $self->unique_key( [] );
  $self->batch_size(undef);
  $self->fields( [] );
  $self->errors(undef);
  $self->purge_state( new PurgeStatus );
  $self->record_failed(undef);
  $self->status_code(undef);
  my $log_state       = new PurgeStatus;
  my $parse_fields    = util::Constants::FALSE;
  my $comma_separator = util::Constants::COMMA_SEPARATOR;

  while (<LOG>) {
    chomp;
    if (/^$TABLE(.*)$/)              { $self->table($1);            next; }
    if (/^$DATA(.*)$/)               { $self->data_file($1);        next; }
    if (/^$RECORD_SEPARATOR'(.*)'$/) { $self->record_separator($1); next; }
    if (/^$FIELD_SEPARATOR'(.*)'$/)  { $self->field_separator($1);  next; }
    if (/^$BATCH_SIZE(.*)$/)         { $self->batch_size($1);       next; }
    if (/^$SKIP_RECORDS(.*)$/)       { $self->skip_records($1);     next; }
    if (/^$DELETE_KEY_NAME(.*)$/)    { $self->unique_key_name($1);  next; }
    if (/^$DELETE_KEY(.*)$/)         {
      my $key_str = $1;
      my @keys = split( /$comma_separator/, $key_str );
      foreach my $index ( 0 .. $#keys ) {
        $self->unique_key( $index, $keys[$index] );
      }
      next;
    }
    if (/^$DELETE_CMD$/) {
      while (<LOG>) {
        chomp;
        last if (/^$END_DELETE_CMD$/);
      }
      next;
    }
    if (/^$FIELDS$/) {
      my $index = 0;
      while (<LOG>) {
        chomp;
        last if (/^$END_FIELDS$/);
        $self->fields( $index, $_ );
        $index++;
      }
      next;
    }
    if (/^$ERROR_MESSAGES$/) {
      my $err_str = util::Constants::EMPTY_STR;
      while (<LOG>) {
        chomp;
        last if (/^$END_ERROR_MESSAGES$/);
        $err_str .= $_ . "\n";
      }
      if ($err_str) { $self->errors($err_str); }
      next;
    }
    if (/^$FAILURE_CODE(.*)$/)    { $self->status_code($1);          next; }
    if (/^\s+(\d+)$SKIPPED$/)     { $log_state->recs_skipped($1);    next; }
    if (/^\s+(\d+)$DELETED$/)     { $log_state->recs_purged($1);     next; }
    if (/^\s+(\d+)$NOT_DELETED$/) { $log_state->recs_not_purged($1); next; }
    if (/^$RUN_BEGIN(.*)$/)       { $log_state->start_time($1);      next; }
    if (/^$RUN_ENDED(.*)$/)       { $log_state->end_time($1);        next; }
    if (/^$ELAPSED_TIME(.*)$/)    { $log_state->elapsed_time($1);    next; }
  }
  if ( !defined( $self->status_code ) ) { $self->status_code(SUCCESSFUL); }
  if ( defined( $log_state->recs_skipped )
    && defined( $log_state->recs_purged )
    && defined( $log_state->recs_not_purged ) )
  {
    if ( $log_state->recs_not_purged > 0 ) {
      $self->record_failed(
        $log_state->recs_skipped + $log_state->recs_purged + 1 );
    }
  }
  close(LOG);
  $self->purge_state($log_state);
}

################################################################################
#
#				Private Methods
#
################################################################################
###
### Method to open files for purging
###
sub _openFiles {
  my ($self) = @_;
  if ( !defined( $self->data_opened ) || !$self->data_opened ) {
    my $df_name = $self->data_file;
    $self->df_handle( new FileHandle ) if ( !defined( $self->df_handle ) );
    $self->msg->dieOnError(
      "Could not open data file " . $self->data_file . ": $!",
      !$self->df_handle->open("<$df_name") );
  }
  if ( !defined( $self->log_opened ) || !$self->log_opened ) {
    my $pf_name = $self->log_file;
    $self->pl_handle( new FileHandle ) if ( !defined( $self->pl_handle ) );
    $self->msg->dieOnError(
      "Could not open data file " . $self->log_file . ": $!",
      !$self->pl_handle->open(">$pf_name") );
    $self->pl_handle->autoflush(util::Constants::TRUE);
  }
  $self->log_opened(util::Constants::TRUE);
  $self->data_opened(util::Constants::TRUE);
}
###
### The SQL queries to use to fetch the
### unique key for the table
###
sub _getUniqueKey {
  my ($self) = @_;
  my $queries = new util::DbQuery( $self->db );
  while ( my ( $query, $query_struct ) = each %{$QUERIES} ) {
    $queries->createQuery( $query, $query_struct->{cmd}, $query_struct->{msg} );
    $queries->prepareQuery($query);
  }
  $queries->executeQuery( PRIMARY_KEY_NAME_QUERY, $self->table,
    $self->schema_owner );
  while ( my $row_ref = $queries->fetchRowRef(PRIMARY_KEY_NAME_QUERY) ) {
    $self->unique_key_name( uc( $$row_ref[0] ) );
  }
  if ( defined( $self->unique_key_name ) ) {
    $queries->executeQuery(
      PRIMARY_KEY_QUERY,      $self->table,
      $self->unique_key_name, $self->schema_owner
    );
    my $index = 0;
    while ( my $row_ref = $queries->fetchRowRef(PRIMARY_KEY_QUERY) ) {
      $self->unique_key( $index, uc( $$row_ref[0] ) );
      $index++;
    }
  }
  else {
    ###
    ### Must Use Some Unique Key, ANYONE WILL DO!
    ###
    $queries->executeQuery( UNIQUE_KEY_NAME_QUERY, $self->table,
      $self->schema_owner );
    while ( my $row_ref = $queries->fetchRowRef(UNIQUE_KEY_NAME_QUERY) ) {
      $self->unique_key_name( uc( $$row_ref[0] ) );
    }
    $self->msg->dieOnError(
      "Cannot Acquire Unique Key for Table\n"
        . "  table = "
        . $self->table . "\n"
        . "  owner = "
        . $self->schema_owner,
      !defined( $self->unique_key_name )
    );
    $queries->executeQuery(
      UNIQUE_KEY_NAME_QUERY, $self->table,
      $self->schema_owner,   $self->unique_key_name
    );
    my $index = 0;
    while ( my $row_ref = $queries->fetchRowRef(UNIQUE_KEY_QUERY) ) {
      $self->unique_key( $index, uc( $$row_ref[0] ) );
      $index++;
    }
  }
  foreach my $query ( keys %{$QUERIES} ) { $queries->finishQuery($query); }
}

sub _validateUniqueKey {
  my ($self) = @_;
  foreach my $field ( @{ $self->unique_key } ) {
    $self->msg->dieOnError(
      "Unique Key Field $field not in Fields",
      !defined( $self->all_fields($field) )
    );
  }
}

sub _getFields {
  my ($self)          = @_;
  my %fields          = ();
  my @query_values    = ();
  my $field_separator = $self->field_separator;
  my $input_line      = $self->df_handle->getline;
  chomp($input_line);
  my @field_values = split( /$field_separator/, $input_line );
  foreach my $index ( 0 .. $#{ $self->variable_fields } ) {
    $fields{ $self->variable_fields->[$index] } = $field_values[$index];
  }
  foreach my $field ( @{ $self->unique_key } ) {
    if ( defined( $fields{$field} ) ) {
      push( @query_values, $fields{$field} );
    }
    else {
      push( @query_values, $self->constant_fields($field) );
    }
  }
  return @query_values;
}

sub _closeFiles {
  my ($self) = @_;

  if ( defined( $self->data_opened ) && $self->data_opened ) {
    $self->df_handle->close() if ( defined( $self->df_handle ) );
  }
  if ( defined( $self->log_opened ) && $self->log_opened ) {
    $self->pl_handle->close() if ( defined( $self->pl_handle ) );
  }
  $self->data_opened(util::Constants::FALSE);
  $self->log_opened(util::Constants::FALSE);
}

################################################################################

1;

__END__

=head1 NAME

SQLPurger - Provides tool corresponding to sqlldr for deleting (purging) loads

=head1 SYNOPSIS

   use db::SqlPurger;

   $sp = new db::SqlPurger;

   $sp->table($table);
   foreach my $index (0..$#{@fields}) {
     $sp->fields($index, $fields[$index]);
   }
   $sp->dbconfig_file($dbconfig_file);
   $sp->data_file($data_file);
   $sp->field_separator($field_separator);
   if (defined($record_separator)) {
     $sp->record_separator($record_separator);
   }
   ###
   ### Optionally set skip record count
   ###
   $sp->skip_records($skip_records);

   $sp->purge;

=head1 DESCRIPTION

The L<db::SqlPurger> module can be used to delete rows of data from
a table.  This module handles all interactions for setting and using
the purge operation. and reporting results.

=head2 Data Members

Each data member has its own accessor methods for setting and
retrieving the current values.

=over

=item my $curr_table_name = $sp->table

=item $sp->table( $name )

Accesses the name of the table which will be deleted by this object.
This data member must be set in order to delete data from the table.

=item my @curr_fields = @{$sp->fields}

=item my $curr_field = $sp->fields( $index )

=item push( @{$sp->fields}, $value )

=item $sp->fields( $index, $value )

The fields defined for deleting is implemented in an array structure
of strings.  Each string specifies a field in the file being deleted.
They must be in the correct order, namely the order in which the
fields appear in each data row.

The string which specifies the field in the file can consist of any
valid syntax permitted in a field_list sentential form (See the BNF in
Section 5, SQL*Loader Control File Reference, Oracle 8i Utilities
Manual).  At a minimum, this must consist of a column name which
exists in the table being loaded.  Specifying only the column name
will default to the CHAR datatype.  In general, this can easily be
converted to all other Oracle datatypes, but it does have a size limit
of less than 256 characters.

=item my $curr_batch_size = $sp->batch_size

=item $sp->batch_size( $batch_size )

Accesses the batch size for delete commits.  If this data member is
not set, it defaults to 100.

=item my $curr_dbconfig_file = $sp->dbconfig_file

=item $sp->dbconfig_file( $dbconfig_file )

A database configuration file is used to provide information about
which Oracle instance to connect to, and which user account to use for
establishing the connections.  The account used here must have
privileges to read the system tables and write into and delete from
certain tables in the IDW schema.  The file consists of resource-value
pairs and must contain the following:

    Server      	OracleDB
    Database		PRI_IDW
    Username		*********
    Password		*******
    Alternatename	EDI

The server name is not used by this tool, but is needed for parsing
compatibility with older Sybase configurations.  The database name is
the actual Oracle instance to connect to.  Also, the file contains an
optional tag (required in this module), B<Alternatename>, that is used
for the owner in the system tables to acquire a unique key.  This file
is parsed using the function B<read_db_config_file> from the module
L<util::DbConfig>.

This data member must be set or passed as a parameter for the purge
operation to execute.

=item my $curr_control = $sp->data_file

=item $sp->data_file( "sample.dat" )

This accessor method controls the name of the file used to hold the
SQL*Loader data file.

=item my $curr_field_separator = $sp->field_separator

=item $sl->field_separator( ',' )

The field separator can be any string of characters.  All of the
fields in each data row are required to be separated by the field
separator.  This field separator is automatically used to format data
if you provide the L<db::SqlPurger> object with a list of individual
fields for each data row.

=item my $curr_rec_separator = $sp->record_separator

=item $sl->record_separator( "string" )

Sets or retrieves the record separator to use for each row of data in
the datafile.  If your data is likely to contain newlines embedded in
the field(s), then choosing a more complex record separator will help
delineate the rows in the file.  The default is just the newline
character.

=item my $curr_skip_records = $sp->skip_records

=item $sl->skip_records( 25 )

Sets or retrieves the the number of records to skip in the data file
before starting to purge.  The default is 0.

=item my $curr_purge_log = $sp->log_file

=item $sp->log_file( "sample.pge" )

Accessor to control the name of the file that contains the logging
information produced by B<purge> operation.  By default, this file is
named the same as the datafile, but with a B<pge> suffix.  Using the
default will enable L<db::SqlPurger> objects to automatically detect
and recover from previous deletes.

=item my $err_str = $sp->errors

This accessor can be used to retrieve a string value which contains
all the errors which occurred as a result of a call to the B<purge()>
or B<parse_log()> operations (undefined if no errors occurred).  If no
such call has been made, the value is undefined.

=item my $status = $sp->status_code

This accessor will return the same value last returned from a call to
the B<purge()> or B<parse_log()> methods.  If no such call has been
made, the value is undefined.  Currently, error statuses include:

    db::SqlPurger::DELETION_FAILURE
    db::SqlPurger::COMMIT_FAILURE


=item my $curr_record_failed = $sp->record_failed

This accessor will return the record number of that caused the delete
failure as a result of a call to the B<purge()> or B<parse_log()>
operations (undefined no delete failure occurred).  If no such call
has been made, the value is undefined.

=item my @curr_unique_key = @{$sp->unique_key}

=item my $@curr_unique_key = $sp->unique_key( $index )

This accessor will return a reference to the unique key array used for
deleting rows as a result of a call to the B<purge()> or
B<parse_log()> operations.  If no such call has been made, the value
is undefined.

=item my $curr_unique_key_name = $sp->unique_key_name

This accessor will return the unique key name that was used for the
purging rows as a result of a call to the B<purge()> or B<parse_log()>
operations.  If no such call has been made, the value is undefined.

=back

=head2 Operations

Each member function below is used to perform more complex operations
as compared to accessor methods documented above.

=over

=item my $status = $sp->purge

=item my $status = $sp->purge( "ids.dbconfig" )

Once the necessary data members have been specified (see
L<"SYNOPSIS">), this method is used to perform the delete operation on
the given table using the data file to determine the rows to delete.
This method will set the data member: errors, record_failed, and
status_code.

=item my $status = $sp->parse_log

=item my $status = $sp->parse_log( "sample.pge" )

This method allows a (previously) generated log file to be parsed and
evaluate the data members: table, data_file, field_separator,
record_separator, unique_key, batch_size, skip_records, fields,
errors, record_failed, and status_code.  If a purge log parameter is
not provided, then purge_log or data_file must have been set.

=back

=cut
