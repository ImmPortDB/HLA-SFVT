#!/bin/bash
source /home/tsmith/opt/hlavt/perl/common/bin/Env/config.bash /home/tsmith/opt/hlavt/perl/hla_feature_variation /home/tsmith/opt/hlavt/perl/common
/home/tsmith/opt/hlavt/perl/hla_feature_variation/bin/runQualityControlPipeline.pl -P /home/tsmith/bisc/Jira.tickets/id-2065-sfvt/hlavf/.properties
