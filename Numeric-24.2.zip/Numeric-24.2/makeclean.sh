#!/bin/sh
/bin/rm -fr build dist rpm_install.sh *.pik rpm_build.sh
/bin/rm -fr Packages/MA/dist Packages/MA/build
/bin/rm -fr Packages/Properties/dist Packages/Properties/build
/bin/rm -fr Packages/RNG/dist Packages/RNG/build
/bin/rm -fr Packages/kinds/dist Packages/kinds/build
/bin/rm -fr Packages/FFT/dist Packages/FFT/build
