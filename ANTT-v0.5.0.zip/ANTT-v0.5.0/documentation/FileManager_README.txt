ANTT File Manager v0.5.1

The Allele Name Translation Tool (ANTT) file manager application (ANTT_FileManager.exe) is intended to make it easy to create and modify the configuration files that direct the actions of the ANTT using a graphical user interface (GUI). In addition, the ANTT File Manager makes it easy to generate translation files (.upd files) from a single translation source file. 

System Requirements
The file manager is a Microsoft .NET application. As such, it can run on Microsoft Windows XP, Vista and Windows 7 operating systems if the .NET framework (v3.5) has been installed, and can run on Apple OSX and Linux operating systems if the Mono Open-Source .NET framework (v2.4) has been installed.

Some Windows XP and Vista platforms may already have the .NET framework installed. To check and see if this is the case, double click on the ANTT_FileManager.exe file. If the application starts up, then no installation is necessary. If it does not start, you can use the setup.exe application to install the .NET framework on your Windows XP or Vista machine. Windows 7 comes with .Net installed. 

To install Mono on your Apple OSX or Linux computer, visit http://www.mono-project.com/. To run the file manager using Mono, type "mono ANTT_FileManager.exe" from the console/terminal/command line in the ANTT v0.4.3 beta directory.

When the file manager is running, the GUI presents a single window with multiple pull-down menus, control buttons and input boxes on the left half of the window. A "Help and Error Messages" box can be found on the right side of the window, above a box that lists the field-names and associated translation files for that configuration file. For help with a particular entry box, click on the name to the left or above that box, and a brief explanation will appear in the Help and Error Messages box.

Configuration Files
Configuration files are plain text-files, and can be created and modified in any text editor, but to minimize the introduction of errors to these files, it is recommended that the file manager be used. 

ANTT configuration files define all but three of the parameters used by the ANTT to translate allele names between nomenclatures. The parameters that are not defined in the configuration file the name and location of the configuration file itself, the name and location of the data-input file, and the name and location of the translated data file. 

The configuration file defines the field-names (column headers) that will be found in the input-data file and identifies which of these field-names contain allele data, the symbol or string used to represent missing data in the input-data file, the symbol or string us to separate alleles in ambiguous allele strings, the locus-specific translation table associated with a given allele-data-containing field-name, and the location of the directory that contains the translation tables. 

To modify an existing configuration file use the "Load Configuration File" button or the "Open Config File" option under the "File" pull-down menu. The config.ini file included with the ANTT is a basic configuration file that is will tell the ANTT how to translate the various sample data-files, and can be used as a template for new configuration files. 

If you are going to change the settings in the current configuration file, you should change the name of the file in the "Configuration File Name" field. If you are creating a new configuration file without editing an existing file, enter a name for the new file in this field. 

If your input-data file includes ambiguous strings of alleles, enter the character or string used to separate each allele in a string in the Ambiguous Allele Separator entry box. Note that this parameter is optional.  If it is omitted, the ANTT assumes that a slash "/" is used to separate ambiguous alleles. You can specify only one ambiguous allele separator per configuration file. 

If your input-data file includes a missing allele-data character, enter the character or string used to identify missing data in the Missing Data Symbol entry box. As with the Ambiguous Allele Separator, this parameter is also optional. The ANTT will assume that missing data are identified using a "****" string. You can specify only one missing data symbol per configuration file. 

If all of your configuration files and input-data files will be in the same directory as the directory that contains the translation files (i.e., the configuration files and input-data files will be one level "up" from the translation files), you can enter the name of the directory that contains the translation files in "Translation File Directory" entry box. For example, the config.ini file includes the name of the directory, "translation_files" without specifying the entire path.

However, if your configuration files and input-data files will be in different directories, then you must explicitly define the entire path to your translation files folder in the configuration file. You can do this by clicking the "Identify Path to Translation Files" button and navigating to the translation file folder. 

There are two ways to enter field names and the translation files associated with them. You can modify or delete any entry in the "File Names and Associated Translation Files" table and add new field names and translation files at the bottom of the table, or you can add each field name in the "Enter New Field Name" entry box, check the "This Field Contains Allele Data" checkbox if the field name contains allele data, and enter the name of the associated translation file in the "Enter Translation Filename" entry box. Once all of these data have been entered, click the "Add New Field Name and Translation File" button to add the data to the table. 

Once you have entered or modified all of the data for your configuration file, you can save the file by clicking the "Save Configuration File" button, or selecting the "Save Config File" option under the "File" pull-down menu. 

If you want to clear the data that has been entered, click the "Clear All Fields" button or select the "Clear All Data" option under the "Edit" pull-down menu.

Generating Translation Files
Translation files are tab-delimited text files that contain two columns. The left column contains allele names recorded using the nomenclature of the data in the input file. The right column contains the corresponding allele name recorded using the nomenclature to which allele names will be translated. Both columns must have headers.

The translation source file is a tab- or space-delimited text file that contains the allele-translation correspondences for all alleles and loci of interest in two columns (as above). The translation source file used to generate the translation files distributed with the ANTT can be found at http://hla.alleles.org/data/txt/Nomenclature_2009.txt. The first row of the translation source file is assumed to contain column headers. 

Use the "Generate Translation Files" option in the "File" menu to generate a new set of translation tables from a translation source file you have saved on your system. One translation file will be generated for each locus in the translation source file in the same directory as the translation source file. Translation files for HLA loci will be named "HLA-<locus name>.upd". If the "File Names and Associated Translation Files" table is empty, the names of the newly-generated translation files will appear in the table.

Other than the header-row, any rows in the translation source file containing the string "None" or that do not contain an asterisk (*) will not be included in the generated translation tables.

Repairing Input Data Files
If the ANTT reports a discrepancy in the number of columns in your input data file, you can try to repair the file using the "Repair Input Data File" option in the "File" pull-down menu.

This option removes any carriage retuns that are not followed by line feeds, and any line feeds that do not follow carriage returns, in your input data file.

If the file can be repaired, a new input data file named <input data filename>-repaired.txt is generated in the same directory as the problem input data files. Use this repaired file as an input file for the ANTT. A log of the repair attempt named <input data filename>_repair_log.txt, documenting the repair attempt, is also generated.


