Allele Name Translation Tool (ANTT) v0.5.0

The Allele Name Translation Tool (ANTT) is intended to translate HLA allele names between various and nomenclature rules. In particular, it has been designed to translate between alleles written under May 2002 to March 2010 nomenclature (e.g., A*01010101) and alleles written under the April 2010 nomenclature (e.g., A*01:01:01:01). 

To use the ANTT, you must have an input file, which contains columns of allele data, a configuration (*.ini) file, which tells the ANTT what to look for in the input file, and a set of translation files, which tell the ANTT how to translate each allele.

Required Files and File Definitions
The ANTT input files are tab-delimited text files that contain columns of data (data organized in rows are not supported). Each column of data must have a header (the field-name) identifying the contents of that column. These field-names must be included in the configuration file. Both allele-data and non-allele data can be included in the input file. Ambiguous allele strings (e.g., A*01010101/0102/0103) can be included in the input file, but the character that separates the alleles in a string must be defined in the configuration file. A missing data character (or string) can also be defined in the configuration file. Other than the characters that constitute missing data and allele names, and that separate alleles in strings, no other characters (e.g., single or double quotes) can be included with allele name data.  

The configuration file can be set up using the ANTT_FileManager. This program lets you import and edit settings from another configuration file, or enter all of the settings yourself. You must specify the full name of the new configuration file, the path to the translation files (by identifying one of the files in the correct folder), the possible fields in the input file (all fields do not need to be in one input file, but this allows you to use the same configuration file for multiple input files), and the translation file that corresponds to a particular locus. In addition, you can specify the character or characters used to separate ambiguous alleles in a string (e.g., A*01010101/0102/0103 represents three alleles separated by a slash [/] while A*01010101,0102,0103 represents the same three alleles separated by a comma [,]), if your input file contains ambiguous alleles, or the character or characters used to represent missing data, if your data includes a particular missing data symbol. The ANTT_FileManager will also generate new individual translation files from a translation source file (e.g., http://hla.alleles.org/data/txt/Nomenclature_2009.txt). For more information about the File Manager, see the ANTT_FilManager_README.txt file.

The ANTT translation files are tab-delimited text files that contain at least two columns. The left-most column contains the reference allele names, which should correspond to the alleles in the input file. The right column should contain the translated allele names, which will appear in the output file. Each column must have a header row containing column names. Locus prefixes (e.g., A*, Cw*, C*, DPB1*, etc.) should be included in the names of the alleles in both columns. 

Using the ANTT
The ANTT is a Microsoft .NET application. As such, it can run on Microsoft Windows XP, Vista and Windows 7 operating systems if the .NET framework (v3.5) has been installed, and can run on Apple OSX and Linux operating systems if the Mono Open-Source .NET framework (v2.4) has been installed.

Some Windows XP and Vista platforms may already have the .NET framework installed. To check and see if this is the case, double click on the ANTT-GUI.exe file. If the application starts up, then no installation is necessary. If it does not start, you can use the setup.exe application to install the .NET framework on your Windows XP or Vista machine. Windows 7 comes with .Net installed. 

To install Mono on your Apple OSX or Linux computer, visit http://www.go-mono.com/mono-downloads/download.html, and select the appropriate platform. To install the ANTT on Linux CentOS 5, read the Linux_CentOS_5-install.txt file distributed with the ANTT. To run the Configuration Editor using Mono, type "mono ANTT_GUI.exe" or "mono ANTT.exe" from the  console/terminal/command line in the ANTT directory. 

The ANTT can be run from the command line using the ANTT.exe application, or through a graphical user interface (GUI) using the ANTT_GUI.exe application.

The GUI application makes it easy to navigate through your file system to select configuration files and input-data files in different directories. However, if you do select configuration and input-data files that are in different directories, the entire path to the translation-tables must be included in the configuration file. 

The console application allows the ANTT to be incorporated into a larger data-manipulation pipeline or for datasets to be translated in batches by calling the ANTT from a script.

To use the ANTT's GUI, double-click the ANTT_GUI.exe file, and select "Translate Alleles" from the "Actions" pull-down menu. You will be prompted to identify the configuration file to use for the translation in a separate window, followed by a prompt to identify the input file (also in a separate window). Translation progress and error messages (e.g., allele names that could not be translated, or truncated allele names that were translated) will be displayed in the "Translation Log and Information" window. 

To translate a dataset that contains alleles written under a newer nomenclature to an older nomenclature using the GUI, select "Back (Reverse) Translate" from the "Settings" pulldown menu and then select "Translate Alleles" from the "Actions" pull-down. To return to standard translation, uncheck this option under "Settings". 

Log Settings:
To include all instances of allele issues (e.g., truncations, or untranslateable alleles) select "Verbose Logging" in the "Settings" pull-down menu. The default behavior is to report only the first instance of each allele issue.
To report the cell position (row and column) of each reported allele issue, select "Cell Reporting" in the "Settings" menu.
To report the sample identifier for a given allele issue, select the "Sample ID Reporting" option in the "Settings" menu. Sample IDs in the left-most 'id' column will be reported.
Unselect each settings option to return to the corresponding default ANTT behavior.

To use the ANTT from the command line, enter "ANTT" followed by up to four parameters separated by spaces (ANTT parameter0 parameter1 parameter2 parameter3).

	Parameter0 can include the following six options:
		"-h" will generate this help message.
		"-a" will generate an "About the ANTT" message.
		(The ANTT will quit after the -h or -a options are used.)
		"-b" will reverse translate from new to old nomenclature.
		"-v" activates 'Verbose Logging' of all allele issues.
		(Otherwise only one instance of each issue is logged)
		"-c" reports the Cell (row and column) of each logged issue.
		"-i" reports the IDs of each logged allele issue.
		(IDs are derived from the first (left-most) 'id' column.)
		-b, -v, -c, and -i can be combined (e.g., -bvc, -vi) as well.

	Parameter1 must be the name of the configuration (.ini) file. 	Parameter2 must be the name of the input-data file. 
	Parameter3 must provide a name for the file into which translated 	data will be written (the translated-data file).

All parameters are optional when the ANTT is started from the command line. Parameter1 and paremeter2 can be entered and parameter3 omitted, or parameter1 can be entered alone, and parameter2 and parameter3 omitted, or all three parameters can be omitted. If nothing is entered, the user will be prompted for parameter0 or parameter1.

If parameter1 is omitted or invalid, the user will be prompted for the name of a valid config.ini file. 

If parameter2 is omitted or invalid, the user will be prompted for the name of a valid input-data file. 

If parameter3 is omitted, the name of the translated-data file will be generated using the name of the input-data file, with "-translation" appended to the input-data file name (<input-data filename>-translation.txt). 

Translation progress, allele issues and error messages (e.g., allele names that could not be translated, or truncated allele names that were translated) will be displayed in the console window.

Allele translation will begin after valid configuration and data-input
filenames have been received. When the translation is completed, the ANTT generates two output files. Translated data are saved with the name <input file name>-translation.txt. These translation.txt files can be used as inputs for the ANTT. The ANTT also generates a log file named <input file name>-translation_log.txt, which includes all translation progress and error messages. 

Alternative Translation Tables
If your data consists of primarily full-length allele names (e.g., A*01010101), then most translations will proceed very rapidly using the translation tables in /translation_tables. However, if your data contains many truncated allele names (e.g., A*01, A*0101 or A*010101), the ANTT will take longer to complete the translation as it checks the validity of each truncated allele name. If you are certain about the validity of the truncated allele names in your dataset, you can translate your data using the translation tables in the /complete_truncation_translation_tables directory and the associated config_complete_translation.ini file. Using these translation tables, the translation of truncated allele names will not appear in the translation log file.

Similarly, if your data contains allele names that end in a lower-case g, signifying alleles that encode the same antigen recognition sequence (ARS) as described by Cano et al., Hum Immunol. 2007 68(5):392-417, and others, you can expand these groups to slash-delimited strings of full-length v2.* allele-names using the translation tables in the /ARS_translation_tables directory and the associated config_ARS.ini file.  These strings can then be translated to their v3.2.0 cognates using the translation tables in /translation_tables.

ANTT README v 2.0 December 10, 2010
